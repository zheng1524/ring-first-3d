from pathlib import Path
import json,hashlib,datetime,numpy as np,cv2,sys
R=Path(__file__).resolve().parents[1];PROJECT=R.parents[2];OLD=R.parent/'ring_first_v2_real_ba/runs/continuous16';DXY=Path('/home/liu/new-polyp-dxy')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def clean(x):
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,np.ndarray):return clean(x.tolist())
 if isinstance(x,(np.integer,np.bool_)):return x.item()
 if isinstance(x,(float,np.floating)):return float(x) if np.isfinite(x) else None
 return x
def save(p,x):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(clean(x),ensure_ascii=False,indent=2,allow_nan=False))
def config():return json.loads((R/'config.json').read_text())
def freeze(name,files):save('metrics/freeze_'+name+'.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={str(Path(p).resolve()):sha(p) for p in sorted(set(map(Path,files)))},GT_used=False,historical_measurement_fallback=0))
def stats(x):
 x=np.asarray(x,float);x=x[np.isfinite(x)];return dict(n=int(len(x)),median=float(np.median(x)) if len(x) else None,MAE=float(np.mean(abs(x))) if len(x) else None,p95=float(np.percentile(abs(x),95)) if len(x) else None,max=float(np.max(abs(x))) if len(x) else None)
def project(X,poses,ids,K):
 pc=np.einsum('ni,nij->nj',X-poses[ids,:3,3],poses[ids,:3,:3]);q=pc@K.T;return q[:,:2]/q[:,2:],pc[:,2]
def triangle(uvs,poses,K):
 A=[]
 for uv,pose in zip(uvs,poses):
  P=np.linalg.inv(pose)[:3];u=np.linalg.inv(K)@np.r_[uv,1.];A.extend([u[0]*P[2]-P[0],u[1]*P[2]-P[1]])
 _,_,V=np.linalg.svd(A);return V[-1,:3]/V[-1,3]
def angle(P,C1,C2):
 a=P-C1;b=P-C2;return np.degrees(np.arccos(np.clip(np.sum(a*b,axis=-1)/(np.linalg.norm(a,axis=-1)*np.linalg.norm(b,axis=-1)),-1,1)))
PREDICT_MODE=False
def config():
 return json.loads((R/('inputs/solver_config.json' if PREDICT_MODE else 'config.json')).read_text())
def prediction_guard(debug=False):
 global PREDICT_MODE
 PREDICT_MODE=True
 def hook(event,args):
  if event=='open' and isinstance(args[0],(str,bytes)):
   p=str(args[0])
   if 'private_gt' in p or (not debug and '/debug_inputs/' in p) or p==str(R/'config.json'):raise PermissionError('GT firewall: '+p)
 sys.addaudithook(hook)

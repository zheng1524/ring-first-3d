"""Supplemental normalized camera center error required by repository audit.
Not a new success criterion: primaryATE/point/holdout scores remain unchanged.
"""
from common import *
import csv
GT=np.load(R/'private_gt/scene.npz')['c2w'];den=np.linalg.norm(GT[:,:3,3],axis=1);rows=[]
for method in ['C0','C1','C2']:
 for rr in range(3):
  pp=np.load(R/f'private_gt/evaluated_{method}_{rr}.npz')['c2w'];e=np.linalg.norm(pp[:,:3,3]-GT[:,:3,3],axis=1)/den;rows.append(dict(method=method,repeat=rr,median_absolute_relative_center_error_percent=100*np.median(e),MAE_relative_percent=100*np.mean(e),p95_relative_percent=100*np.percentile(e,95),max_relative_percent=100*np.max(e)))
with (R/'metrics/relative_camera_position.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
freeze('relative_position_audit',[Path(__file__),R/'metrics/relative_camera_position.csv']);print('Relative position error supplemental audit saved')

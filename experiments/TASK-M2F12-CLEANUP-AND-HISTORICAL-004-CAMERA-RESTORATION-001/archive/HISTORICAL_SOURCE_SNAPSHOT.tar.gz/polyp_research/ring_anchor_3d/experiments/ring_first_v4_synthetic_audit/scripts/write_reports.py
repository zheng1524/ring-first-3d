from common import *
import csv
A=json.loads((R/'metrics/projection_gate.json').read_text());B=json.loads((R/'metrics/B_evaluation.json').read_text());BK=json.loads((R/'metrics/B_known_evaluation.json').read_text());C=json.loads((R/'metrics/C_evaluation.json').read_text());O=json.loads((R/'metrics/observation_audit_summary.json').read_text());P=json.loads((R/'metrics/point_diagnostics.json').read_text());E=json.loads((R/'metrics/boundary_role_exact.json').read_text());L=json.loads((R/'metrics/loss_activation_and_stability.json').read_text());G=json.loads((R/'private_gt/scene.json').read_text());TR=json.loads((R/'metrics/rgb_tracks.json').read_text())
AUDIT='''| 审计项目 | 必须汇报 |
| --- | --- |
| 目标组数 | 1个新增合成场景、16视角；原真实1组16帧只读观测审计，不计新三维重建样本 |
| 本算法独立成功 | A投影16/16通过；B未知相机16/16输出；C1/C2正式RGB各3/3次注册16/16；C0三次仅诊断不算正式算法成绩 |
| 本算法失败 | 数值无解0/1组；C2稳定点精度增益未获证实；RGB存在离群对应、长尾3D误差；真实BA未运行，真实位姿/点误差NaN |
| 历史测量值回退 | 0；不使用Dxy测量、旧相机/点云或DA2回填；本轮B/C预测来自本轮合成输入 |
| 失败组及具体原因 | 同一合成组RGB点误差及C2负面结果见[FAILURES.md](FAILURES.md)；全部初值保留 |
| 最终统计样本 | 全16帧B、3次C0诊断及6次正式C1/C2；正式独立留出787轨迹/4777观测，不以较好初值替代全体 |
| 是否使用 GT 选择算法 | 否；参数先冻结，GT仅用于用户指定A/已知相机B/C0诊断、预设关口及独立评价；不按GT切算法、选最佳初值或调权；阶段权限见GT_USAGE_AUDIT.json |
'''
def tbl(h,rows):return '| '+' | '.join(h)+' |\n| '+' | '.join(['---']*len(h))+' |\n'+'\n'.join('| '+' | '.join(map(str,x))+' |' for x in rows)+'\n'
ct=[]
for x in C['results']:
 ct.append([x['method'],x['repeat'],x['registered'],x['points'],f"{x['rotation_deg']['MAE']:.6f}",f"{x['ATE_RMSE_mm']:.6f}",f"{x['point_error_mm']['MAE']:.6f}",f"{x['heldout']['error_px']['MAE']:.6g}",f"{x['ring_whole_frame_holdout']['error_px']['MAE']:.6f}"])
target=[]
for x in P['per_repeat']:
 target.append([x['repeat'],f"{x['GT_cameras_RGB_correspondences_DLT_only']['reference8_visible_polyp']['MAE']:.6f}",f"{x['formal']['C1']['reference8_target_point_error_mm']['MAE']:.6f}",f"{x['formal']['C2']['reference8_target_point_error_mm']['MAE']:.6f}",x['formal']['C1']['reference8_target_count']])
ort=[]
for x in O['rows']:
 ort.append([x['scope'],x['visible_identity_pixels'],x['old_DXY_supported_kept'],x['DXY_supported_no_polyp_distance_delete'],x['specifically_polyp_distance_dropped'],f"{100*x['specifically_polyp_distance_dropped']/x['DXY_supported_no_polyp_distance_delete']:.2f}%",x['unknown_order_ring_polyp_boundary']])
obs='''# Ring二维观测审计

## 结论

旧三维适配器确实误删大量有原Ring Mask支持的可见环边缘候选，但并没有从历史文件中删除整个Ring Mask。错误发生在进入三维损失的观测筛选：只要靠息肉太近就删除边缘，且没有使用完整可见Ring身份区域。不能把这一发现写成“DXY的P/Q算法错误”：旧三维没有调用P/Q，它自行添加了类似保守排除的规则。

审计代码：`ring_first_v2_real_ba/runs/continuous16/scripts/dxy_adapter.py`，V3直接复用其缓存。旧规则为：DXY inner/outer候选需距原Ring边界≤1.5原图px、距填孔区域>2px，另外强制`distance_to_polyp > 2*3=6 native px`。后一项同时删掉Ring在前、环真实可见的Ring/Polyp自身轮廓。原DXY ring_points本身仍有对比度、切向等观测质量筛选；本轮不改这些核心实现。

## 量化审计

'''+tbl(['数据','完整Ring标签像素','旧保留边缘','无息肉距离删除的Mask支持边缘','仅因靠息肉删除','删除比例','未判前后顺序的原边界'],ort)+'''

真实16帧中7288→21987个Mask支持的DXY边缘候选，新增14699个、总数约3.02倍。旧缓存与本轮重新只读调用的DXY内/外缘数组逐项完全相同，旧保留总数也相同，见`metrics/real_reuse_crosscheck.json`。因此该差异确实来自三维额外排除规则，而非修改DXY算法。391983为既有INIT预测Ring标签像素，不是独立人工逐像素真值；合成78840像素来自准确实例标签。不同分辨率的边缘数/面积数不能混为同一个观测单位。

## 修正后的观测合同

1. 原始真实可见Ring身份Mask全部保存，Ring/Polyp相邻也不删除。身份信息只要求预测完整torus投影覆盖这些可见Ring点。
2. 原内/外缘、内外椭圆、Mid椭圆、分支、质量和填孔诊断来自DXY原API。Mid/拟合曲线都是推断，不等于物理三维中心线的精确投影；仅用于初值和检查。直接三维观测中推断曲线权重为0。
3. Ring/Polyp相邻边界全部保留，但前后顺序未知时只作为区域身份，不强制其贴torus表观轮廓。合成GT仅在A/evaluation中把真实自轮廓、遮挡切边和交汇不确定区分开。
4. 合成受控场景的背景为环后支撑面，可作为环区域的负样本；这一前后顺序假设不能直接迁移到真实前景组织。真实审计只输出候选观测，没有运行新的真实三维BA。
5. Mask是完整数据，优化用固定等距子采样：适配器最多保留1200正区域/1200背景样本；B和C2每次均取其中最多300+300点，另加轮廓候选。不是逐迭代对全部391983/78840像素计算损失。`visible_pixels_in_region_constraints`旧命名指可用完整Mask，不是每次损失样本数；此合同明确纠正该字段语义。

GT边界审计按相邻像素射线分类：两射线都打中完整Ring、其中一条被遮挡的是遮挡切边；完整Ring射线占用变化的是自身表观轮廓；两类交汇1.5px内标为不确定。16帧共有10829个明确自身轮廓边、1294个遮挡切边、353个交汇不确定边。遮挡切边距torus自身轮廓可达数像素，不能把全Mask边界直接拟合成torus轮廓。详见`metrics/boundary_role_exact.json`；最初A报告的近边界1px角色近似由这个更精确的审计补充，不改预测或A关口。

可检查图：[观测新旧对照及原DXY椭圆](visualizations/fig2_ring_observation_audit.png)、[精确边界角色与torus投影](visualizations/fig5_final_exact_roles.png)。源码与合同在`preparation/DXY_reuse.json`、`preparation/source_contract_audit.json`。

## 固定审计表

'''+AUDIT
(R/'RING_OBSERVATION_AUDIT.md').write_text(obs)
tech='''# Ring-First V4：完整Ring观测与合成几何正确性验证

## 四个问题的回答

**A：旧观测是否误删大量可见信息？** 是。旧三维适配器额外使用距息肉>6原图px的条件，使真实16帧中21987个原Mask支持的DXY环边缘候选丢掉14699个（66.85%）。原Ring Mask仍保存，丢失的是三维损失中的信息。修正保留全部Ring身份区域，边界按自身轮廓/遮挡切边/未知顺序分开；不是把全部新增边缘强塞到torus轮廓。不是DXY P/Q代码被改动或直接调用的结果。

**B：已知Blender几何下投影正确吗？** 在本轮已验证的开孔视角范围内正确。16/16通过预先冻结的A关口：最小完整Mask IoU=0.999137，最小遮挡后可见Mask IoU=0.998793，完整轮廓最差帧p95约0.450px，解析torus/Blender网格深度MAE≤0.000541mm。完整轮廓公式只适用于其合法视角；不能把这个结论推广到V3非法分支或无可见性处理的任意相机。

**C：能恢复相机与点吗？** 未知相机B可恢复可观测5DoF，中心MAE=0.011039mm，法向MAE=0.075203°。C0真对应诊断的相对几何达到数值精度；正式RGB方法也全部注册16帧，相机ATE约0.14—0.36mm、旋转MAE约0.21—0.29°。但RGB参考可见息肉点MAE仍约0.17—0.26mm，背景点有严重长尾，附加Ring联合项未稳定改善点精度。不能因相机能定位就称完整重建已可靠。

**D：合成与真实的差距？** 本轮有精确K、刚性标准torus、准确实例标签、固定三维非重复纹理、漫反射和无畸变成像；真实K/D适用性、实物环与标准torus的差异、分割/可见性、反光和低纹理匹配仍未分离。真实组只做只读观测审计，没有重跑真实BA，不宣称真实精度改善。

## 继承与实验边界

复用`01p型/01p-4-/息肉.blend`的原Ip对象“球体”，不是新造息肉；只做XYZ等比缩放及平移。复用`ring_pose_contact_v1`的Blender对象导出/BVH工具、`ring_depth_v4/synthetic/D_oblique`已有14帧轨迹并插值成16帧、旧完整torus轮廓、Ring-First V1四次方程ray-torus求交、旧Ring5DoF多初值、V3 E/PnP/DLT/BA、成熟OpenCV SIFT图。没有重造椭圆拟合。

DXY当前`dxy-mid-migration@991ea2017ef522decf76b4521b4ce7ea8d132121`，全部只读。实际调用小孔、existing_ring_check、ring_component及其原RANSAC、质量API；合成使用理想实例标签，真实使用冻结INIT缓存，不训练/重推INIT。原ring_component内部会生成未使用的rectifier/scale诊断，本轮不使用Mid尺度，不运行Dxy直径测量/Gate/Fusion。完整函数/文件SHA见preparation/DXY_reuse.json。

只生成一个合成场景。原真实视频`GP_Ip_12.0mm_closed_R10_single_refY_004.mp4`的固定16帧和raw674保持不变，只审计同帧缓存，文件名12mm不作真值。合成帧8与真实raw674不是同一相机或几何，仅沿用参考索引8；没有借真实视频的GT或预测生成本轮3D。

## 场景与GT隔离

640×360、f_x=f_y=490，整数像素主点(319.5,179.5)，Blender物理中心(320,180)，OpenCV c2w相机向右/向下/向前；坐标毫米。Ring为R10，R=5.6mm、r=0.6mm，世界环中心0、法向Z；圆形截面，非平面双圆。

原Ip等比缩放最大XY宽度9.8mm，在头部最大径向位置放置套头Ring。仅将息肉水平移动0.105810mm至首次外切，24步三角形重心坐标最小SDF＋二分搜索，最小解析间隙约0.000010mm。不是将Ring穿入头部。支撑面z=-5.628643mm，全部静止，只有相机运动。生成接触点、源模型SHA和完整场景保存在private_gt/scene.json与models/scene.blend；此SDF搜索是几何生成检查，属于数值验证而非形式化全网格布尔证明。

相机距Ring约35mm，已有轨迹的视角变化约20°方位、8°倾角，未按预测结果选择最佳角度。固定世界Position输入三维Voronoi Color，息肉1.7/mm、背景1.1/mm，材质roughness0.9、两盏固定广面光；纹理不会跟相机移动。特殊纹理用于几何验证，不宣称模拟真实内镜域。Cycles CPU16采样，Ring网格384×96，原Ip1908顶点/3812三角面。

- inputs/：RGB、0背景/1息肉/2Ring理想标签、K/已知Ring尺寸与无GT位姿的solver_config。
- private_gt/：真实c2w/w2c约定、完整模型、每像素轴向深度、Ring-alone深度/可见性、Polyp-alone深度、接触几何、评价产物。
- debug_inputs/：C0专用真实二维对应，以及已知相机B专用c2w；与正式输入物理分开。
- predictions/：本轮算法结果；C0/B_known文件名和报告明确诊断身份，C1/C2不读取它们。

正式B未知相机和C1/C2启用Python读文件审计钩子，拒绝private_gt、debug_inputs及生成用config；只读安全solver_config。钩子实测拒绝三种GT读取，见metrics/GT_USAGE_AUDIT.json。它是明确的程序读文件防误用机制，不是针对恶意代码的OS安全隔离。各阶段按用户要求读取A/B是否通过的布尔值，不读取其GT相机/深度/点进入求解。

重要元数据更正：复用的freeze helper固定写`GT_used=False`，这一模板不适用于A、已知相机B、C0或GT评价；已通过GT_USAGE_AUDIT.json逐阶段明确更正，保留原冻结文件，不能据该泛化布尔值声称诊断完全不用GT。正式B/C1/C2的源码和实际输入独立核验，GT不用于调权、切算法或从候选中选择答案。

## Ring观测修正

详见[RING_OBSERVATION_AUDIT.md](RING_OBSERVATION_AUDIT.md)。真实16帧DXY内/外缘与历史缓存逐项一致，排除来自三维适配器，原Mask391983个Ring标签像素没有丢弃。新Mask身份全部保留，B/C优化固定采样，不能把完整Mask像素数冒充每次实际计算的样本数。

合成GT还确认：10829个明确的Ring自身表观轮廓边中，5195个落在息肉6px邻域，约47.97%；它们不是遮挡切边，却会被该接近性规则排除。这直接验证了“可见Ring邻接息肉仍可有真实自身轮廓”，见metrics/synthetic_self_contour_proximity.json。

自身轮廓与区域不是同一个约束：可见Ring正区域应落入完整torus投影；Ring/Polyp交界若未知前后顺序，不强制其贴torus自身表观轮廓，也不使用隐藏补全曲线。仅在当前合成背景确为环后支撑面时，用背景负样本排除错误覆盖；这一假设不能不加验证地用于真实前景组织。

## 实验A：投影关口

完整透视表观轮廓复用旧`torus_contours`；按整数像素中心作多边形点包含，不使用错配的cv2像素中心填充。再复用四次方程求最近正射线根，计算完整Ring占用及轴向深度；按GT Polyp-alone深度比较前后，得到可见Ring与遮挡Ring。GT只用于本诊断。

与Blender完整网格BVH逐像素GT比较。所有16帧最小完整Mask IoU0.999137、最小可见Mask IoU0.998793，最大Ring深度MAE0.000540mm；误差是有限网格与边缘像素离散化量级。真实自身轮廓p95≤0.450px；不能把遮挡切边距完整torus的数像素距离当投影失败。

精确边界角色按相邻像素射线确定，共10829自身轮廓、1294遮挡切边、353交汇未知。1.5px交汇邻域保留不确定，不强行二分。最初A近边界1px角色近似保留，最终角色数据为metrics/boundary_role_exact.json。所有相机满足开孔必要条件，非法几何0/16。

A阈值在生成前固定：IoU≥0.99、边界p95≤1px、Ring深度MAE≤0.01mm。16/16通过后才执行B。没有凭好看的图跳过检查。

## 实验B：5DoF与已知相机诊断

复用旧decode/image_seeds/solve定义及稳健多初值实现，旧数据/旧GT全局变量不导入。已知R/r与K，待求相机坐标中的Ring中心和无符号法向；轴内旋转保留不可观测。DXY Mid椭圆只提供近似深度/倾角初始化，最终用完整torus投影评分；不把二维Mid等同于三维中心线投影。

每帧8个保留种子、最多120函数评估、轮廓每条512采样。损失含背景侧可观测轮廓距离、可见Ring区域单侧包含及受控后背景排除。每帧约180轮廓、最多300Ring区域、300背景样本；Polyp未知顺序区不作负样本。加入开孔合法性检查，不靠夹紧非法根号把分支当有效。

16帧未知相机B的中心误差（中位/MAE/p95/最大）=0.009379/0.011039/0.022292/0.027971mm；法向=0.067011/0.075203/0.152886/0.170982°。中心相对误差中位约0.0268%（分母为GT相机到Ring的距离约35mm），不是直径误差。相机圈内旋转不纳入5DoF评价。所有候选及残差保留，不根据GT挑选；机器记录的候选集合最优值仅为标记Oracle的诊断，不替代所选输出。

独立的已知相机B诊断共享一个未知Ring位姿，排除整帧3/12的Ring数据，中心误差0.002479mm、法向0.018433°；不将其当作未知相机成功结果。B未知相机的基本关口中心MAE<0.2mm、法向MAE<3°在运行前固定，实际通过，随后执行C。

## 实验C：真实对应诊断与严格RGB对照

C0读取Blender表面网格生成的真实跨帧二维对应，**不读取GT相机、深度或三维点初始化**，仅用于E/PnP/DLT/BA数学正确性诊断。C1/C2仅从本轮RGB提取SIFT，OpenCV3000特征、0.01对比阈值、12边缘阈值、双向Lowe0.8；相邻4帧连接及少量长连接，重复帧冲突不合并。特征类别区分息肉与背景、排除Ring膨胀及分类边界，全部固定。4027条至少3视图轨迹，其中息肉177条；保留787条独立留出（另19条近重复测试轨迹按V3同样2px/2视图规则剔除，不按误差挑点），4777个测试观测。C0独立留出460轨迹/5596观测，97条近重复测试被排除。

复用V3的参考8优先E与鲁棒DLT，20点/正深度/1°/2px初始化门限、PnP至少12内点，向所有16帧扩展。三次训练支持排名初值在读取GT评价前确定，不从最终误差中选择。全部9次C0/C1/C2运行都恢复16个数值相机和正深度训练点。

先做共同100步仅视觉BA，再由本轮B未知相机候选和可见区域求一个全局Sim3，固定Ring毫米规范；C1/C2使用同一初始相机、同一点ID和训练观测Mask。它们再各100步LBFGS，只有Ring项开关不同。C1已共享Ring尺度初始化，不得称其完全不依赖Ring。

`L_C1 = mean rho(||Pi(K,T,X)-u||) + 10 L_positive`

`L_C2 = L_C1 + (L_contour + L_visible_inclusion + L_rear_background_exclusion)/3`

`rho(e)=sqrt(1+e²)-1`，Ring总权重1、无GT调权。区域包含由投影闭合内外轮廓判断，只在违反单侧关系时处罚；三角化点不能复制Ring深度。整帧3/12的Ring数据同时从共享尺度拟合和C2优化留出；相机仍可由RGB定位。C1/C2同支持集逐项断言，测试轨迹不参与相机初始化/BA；评价两端点三角化、预测剩余观测，不剔除高误差或负深度测试。

### GT对齐规范与评价精度限制

主要指标仅允许一次全序列Ring对称群变换：一个全局环轴角及一个全局等价法向翻转，**不拟合平移/尺度到GT，不逐帧配准**。Ring固定中心和半径使公制误差保留。额外报告一次全序列Sim3的Oracle诊断以检查相对几何与尺度歧义，严格不用于预测。

C0三维点可与真实同ID网格点比较。RGB没有天然GT物理点ID，采用固定参考8像素（若不可见则首个观测）和Blender轴向深度双线性采样反投影，作为该观测的GT锚点；点被排除在边缘附近，仍有离散深度采样误差，不能把这一近似当无限精度真值或网格表面Chamfer。真实错误匹配会造成跨帧GT物理点不一致，单列诊断。

### 所有运行结果

'''+tbl(['方法','初值','注册帧','三角点','旋转MAE°','ATE RMSE mm','全场景点MAE mm','特征留出MAE px','整帧环留出MAE px'],ct)+'''

C0除整体Ring像素定标偏差外，相对几何正确：一次Oracle全局Sim3后相机ATE约1e-7mm、点MAE约1e-7—1e-6mm；正式共享Ring尺度下C0相机ATE约0.0104mm、点MAE约0.0251mm，不能把Oracle的数值精度当作正式算法公制精度。

C2相对C1仅2/3次ATE略降、1/3次特征留出MAE略降，3/3次整体点MAE微升，3/3次整帧Ring留出误差微升，未形成稳定几何收益。三次相机中心离跨初值均值平均0.1954→0.1886mm，有轻微稳定性变化但不足以支持强收益结论。

完整分布（中位/MAE/p95/最大）均在metrics/C_evaluation.json。补充相机中心中位绝对相对误差定义为median(||C_pred-C_GT||/||C_GT-O_ring||)，分母为GT相机到环距离，全部9次的中位、MAE、p95、最大百分比见metrics/relative_camera_position.csv；这是额外审计指标，不替代ATE，不用作新增成功门限，也不使用Dxy名义直径归一化。RGB测试误差中位约0.19—0.23px、p95约0.67—0.96px，但最大约519px，不能仅报中位或p95掩盖少数严重失败。所有相机/点/样本分母保持相同；未根据优化后残差裁支持集。

### 息肉可见点与误差归因

全场景点MAE约2—2.57mm由背景点和长尾主导，不等同于息肉表面误差。息肉全部三角点MAE约0.188—0.291mm。固定参考8可见的78个息肉点如下：

'''+tbl(['初值','GT相机+同RGB DLT诊断MAE mm','C1目标MAE mm','C2目标MAE mm','目标点数'],target)+'''

这个GT相机DLT只用于归因，不作为正式结果。GT相机将目标点MAE降至0.083—0.091mm，说明估计相机的小偏差与三角化条件会显著放大深度误差；同时GT相机下全场景仍有约0.37—0.40mm MAE和约47mm最坏点，说明匹配/定位漂移与弱三角化也存在。对应真实世界点轨迹最大漂移的中位约0.054mm、少数最大约46.6mm，不能把所有RGB匹配当同一物理点。

完整Ring区域约束确实激活：三次C1的可见Ring点违反率2.155%/0.433%/0.756%，C2变为1.870%/0.406%/0.739%；这改善了部分区域覆盖，却没有对应的稳定点精度提升。信息已部分进入共同Ring尺度初始化，不能把其后C2微小变化当“完整Ring没有价值”的证明，也不能把满足包含不等式当作息肉形态正确。

## 图像与资产检查

- [合成RGB/实例Mask/遮挡区域](visualizations/fig1_synthetic_observations.png)
- [旧新观测和原DXY内外缘/Mid](visualizations/fig2_ring_observation_audit.png)
- [Ring恢复与GT](visualizations/fig3_ring_pose_recovery.png)
- [GT和三种相机轨迹](visualizations/fig4_camera_trajectories.png)
- [最终fig5：精确边界角色及投影](visualizations/fig5_final_exact_roles.png)
- [三角点与GT锚点](visualizations/fig6_points_vs_GT.png)
- [全部初值联合对照](visualizations/fig7_joint_ablation.png)

最终fig5为2210×1870 RGBA、alpha全部255、1378235个彩色像素，实际Blender RGB区域和正确像素坐标可见；已程序检查并人工查看。初版近边界角色图保留，最终图使用精确角色并明确合成身份，不是假透明/空白PNG。指标见metrics/fig5_final_integrity.json及PNG_INTEGRITY.json。

private_gt/models/保存完整Blender场景和真实Ring/Polyp/Background模型。evaluation_exports/保存各方法点云与对应GT锚点（明确评价用变换），不是正式预测再拟合；predictions/保留原始算法坐标。没有生成闭合息肉网格、补隐藏面或体积。

## 真实迁移与停止决定

本轮不重跑真实16帧BA。理由是合成A/B和C0已证实基础几何正确，但新增Ring项尚未稳定改善RGB点精度，且当前后背景负样本假设不能直接用于真实可能在前方的组织。真实K/D与标准Ring模型也未完成独立确认；不能把合成里的接近像素精度直接外推。原真实raw674及V3轨迹全部冻结保留。

下一轮只建议：①在本轮同一数据中先改善/验证对应身份和三角化条件，量化小相机偏差如何放大深度误差，避免直接增加Ring权重；②设计一次仅使用安全Ring身份正区域、保留未知遮挡顺序的真实同初值轻量对照，独立检查K/实物Ring/Mask/跟踪四类差距，不重新标定或训练。

## 复现与保护

主环境`/home/liu/polyp_research/ring_anchor_3d/.venv/bin/python`，DXY只读API环境`.venv-release/bin/python`，Blender5.0.1既有CPU安装；无新包/新权重。安全复现须在同层全新空目录复制scripts后运行，setup会拒绝已有config；不要覆盖本轮或历史冻结目录。

```bash
PY=/home/liu/polyp_research/ring_anchor_3d/.venv/bin/python
DXY_PY=/home/liu/new-polyp-dxy/.venv-release/bin/python
$PY scripts/setup.py
$PY scripts/export_public_config.py
/home/liu/blender/blender-5.0.1-linux-x64/blender -b -t 8 --python scripts/generate_blender.py
$DXY_PY scripts/adapter.py
$PY scripts/projection_gate.py
$PY scripts/ring_recover.py
$PY scripts/evaluate_B.py
$PY scripts/export_known_cameras_debug.py
$PY scripts/B_known.py
$PY scripts/rgb_tracks.py
$PY scripts/validation_split.py
$PY scripts/make_region_ba.py
$PY scripts/solve_C.py --debug
$PY scripts/solve_C.py
$PY scripts/evaluate_C.py
$PY scripts/point_diagnostics.py
$PY scripts/boundary_role_audit.py
$PY scripts/self_contour_proximity.py
$PY scripts/relative_position_audit.py
$PY scripts/loss_activation.py
$PY scripts/visualize.py
$PY scripts/fig5_final.py
$PY scripts/source_contract_audit.py
$PY scripts/gt_usage_audit.py
$PY scripts/write_reports.py
```

公开solver_config与仅相机的debug导出均有独立脚本；首次运行是相同确定性操作，最终脚本已对现有文件逐项验证而不覆盖，数据字段与权限明确。阶段源码、输入、预测哈希在metrics/freeze_*.json，原路径与函数SHA见preparation/。所有算法权重、采样/初值预算在GT评价之前固定，没有按GT找最好角度或调参。

所有新增文件位于本独立目录。未改DXY参数/代码/测量、旧V1—V4或Ring-First实验；保留原14处用户未提交修改。未删除/移动/压缩旧资产，清理候选0；保护核验见metrics/protection_verification.json，交付清单见DELIVERY_MANIFEST.json。

## 固定审计表

'''+AUDIT
(R/'TECHNICAL_REPORT.md').write_text(tech)
fail='''# 失败与不确定性

## 本轮没有掩盖的负面结果

- 旧三维适配器把靠息肉的可见Ring边缘统一排除，真实组丢失66.85%原Mask支持的DXY候选，且未用完整身份区域。DXY本身未修改，也没有直接调用P/Q造成该删除。修正见RING_OBSERVATION_AUDIT。
- A、B数值关口均通过，但只覆盖当前开孔视角、标准刚性torus、理想实例Mask；其他非法视角不能靠acos夹紧当作已验证。
- C1/C2均注册16/16，不代表三角点可靠。C2三次整体点误差均微升、整帧Ring留出误差均微升；没有稳定独立收益，全部三初值保留，见metrics/C_summary.csv。
- RGB全场景点MAE约2—2.57mm，背景主导且有长尾；目标78点约0.17—0.26mm。GT相机诊断目标仍约0.083—0.091mm、最大RGB世界对应漂移约46.6mm，不能把纹理丰富等同于全匹配正确。独立特征测试最大约519px，未裁除。
- 同一相机/点集增加Ring覆盖约束可减少包含违反率，但没有自动降低真实点误差。不能仅根据区域/环投影漂亮宣布形态正确。
- C0的1e-7级相对几何是GT2D诊断；共享Ring毫米规范下仍有像素定标偏差。GT相机DLT和Oracle全序列Sim3均非正式预测，不替代RGB结果。
- 真实组只读观测审计，未运行修正后的真实BA；真实相机GT/形态误差为unknown/NaN，不从Dxy直径或本轮合成结果补齐。

## 可见性与元数据边界

Ring像素身份不等于边界是自身表观轮廓；新增Ring/Polyp交界保留为区域证据，前后顺序未知不强拟合。GT分类交汇处353个边标未知。当前背景负样本依赖合成后支撑面条件，不能将真实静态背景自动视为在Ring后方。

复用freeze helper的`GT_used=False`模板对A/C0/已知相机B/evaluation不准确；metrics/GT_USAGE_AUDIT.json明确各阶段实际GT权限并保留原文件。正式预测读文件钩子验证禁止private_gt/debug_inputs和生成config，但它不是OS安全隔离。适配器visible_pixels_in_region_constraints字段表示全可用Mask，实际优化是固定300+300区域子采样，不冒充逐像素全量损失。

最初A边界角色使用近边界1px代理，最终由相邻射线GT角色审计替代并保留交汇不确定性，原结果不覆盖。初版fig5保留，最终精确角色图单独输出并验证alpha/彩色像素/坐标，非空白PNG。

没有无解或异常日志被隐藏，本轮正式算法均完成数值运行；“无独立收益”和极端错误匹配也作为失败证据。没有为得到正结果追加场景、换模型、调权或启动网络。真实K/D、实物环形变、Mask误差、跟踪误差仍待分离，不武断判定某一项已经证明是主因。

清理候选0：旧结果有审计和对照价值，没有删除、移动或压缩。下一轮最多两项见技术报告，不进入3DGS。

## 固定审计表

'''+AUDIT
(R/'FAILURES.md').write_text(fail)
reuse='''# 技术复用记录

DXY源码只读，实际分支/提交见preparation/source_contract_audit.json：dxy-mid-migration@991ea2017ef522decf76b4521b4ce7ea8d132121。本轮真实调用ring_holes.run、existing_ring_check、ring_component.recover/ring_points/validate/fit、selection.evaluate，原内外缘RANSAC与Mid构造不改。完整函数SHA与文件SHA在preparation/DXY_reuse.json。INIT只读复用核验过的16帧缓存，合成使用理想实例Mask，没有网络推理或训练。

| 模块 | 输入输出/来源 | 使用范围与限制 |
| --- | --- | --- |
| segmentation.INITSegmentation | 原RGB→原0/1/2标签的历史冻结缓存 | 本轮仅真实审计缓存，逐帧SHA对manifest；不声称重新调用INIT |
| ring_holes.run | 标签→小孔处理、填孔诊断 | 调用原API；原真实Ring身份Mask仍完整保存 |
| ring_component / existing_ring_check | 原RGB、标签、R10规格→观测内外缘、内外椭圆、Mid及质量 | 原Fit不改；Mid及推断曲线仅初值/检查，非精确3D投影或直接观测 |
| 原RANSAC/quality | 原代码内部调用/图像质量 | 不改参数、P/Q、Gate/Fusion；未用Mid尺度或Dxy测量值 |
| geometry.py::torus_contours | Ring局部相机、K/R/r→完整圆形截面透视表观轮廓 | AST原函数，A验证开孔条件；不读旧场景数据 |
| ring_first_v1/common.py::torus_depth | 射线、相机、Ring变换→最近正四次方程根/轴向Z | AST原函数，用于A，未重写求交 |
| ring_pose_contact_v1/generate_blender.py | 原OBJ导出/BVH工具 | 新单一套头场景，原Ip网格与轨迹，不复用侧面相切样本 |
| ring_pose_contact_v1/recover.py | 原decoder/image_seeds/multi-start solve | AST复用，新三维适配层区域/轮廓损失，保留所有初值，不导入旧GT |
| V2 SIFT / V3 E/PnP/DLT/BA | RGB轨迹、相机/点优化 | 共享初值/点集/预算，C1/C2只切Ring项。GT2D只在独立C0 |

新增内容仅为完整Ring身份观测适配、区域包含/排除损失、GT防误用与评价/可视化；没有另写一套椭圆拟合。原ring_component内部rectifier/scale诊断保留但不参与三维预测。P/Q隐藏补全不作Ring真值或接触点。

所有源码最终哈希和阶段冻结在metrics/；本轮只从新合成RGB/实例标签、K、已知Ring尺寸生成正式B/C预测，旧测量/点云/DA2不回填。GT使用模板更正见metrics/GT_USAGE_AUDIT.json。

## 固定审计表

'''+AUDIT
(R/'TECHNOLOGY_REUSE.md').write_text(reuse)
human='''旧规则误删约67%环边缘。合成投影和环位姿通过；RGB可定位，环联合无稳定点精度收益。应查匹配、视差与成像差异。

|审计项目|必须汇报|
|---|---|
|目标组数|1|
|本算法独立成功|数值1|
|本算法失败|增益未证实|
|历史测量值回退|0|
|失败组及具体原因|[点误差](FAILURES.md)|
|最终统计样本|全16帧/9次|
|是否使用 GT 选择算法|否；诊断另标|
'''
assert len(human)<=200,len(human)
(R/'HUMAN_REPORT.md').write_text(human)
# Flat scalar tables, full distributions remain in JSON.
for name,rows in [('B_frames',B['per_frame']),('projection_frames',[dict(frame=x['frame'],full_iou=x['full_mask_iou'],visible_iou=x['visible_ring_iou'],ray_full_iou=x['ray_torus_full_iou'],boundary_p95_px=x['full_apparent_boundary']['p95'],depth_MAE_mm=x['visible_depth_error_mm']['MAE']) for x in A['per_frame']])]:
 with (R/f'metrics/{name}.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
freeze('reports',[R/n for n in ['TECHNICAL_REPORT.md','RING_OBSERVATION_AUDIT.md','TECHNOLOGY_REUSE.md','HUMAN_REPORT.md','FAILURES.md']]+[Path(__file__),R/'metrics/B_frames.csv',R/'metrics/projection_frames.csv']);print('Reports written human chars',len(human),'technical',len(tech))

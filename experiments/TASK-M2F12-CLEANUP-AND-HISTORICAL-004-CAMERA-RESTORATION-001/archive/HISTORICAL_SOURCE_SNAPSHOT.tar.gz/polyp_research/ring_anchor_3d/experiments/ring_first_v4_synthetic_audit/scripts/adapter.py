"""Existing DXY APIs remain unmodified; all real visible Ring identity preserved.
No new ellipse fitter. No GT geometry is read by this adapter.
"""
from common import *
import inspect
sys.path.insert(0,str(DXY/'src'))
from dxy_mid._engine.ring_holes import run as holes
from dxy_mid._engine.components import FrameInput
from dxy_mid._engine.v81_components import existing_ring_check
from dxy_mid._engine import ring_component
from dxy_mid.selection import evaluate as quality

def edges(mask):
 y,x=np.nonzero(mask[:,:-1]!=mask[:,1:]);a=np.c_[x+.5,y]
 y,x=np.nonzero(mask[:-1]!=mask[1:]);return np.r_[a,np.c_[x,y+.5]]
def adapt(image,labels,source):
 effective,filled,info=holes(labels);frame=FrameInput(image,effective,10.,source,hashlib.sha256(image.tobytes()).hexdigest(),hashlib.sha256(labels.tobytes()).hexdigest());result,attempts=existing_ring_check(frame,None);geom=result.geometry;e=result.evidence
 m=labels==2;p=labels==1;inner=np.asarray(e.get('inner_points',np.empty((0,2))),float);outer=np.asarray(e.get('outer_points',np.empty((0,2))),float);points=np.r_[inner,outer]
 adj=cv2.dilate(m.astype(np.uint8),np.ones((3,3),np.uint8))!=cv2.erode(m.astype(np.uint8),np.ones((3,3),np.uint8));dt=cv2.distanceTransform((~adj).astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);dpoly=cv2.distanceTransform((~p).astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);dfill=cv2.distanceTransform((~filled).astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE) if filled.any() else np.full(m.shape,1e6)
 q=np.rint(points).astype(int);q[:,0]=np.clip(q[:,0],0,m.shape[1]-1);q[:,1]=np.clip(q[:,1],0,m.shape[0]-1);base=(dt[q[:,1],q[:,0]]<=1.5)&(dfill[q[:,1],q[:,0]]>2);old=base&(dpoly[q[:,1],q[:,0]]>6)
 edge=edges(m);xy=np.floor(edge+.5).astype(int);xy[:,0]=np.clip(xy[:,0],0,m.shape[1]-1);xy[:,1]=np.clip(xy[:,1],0,m.shape[0]-1);near=cv2.dilate(p.astype(np.uint8),np.ones((5,5),np.uint8))>0;ambiguous=near[xy[:,1],xy[:,0]]
 # Region-only interpretation for Polyp-adjacent borders: no GT order inferred.
 outline=edge[~ambiguous];visible=np.column_stack(np.nonzero(m)[::-1]).astype(float);bg=(labels==0)&(cv2.dilate(m.astype(np.uint8),np.ones((17,17),np.uint8))>0);negative=np.column_stack(np.nonzero(bg)[::-1]).astype(float)
 def sample(a,n):return a[np.linspace(0,len(a)-1,min(n,len(a)),dtype=int)] if len(a) else a
 out=dict(ring_mask=m,polyp_mask=p,background_mask=labels==0,visible_region=sample(visible,1200),background_region=sample(negative,1200),raw_boundary=edge,ambiguous_boundary=edge[ambiguous],ring_train=sample(outline,320)[np.arange(min(len(outline),320))%5!=0],ring_heldout=sample(outline,320)[np.arange(min(len(outline),320))%5==0],inner=inner,outer=outer,old_accepted=points[old],new_supported_DXY_edges=points[base])
 status=dict(source=source,DXY_valid=bool(result.valid),DXY_reason=result.reason,geometry=geom,attempts=attempts,quality=quality(image,labels),hole_info=info,raw_visible_ring_pixels=int(m.sum()),visible_pixels_in_region_constraints=int(m.sum()),DXY_candidate_edges=len(points),old_kept_edges=int(old.sum()) if result.valid else 0,new_raw_supported_DXY_edges=int(base.sum()),old_near_polyp_dropped=int((base&~old).sum()),all_raw_boundary=len(edge),order_unknown_boundary=len(edge[ambiguous]),background_facing_contour_candidates=len(outline),inferred_ellipse_points_in_observation_loss=0,occlusion_policy='all real Ring pixels positive; Polyp unknown-order, not negative; adjacent boundary not forced to apparent contour; background negative assumes controlled rear support, not safe for arbitrary foreground tissue')
 return out,status

def main():
 prediction_guard();freeze('adapter_protocol',[Path(__file__),R/'scripts/common.py',R/'inputs/solver_config.json']);records=[];real=[]
 for i in range(16):
  im=cv2.imread(str(R/f'inputs/rgb/{i:03d}.png'));lab=cv2.imread(str(R/f'inputs/labels/{i:03d}.png'),0);ob,status=adapt(im,lab,f'synthetic-{i}');np.savez_compressed(R/f'observations/{i:03d}.npz',**ob);records.append(status);print('SYNTHETIC_RING',i,status['DXY_valid'],status['raw_visible_ring_pixels'],status['old_kept_edges'],status['old_near_polyp_dropped'],flush=True)
 # Read-only audit same16 real RGB/INIT masks. No real 3D optimization.
 for i in range(16):
  im=cv2.imread(str(OLD/f'inputs/images/{i:03d}.jpg'));lab=cv2.imread(str(OLD/f'inputs/masks/{i:03d}.png'),0);ob,status=adapt(im,lab,f'real-{i}');np.savez_compressed(R/f'observations/real_{i:03d}.npz',**ob);real.append(status)
 save('metrics/ring_observation_synthetic.json',records);save('metrics/ring_observation_real_audit.json',real)
 funcs=[holes,existing_ring_check,ring_component.recover,ring_component.ring_points,ring_component.validate,ring_component.fit,quality]
 save('preparation/DXY_reuse.json',dict(functions=[dict(name=f.__module__+'.'+f.__name__,path=inspect.getsourcefile(f),file_sha=sha(inspect.getsourcefile(f)),function_sha=hashlib.sha256(inspect.getsource(f).encode()).hexdigest()) for f in funcs],no_Dxy_measurement_call=True,no_Mid_scale_used=True,ring_recover_internal_unused_scale_diagnostic=True,all_ring_identity_preserved_even_when_DXY_quality_fails=True))
 freeze('observations',list((R/'observations').glob('*.npz'))+[R/'metrics/ring_observation_synthetic.json',R/'metrics/ring_observation_real_audit.json',R/'preparation/DXY_reuse.json']);print('ADAPTER_COMPLETE')
if __name__=='__main__':main()

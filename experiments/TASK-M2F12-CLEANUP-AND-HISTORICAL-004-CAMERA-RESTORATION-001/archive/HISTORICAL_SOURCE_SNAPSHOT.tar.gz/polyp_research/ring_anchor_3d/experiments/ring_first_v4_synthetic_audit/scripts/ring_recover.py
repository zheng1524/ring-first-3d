"""B unknown-camera torus5DoF. Only image labels, original DXY fitting/K/size.
Unchanged old decoder/seeding/multi-start implementation; new censored-region loss.
"""
from common import *
from geometry_tools import *
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from scipy.optimize import least_squares
import ast
source=PROJECT/'ring_anchor_3d/experiments/ring_pose_contact_v1/scripts/recover.py';ns=dict(np=np,cv2=cv2,Rotation=Rotation,least_squares=least_squares,cKDTree=cKDTree,n=512,rad=5.6,tube=.6)
for node in ast.parse(source.read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name in ['decode','image_seeds','solve']:exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
def observations():
 out=[]
 for i in range(16):
  ob=np.load(R/f'observations/{i:03d}.npz');im=cv2.imread(str(R/f'inputs/rgb/{i:03d}.png'));q=ob['ring_train'];q=q[np.linspace(0,len(q)-1,min(180,len(q)),dtype=int)];p=ob['visible_region'][::4];b=ob['background_region'][::4];out.append(dict(frame=i,q=q,mask=ob['ring_mask'],polyp=ob['polyp_mask'],positive=p,negative=b))
 return out

def configure(cameras,K):
 cfg=dict(seed_depth_factors=[.85,1.,1.2],seed_inclinations_deg=[0,35,60],seed_azimuths_deg=[0,90,180,270],seed_retain=config()['ring_seed_retain'],max_nfev=config()['ring_max_nfev'],huber_px=1.,numerical_success_max_training_px=3.)
 ns.update(cfg=cfg,K=K)
 def proj(center,Q,i):
  C=Q.T@(cameras[i,:3,3]-center);rot=Q.T@cameras[i,:3,:3]
  if np.linalg.norm(C)<6.2 or abs(C[2])/np.linalg.norm(C)<=.6/5.6+.001:raise ValueError('invalid open-hole torus view')
  curve=contours(C,rot,K,n=512);return curve
 def residual(a,ref,obs):
  center,Q=ns['decode'](a,ref);parts=[]
  for ob in obs:
   q,p,b=ob['q'],ob['positive'],ob['negative'];size=len(q)+len(p)+len(b)
   try:
    cr=proj(center,Q,ob['frame']);tree=cKDTree(cr.reshape(-1,2));dq=tree.query(q)[0];dp=tree.query(p)[0]*(~inside(cr,p));db=tree.query(b)[0]*inside(cr,b);parts.extend([dq,dp*np.sqrt(len(q)/max(len(p),1)),db*np.sqrt(len(q)/max(len(b),1))])
   except ValueError:parts.append(np.full(size,1000.))
  return np.concatenate(parts)
 ns['residual']=residual;return proj

def mid_seeds(geometry,ob):
 seeds=ns['image_seeds'](ob)
 e=geometry.get('centerline')
 if e:
  K=ns['K'];z=5.6*K[0,0]/e['major_radius'];xy=(np.array([e['cx'],e['cy']])-K[:2,2])/np.diag(K)[:2];inc=np.arccos(np.clip(e['minor_radius']/e['major_radius'],0,1));ang=np.deg2rad(e['angle_deg'])
  for sign in [-1,1]:seeds.append(np.r_[xy,np.log(z),sign*inc*np.cos(ang),sign*inc*np.sin(ang)])
 return seeds

def main():
 prediction_guard();assert json.loads((R/'metrics/projection_gate.json').read_text())['passed'],'A gate failed; B prohibited';K=np.array(config()['K']);obs=observations();configure(np.tile(np.eye(4),(16,1,1)),K);status=json.loads((R/'metrics/ring_observation_synthetic.json').read_text());out=[]
 freeze('B_protocol',[Path(__file__),R/'scripts/geometry_tools.py',R/'scripts/common.py',R/'inputs/solver_config.json',source]+list((R/'observations').glob('[0-9]*.npz')))
 for i,ob in enumerate(obs):
  if len(ob['q'])<25:
   out.append(dict(frame=i,numerical_success=False,reason='insufficient unoccluded outline evidence',center=None,normal=None));continue
  result=ns['solve']([ob],np.eye(4),mid_seeds(status[i]['geometry'],ob));result.update(frame=i,normal_spin_unobservable=True,GT_inputs=False);out.append(result);save('predictions/B_unknown.json',out);print('B',i,result['loss'],result['center'],result['normal'],len(result['ambiguity_alternatives']),flush=True)
 freeze('B_predictions',[R/'predictions/B_unknown.json',Path(__file__)]);print('B_UNKNOWN_COMPLETE')
if __name__=='__main__':main()

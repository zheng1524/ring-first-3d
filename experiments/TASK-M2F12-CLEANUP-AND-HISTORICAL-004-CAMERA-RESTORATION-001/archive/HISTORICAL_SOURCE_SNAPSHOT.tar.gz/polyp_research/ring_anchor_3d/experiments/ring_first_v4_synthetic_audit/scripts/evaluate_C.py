"""GT used only after allC predictions frozen. Single global ring symmetry gauge;
separate optional one-global-Sim3 Oracle diagnostic, never per-frame alignment.
"""
from common import *
from geometry_tools import *
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
import ast,csv
old=PROJECT/'ring_anchor_3d/experiments/ring_first_v3_static_ba/scripts/evaluate.py';ns=globals()
node=next(x for x in ast.parse(old.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='holdout');exec(compile(ast.Module(body=[node],type_ignores=[]),str(old),'exec'),ns)
def gt_point(track,cat,data):
 fr=np.flatnonzero(np.isfinite(track[:,0]));i=8 if 8 in fr else int(fr[0]);uv=track[i];g=np.load(R/f'private_gt/{i:03d}.npz');z=float(cv2.getRectSubPix(g['depth'].astype(np.float32),(1,1),tuple(map(float,uv)))[0,0]);P=(np.linalg.inv(data['K'])@np.r_[uv,1.])*z;return data['c2w'][i,:3,:3]@P+data['c2w'][i,:3,3]
def ring_symmetry(P,GT):
 best=None
 for H in [np.eye(3),np.diag([1.,-1,-1])]:
  S=sum(GT[i,:3,:3]@(H@P[i,:3,:3]).T for i in range(16));a=np.arctan2(S[1,0]-S[0,1],S[0,0]+S[1,1]);U=Rotation.from_rotvec([0,0,a]).as_matrix()@H;err=[np.linalg.norm(Rotation.from_matrix(GT[i,:3,:3].T@U@P[i,:3,:3]).as_rotvec()) for i in range(16)];score=np.mean(err)
  if best is None or score<best[0]:best=(score,U)
 return best[1]
def one_sim3(P,GT):
 S=sum(GT[i,:3,:3]@P[i,:3,:3].T for i in range(16));u,_,v=np.linalg.svd(S);U=u@np.diag([1,1,np.linalg.det(u@v)])@v;x=P[:,:3,3]@U.T;y=GT[:,:3,3];mx,my=x.mean(0),y.mean(0);s=float(np.sum((x-mx)*(y-my))/np.sum((x-mx)**2));return U,s,my-s*mx

def main():
 for label in ['C_predictions_C0','C_predictions_RGB']:
  m=json.loads((R/f'metrics/freeze_{label}.json').read_text());assert all(sha(Path(p))==h for p,h in m['files'].items())
 save('metrics/GT_evaluation_start.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),predictions_hashes_verified_before_GT=True,no_prediction_modification=True));data=np.load(R/'private_gt/scene.npz');GT=data['c2w'];packs={'C0':np.load(R/'debug_inputs/C0_correspondences.npz'),'RGB':np.load(R/'observations/rgb_tracks.npz')};splits={k:np.load(R/f'observations/validation_split_{k}.npz') for k in packs};trueC0=np.load(R/'private_gt/C0_worldpoints.npz')['points'];results=[];rows=[]
 for method in ['C0','C1','C2']:
  scope='C0' if method=='C0' else 'RGB';pack=packs[scope];xy=pack['xy'];cat=pack['category'];held=np.flatnonzero(~pack['train_track']&splits[scope]['holdout_eligible'])
  for rr in range(3):
   path=R/f'predictions/{method}_{rr}.npz'
   if not path.exists():results.append(dict(method=method,repeat=rr,success=False,reason='initializer failed; missing predictions retained as failure',pose_error_mm=None));continue
   p=np.load(path);P=p['c2w'];X=p['points'];ids=p['point_ids'];K=p['K'];U=ring_symmetry(P,GT);W=P.copy();W[:,:3,:3]=U@P[:,:3,:3];W[:,:3,3]=P[:,:3,3]@U.T;XX=X@U.T;center=np.linalg.norm(W[:,:3,3]-GT[:,:3,3],axis=1);rot=np.array([np.degrees(np.linalg.norm(Rotation.from_matrix(GT[i,:3,:3].T@W[i,:3,:3]).as_rotvec())) for i in range(16)]);relative=[]
   for i in range(15):
    a=P[i,:3,:3].T@P[i+1,:3,:3];b=GT[i,:3,:3].T@GT[i+1,:3,:3];relative.append(np.degrees(np.linalg.norm(Rotation.from_matrix(a.T@b).as_rotvec())))
   truth=trueC0[ids] if method=='C0' else np.array([gt_point(xy[j],cat[j],data) for j in ids]);pe=np.linalg.norm(XX-truth,axis=1);test=holdout(P,K,xy,held,cat);ringerr=[];ringframes=[];recall=[];bgfalse=[]
   for i in config()['ring_frame_holdout']:
    ob=np.load(R/f'observations/{i:03d}.npz');cr=contours(P[i,:3,3],P[i,:3,:3],K,n=2048);e=cKDTree(cr.reshape(-1,2)).query(np.r_[ob['ring_train'],ob['ring_heldout']])[0];ringerr.extend(e);ringframes.append(dict(frame=i,error_px=stats(e)));recall.append(float(inside(cr,ob['visible_region']).mean()));bgfalse.append(float(inside(cr,ob['background_region']).mean()))
   oU,os,ot=one_sim3(P,GT);oracleCenter=np.linalg.norm(os*(P[:,:3,3]@oU.T)+ot-GT[:,:3,3],axis=1);oraclePoints=np.linalg.norm(os*(X@oU.T)+ot-truth,axis=1)
   trerr=[];positive=[];pa=[]
   for n,(xx,j) in enumerate(zip(X,ids)):
    fr=np.flatnonzero(p['observation_mask'][n]);uv,z=project(np.tile(xx,(len(fr),1)),P,fr,K);trerr.extend(np.linalg.norm(uv-xy[j,fr],axis=1));positive.extend(z>0);a,b=fr[0],fr[-1];pa.append(float(angle(xx,P[a,:3,3],P[b,:3,3])))
   steps=[float(np.degrees(np.linalg.norm(Rotation.from_matrix(P[i,:3,:3].T@P[i+1,:3,:3]).as_rotvec()))) for i in range(15)];item=dict(method=method,repeat=rr,registered=16,reference8=True,points=len(X),polyp_points=int((cat[ids]==1).sum()),background_points=int((cat[ids]==0).sum()),rotation_deg=stats(rot),relative_rotation_deg=stats(relative),center_error_mm=stats(center),ATE_RMSE_mm=float(np.sqrt(np.mean(center**2))),point_error_mm=stats(pe),polyp_point_error_mm=stats(pe[cat[ids]==1]),background_point_error_mm=stats(pe[cat[ids]==0]),training_reprojection_px=stats(trerr),positive_fraction=float(np.mean(positive)),anchor_parallax_deg=stats(pa),heldout=test,ring_whole_frame_holdout=dict(error_px=stats(ringerr),frames=ringframes,visible_ring_recall=float(np.mean(recall)),known_rear_background_false_fraction=float(np.mean(bgfalse))),symmetry_rotation=U.tolist(),Oracle_one_global_Sim3=dict(scale=os,center_error_mm=stats(oracleCenter),ATE_RMSE_mm=float(np.sqrt(np.mean(oracleCenter**2))),point_error_mm=stats(oraclePoints),warning='diagnostic GTscale/rotation/translation; not formal prediction, no perframe alignment'),max_step_rotation_deg=max(steps),debug_only=method=='C0',success=True)
   results.append(item);np.savez_compressed(R/f'private_gt/evaluated_{method}_{rr}.npz',c2w=W,points=XX,GT_points=truth,point_ids=ids,point_errors=pe,classes=cat[ids],symmetry_rotation=U,not_prediction=True);row=dict(method=method,repeat=rr,registered=16,points=len(X),rotation_MAE_deg=item['rotation_deg']['MAE'],relative_rotation_MAE_deg=item['relative_rotation_deg']['MAE'],ATE_RMSE_mm=item['ATE_RMSE_mm'],center_MAE_mm=item['center_error_mm']['MAE'],point_MAE_mm=item['point_error_mm']['MAE'],point_p95_mm=item['point_error_mm']['p95'],heldout_MAE_px=test['error_px']['MAE'],heldout_p95_px=test['error_px']['p95'],ring_heldout_MAE_px=item['ring_whole_frame_holdout']['error_px']['MAE'],Oracle_Sim3_ATE_mm=item['Oracle_one_global_Sim3']['ATE_RMSE_mm'],Oracle_scale=os,positive_fraction=item['positive_fraction']);rows.append(row);print(row,flush=True)
 # Same C1/C2 support assertions before paired report.
 for rr in range(3):
  a=np.load(R/f'predictions/C1_{rr}.npz');b=np.load(R/f'predictions/C2_{rr}.npz');assert np.array_equal(a['point_ids'],b['point_ids']) and np.array_equal(a['observation_mask'],b['observation_mask'])
 save('metrics/C_evaluation.json',dict(results=results,GT_used_for_evaluation_only=True,same_C1_C2_support=True,alignment='one global torus symmetry rotation only, no scale/translation for primary metrics',RGB_point_GT_reference='known Blender GTdepth bilinear at fixed reference8 observation, else first observed pixel; smooth interior points; no GTused forprediction',C0_GT2D_debug_only=True))
 with (R/'metrics/C_summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 known=json.loads((R/'predictions/B_known.json').read_text());c=np.array(known['center']);n=np.array(known['normal']);save('metrics/B_known_evaluation.json',dict(center_mm=float(np.linalg.norm(c)),normal_deg=float(np.degrees(np.arccos(np.clip(abs(n[2]),0,1)))),known_cameras_debug_only=True))
 freeze('C_evaluation',[Path(__file__),R/'metrics/C_evaluation.json',R/'metrics/C_summary.csv',R/'metrics/B_known_evaluation.json']);print('C_EVALUATION_COMPLETE')
if __name__=='__main__':main()

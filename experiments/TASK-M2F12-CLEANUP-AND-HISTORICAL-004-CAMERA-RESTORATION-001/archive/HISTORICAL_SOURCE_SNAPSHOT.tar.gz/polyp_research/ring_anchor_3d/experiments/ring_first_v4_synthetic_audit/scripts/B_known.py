"""Authorized known-camera diagnostic B; no true ring center/normal read."""
from common import *
from ring_recover import *
def main():
 prediction_guard(debug=True);d=np.load(R/'debug_inputs/known_cameras.npz');cams=d['c2w'];K=d['K'];obs=observations();configure(cams,K);pred=json.loads((R/'predictions/B_unknown.json').read_text());ref=cams[8];train=[o for o in obs if o['frame'] not in config()['ring_frame_holdout']];seeds=ns['image_seeds'](obs[8])
 for i,p in enumerate(pred):
  for x in [p]+p['alternatives'][:1]:
   center=cams[i,:3,3]+cams[i,:3,:3]@np.array(x['center']);normal=ref[:3,:3].T@cams[i,:3,:3]@np.array(x['normal']);pc=ref[:3,:3].T@(center-ref[:3,3]);normal=normal if normal[2]>=0 else -normal;v=np.cross([0,0,1.],normal);ang=np.arccos(np.clip(normal[2],-1,1));w=v*ang/max(np.linalg.norm(v),1e-9);seeds.append(np.r_[pc[:2]/pc[2],np.log(pc[2]),w[:2]])
 freeze('B_known_protocol',[Path(__file__),R/'debug_inputs/known_cameras.npz',R/'predictions/B_unknown.json']);out=ns['solve'](train,ref,seeds);save('predictions/B_known.json',out);freeze('B_known_predictions',[Path(__file__),R/'predictions/B_known.json']);print('B_KNOWN_COMPLETE',out['loss'],out['center'],out['normal'])
if __name__=='__main__':main()

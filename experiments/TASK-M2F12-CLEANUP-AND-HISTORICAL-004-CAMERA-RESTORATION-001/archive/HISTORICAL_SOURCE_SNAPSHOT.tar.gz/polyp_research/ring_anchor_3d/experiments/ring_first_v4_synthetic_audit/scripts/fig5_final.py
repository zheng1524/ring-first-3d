from common import *
from geometry_tools import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=np.load(R/'private_gt/scene.npz');B=json.loads((R/'predictions/B_unknown.json').read_text());BE=json.loads((R/'metrics/B_evaluation.json').read_text())['per_frame'];fig,axes=plt.subplots(4,3,figsize=(13,11),layout='constrained')
for row,i in enumerate([0,5,8,15]):
 im=cv2.imread(str(R/f'inputs/rgb/{i:03d}.png'))[:,:,::-1];pr=np.load(R/f'private_gt/projection_{i:03d}.npz');roles=np.load(R/f'private_gt/boundary_roles_{i:03d}.npz');lab=cv2.imread(str(R/f'inputs/labels/{i:03d}.png'),0)
 for ax in axes[row]:ax.imshow(im);ax.set_xlim(210,430);ax.set_ylim(280,75);ax.axis('off')
 ax=axes[row,0]
 for cr in pr['curves']:ax.plot(*cr.T,c='orange',ls='--',lw=.9)
 q=edges(lab==2);ax.scatter(*q.T,c='cyan',s=1);ax.set_title(f'Frame{i}: analytic GT-pose full torus vs visible Ring cyan',fontsize=8)
 ax=axes[row,1]
 for name,c,label in [('self_contour','lime','actual own contour'),('occlusion_cut','magenta','occlusion cut'),('junction_unknown','gray','junction unknown')]:
  q=roles[name];ax.scatter(*q.T,c=c,s=3,label=label)
 ax.legend(fontsize=5,loc='upper right');ax.set_title('GT pixel-ray boundary roles; no cut forced to silhouette',fontsize=8)
 ax=axes[row,2];Q=np.array(B[i]['Q']);t=np.array(B[i]['center']);cr=contours(-Q.T@t,Q.T,D['K'],n=1024)
 for q in cr:ax.plot(*q.T,c='yellow',lw=.9)
 ax.set_title(f"B unknown pose: center {BE[i]['center_error_mm']:.3f}mm; normal {BE[i]['normal_error_deg']:.3f}deg",fontsize=8)
fig.suptitle('SYNTHETIC Blender RGB. Dashed/full hidden curves are model projections, not visible observations.');out=R/'visualizations/fig5_final_exact_roles.png';fig.savefig(out,dpi=170,facecolor='white',transparent=False);plt.close(fig);im=cv2.imread(str(out),cv2.IMREAD_UNCHANGED);assert im.shape[2]==4 and (im[:,:,3]==255).all();colors=int((np.ptp(im[:,:,:3].astype(int),axis=2)>20).sum());assert colors>10000;save('metrics/fig5_final_integrity.json',dict(path=str(out.relative_to(R)),shape=list(im.shape),all_alpha255=True,colored_pixels=colors,actual_RGB_tiles=True,correct_image_coordinates=[210,430,280,75],pass_check=True));freeze('fig5_final',[Path(__file__),out,R/'metrics/fig5_final_integrity.json']);print('Final fig5 nonblank opaque RGB verified')

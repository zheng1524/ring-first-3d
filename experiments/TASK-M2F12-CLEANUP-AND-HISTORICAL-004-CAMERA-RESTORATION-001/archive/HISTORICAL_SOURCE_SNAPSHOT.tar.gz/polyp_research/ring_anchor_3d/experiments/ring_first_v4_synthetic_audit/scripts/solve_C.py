"""C0 debugGT2D and C1/C2 RGB; formal predictor GT-read firewall enabled.
No GT cameras, depths or3D points. Same C1/C2 initialized arrays and observed3D points.
"""
from common import *
from geometry_tools import *
from shared_ba_region import optimize
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
from itertools import combinations
import ast,argparse
# Reuse exactly V3 E/PnP support and DLT triangulation functions (no old data).
ns=globals();old=PROJECT/'ring_anchor_3d/experiments/ring_first_v3_static_ba/scripts/visual_initialize.py'
for node in ast.parse(old.read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name in ['pair_initial','triangulate']:exec(compile(ast.Module(body=[node],type_ignores=[]),str(old),'exec'),ns)

def transform(P,X,U,s,t):
 out=P.copy();ok=np.isfinite(P[:,0,0]);out[ok,:3,:3]=U@P[ok,:3,:3];out[ok,:3,3]=s*(P[ok,:3,3]@U.T)+t;return out,s*(X@U.T)+t

def initialize(pack,repeat,K):
 trainids=np.flatnonzero(pack['train_track']);xy=pack['xy'][trainids];cv2.setRNGSeed(20261016+repeat);candidates=[];audit=[]
 for j in [7,9,6,10,5,11,3,13,0,15]:
  c,a=pair_initial(xy,K,j);audit.append(a)
  if c:candidates.append(c)
 if not candidates:return None,dict(success=False,reason='no positive20point1deg initializer',pair_attempts=audit)
 candidates.sort(key=lambda x:(x['score'],x['parallax']),reverse=True);chosen=candidates[min(repeat,len(candidates)-1)];base=chosen['other'];P=np.full((16,4,4),np.nan);P[8]=np.eye(4);P[base]=chosen['pose'];X=chosen['points'];ids=chosen['ids'];mask=np.empty((0,16),bool)
 for step in range(6):
  pending=[i for i in range(16) if not np.isfinite(P[i,0,0])];pending.sort(key=lambda i:np.isfinite(xy[ids,i,0]).sum(),reverse=True);added=0
  for i in pending:
   ok=np.isfinite(xy[ids,i,0]);xx=X[ok];uv=xy[ids[ok],i]
   if len(xx)<12:continue
   success,rv,tv,inds=cv2.solvePnPRansac(xx,uv,K,None,iterationsCount=300,reprojectionError=2.,confidence=.999,flags=cv2.SOLVEPNP_EPNP)
   if success and inds is not None and len(inds)>=12:
    ii=inds.ravel();rv,tv=cv2.solvePnPRefineLM(xx[ii],uv[ii],K,None,rv,tv);rot=cv2.Rodrigues(rv)[0];pose=np.eye(4);pose[:3,:3]=rot.T;pose[:3,3]=-rot.T@tv.ravel();u,z=project(xx[ii],np.array([pose]),np.zeros(len(ii),int),K)
    if (z>0).mean()<.95:continue
    P[i]=pose;added+=1
  nX,nids,nmask=triangulate(xy,P,K)
  if len(nX)>=3:X,ids,mask=nX,nids,nmask
  if not added:break
 if len(mask)!=len(X):X,ids,mask=triangulate(xy,P,K)
 return (P,X,trainids[ids],mask),dict(success=True,pair=[8,base],registered=np.flatnonzero(np.isfinite(P[:,0,0])).tolist(),points=len(X),pair_attempts=audit)

def align_ring(P,X,K):
 B=json.loads((R/'predictions/B_unknown.json').read_text());active=[int(i) for i in np.flatnonzero(np.isfinite(P[:,0,0])) if i not in config()['ring_frame_holdout']];A=[];y=[];normals=[]
 for i in active:
  v=P[i,:3,:3]@np.array(B[i]['center']);A.append(np.c_[np.eye(3),-v]);y.append(P[i,:3,3]);normal=P[i,:3,:3]@np.array(B[i]['normal']);normal=normal if not normals or np.dot(normal,normals[0])>=0 else -normal;normals.append(normal)
 a=np.linalg.lstsq(np.vstack(A),np.concatenate(y),rcond=None)[0];s=1/max(a[3],1e-4);n=np.mean(normals,0);n/=np.linalg.norm(n);U=Rotation.align_vectors([[0,0,1]],[n])[0].as_matrix();t=-s*U@a[:3];pp,_=transform(P,X,U,s,t)
 if pp[8,2,3]<0:H=np.diag([1.,-1,-1]);U=H@U;t=H@t
 par=np.r_[Rotation.from_matrix(U).as_rotvec(),t,np.log(s)];obs={i:np.load(R/f'observations/{i:03d}.npz') for i in active}
 def decode(a):return Rotation.from_rotvec(a[:3]).as_matrix(),np.exp(a[6]),a[3:6]
 def residual(a):
  U,s,t=decode(a);pp,_=transform(P,X[:1],U,s,t);out=[]
  for i,ob in obs.items():
   q=ob['ring_train'][::2];p=ob['visible_region'][::8];b=ob['background_region'][::8]
   try:
    C=pp[i,:3,3]
    if abs(C[2])/np.linalg.norm(C)<=.6/5.6+.001:raise ValueError('invalid')
    cr=contours(C,pp[i,:3,:3],K,n=512);tree=cKDTree(cr.reshape(-1,2));out.extend(tree.query(q)[0]);out.extend(tree.query(p)[0]*~inside(cr,p));out.extend(tree.query(b)[0]*inside(cr,b))
   except ValueError:out.extend(np.full(len(q)+len(p)+len(b),1000.))
  return np.array(out)
 fit=least_squares(residual,par,loss='soft_l1',f_scale=1.,max_nfev=160,bounds=(np.r_[np.full(6,-np.inf),-8],np.r_[np.full(6,np.inf),8]));U,s,t=decode(fit.x);P,X=transform(P,X,U,s,t);yaw=-np.arctan2(P[8,1,0],P[8,0,0]);Y=Rotation.from_rotvec([0,0,yaw]).as_matrix();P,X=transform(P,X,Y,1.,np.zeros(3));return P,X,dict(scale=s,fit_success=bool(fit.success),nfev=int(fit.nfev),ring_residual=stats(residual(fit.x)),GT_used=False)

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--debug',action='store_true');args=parser.parse_args();prediction_guard(debug=args.debug);assert json.loads((R/'metrics/projection_gate.json').read_text())['passed'];assert json.loads((R/'metrics/B_evaluation.json').read_text())['basic_passed'];name='C0' if args.debug else 'RGB';path=R/('debug_inputs/C0_correspondences.npz' if args.debug else 'observations/rgb_tracks.npz');pack=np.load(path);K=np.array(config()['K']);status=[]
 freeze('C_protocol_'+name,[Path(__file__),R/'scripts/common.py',R/'scripts/shared_ba_region.py',old,R/'inputs/solver_config.json',path,R/'predictions/B_unknown.json'])
 for rr in range(3):
  initial,record=initialize(pack,rr,K);record['repeat']=rr
  if initial is None:status.append(record);save(f'metrics/C_status_{name}.json',status);continue
  P,X,ids,mask=initial;np.savez_compressed(R/f'predictions/{name}_visual_init_{rr}.npz',c2w=P,points=X,point_ids=ids,observation_mask=mask,K=K)
  P,X,h=optimize(P,X,pack['xy'],ids,mask,K,False);P,X,align=align_ring(P,X,K);save(f'metrics/{name}_alignment_{rr}.json',align);np.savez_compressed(R/f'predictions/{name}_shared_init_{rr}.npz',c2w=P,points=X,point_ids=ids,observation_mask=mask,K=K);freeze(f'{name}_shared_{rr}',[R/f'predictions/{name}_shared_init_{rr}.npz',R/f'metrics/{name}_alignment_{rr}.json'])
  for method,ring in ([('C0',False)] if args.debug else [('C1',False),('C2',True)]):
   pp,xx,history=optimize(P.copy(),X.copy(),pack['xy'],ids,mask,K,ring);theta=-np.arctan2(pp[8,1,0],pp[8,0,0]);Y=Rotation.from_rotvec([0,0,theta]).as_matrix();pp,xx=transform(pp,xx,Y,1.,np.zeros(3));np.savez_compressed(R/f'predictions/{method}_{rr}.npz',c2w=pp,points=xx,point_ids=ids,observation_mask=mask,K=K);save(f'metrics/{method}_{rr}_history.json',history);print('C_RUN',method,rr,'frames',np.isfinite(pp[:,0,0]).sum(),'points',len(xx),'last',history[-1],flush=True)
  record.update(alignment=align,same_C1_C2_initial_state=True,same_training_points=True,same_BA_steps=100);status.append(record);save(f'metrics/C_status_{name}.json',status)
 freeze('C_predictions_'+name,list((R/'predictions').glob(('C0_*.npz' if args.debug else 'C[12]_*.npz')))+[Path(__file__),R/f'metrics/C_status_{name}.json']);print(name,'COMPLETE')
if __name__=='__main__':main()

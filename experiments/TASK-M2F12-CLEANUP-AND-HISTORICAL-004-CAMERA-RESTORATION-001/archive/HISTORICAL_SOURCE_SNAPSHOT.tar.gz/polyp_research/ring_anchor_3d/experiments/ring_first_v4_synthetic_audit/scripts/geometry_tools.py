from common import *
import ast
from matplotlib.path import Path as PolygonPath
ns={'np':np,'cv2':cv2}
def get_function(path,name):
 node=next(x for x in ast.parse(path.read_text()).body if isinstance(x,ast.FunctionDef) and x.name==name);exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),ns);return ns[name]
contours=get_function(PROJECT/'ring_anchor_3d/scripts/geometry.py','torus_contours')
torus_depth=get_function(PROJECT/'ring_anchor_3d/experiments/ring_first_v1/scripts/common.py','torus_depth')
def inside(curves,uv):
 areas=[abs(cv2.contourArea(x.astype(np.float32))) for x in curves];outer=int(np.argmax(areas));return PolygonPath(curves[outer]).contains_points(uv)&~PolygonPath(curves[1-outer]).contains_points(uv)
def edges(m):
 y,x=np.nonzero(m[:,:-1]!=m[:,1:]);a=np.c_[x+.5,y]
 y,x=np.nonzero(m[:-1]!=m[1:]);return np.r_[a,np.c_[x,y+.5]]
def border(m):return m&(cv2.erode(m.astype(np.uint8),np.ones((3,3),np.uint8))==0)

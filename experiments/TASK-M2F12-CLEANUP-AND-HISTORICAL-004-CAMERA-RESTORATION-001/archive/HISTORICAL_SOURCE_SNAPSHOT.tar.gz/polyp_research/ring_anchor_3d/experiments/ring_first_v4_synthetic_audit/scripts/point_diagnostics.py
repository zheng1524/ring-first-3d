"""Evaluation-only GT-camera triangulation, GTphysical-track consistency and
class-specific visible target metrics. Not formal predictions or parameter search.
"""
from common import *
from evaluate_C import gt_point
from itertools import combinations
pack=np.load(R/'observations/rgb_tracks.npz');data=np.load(R/'private_gt/scene.npz');xy=pack['xy'];cat=pack['category'];cache={i:np.load(R/f'private_gt/{i:03d}.npz')['depth'].astype(np.float32) for i in range(16)}
def true_at(uv,i):
 z=float(cv2.getRectSubPix(cache[i],(1,1),tuple(map(float,uv)))[0,0]);return data['c2w'][i,:3,:3]@(np.linalg.inv(data['K'])@np.r_[uv,1.]*z)+data['c2w'][i,:3,3]
rows=[]
for rr in range(3):
 p=np.load(R/f'predictions/C1_{rr}.npz');idlist=p['point_ids'];errors=[];spread=[];angles=[];target=[]
 for n,j in enumerate(idlist):
  fr=np.flatnonzero(p['observation_mask'][n]);X=triangle(xy[j,fr],data['c2w'][fr],data['K']);truth=gt_point(xy[j],cat[j],data);errors.append(np.linalg.norm(X-truth));gtpoints=np.array([true_at(xy[j,i],int(i)) for i in fr]);spread.append(np.max(np.linalg.norm(gtpoints-truth,axis=1)));angles.append(max(float(angle(truth,data['c2w'][a,:3,3],data['c2w'][b,:3,3])) for a,b in combinations(fr,2)));target.append(cat[j]==1 and np.isfinite(xy[j,8,0]))
 errors=np.array(errors);spread=np.array(spread);target=np.array(target);item=dict(repeat=rr,GT_cameras_RGB_correspondences_DLT_only=dict(all=stats(errors),polyp=stats(errors[cat[idlist]==1]),background=stats(errors[cat[idlist]==0]),reference8_visible_polyp=stats(errors[target])),GT_world_track_max_drift_mm=stats(spread),GT_max_point_parallax_deg=stats(angles),formal={})
 for method in ['C1','C2']:
  ev=np.load(R/f'private_gt/evaluated_{method}_{rr}.npz');ee=ev['point_errors'];item['formal'][method]=dict(reference8_target_point_error_mm=stats(ee[target]),reference8_target_count=int(target.sum()))
 rows.append(item)
C=json.loads((R/'metrics/C_evaluation.json').read_text());save('metrics/point_diagnostics.json',dict(per_repeat=rows,debug_GT_camera_DLT_not_formal=True,not_used_to_refine_or_select_predictions=True,original_Oracle_shape_point_errors={f"{x['method']}_{x['repeat']}":x['Oracle_one_global_Sim3']['point_error_mm'] for x in C['results']}));freeze('point_diagnostics',[Path(__file__),R/'metrics/point_diagnostics.json']);print(json.dumps(rows,indent=2))

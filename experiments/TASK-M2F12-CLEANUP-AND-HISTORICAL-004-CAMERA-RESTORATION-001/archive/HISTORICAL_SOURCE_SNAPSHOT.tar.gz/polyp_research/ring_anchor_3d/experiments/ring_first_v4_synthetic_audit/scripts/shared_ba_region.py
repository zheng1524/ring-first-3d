"""V3 BA adapted only in Ring loss: known visible-region inclusion + rear-background exclusion + contour. Shared feature, variables and budgets unchanged."""
"""Same variables, observations, optimizer and budget. Only L_ring toggles.
Reuses V2 torch BA and exact torus silhouette equations; no new 2D ring fitting.
"""
from common import *
import torch,torch.nn.functional as F

def optimize(poses,X,xy,ids,obsmask,K,ring_enabled=False,steps=None):
 torch.set_num_threads(4);dtype=torch.float64;conf=config();active=np.flatnonzero(np.isfinite(poses[:,0,0]));lookup={int(f):i for i,f in enumerate(active)};N=len(active)
 C0=torch.tensor(poses[active,:3,3],dtype=dtype);R0=torch.tensor(poses[active,:3,:3],dtype=dtype);kt=torch.tensor(K,dtype=dtype);delta=torch.zeros((N,6),dtype=dtype,requires_grad=True);offset=torch.zeros_like(torch.tensor(X,dtype=dtype),requires_grad=True);X0=torch.tensor(X,dtype=dtype)
 rows=[]
 for n,j in enumerate(ids):
  for i in active:
   if obsmask[n,i] and np.isfinite(xy[j,i,0]):rows.append((n,lookup[int(i)],*xy[j,i]))
 rows=np.array(rows);pi=torch.tensor(rows[:,0],dtype=torch.long);fi=torch.tensor(rows[:,1],dtype=torch.long);uv=torch.tensor(rows[:,2:],dtype=dtype)
 ringids=[];observed=[];positive_region=[];negative_region=[];dt=[]
 for local,i in enumerate(active):
  if not ring_enabled or i in conf['ring_frame_holdout']:continue
  ob=np.load(R/f'observations/{i:03d}.npz');q=ob['ring_train'];q=q[np.linspace(0,len(q)-1,min(128,len(q)),dtype=int)];observed.append(torch.tensor(q,dtype=dtype));positive_region.append(torch.tensor(ob['visible_region'][::4],dtype=dtype));negative_region.append(torch.tensor(ob['background_region'][::4],dtype=dtype));ringids.append(local)
  allowed=np.ones((360,640),np.uint8);p=np.rint(q).astype(int);allowed[p[:,1],p[:,0]]=0;poly=cv2.dilate(ob['polyp_mask'].astype(np.uint8),np.ones((5,5),np.uint8))>0;allowed[poly]=0;dt.append(cv2.distanceTransform(allowed,cv2.DIST_L2,cv2.DIST_MASK_PRECISE))
 if ring_enabled:dt=torch.tensor(np.array(dt)[:,None],dtype=dtype)
 th=torch.arange(256,dtype=dtype)*2*np.pi/256;co,si=th.cos(),th.sin();history=[]
 def state():
  w=delta[:,:3];zero=torch.zeros(N,dtype=dtype);skew=torch.stack([zero,-w[:,2],w[:,1],w[:,2],zero,-w[:,0],-w[:,1],w[:,0],zero],1).reshape(N,3,3)
  return C0+delta[:,3:],torch.matrix_exp(skew)@R0,X0+offset
 def rho(e):return torch.sqrt(1+e**2)-1
 def loss():
  C,rot,points=state();cam=torch.bmm((points[pi]-C[fi])[:,None],rot[fi]).squeeze(1);p=cam@kt.T;pred=p[:,:2]/torch.clamp(p[:,2:],min=.01);feature=rho(torch.linalg.vector_norm(pred-uv,dim=1)).mean();positive=10*torch.relu(.01-cam[:,2]).square().mean();ringloss=feature*0
  if ring_enabled:
   a=C[:,0,None]*co+C[:,1,None]*si-5.6;b=C[:,2,None];phi=torch.atan2(b,a)[:,None,:]+torch.tensor([-1.,1.],dtype=dtype)[None,:,None]*torch.acos(torch.clamp(.6/torch.sqrt(a*a+b*b),-1+1e-8,1-1e-8))[:,None,:];ring=torch.stack([(5.6+.6*phi.cos())*co,(5.6+.6*phi.cos())*si,.6*phi.sin()],-1).reshape(N,-1,3);rc=torch.bmm(ring-C[:,None],rot);rq=rc@kt.T;proj=rq[:,:,:2]/torch.clamp(rq[:,:,2:],min=.01);terms=[]
   def membership(curves,points):
    cr=curves.reshape(2,-1,2);areas=(cr[:,:,0]*torch.roll(cr[:,:,1],-1,1)-cr[:,:,1]*torch.roll(cr[:,:,0],-1,1)).sum(1).abs();oi=int(areas.argmax().detach());ans=[]
    for curve in cr:
     a=curve;b=torch.roll(curve,-1,0);px=points[:,0,None];py=points[:,1,None];cross=((a[None,:,1]>py)!=(b[None,:,1]>py))&(px<(b-a)[None,:,0]*(py-a[None,:,1])/(b-a)[None,:,1].add(1e-12)+a[None,:,0]);ans.append(cross.sum(1)%2==1)
    return ans[oi]&~ans[1-oi]
   for slot,(i,q) in enumerate(zip(ringids,observed)):
    first=rho(torch.cdist(proj[i],q).min(0).values).mean();pp=positive_region[slot];bb=negative_region[slot];dp=torch.cdist(pp,proj[i]).min(1).values;db=torch.cdist(bb,proj[i]).min(1).values;pos=rho(dp*(~membership(proj[i],pp))).mean();neg=rho(db*membership(proj[i],bb)).mean();terms.append((first+pos+neg)/3)
   ringloss=torch.stack(terms).mean()
  return feature+ringloss+positive,feature,ringloss,positive
 optim=torch.optim.LBFGS([delta,offset],lr=.5,max_iter=steps or conf['BA_steps'],line_search_fn='strong_wolfe',tolerance_grad=1e-7,tolerance_change=1e-9)
 def closure():
  optim.zero_grad();total,feature,ring,pos=loss();total.backward();history.append(dict(total=float(total.detach()),feature=float(feature.detach()),ring=float(ring.detach()),positive=float(pos.detach())));return total
 optim.step(closure);C,rot,points=state();out=poses.copy();out[active,:3,3]=C.detach().numpy();out[active,:3,:3]=rot.detach().numpy();return out,points.detach().numpy(),history

from common import *
from geometry_tools import *
from scipy.spatial import cKDTree
records=[]
for rr in range(3):
 for method in ['C1','C2']:
  p=np.load(R/f'predictions/{method}_{rr}.npz');frames=[]
  for i in range(16):
   ob=np.load(R/f'observations/{i:03d}.npz');uv=np.column_stack(np.nonzero(ob['ring_mask'])[::-1]);cr=contours(p['c2w'][i,:3,3],p['c2w'][i,:3,:3],p['K'],n=1024);good=inside(cr,uv);bad=inside(cr,ob['background_region']);frames.append(dict(frame=i,ring_identity_pixels=len(uv),positive_violations=int((~good).sum()),background_sample_inside=int(bad.sum()),background_samples=len(bad),view_cosine=float(abs(p['c2w'][i,2,3])/np.linalg.norm(p['c2w'][i,:3,3]))))
  records.append(dict(method=method,repeat=rr,frames=frames,positive_violation_fraction=sum(x['positive_violations'] for x in frames)/sum(x['ring_identity_pixels'] for x in frames),BG_false_fraction=sum(x['background_sample_inside'] for x in frames)/sum(x['background_samples'] for x in frames),all_open_hole_necessary=all(x['view_cosine']>.6/5.6 for x in frames)))
centers={}
for method in ['C0','C1','C2']:
 c=np.array([np.load(R/f'private_gt/evaluated_{method}_{r}.npz')['c2w'][:,:3,3] for r in range(3)]);dev=np.linalg.norm(c-c.mean(0),axis=2);centers[method]=stats(dev.ravel())
save('metrics/loss_activation_and_stability.json',dict(per_run=records,center_deviation_across_initializations_mm=centers,GT_symmetry_only_for_stability=True));freeze('activation_stability',[Path(__file__),R/'metrics/loss_activation_and_stability.json']);print('Activation and stability recorded')

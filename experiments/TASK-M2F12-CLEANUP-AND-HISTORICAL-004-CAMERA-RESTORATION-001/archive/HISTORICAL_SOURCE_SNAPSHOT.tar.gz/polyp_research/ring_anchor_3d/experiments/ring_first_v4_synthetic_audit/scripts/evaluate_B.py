"""Independent GT comparison AFTER unknown-camera prediction freeze. No tuning."""
from common import *
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from geometry_tools import contours
p=json.loads((R/'metrics/freeze_B_predictions.json').read_text());assert all(sha(Path(k))==v for k,v in p['files'].items());data=np.load(R/'private_gt/scene.npz');pred=json.loads((R/'predictions/B_unknown.json').read_text());rows=[]
for i,(p,cam) in enumerate(zip(pred,data['c2w'])):
 cg=cam[:3,:3].T@(-cam[:3,3]);ng=cam[:3,:3].T@np.array([0,0,1.]);c=np.array(p['center']);n=np.array(p['normal']);e=float(np.linalg.norm(c-cg));ang=float(np.degrees(np.arccos(np.clip(abs(n@ng),0,1))));alts=[p]+p.get('alternatives',[]);coverage=min(np.linalg.norm(np.array(x['center'])-cg)+np.degrees(np.arccos(np.clip(abs(np.array(x['normal'])@ng),0,1)))/10 for x in alts);rows.append(dict(frame=i,numerical_success=p['numerical_success'],center_error_mm=e,normal_error_deg=ang,ambiguity=len(p['ambiguity_alternatives']),oracle_candidate_combined_min_only_for_diagnosis=float(coverage),loss=p['loss']))
cfg=config();summary=dict(center_error_mm=stats([x['center_error_mm'] for x in rows]),normal_error_deg=stats([x['normal_error_deg'] for x in rows]),numeric_success=sum(x['numerical_success'] for x in rows),targets=16,per_frame=rows);summary['basic_passed']=summary['center_error_mm']['MAE']<cfg['B_gate']['max_center_MAE_mm'] and summary['normal_error_deg']['MAE']<cfg['B_gate']['max_normal_MAE_deg'];save('metrics/B_evaluation.json',summary);freeze('B_evaluation',[Path(__file__),R/'metrics/B_evaluation.json']);print(json.dumps(summary,indent=2))

from common import *
records=[]
for debug in [False]:
 prediction_guard(debug=debug)
 for p in [R/'private_gt/scene.npz',R/'debug_inputs/C0_correspondences.npz',R/'config.json']:
  try:
   with open(p,'rb') as f:f.read(1)
   records.append(dict(path=str(p),blocked=False))
  except PermissionError:records.append(dict(path=str(p),blocked=True))
assert all(x['blocked'] for x in records)
save('metrics/GT_USAGE_AUDIT.json',dict(firewall_test=records,formal_B_unknown='reads only publicK,R/r,RGB/instance-derived observations and stagepass booleans, no GTcameras/depth/points/correspondences',formal_C1_C2='only sameRGB2Dfeatures, knownK, ringBpredictions; guard denies private_gt/debug_inputs/generationconfig',diagnostic_A='explicitly reads true cameras,ring,depth/occlusion; authorized projection correctness check',diagnostic_B_known='explicit known truecamera input, no ringGTpose input',diagnostic_C0='GT2D correspondences intentionally allowed ONLY in debugprocess; no truecamera/depth/worldpoints in solver',evaluation='privateGT reads after unknownB and C prediction hashes frozen; no parameter tuning',legacy_freeze_flag_correction='common.freeze GT_used=False is a copied broad template. It does NOT describe A, C0, known-cameraB or evaluation. This stage-specific audit supersedes its generic flag; original freeze files kept.',scope='not an OSsecurityboundary against adversarial code; explicit Python open hook + physically separate directories and source audit',GT_used_for_selection_or_weights=False))
print('GTfirewall test passed')

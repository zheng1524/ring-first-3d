"""Experiment A: authorized GT projection diagnostic; never a formal predictor."""
from common import *
from geometry_tools import *
from scipy.spatial import cKDTree
import csv
cfg=config();data=np.load(R/'private_gt/scene.npz');K=data['K'];records=[]
freeze('projection_protocol',[Path(__file__),R/'scripts/geometry_tools.py',R/'config.json'])
for i,pose in enumerate(data['c2w']):
 g=np.load(R/f'private_gt/{i:03d}.npz');full=np.isfinite(g['ring_depth_alone']);vis=g['visible_ring'];poly=g['polyp_depth_alone'];C=pose[:3,3];curve=contours(C,pose[:3,:3],K,n=4096);y,x=np.indices(full.shape);uv=np.c_[x.ravel(),y.ravel()];pred=inside(curve,uv).reshape(full.shape)
 # Reuse analytic quartic nearest front surface for exact pixel occupancy/depth.
 lo=np.floor(curve.reshape(-1,2).min(0)-1).astype(int);hi=np.ceil(curve.reshape(-1,2).max(0)+1).astype(int);yy,xx=np.mgrid[max(0,lo[1]):min(360,hi[1]+1),max(0,lo[0]):min(640,hi[0]+1)];q=np.c_[xx.ravel(),yy.ravel()];z=torus_depth(q,pose,K,np.zeros(3),np.eye(3),major=5.6,tube=.6);zmap=np.full(full.shape,np.nan);zmap[yy.ravel(),xx.ravel()]=z;raymask=np.isfinite(zmap);v=raymask&(~np.isfinite(poly)|(zmap<=poly));occluded=raymask&~v
 boundary=edges(vis);fulledge=edges(full);bD=cKDTree(fulledge).query(boundary)[0];own=bD<=1.01;occ=~own;dist=cKDTree(curve.reshape(-1,2)).query(fulledge)[0];selfdist=cKDTree(curve.reshape(-1,2)).query(boundary[own])[0];occwrong=cKDTree(curve.reshape(-1,2)).query(boundary[occ])[0]
 def iou(a,b):return float((a&b).sum()/max((a|b).sum(),1))
 dd=abs(zmap[raymask&full]-g['ring_depth_alone'][raymask&full]);occB=edges(occluded) if occluded.any() else np.empty((0,2));predbe=edges(v);actualbe=edges(vis);actualdist=cKDTree(predbe).query(actualbe)[0]
 row=dict(frame=i,full_mask_iou=iou(pred,full),ray_torus_full_iou=iou(raymask,full),visible_ring_iou=iou(v,vis),occluded_region_iou=iou(occluded,g['occluded_ring']),full_apparent_boundary=stats(dist),visible_mask_boundary=stats(actualdist),visible_self_contour=stats(selfdist),occlusion_boundary_if_incorrectly_used_as_contour=stats(occwrong),self_boundary_count=int(own.sum()),occlusion_boundary_count=int(occ.sum()),all_visible_ring_pixels=int(vis.sum()),visible_depth_error_mm=stats(dd),view_cosine=float(abs(C[2])/np.linalg.norm(C)),regime_valid=bool(abs(C[2])/np.linalg.norm(C)>.6/5.6));records.append(row);np.savez_compressed(R/f'private_gt/projection_{i:03d}.npz',pred_full=pred,ray_full=raymask,pred_visible=v,pred_occluded=occluded,torus_depth=zmap,self_boundary=boundary[own],occlusion_boundary=boundary[occ],curves=curve);print('PROJECTION',i,row['full_mask_iou'],row['visible_ring_iou'],row['visible_depth_error_mm']['MAE'],flush=True)
passed=all(x['full_mask_iou']>=cfg['projection_gate']['min_IoU'] and x['ray_torus_full_iou']>=.99 and x['visible_ring_iou']>=.99 and x['full_apparent_boundary']['p95']<=cfg['projection_gate']['max_boundary_p95_px'] and x['visible_depth_error_mm']['MAE']<=cfg['projection_gate']['max_ring_depth_MAE_mm'] and x['regime_valid'] for x in records)
save('metrics/projection_gate.json',dict(passed=passed,criteria=cfg['projection_gate'],GT_usage='explicit authorized experimentA only',per_frame=records));freeze('projection_results',[R/'metrics/projection_gate.json',Path(__file__)]);print('PROJECTION_GATE',passed)

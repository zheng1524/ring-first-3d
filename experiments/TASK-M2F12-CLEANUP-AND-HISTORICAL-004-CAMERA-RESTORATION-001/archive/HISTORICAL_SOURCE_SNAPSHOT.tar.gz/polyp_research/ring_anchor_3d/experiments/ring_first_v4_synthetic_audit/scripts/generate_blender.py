"""One Ip + head-enclosing R10, original Blender mesh and trajectory tools.
Generation/evaluation-only process; private GT never imported by formal solver.
"""
import bpy,numpy as np,json,math,hashlib,ast,struct,zlib
from pathlib import Path
from mathutils import Matrix,Vector
from mathutils.bvhtree import BVHTree
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parents[2];CFG=json.loads((ROOT/'config.json').read_text());W,H=CFG['work_size'];F=490.
# Reuse unchanged mesh-export/BVH helper definitions from earlier Blender generator.
old=PROJECT/'ring_anchor_3d/experiments/ring_pose_contact_v1/scripts/generate_blender.py';tree=ast.parse(old.read_text())
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in ['obj_export','bvh_for']:exec(compile(ast.Module(body=[node],type_ignores=[]),str(old),'exec'))
def material(name,color,texture=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;bs=n.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=.9
 if texture:
  pos=n.new('ShaderNodeNewGeometry');vor=n.new('ShaderNodeTexVoronoi');vor.inputs['Scale'].default_value=1.7 if name=='polyp' else 1.1;l.new(pos.outputs['Position'],vor.inputs['Vector']);l.new(vor.outputs['Color'],bs.inputs['Base Color'])
 return m
def png(path,a):
 def chunk(k,v):return struct.pack('>I',len(v))+k+v+struct.pack('>I',zlib.crc32(k+v)&0xffffffff)
 data=b''.join(b'\0'+row.tobytes() for row in a.astype(np.uint8));path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',W,H,8,0,0,0,0))+chunk(b'IDAT',zlib.compress(data))+chunk(b'IEND',b''))
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False);scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=16;scene.render.threads_mode='FIXED';scene.render.threads=8;scene.render.resolution_x=W;scene.render.resolution_y=H;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.view_settings.view_transform='Standard';scene.world.color=(.3,.3,.3)
source=PROJECT/CFG['source_mesh']
with bpy.data.libraries.load(str(source),link=False) as (src,dst):dst.objects=[CFG['source_object']]
polyp=dst.objects[0];scene.collection.objects.link(polyp);vs=np.array([tuple(polyp.matrix_world@v.co) for v in polyp.data.vertices]);lo,hi=vs.min(0),vs.max(0);vs=(vs-(lo+hi)/2)*(CFG['polyp_width_mm']/max((hi-lo)[:2]));rr=np.linalg.norm(vs[:,:2],axis=1);ringheight=float(vs[np.argmax(rr),2]);vs[:,2]-=ringheight
polyp.matrix_world=Matrix.Identity(4);polyp.data.calc_loop_triangles();faces=np.array([list(t.vertices) for t in polyp.data.loop_triangles]);tri=vs[faces]
def sdf(p):return np.sqrt((np.linalg.norm(p[...,:2],axis=-1)-5.6)**2+p[...,2]**2)-.6
def clearance(dx,detail=False):
 tt=tri+np.array([dx,0,0]);vals=sdf(tt);candidates=tt[vals.min(1)<vals.min()+.3];a=np.full(len(candidates),1/3);b=a.copy();step=.4
 for _ in range(24):
  off=np.array([[i,j] for i in [-1,0,1] for j in [-1,0,1]])*step;aa=np.clip(a[:,None]+off[None,:,0],0,1);bb=np.minimum(np.clip(b[:,None]+off[None,:,1],0,1),1-aa);p=candidates[:,0,None,:]+aa[...,None]*(candidates[:,1]-candidates[:,0])[:,None,:]+bb[...,None]*(candidates[:,2]-candidates[:,0])[:,None,:];v=sdf(p);k=v.argmin(1);a=aa[np.arange(len(a)),k];b=bb[np.arange(len(a)),k];step*=.6
 p=candidates[:,0]+a[:,None]*(candidates[:,1]-candidates[:,0])+b[:,None]*(candidates[:,2]-candidates[:,0]);v=sdf(p);i=v.argmin();return (float(v[i]),p[i].tolist()) if detail else float(v[i])
assert clearance(0)>0
low,high=0.,1.
assert clearance(high)<0
for _ in range(32):
 mid=(low+high)/2
 if clearance(mid)>0:low=mid
 else:high=mid
shift=low-1e-5;vs[:,0]+=shift
for v,q in zip(polyp.data.vertices,vs):v.co=q
polyp.name='Ip_original_mesh';polyp.data.materials.clear();polyp.data.materials.append(material('polyp',(.8,.4,.3),True))
for p in polyp.data.polygons:p.use_smooth=True
bpy.ops.mesh.primitive_torus_add(major_radius=5.6,minor_radius=.6,major_segments=384,minor_segments=96);ring=bpy.context.object;ring.name='single_R10';ring.data.materials.append(material('ring',(.018,.018,.018)))
for p in ring.data.polygons:p.use_smooth=True
floorz=float(vs[:,2].min());bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,floorz));floor=bpy.context.object;floor.name='static_background';floor.data.materials.append(material('background',(.5,.6,.5),True))
for loc,power,size in [((12,-20,100),10400,80),((-60,40,100),4800,100)]:
 bpy.ops.object.light_add(type='AREA',location=loc);light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.sensor_fit='HORIZONTAL';cam.data.sensor_width=36;cam.data.lens=F*36/W;cam.data.clip_start=.01;cam.data.clip_end=2000;bpy.context.view_layer.update();bvh,ids=bvh_for([floor,polyp,ring]);br,_=bvh_for([ring]);bp,_=bvh_for([polyp]);poses=np.load(ROOT/'private_gt/generation_cameras.npz')['c2w'];K=np.array(CFG['K']);metadata=[];depths=[];rdepths=[];pdepths=[];labels=[];points=[];pointcat=[]
for o,n in [(polyp,'polyp.obj'),(ring,'ring.obj'),(floor,'background.obj')]:obj_export(o,ROOT/'private_gt/models'/n)
for i,pose in enumerate(poses):
 cam.matrix_world=Matrix(pose@np.diag([1,-1,-1,1]));bpy.context.view_layer.update();scene.render.filepath=str(ROOT/f'inputs/rgb/{i:03d}.png');bpy.ops.render.render(write_still=True)
 depth=np.full((H,W),np.nan,np.float32);rz=depth.copy();pz=depth.copy();lab=np.full((H,W),255,np.uint8);origin=Vector(pose[:3,3]);rot=pose[:3,:3]
 for y in range(H):
  for x in range(W):
   ray=rot@np.array([(x-319.5)/F,(y-179.5)/F,1.]);length=float(np.linalg.norm(ray));unit=Vector(ray/length);hit,_,idx,dist=bvh.ray_cast(origin,unit,2000.)
   if hit is not None:
    depth[y,x]=dist/length;lab[y,x]=ids[idx]
    if x%18==9 and y%18==9 and lab[y,x]!=2:points.append(np.array(hit));pointcat.append(int(lab[y,x]))
   hit,_,_,dist=br.ray_cast(origin,unit,2000.)
   if hit is not None:rz[y,x]=dist/length
   hit,_,_,dist=bp.ray_cast(origin,unit,2000.)
   if hit is not None:pz[y,x]=dist/length
 png(ROOT/f'inputs/labels/{i:03d}.png',lab);np.savez_compressed(ROOT/f'private_gt/{i:03d}.npz',depth=depth,ring_depth_alone=rz,polyp_depth_alone=pz,visible_ring=lab==2,occluded_ring=np.isfinite(rz)&(lab!=2),labels=lab);depths.append(depth);rdepths.append(rz);pdepths.append(pz);labels.append(lab);metadata.append(dict(frame=i,ring_visible_pixels=int((lab==2).sum()),ring_full_pixels=int(np.isfinite(rz).sum()),polyp_pixels=int((lab==1).sum()),camera_distance_mm=float(np.linalg.norm(pose[:3,3]))));print('FRAME_DONE',i,metadata[-1],flush=True)
# GT2D correspondences for debugC0 only, not used by RGB methods.
world=np.array(points)[::4];pcat=np.array(pointcat)[::4];xy=np.full((len(world),16,2),np.nan)
for i,pose in enumerate(poses):
 camera=(world-pose[:3,3])@pose[:3,:3];uv=camera@K.T;uv=uv[:,:2]/uv[:,2:]
 for j,(P,q,z) in enumerate(zip(world,uv,camera[:,2])):
  if z<=0 or not(2<q[0]<638 and 2<q[1]<358):continue
  ray=P-pose[:3,3];dist=np.linalg.norm(ray);hit,_,idx,d=bvh.ray_cast(Vector(pose[:3,3]),Vector(ray/dist),2000.)
  if hit is not None and abs(d-dist)<.005 and ids[idx]==pcat[j]:xy[j,i]=q
keep=np.isfinite(xy[:,:,0]).sum(1)>=3;xy=xy[keep];world=world[keep];pcat=pcat[keep];np.savez_compressed(ROOT/'debug_inputs/C0_correspondences.npz',xy=xy,category=pcat,train_track=np.arange(len(xy))%5!=0,holdout_eligible=np.ones(len(xy),bool));np.savez_compressed(ROOT/'private_gt/C0_worldpoints.npz',points=world,category=pcat)
np.savez_compressed(ROOT/'private_gt/scene.npz',c2w=poses,K=K,ring_center=np.zeros(3),ring_Q=np.eye(3));meta=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),blender_version=bpy.app.version_string,ring_R=5.6,ring_r=.6,ring_center=[0,0,0],ring_normal=[0,0,1],mesh_uniform_scale=True,polyp_width_mm=9.8,polyp_horizontal_shift_mm=shift,contact_gap_and_point=clearance(shift,True),support_z_mm=floorz,frames=metadata,texture_coordinates='world Position ->3D Voronoi Color, polyp1.7/mm background1.1/mm; fixed in 3D, diffuse roughness.9',reuse_generator=str(old),generator_sha256=hashlib.sha256(old.read_bytes()).hexdigest());(ROOT/'private_gt/scene.json').write_text(json.dumps(meta,indent=2));bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'private_gt/models/scene.blend'));print('SCENE_COMPLETE',len(xy),'C0debug tracks',flush=True)

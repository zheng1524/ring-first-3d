"""Reuse V2 mature SIFT mutual-ratio, duplicate-frame-safe track graph, broadened
like V3 to static polyp+background. No GT correspondences or camera input.
"""
from common import *
from scipy.spatial import cKDTree
cv2.setNumThreads(4)
def main():
 prediction_guard();assert json.loads((R/'metrics/projection_gate.json').read_text())['passed'];assert json.loads((R/'metrics/B_evaluation.json').read_text())['basic_passed'];freeze('rgb_tracking_protocol',[Path(__file__),R/'scripts/common.py',R/'inputs/solver_config.json']);key=[];desc=[];cats=[]
 for i in range(16):
  im=cv2.imread(str(R/f'inputs/rgb/{i:03d}.png'));lab=cv2.imread(str(R/f'inputs/labels/{i:03d}.png'),0);valid=cv2.dilate((lab==2).astype(np.uint8),np.ones((13,13),np.uint8))==0;interface=cv2.dilate((lab==1).astype(np.uint8),np.ones((9,9),np.uint8))!=cv2.erode((lab==1).astype(np.uint8),np.ones((9,9),np.uint8));valid&=~interface;kp,d=cv2.SIFT_create(nfeatures=3000,contrastThreshold=.01,edgeThreshold=12).detectAndCompute(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),valid.astype(np.uint8)*255);selected=[];cells=set()
  for j,k in enumerate(kp):
   c=tuple(np.rint(k.pt).astype(int))
   if c not in cells:cells.add(c);selected.append(j)
  q=np.array([kp[j].pt for j in selected],float).reshape(-1,2);key.append(q);desc.append(d[selected]);z=np.rint(q).astype(int);cats.append(lab[z[:,1],z[:,0]]);print('SIFT',i,len(q),flush=True)
 parent={};members={}
 def root(x):
  if x not in parent:parent[x]=x;members[x]={x[0]:x[1]}
  if parent[x]!=x:parent[x]=root(parent[x])
  return parent[x]
 edges=[];pairs=[];conflicts=0
 for i in range(16):
  for j in range(i+1,16):
   if j-i>4 and (i,j) not in [(0,8),(8,15),(0,15)]:continue
   matcher=cv2.BFMatcher(cv2.NORM_L2);ij=matcher.knnMatch(desc[i],desc[j],k=2);ji=matcher.knnMatch(desc[j],desc[i],k=2);rev={m.queryIdx:m.trainIdx for m,n in ji if m.distance<.8*n.distance};valid=[m for m,n in ij if m.distance<.8*n.distance and rev.get(m.trainIdx)==m.queryIdx and cats[i][m.queryIdx]==cats[j][m.trainIdx]];edges.extend((m.distance,i,m.queryIdx,j,m.trainIdx) for m in valid);pairs.append(dict(i=i,j=j,matches=len(valid)))
 for distance,i,a,j,b in sorted(edges):
  ra,rb=root((i,a)),root((j,b))
  if ra==rb:continue
  if set(members[ra])&set(members[rb]):conflicts+=1;continue
  parent[rb]=ra;members[ra].update(members[rb])
 tracks=[];category=[]
 for node in list(parent):
  if root(node)!=node:continue
  obs=members[node]
  if len(obs)<3:continue
  array=np.full((16,2),np.nan)
  for frame,k in obs.items():array[frame]=key[frame][k]
  tracks.append(array);category.append(int(cats[node[0]][node[1]]))
 xy=np.array(tracks);cat=np.array(category);train=np.arange(len(xy))%5!=0;np.savez_compressed(R/'observations/rgb_tracks.npz',xy=xy,category=cat,train_track=train,holdout_eligible=np.ones(len(xy),bool));save('metrics/rgb_tracks.json',dict(keypoints=[len(x) for x in key],pairs=pairs,tracks=len(xy),polyp=int((cat==1).sum()),background=int((cat==0).sum()),train=int(train.sum()),heldout=int((~train).sum()),reference8=int(np.isfinite(xy[:,8,0]).sum()),duplicate_frame_conflicts=conflicts,geometry_filtered_with_heldout=False));freeze('rgb_tracks',[Path(__file__),R/'observations/rgb_tracks.npz',R/'metrics/rgb_tracks.json']);print('RGB_TRACKS_COMPLETE',len(xy))
if __name__=='__main__':main()

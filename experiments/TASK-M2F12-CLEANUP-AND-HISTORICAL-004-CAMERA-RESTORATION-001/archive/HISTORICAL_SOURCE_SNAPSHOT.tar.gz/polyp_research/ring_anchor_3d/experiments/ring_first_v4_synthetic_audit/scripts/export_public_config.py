from common import *
c=json.loads((R/'config.json').read_text());safe={k:c[k] for k in ['frames','reference','work_size','R_mm','r_mm','K','BA_steps','ring_frame_holdout','repeats','ring_samples','ring_seed_retain','ring_max_nfev','ring_observation_px']};safe.update(seed=20261016,min_E_matches=20,min_triangulation_deg=1.,min_positive_fraction=.95);p=R/'inputs/solver_config.json'
if p.exists():assert json.loads(p.read_text())==safe;print('Existing public solver config verified, not overwritten')
else:save('inputs/solver_config.json',safe);freeze('predictor_config',[p,R/'scripts/common.py']);print('Public solver config exported without private pose/shape data')

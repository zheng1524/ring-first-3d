"""GT-only exact pixel-edge visibility roles; one-pixel junction ambiguity explicit.
Supersedes approximate closest-full-boundary role labels in the first A diagnostic.
Does not change gate, observations or predictions.
"""
from common import *
from geometry_tools import *
from scipy.spatial import cKDTree
D=np.load(R/'private_gt/scene.npz');rows=[]
for i in range(16):
 g=np.load(R/f'private_gt/{i:03d}.npz');m=g['visible_ring'];full=np.isfinite(g['ring_depth_alone']);y,x=np.nonzero(m[:,:-1]!=m[:,1:]);a=np.c_[x+.5,y];cut_a=full[y,x]&full[y,x+1];y,x=np.nonzero(m[:-1]!=m[1:]);b=np.c_[x,y+.5];cut_b=full[y,x]&full[y+1,x];q=np.r_[a,b];iscut=np.r_[cut_a,cut_b];selfq=q[~iscut];cutq=q[iscut];junction_self=cKDTree(cutq).query(selfq)[0]<=1.5 if len(cutq) else np.zeros(len(selfq),bool);junction_cut=cKDTree(selfq).query(cutq)[0]<=1.5 if len(selfq) else np.zeros(len(cutq),bool);curve=contours(D['c2w'][i,:3,3],D['c2w'][i,:3,:3],D['K'],n=4096).reshape(-1,2);sd=cKDTree(curve).query(selfq[~junction_self])[0];cd=cKDTree(curve).query(cutq[~junction_cut])[0];np.savez_compressed(R/f'private_gt/boundary_roles_{i:03d}.npz',self_contour=selfq[~junction_self],occlusion_cut=cutq[~junction_cut],junction_unknown=np.r_[selfq[junction_self],cutq[junction_cut]]);rows.append(dict(frame=i,all_boundary=len(q),own_contour=int((~junction_self).sum()),occlusion_cut=int((~junction_cut).sum()),junction_unknown=int(junction_self.sum()+junction_cut.sum()),own_contour_error_px=stats(sd),occlusion_cut_to_torus_distance_px=stats(cd)))
save('metrics/boundary_role_exact.json',dict(method='two adjacent pixel rays: full ring visibility changes -> own apparent contour; both intersect ring but one hidden -> occlusion cut;1.5px role-junction unknown',per_frame=rows,first_A_role_warning='projection_gate first report uses nearest-boundary1px proxy, this independent role audit is more precise and should be used for boundary counts',not_prediction_input=True));freeze('exact_boundary_roles',[Path(__file__),R/'metrics/boundary_role_exact.json']);print('Exact boundary role audit complete')

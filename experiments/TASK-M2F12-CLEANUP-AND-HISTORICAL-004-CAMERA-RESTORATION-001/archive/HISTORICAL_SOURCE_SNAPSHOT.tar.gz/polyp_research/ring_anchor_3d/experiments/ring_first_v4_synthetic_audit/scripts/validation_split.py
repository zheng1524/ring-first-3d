from common import *
from scipy.spatial import cKDTree
prediction_guard(debug=True);freeze('validation_split_protocol',[Path(__file__),R/'inputs/solver_config.json'])
for name,path in [('RGB',R/'observations/rgb_tracks.npz'),('C0',R/'debug_inputs/C0_correspondences.npz')]:
 p=np.load(path);xy=p['xy'];train=p['train_track'];counts={}
 for i in range(16):
  tr=np.flatnonzero(train&np.isfinite(xy[:,i,0]));he=np.flatnonzero(~train&np.isfinite(xy[:,i,0]));pairs=cKDTree(xy[tr,i]).query_ball_point(xy[he,i],r=2.)
  for j,neighbors in zip(he,pairs):
   for n in neighbors:counts[(int(j),int(tr[n]))]=counts.get((int(j),int(tr[n])),0)+1
 excluded={j for (j,k),v in counts.items() if v>=2};eligible=np.ones(len(xy),bool);eligible[list(excluded)]=False;np.savez_compressed(R/f'observations/validation_split_{name}.npz',train_track=train,holdout_eligible=eligible);save(f'metrics/validation_split_{name}.json',dict(raw_heldout=int((~train).sum()),near_duplicate_heldout_removed=len(excluded),independent_heldout=int((~train&eligible).sum()),criteria='same2px/2views duplicate-exclusion as V3, no residual or GT metric threshold',excluded_ids=sorted(excluded)));print(name,'heldout',int((~train&eligible).sum()),'near-duplicates',len(excluded))
freeze('validation_split',[Path(__file__)]+list((R/'observations').glob('validation_split_*.npz'))+list((R/'metrics').glob('validation_split_*.json')))

"""Only post-freeze diagnostics/GT visualization, no effect on predictions."""
from common import *
from geometry_tools import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv
from scipy.spatial.transform import Rotation

def ring3d(ax,c=np.zeros(3),Q=np.eye(3),color='black',label=None):
 t=np.linspace(0,2*np.pi,200)
 for j,ph in enumerate([0,np.pi/2,np.pi,3*np.pi/2]):
  X=np.c_[(5.6+.6*np.cos(ph))*np.cos(t),(5.6+.6*np.cos(ph))*np.sin(t),np.full(len(t),.6*np.sin(ph))]@Q.T+c;ax.plot(*X.T,c=color,lw=.8,label=label if j==0 else None)
 ax.set(xlabel='X mm',ylabel='Y mm',zlabel='Z mm')
def image(i,real=False):
 p=OLD/f'inputs/images/{i:03d}.jpg' if real else R/f'inputs/rgb/{i:03d}.png';im=cv2.imread(str(p));return cv2.resize(im,(640,360),interpolation=cv2.INTER_AREA)[:,:,::-1]
def face(ax,i):ax.imshow(image(i));ax.set_xlim(0,639);ax.set_ylim(359,0);ax.axis('off')
def ply(path,X,colors):
 with path.open('w') as f:
  f.write(f'ply\nformat ascii 1.0\nelement vertex {len(X)}\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n')
  for x,c in zip(X,colors):f.write(' '.join([*(f'{v:.8f}' for v in x),*(str(int(v)) for v in c)])+'\n')
def main():
 plt.rcParams.update({'font.size':8});V=R/'visualizations';G=np.load(R/'private_gt/scene.npz');GT=G['c2w'];B=json.loads((R/'predictions/B_unknown.json').read_text());ce=json.loads((R/'metrics/C_evaluation.json').read_text())['results'];records=json.loads((R/'metrics/ring_observation_synthetic.json').read_text());fig,axes=plt.subplots(3,3,figsize=(12,8),layout='constrained')
 for row,i in enumerate([0,8,15]):
  face(axes[row,0],i);lab=cv2.imread(str(R/f'inputs/labels/{i:03d}.png'),0);im=image(i);color=np.zeros_like(im);color[lab==1]=[240,80,80];color[lab==2]=[20,240,60];axes[row,1].imshow(np.where((lab>0)[:,:,None],im*.45+color*.55,im).astype(np.uint8));axes[row,1].axis('off');g=np.load(R/f'private_gt/{i:03d}.npz');state=np.zeros((*lab.shape,3),np.uint8);state[g['visible_ring']]=[20,220,60];state[g['occluded_ring']]=[230,40,200];axes[row,2].imshow(state);axes[row,2].axis('off');axes[row,0].set_title(f'Frame {i} RGB; original Ip mesh, static3D pattern');axes[row,1].set_title('Ideal mask: red=Polyp, green=Ring');axes[row,2].set_title('GT: green=visible Ring, magenta=occluded')
 fig.suptitle('Single head-enclosing R10,16views; no side-contact replacement scene.');fig.savefig(V/'fig1_synthetic_observations.png',dpi=155,facecolor='white');plt.close(fig)
 fig,axes=plt.subplots(2,3,figsize=(13,7),layout='constrained')
 for row,(real,i) in enumerate([(True,8),(False,8)]):
  ob=np.load(R/f'observations/{"real_" if real else ""}{i:03d}.npz');base=image(i,real);scale=.5 if real else 1.
  axes[row,0].imshow(base);q=(ob['old_accepted']+.5)*scale-.5;axes[row,0].scatter(*q.T,c='lime',s=3);axes[row,0].set_title(('Real' if real else 'Synthetic')+': old accepted Ring edges')
  axes[row,1].imshow(base);m=cv2.resize(ob['ring_mask'].astype(np.uint8),(640,360),interpolation=cv2.INTER_NEAREST)>0;col=base.copy();col[m]=(.5*base[m]+.5*np.array([10,240,70])).astype(np.uint8);axes[row,1].imshow(col);q=(ob['ambiguous_boundary']+.5)*scale-.5;axes[row,1].scatter(*q.T,c='magenta',s=2);axes[row,1].set_title('All visible Ring identity kept; magenta=order unknown')
  axes[row,2].imshow(base);st=json.loads((R/('metrics/ring_observation_real_audit.json' if real else 'metrics/ring_observation_synthetic.json')).read_text())[i]
  for name,color in [('inner','cyan'),('outer','orange'),('centerline','magenta')]:
   e=st['geometry'].get(name)
   if e is None:continue
   th=np.linspace(0,2*np.pi,300);a=np.deg2rad(e['angle_deg']);Q=np.array([[np.cos(a),np.sin(a)],[-np.sin(a),np.cos(a)]]);q=np.c_[e['major_radius']*np.cos(th),e['minor_radius']*np.sin(th)]@Q+[e['cx'],e['cy']];q=(q+.5)*scale-.5;axes[row,2].plot(*q.T,c=color,ls='--',lw=.8,label=name+' inferred2D')
  axes[row,2].set_title('Unmodified DXY inner/outer/Mid');axes[row,2].legend(fontsize=6)
  for ax in axes[row]:ax.set_xlim(0,639);ax.set_ylim(359,0);ax.axis('off')
 fig.suptitle('No new ellipse fitter. Ring identity and torus apparent contour are different observations.');fig.savefig(V/'fig2_ring_observation_audit.png',dpi=160,facecolor='white');plt.close(fig)
 fig,axes=plt.subplots(4,3,figsize=(13,11),layout='constrained')
 for row,i in enumerate([0,5,8,15]):
  pa=np.load(R/f'private_gt/projection_{i:03d}.npz');ob=np.load(R/f'observations/{i:03d}.npz')
  for ax in axes[row]:face(ax,i)
  for cr in pa['curves']:axes[row,0].plot(*cr.T,c='orange',ls='--',lw=.9)
  q=edges(np.load(R/f'private_gt/{i:03d}.npz')['visible_ring']);axes[row,0].scatter(*q.T,c='cyan',s=1);axes[row,0].set_title(f'Frame{i}: GT visible cyan / analytic full orange')
  for q,c,label in [(pa['self_boundary'],'lime','visible own contour'),(pa['occlusion_boundary'],'magenta','occlusion cut: NOT torus contour')]:axes[row,1].scatter(*q.T,c=c,s=2,label=label)
  axes[row,1].set_title('GT boundary roles (evaluation only)');axes[row,1].legend(fontsize=5)
  bp=B[i];Q=np.array(bp['Q']);t=np.array(bp['center']);cr=contours(-Q.T@t,Q.T,G['K'],n=1024)
  for q in cr:axes[row,2].plot(*q.T,c='yellow',lw=.9)
  axes[row,2].scatter(*ob['ring_train'].T,c='cyan',s=2);axes[row,2].set_title('B unknown pose, fitted full torus / valid silhouette samples')
  for ax in axes[row]:ax.set_xlim(210,430);ax.set_ylim(280,75)
 fig.suptitle('fig5 projection audit: real RGB pixels rendered in fixed valid image coordinates. Hidden curves are model predictions.');fig.savefig(V/'fig5_projection_checked.png',dpi=170,facecolor='white',transparent=False);plt.close(fig)
 fig=plt.figure(figsize=(12,5));ax=fig.add_subplot(121,projection='3d');ring3d(ax,label='GT Ring')
 for i in [0,8,15]:
  c=GT[i,:3,3]+GT[i,:3,:3]@np.array(B[i]['center']);Q=GT[i,:3,:3]@np.array(B[i]['Q']);ring3d(ax,c,Q,color=['blue','red','green'][[0,8,15].index(i)],label=f'Bframe{i} recovered; spin irrelevant')
 ax.legend(fontsize=6);ax.set_title('Known-camera evaluation maps B rings to one world');ax.view_init(30,-50);ax=fig.add_subplot(122);b=json.loads((R/'metrics/B_evaluation.json').read_text())['per_frame'];ax.plot([x['center_error_mm'] for x in b],'o-',label='center mm');ax.plot([x['normal_error_deg'] for x in b],'o-',label='unsigned normal deg');ax.set(xlabel='frame',ylabel='separate units as labeled',title='All16 unknown-camera Ring solutions');ax.legend();fig.tight_layout();fig.savefig(V/'fig3_ring_pose_recovery.png',dpi=155,facecolor='white');plt.close(fig)
 fig=plt.figure(figsize=(14,5));ax=fig.add_subplot(121,projection='3d');ring3d(ax);ax.plot(*GT[:,:3,3].T,'k.-',label='GTcamera')
 for method,color in [('C0','green'),('C1','blue'),('C2','orange')]:
  for rr in range(3):
   p=np.load(R/f'private_gt/evaluated_{method}_{rr}.npz');ax.plot(*p['c2w'][:,:3,3].T,c=color,lw=1 if rr==0 else .5,alpha=.9 if rr==0 else .35,label=method if rr==0 else None)
 ax.set_title('One global ring symmetry gauge only; all3starts');ax.legend(fontsize=6);ax.view_init(25,-45);ax=fig.add_subplot(122);x=np.arange(3)
 for method,color in [('C0','green'),('C1','blue'),('C2','orange')]:
  item=[x for x in ce if x['method']==method];ax.plot(range(3),[v['ATE_RMSE_mm'] for v in item],'o-',c=color,label=method)
 ax.set(title='True camera center ATE (no perframe registration)',xlabel='initialization',ylabel='RMSE mm');ax.legend();fig.tight_layout();fig.savefig(V/'fig4_camera_trajectories.png',dpi=165,facecolor='white');plt.close(fig)
 fig=plt.figure(figsize=(14,6));pack=np.load(R/'observations/rgb_tracks.npz');out=R/'evaluation_exports';out.mkdir(exist_ok=True)
 for col,method in enumerate(['C1','C2']):
  p=np.load(R/f'private_gt/evaluated_{method}_0.npz');X=p['points'];truth=p['GT_points'];ids=p['point_ids'];cat=p['classes'];target=(cat==1)&np.isfinite(pack['xy'][ids,8,0]);ax=fig.add_subplot(1,2,col+1,projection='3d');ring3d(ax)
  ax.scatter(*truth[cat==0][::8].T,c='gray',s=2,label='GT background anchor');ax.scatter(*X[cat==0][::8].T,c='cyan',s=2,label='pred background auxiliary');ax.scatter(*truth[target].T,c='black',s=10,label='GTreference-visible polyp');ax.scatter(*X[target].T,c='red',s=5,label='predreference-visible polyp');ax.set_title(method+' repeat0: actual triangulation vsGTanchor');ax.legend(fontsize=6);ax.view_init(30,-50)
 for pth in sorted((R/'private_gt').glob('evaluated_*.npz')):
  p=np.load(pth);X=p['points'];cat=p['classes'];colors=np.where((cat==1)[:,None],np.array([[230,60,60]]),np.array([[40,180,230]]));ply(out/(pth.stem+'_pred.ply'),X,colors);ply(out/(pth.stem+'_GT_anchor.ply'),p['GT_points'],np.full((len(X),3),140));
 fig.suptitle('Evaluation-only single global symmetry transform; no new surface, no hidden completion.');fig.tight_layout();fig.savefig(V/'fig6_points_vs_GT.png',dpi=160,facecolor='white');plt.close(fig)
 fig,axes=plt.subplots(1,3,figsize=(14,4),layout='constrained')
 for ax,key,label in zip(axes,['ATE_RMSE_mm','point_error_mm','heldout'],['Camera ATE mm','3Dpoint MAE mm','Independent feature MAE px']):
  for m,c in [('C0','green'),('C1','blue'),('C2','orange')]:
   it=[x for x in ce if x['method']==m];vals=[v[key] if key=='ATE_RMSE_mm' else (v[key]['MAE'] if key=='point_error_mm' else v[key]['error_px']['MAE']) for v in it];ax.plot(range(3),vals,'o-',c=c,label=m)
  ax.set(title=label,xlabel='initialization',yscale='log');ax.legend(fontsize=6)
 fig.suptitle('C0 = GT2D debug ONLY; C1/C2 same RGB tracks, same initialized state and budget.');fig.savefig(V/'fig7_joint_ablation.png',dpi=170,facecolor='white');plt.close(fig)
 # PNG integrity verifies actual raster content, alpha, bounds and nonwhite pixels.
 integrity=[]
 for f in sorted(V.glob('*.png')):
  im=cv2.imread(str(f),cv2.IMREAD_UNCHANGED);alpha=True if im.shape[2]==3 else bool((im[:,:,3]==255).all());colored=int(np.sum(np.ptp(im[:,:,:3].astype(int),axis=2)>20));nonwhite=int(np.sum(im[:,:,:3].min(2)<245));ok=im.shape[0]>100 and im.shape[1]>100 and alpha and colored>1000 and nonwhite>5000;integrity.append(dict(file=str(f.relative_to(R)),shape=list(im.shape),opaque=alpha,colored_pixels=colored,nonwhite_pixels=nonwhite,pass_check=bool(ok)));assert ok,f
 save('metrics/PNG_INTEGRITY.json',integrity);freeze('visualizations',[Path(__file__),R/'metrics/PNG_INTEGRITY.json']+list(V.glob('*.png'))+list(out.glob('*.ply')));print('VISUALIZATIONS_AND_PNG_CHECK_PASS')
if __name__=='__main__':main()

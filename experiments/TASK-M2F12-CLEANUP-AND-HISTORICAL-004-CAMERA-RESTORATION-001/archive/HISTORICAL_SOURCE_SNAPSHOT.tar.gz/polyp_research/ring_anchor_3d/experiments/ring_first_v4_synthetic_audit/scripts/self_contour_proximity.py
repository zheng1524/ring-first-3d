"""GT-only audit of old proximity rule on CONFIRMED true self-contours.
No prediction changes. Captures the deterministic diagnostic performed this round.
"""
from common import *
rows=[]
for i in range(16):
 q=np.load(R/f'private_gt/boundary_roles_{i:03d}.npz')['self_contour'];lab=cv2.imread(str(R/f'inputs/labels/{i:03d}.png'),0);dt=cv2.distanceTransform((lab!=1).astype('uint8'),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);xy=np.clip(np.rint(q).astype(int),[0,0],[639,359]);close=dt[xy[:,1],xy[:,0]]<=6;rows.append(dict(frame=i,true_self_contour=len(q),near_polyp_removed_by_6px=int(close.sum())))
d=dict(rows=rows,total_self=sum(x['true_self_contour'] for x in rows),self_near_polyp=sum(x['near_polyp_removed_by_6px'] for x in rows),GT_evaluation_only=True);p=R/'metrics/synthetic_self_contour_proximity.json'
if p.exists():assert json.loads(p.read_text())==d
else:save('metrics/synthetic_self_contour_proximity.json',d)
freeze('self_contour_proximity',[Path(__file__),p]);print('Verified own apparent-contour edges nearPolyp',d['self_near_polyp'],'/',d['total_self'])

from common import *
import subprocess
frames=json.loads((OLD/'inputs/manifest.json').read_text());checks=[]
for i,row in enumerate(frames):
 ip=OLD/f'inputs/images/{i:03d}.jpg';mp=OLD/f'inputs/masks/{i:03d}.png';assert sha(ip)==row['image_sha256'] and sha(mp)==row['mask_sha256'];checks.append(dict(frame=i,raw=row['frame_index'],image_sha256=sha(ip),mask_sha256=sha(mp)))
contracts=[]
for scope,f in [('real','ring_observation_real_audit.json'),('synthetic','ring_observation_synthetic.json')]:
 for i,st in enumerate(json.loads((R/f'metrics/{f}').read_text())):contracts.append(dict(scope=scope,frame=i,branch=st['geometry'].get('branch'),inner_ellipse_inferred=st['geometry'].get('branch')=='centerline_symmetry_2mid_minus_outer',Mid_is_2D_inference=True,ellipse_samples_not_true_visible_evidence=True,full_visible_region_in_npz='ring_mask',unknown_occlusion_order_npz='ambiguous_boundary',hidden_ring_region_unknown_to_formal_predictor=True))
save('preparation/source_contract_audit.json',dict(DXY_commit=subprocess.check_output(['git','-C',str(DXY),'rev-parse','HEAD'],text=True).strip(),DXY_branch=subprocess.check_output(['git','-C',str(DXY),'branch','--show-current'],text=True).strip(),real_cache_checks=checks,observation_contracts=contracts,ellipse_fitter_reimplemented=False,Mid_scale_used=False,training=False,real_3D_BA_rerun=False));freeze('source_contracts',[Path(__file__),R/'preparation/source_contract_audit.json']);print('Source and observation contracts verified')

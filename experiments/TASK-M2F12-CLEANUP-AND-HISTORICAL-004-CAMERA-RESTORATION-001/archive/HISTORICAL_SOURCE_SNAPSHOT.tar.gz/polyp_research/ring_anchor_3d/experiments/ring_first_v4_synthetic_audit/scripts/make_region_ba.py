from pathlib import Path
R=Path(__file__).resolve().parents[1];s=(R/'scripts/shared_ba_base.py').read_text();s=s.replace('observed=[];dt=[]','observed=[];positive_region=[];negative_region=[];dt=[]')
s=s.replace("observed.append(torch.tensor(q,dtype=dtype));ringids.append(local)","observed.append(torch.tensor(q,dtype=dtype));positive_region.append(torch.tensor(ob['visible_region'][::4],dtype=dtype));negative_region.append(torch.tensor(ob['background_region'][::4],dtype=dtype));ringids.append(local)")
s=s.replace('th=torch.arange(128,dtype=dtype)*2*np.pi/128','th=torch.arange(256,dtype=dtype)*2*np.pi/256')
start=s.index('   for slot,(i,q) in enumerate(zip(ringids,observed)):');end=s.index('   ringloss=torch.stack(terms).mean()',start)
s=s[:start]+'''   def membership(curves,points):
    cr=curves.reshape(2,-1,2);areas=(cr[:,:,0]*torch.roll(cr[:,:,1],-1,1)-cr[:,:,1]*torch.roll(cr[:,:,0],-1,1)).sum(1).abs();oi=int(areas.argmax().detach());ans=[]
    for curve in cr:
     a=curve;b=torch.roll(curve,-1,0);px=points[:,0,None];py=points[:,1,None];cross=((a[None,:,1]>py)!=(b[None,:,1]>py))&(px<(b-a)[None,:,0]*(py-a[None,:,1])/(b-a)[None,:,1].add(1e-12)+a[None,:,0]);ans.append(cross.sum(1)%2==1)
    return ans[oi]&~ans[1-oi]
   for slot,(i,q) in enumerate(zip(ringids,observed)):
    first=rho(torch.cdist(proj[i],q).min(0).values).mean();pp=positive_region[slot];bb=negative_region[slot];dp=torch.cdist(pp,proj[i]).min(1).values;db=torch.cdist(bb,proj[i]).min(1).values;pos=rho(dp*(~membership(proj[i],pp))).mean();neg=rho(db*membership(proj[i],bb)).mean();terms.append((first+pos+neg)/3)
''' + s[end:]
s=s.replace('clamp(.6/torch.sqrt(a*a+b*b),-.999,.999)','clamp(.6/torch.sqrt(a*a+b*b),-1+1e-8,1-1e-8)')
(R/'scripts/shared_ba_region.py').write_text('"""V3 BA adapted only in Ring loss: known visible-region inclusion + rear-background exclusion + contour. Shared feature, variables and budgets unchanged."""\n'+s)

from common import *
d=np.load(R/'private_gt/scene.npz');p=R/'debug_inputs/known_cameras.npz'
if p.exists():
 old=np.load(p);assert np.array_equal(old['c2w'],d['c2w']) and np.array_equal(old['K'],d['K']);print('Existing debug-camera export verified, not overwritten')
else:np.savez_compressed(p,c2w=d['c2w'],K=d['K']);print('Known cameras exported for explicit B diagnostic ONLY')

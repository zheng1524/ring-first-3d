"""Post-prediction failure attribution. Does not change frozen primary acceptance,
select models or recompute predictions. Common visibility and geometry-only gates.
"""
from common import *
from evaluate import holdout
from run_ablation import contours
from scipy.spatial.transform import Rotation
import torch

def epipolar(P,K,a,b,p,q):
 ra=P[a,:3,:3];rb=P[b,:3,:3];rot=rb.T@ra;t=rb.T@(P[a,:3,3]-P[b,:3,3]);x,y,z=t;E=np.array([[0,-z,y],[z,0,-x],[-y,x,0]])@rot;u=np.c_[p,np.ones(len(p))]@np.linalg.inv(K).T;v=np.c_[q,np.ones(len(q))]@np.linalg.inv(K).T;Eu=u@E.T;Ev=v@E;return abs(np.sum(v*Eu,axis=1))/np.maximum(np.sqrt(np.sum(Eu[:,:2]**2,axis=1)+np.sum(Ev[:,:2]**2,axis=1)),1e-12)*K[0,0]

def main():
 cfg=config();pack=np.load(R/'observations/tracks.npz');held=np.flatnonzero(~pack['train_track']&pack['holdout_eligible']);xy=pack['xy'];cat=pack['category'];res={};maxround=0;maxcontour=0
 freeze('diagnostic_safe_protocol',[Path(__file__),R/'scripts/evaluate.py',R/'config.json']);primary=json.loads((R/'metrics/results.json').read_text())
 for kc in cfg['intrinsics']:
  key=kc['name'];res[key]=[]
  for repeat in range(3):
   item=dict(repeat=repeat);packs={m:np.load(R/f'predictions/{m}_{key}_{repeat}.npz') for m in ['A','C']}
   tests={m:{x['track']:x for x in primary['methods'][key][m][repeat]['heldout']['tracks']} for m in ['A','C']};common=set.intersection(*[set(t) for t in tests.values()]);stable=[j for j in common if all(tests[m][j]['positive'] and tests[m][j]['parallax_deg']>=1. for m in ['A','C'])]
   item['aux_common_positive_1deg_holdout']={m:dict(tracks=len(stable),total_eligible=len(held),errors=stats([e for j in stable for e in tests[m][j]['test_errors']])) for m in ['A','C']}
   for method,p in packs.items():
    P=p['c2w'];K=p['K'];frames=[]
    for j in [6,7,9,10]:
     ids=[int(i) for i in held if np.isfinite(xy[i,8,0]) and np.isfinite(xy[i,j,0])];e=epipolar(P,K,8,j,xy[ids,8],xy[ids,j]);frames.append(dict(pair=[8,j],heldout_matches=len(ids),sampson_px=stats(e),polyp_px=stats(e[cat[ids]==1]),background_px=stats(e[cat[ids]==0])))
    local=holdout(P,K,xy,held,cat,[6,7,8,9,10]);Z=[];cos=[];invalid=[]
    for i in range(16):
     th=np.arange(128)*2*np.pi/128;C=P[i,:3,3];a=C[0]*np.cos(th)+C[1]*np.sin(th)-5.6;b=C[2];phi=np.arctan2(b,a)[None,:]+np.array([-1,1])[:,None]*np.arccos(np.clip(.6/np.sqrt(a*a+b*b),-.999,.999))[None,:];ring=np.stack([(5.6+.6*np.cos(phi))*np.cos(th),(5.6+.6*np.cos(phi))*np.sin(th),.6*np.sin(phi)],-1).reshape(-1,3);cam=(ring-C)@P[i,:3,:3];q=cam@K.T;q=q[:,:2]/q[:,2:];Z.extend(cam[:,2]);cos.append(abs(C[2])/np.linalg.norm(C))
     try:
      exact=contours(C,P[i,:3,:3],K,n=128).reshape(-1,2);maxcontour=max(maxcontour,float(np.max(abs(q-exact))))
     except ValueError:invalid.append(i)
    x=p['points'][:200];uv,z=project(x,P,np.full(len(x),8),K);backcam=np.c_[uv,np.ones(len(uv))]@np.linalg.inv(K).T*z[:,None];back=backcam@P[8,:3,:3].T+P[8,:3,3];maxround=max(maxround,float(np.max(abs(back-x))))
    item[method]=dict(reference_neighborhood_epipolar=frames,local_heldout=local,ring_all_surface_contour_positive_fraction=float((np.array(Z)>0).mean()),minimum_open_hole_view_cosine=min(cos),open_hole_necessary_condition_all=bool(min(cos)>.6/5.6),smallest_ring_contour_depth=float(min(Z)),invalid_exact_contour_frames=invalid)
   align=json.loads((R/f'metrics/alignment_{key}_{repeat}.json').read_text());item['alignment']=align;res[key].append(item)
 save('metrics/diagnostics.json',dict(results=res,world_camera_roundtrip_max_mm=maxround,old_torus_vs_BA_formula_max_px=maxcontour,auxiliary_only=True,primary_validation_unchanged=True,not_GT_accuracy=True));freeze('diagnostics_safe',[Path(__file__),R/'metrics/diagnostics.json']);print('DIAGNOSTICS',maxround,maxcontour)
if __name__=='__main__':main()

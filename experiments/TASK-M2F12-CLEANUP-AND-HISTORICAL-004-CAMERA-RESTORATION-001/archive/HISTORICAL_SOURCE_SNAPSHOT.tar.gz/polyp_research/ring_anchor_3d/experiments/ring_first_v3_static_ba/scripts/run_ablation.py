from common import *
from shared_ba import optimize
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
from scipy.optimize import least_squares
import ast
# Exact old 3D geometry source function; no original scene globals.
source=PROJECT/'ring_anchor_3d/scripts/geometry.py';ns={'np':np,'cv2':cv2}
node=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='torus_contours');exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns);contours=ns['torus_contours']

def transform(poses,X,U,s,t):
 out=poses.copy();ids=np.flatnonzero(np.isfinite(poses[:,0,0]));out[ids,:3,:3]=U@poses[ids,:3,:3];out[ids,:3,3]=s*(poses[ids,:3,3]@U.T)+t;return out,s*(X@U.T)+t

def align_ring(poses,X,K,key):
 # Only global Sim3, never change relative trajectory or shape here.
 B=json.loads((OLD/f'predictions/B_{key}.json').read_text());active=[int(i) for i in np.flatnonzero(np.isfinite(poses[:,0,0])) if i not in config()['ring_frame_holdout']];A=[];y=[];normals=[]
 for i in active:
  v=poses[i,:3,:3]@np.array(B[i]['center']);A.append(np.c_[np.eye(3),-v]);y.append(poses[i,:3,3]);normal=poses[i,:3,:3]@np.array(B[i]['Q'])[:,2]
  if normals and np.dot(normal,normals[0])<0:normal=-normal
  normals.append(normal)
 solution=np.linalg.lstsq(np.vstack(A),np.concatenate(y),rcond=None)[0];Ov=solution[:3];inverse=solution[3];s=1/inverse if inverse>1e-6 else 10.;n=np.mean(normals,axis=0);n/=np.linalg.norm(n);U=Rotation.align_vectors([[0,0,1]],[n])[0].as_matrix();t=-s*U@Ov
 initialposes,_=transform(poses,X,U,s,t)
 # Ensure global normal sign canonical at reference, still no physical axial angle.
 if initialposes[8,2,3]<0:
  H=np.diag([1.,-1.,-1.]);U=H@U;t=H@t
 params=np.r_[Rotation.from_matrix(U).as_rotvec(),t,np.log(s)];obs={i:np.load(R/f'observations/{i:03d}.npz')['ring_train'][::2] for i in active}
 def decode(p):return Rotation.from_rotvec(p[:3]).as_matrix(),np.exp(p[6]),p[3:6]
 def residual(p):
  U,s,t=decode(p);P,_=transform(poses,X[:1],U,s,t);out=[]
  for i in active:
   try:
    curve=contours(P[i,:3,3],P[i,:3,:3],K,n=256).reshape(-1,2);e=cKDTree(curve).query(obs[i])[0];out.extend(e)
   except (ValueError,RuntimeError):out.extend(np.full(len(obs[i]),1e3))
  return np.array(out)
 fit=least_squares(residual,params,loss='soft_l1',f_scale=1.,max_nfev=120,bounds=(np.r_[np.full(6,-np.inf),-8],np.r_[np.full(6,np.inf),8]));U,s,t=decode(fit.x);P,XX=transform(poses,X,U,s,t)
 # Deterministic global yaw gauge fixed by ref8 right direction.
 yaw=-np.arctan2(P[8,1,0],P[8,0,0]);Y=Rotation.from_rotvec([0,0,yaw]).as_matrix();P,XX=transform(P,XX,Y,1.,np.zeros(3));return P,XX,dict(scale_mm_per_visual_unit=s,rotation=U.tolist(),translation=t.tolist(),yaw_gauge_rad=yaw,ring_train_error=stats(residual(fit.x)),success=bool(fit.success),nfev=int(fit.nfev),observed_frames=active,ring_B_prior_source_sha=sha(OLD/f'predictions/B_{key}.json'),changed_relative_trajectory=False,GT_used=False)

def gauge_back_A(P,X,initial,baseline):
 # A has a free Sim3; normalize only to its OWN shared initialization gauge.
 U=initial[8,:3,:3]@P[8,:3,:3].T;den=np.linalg.norm(P[baseline,:3,3]-P[8,:3,3]);num=np.linalg.norm(initial[baseline,:3,3]-initial[8,:3,3]);s=num/den;t=initial[8,:3,3]-s*U@P[8,:3,3];return transform(P,X,U,s,t)

def main():
 cfg=config();pack=np.load(R/'observations/tracks.npz');xy=pack['xy'];records=[]
 freeze('ablation_protocol',[Path(__file__),R/'scripts/shared_ba.py',R/'config.json',R/'observations/tracks.npz',source]+list((R/'predictions').glob('visual_init_*.npz'))+[OLD/f'predictions/B_{k["name"]}.json' for k in cfg['intrinsics']])
 initstats=json.loads((R/'metrics/visual_initialization.json').read_text())
 for kc in cfg['intrinsics']:
  key=kc['name']
  for repeat in range(3):
   init=np.load(R/f'predictions/visual_init_{key}_{repeat}.npz');P=init['c2w'];X=init['points'];ids=init['point_ids'];mask=init['observation_mask'];K=init['K'];record=dict(K=key,repeat=repeat,success=False)
   if len(X)<20 or not np.isfinite(P[8,0,0]):record['reason']='visual initializer failed';records.append(record);save('metrics/ablation_status.json',records);continue
   # Identical common visual refinement before ring-based global coordinate/scale anchoring.
   P,X,h=optimize(P,X,xy,ids,mask,K,False);save(f'metrics/common_visual_{key}_{repeat}.json',h);np.savez_compressed(R/f'predictions/common_visual_{key}_{repeat}.npz',c2w=P,points=X,point_ids=ids,observation_mask=mask,K=K)
   P,X,alignment=align_ring(P,X,K,key);save(f'metrics/alignment_{key}_{repeat}.json',alignment);np.savez_compressed(R/f'predictions/shared_init_{key}_{repeat}.npz',c2w=P,points=X,point_ids=ids,observation_mask=mask,K=K)
   freeze(f'shared_init_{key}_{repeat}',[R/f'predictions/shared_init_{key}_{repeat}.npz',R/f'metrics/alignment_{key}_{repeat}.json']);baseline=initstats[key][repeat]['chosen_pair'][1]
   for method,enabled in [('A',False),('C',True)]:
    pp,xx,hist=optimize(P.copy(),X.copy(),xy,ids,mask,K,enabled)
    if method=='A':pp,xx=gauge_back_A(pp,xx,P,baseline)
    else:
     theta=-np.arctan2(pp[8,1,0],pp[8,0,0]);U=Rotation.from_rotvec([0,0,theta]).as_matrix();pp,xx=transform(pp,xx,U,1.,np.zeros(3))
    np.savez_compressed(R/f'predictions/{method}_{key}_{repeat}.npz',c2w=pp,points=xx,point_ids=ids,observation_mask=mask,K=K,registered=np.isfinite(pp[:,0,0]),shared_ring_scale=True,GT_accuracy_available=False);save(f'metrics/{method}_{key}_{repeat}_history.json',hist);print('BA',method,key,repeat,'frames',np.isfinite(pp[:,0,0]).sum(),'points',len(xx),'last',hist[-1],flush=True)
   record.update(success=True,registered=int(np.isfinite(P[:,0,0]).sum()),points=len(X),same_initial_state=True,same_point_ids=True,same_observation_mask=True,same_optimization_steps=cfg['BA_steps']);records.append(record);save('metrics/ablation_status.json',records)
 freeze('ablation_predictions',list((R/'predictions').glob('[AC]_*.npz'))+[R/'metrics/ablation_status.json']+list((R/'metrics').glob('*_history.json')));print('ABLATION_COMPLETE')
if __name__=='__main__':main()

"""Frozen predictions; independent whole held-out tracks and whole ring frames.
No real camera/shape GT. Every failure remains in denominator, no residual filtering.
"""
from common import *
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
from run_ablation import contours
import csv,itertools

def holdout(poses,K,xy,held,cat,restricted=None):
 errors=[];classes=[];targeterrors=[];records=[];pos=[];parallax=[]
 for j in held:
  fr=[i for i in range(16) if np.isfinite(xy[j,i,0]) and np.isfinite(poses[i,0,0]) and (restricted is None or i in restricted)]
  if len(fr)<3:continue
  # Fixed endpoint anchors that exclude reference8, to genuinely test reference8.
  anchors=[i for i in fr if i!=8];a,b=anchors[0],anchors[-1];test=[i for i in fr if i not in [a,b]];P=triangle(xy[j,[a,b]],poses[[a,b]],K)
  u,z=project(np.tile(P,(len(fr),1)),poses,np.array(fr),K);e=np.linalg.norm(u-xy[j,fr],axis=1);pa=float(angle(P,poses[a,:3,3],poses[b,:3,3]));positive=bool((z>0).all());pos.append(positive);parallax.append(pa)
  ee=[]
  for i in test:
   v=float(e[fr.index(i)]);errors.append(v);classes.append(int(cat[j]));ee.append(v)
   if i==8:targeterrors.append(v)
  records.append(dict(track=int(j),category=int(cat[j]),anchors=[a,b],test_frames=test,test_errors=ee,positive=positive,parallax_deg=pa))
 errors=np.asarray(errors);classes=np.asarray(classes)
 return dict(target_heldout_tracks=len(held),testable_tracks=len(records),error_px=stats(errors),polyp_error_px=stats(errors[classes==1]),background_error_px=stats(errors[classes==0]),reference8_error_px=stats(targeterrors),positive_track_fraction=float(np.mean(pos)) if pos else None,anchor_parallax_deg=stats(parallax),tracks=records,protocol='whole track holdout from initialization/BA; two endpoint observations other than reference8 triangulate; all remaining observations test; no error/negative-depth exclusion')

def ring_eval(poses,K,whole_frames=False):
 errors=[];records=[];regime=[]
 for i in range(16):
  if whole_frames and i not in config()['ring_frame_holdout']:continue
  if not np.isfinite(poses[i,0,0]):records.append(dict(frame=i,status='unregistered',errors=None));continue
  ob=np.load(R/f'observations/{i:03d}.npz');q=ob['ring_heldout'] if not whole_frames else ob['direct_work'];C=poses[i,:3,3];cos=abs(C[2])/np.linalg.norm(C);regime.append(cos)
  try:
   pred=contours(C,poses[i,:3,:3],K,n=1024).reshape(-1,2);ee=cKDTree(pred).query(q)[0];errors.extend(ee);records.append(dict(frame=i,status='numeric',error_px=stats(ee)))
  except ValueError:records.append(dict(frame=i,status='invalid_contour_regime',error_px=stats([])))
 return dict(error_px=stats(errors),frames=records,min_view_cosine=min(regime,default=None),warning='whole frames4/11 absent from ring alignment and BA; boundary holdout elsewhere is same-frame local diagnostic; upstream DXY proposals see full masks')

def geometry(pack,xy,cat):
 P=pack['c2w'];X=pack['points'];ids=pack['point_ids'];mask=pack['observation_mask'];active=np.flatnonzero(np.isfinite(P[:,0,0]));err=[];pos=[];angles=[];accepted=[];records=[]
 for n,(x,j) in enumerate(zip(X,ids)):
  fr=[int(i) for i in active if mask[n,i] and np.isfinite(xy[j,i,0])]
  u,z=project(np.tile(x,(len(fr),1)),P,np.array(fr),pack['K']);e=np.linalg.norm(u-xy[j,fr],axis=1);pa=max([float(angle(x,P[a,:3,3],P[b,:3,3])) for a,b in itertools.combinations(fr,2)],default=0.);good=bool((z>0).all() and len(fr)>=3 and pa>=1 and np.max(e)<=2);err.extend(e);pos.extend(z>0);angles.append(pa);accepted.append(good);records.append(dict(track=int(j),category=int(cat[j]),frames=fr,positive=bool((z>0).all()),maxparallax_deg=pa,reprojection=stats(e),geometric_gate=good,reference8_visible=bool(np.isfinite(xy[j,8,0]))))
 steps=[]
 for a,b in zip(active[:-1],active[1:]):steps.append(dict(a=int(a),b=int(b),rotation_deg=float(np.degrees(np.linalg.norm(Rotation.from_matrix(P[b,:3,:3].T@P[a,:3,:3]).as_rotvec()))),distance_nominal_mm=float(np.linalg.norm(P[b,:3,3]-P[a,:3,3]))))
 return dict(registered=active.tolist(),reference8=bool(np.isfinite(P[8,0,0])),candidate_points=len(X),polyp_points=int((cat[ids]==1).sum()),background_points=int((cat[ids]==0).sum()),geometric_points=int(np.sum(accepted)),positive_fraction=float(np.mean(pos)) if pos else None,training_error_px=stats(err),max_pair_parallax_deg=stats(angles),point_records=records,camera_steps=steps,largest_rotation_step_deg=max([s['rotation_deg'] for s in steps],default=None),camera_accuracy_mm=None,polyp_shape_accuracy_mm=None)

def simalign(P,Q):
 ids=np.flatnonzero(np.isfinite(P[:,0,0])&np.isfinite(Q[:,0,0]));x=P[ids,:3,3];y=Q[ids,:3,3];xc=x-x.mean(0);yc=y-y.mean(0);u,s,v=np.linalg.svd(yc.T@xc);U=u@np.diag([1,1,np.linalg.det(u@v)])@v;scale=float(np.sum(yc*(xc@U.T))/np.sum(xc**2));t=y.mean(0)-scale*U@x.mean(0);e=np.linalg.norm(scale*(x@U.T)+t-y,axis=1);return dict(scale=scale,error=stats(e),translation=t.tolist(),rotation=U.tolist(),not_GT_accuracy=True)

def main():
 cfg=config();pack=np.load(R/'observations/tracks.npz');xy=pack['xy'];cat=pack['category'];held=np.flatnonzero(~pack['train_track']&pack['holdout_eligible']);result={};paired=[];rows=[]
 for kc in cfg['intrinsics']:
  key=kc['name'];result[key]={'A':[],'C':[]}
  for repeat in range(3):
   files={m:R/f'predictions/{m}_{key}_{repeat}.npz' for m in ['A','C']}
   if not all(p.exists() for p in files.values()):continue
   packs={m:np.load(p) for m,p in files.items()};sameids=np.array_equal(packs['A']['point_ids'],packs['C']['point_ids']);samemask=np.array_equal(packs['A']['observation_mask'],packs['C']['observation_mask']);assert sameids and samemask
   common=np.flatnonzero(np.isfinite(packs['A']['c2w'][:,0,0])&np.isfinite(packs['C']['c2w'][:,0,0]));pair=dict(K=key,repeat=repeat,common_frames=common.tolist(),same_train_ids=sameids,same_train_observations=samemask)
   for method,p in packs.items():
    item=geometry(p,xy,cat);item['heldout']=holdout(p['c2w'],p['K'],xy,held,cat);item['ring_boundary_diagnostic']=ring_eval(p['c2w'],p['K']);item['ring_whole_frame_holdout']=ring_eval(p['c2w'],p['K'],True)
    ac=cfg['acceptance'];item['basic_validation']=bool(len(item['registered'])>=ac['min_registered'] and item['reference8'] and item['heldout']['testable_tracks']>=ac['min_test_tracks'] and item['heldout']['error_px']['MAE']<=ac['max_holdout_MAE_px'] and item['positive_fraction']>=ac['min_positive_fraction'] and item['largest_rotation_step_deg']<=ac['max_rotation_step_deg']);item['repeat']=repeat;result[key][method].append(item);pair[method]=holdout(p['c2w'],p['K'],xy,held,cat,common);e=item['heldout']['error_px'];rows.append(dict(K=key,repeat=repeat,method=method,registered=len(item['registered']),reference8=item['reference8'],points=len(p['points']),polyp_points=item['polyp_points'],background_points=item['background_points'],geometric_points=item['geometric_points'],positive_fraction=item['positive_fraction'],heldout_n=e['n'],heldout_median_px=e['median'],heldout_MAE_px=e['MAE'],heldout_p95_px=e['p95'],heldout_max_px=e['max'],reference8_heldout_MAE_px=item['heldout']['reference8_error_px']['MAE'],ring_whole_frame_MAE_px=item['ring_whole_frame_holdout']['error_px']['MAE'],max_rotation_step_deg=item['largest_rotation_step_deg'],basic_validation=item['basic_validation'],real_pose_error_mm=None))
   paired.append(pair)
 stability={}
 for kc in cfg['intrinsics']:
  key=kc['name'];stability[key]={}
  for method in ['A','C']:
   paths=[R/f'predictions/{method}_{key}_{r}.npz' for r in range(3)]
   if not all(p.exists() for p in paths):continue
   P=[np.load(p)['c2w'] for p in paths];centers=np.array([p[:,:3,3] for p in P]);dev=np.linalg.norm(centers-centers.mean(0),axis=2);stability[key][method]=dict(ring_gauge_center_spread_nominal_mm=stats(dev.ravel()),one_global_Sim3_to_repeat0=[simalign(p,P[0]) for p in P[1:]],not_GT_accuracy=True)
 save('metrics/results.json',dict(methods=result,paired_common_support=paired,initialization_stability=stability,target_groups=1,GT_available=False,relative_metric_error_or_ATE=None,shared_ring_scale_initialization=True,strict_AC_same_state_ablation=True,acceptance=cfg['acceptance']))
 with (R/'metrics/summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 freeze('evaluation',[Path(__file__),R/'metrics/results.json',R/'metrics/summary.csv']);print(json.dumps(rows,indent=2))
if __name__=='__main__':main()

from common import *
import shutil,subprocess
assert not (R/'config.json').exists()
cfg=dict(video='GP_Ip_12.0mm_closed_R10_single_refY_004.mp4',reference=8,frames=16,R_mm=5.6,r_mm=.6,intrinsics=json.loads((OLD/'config.json').read_text())['intrinsics'],work_size=[640,360],raw_stride=4,corners_per_seed=600,minimum_spacing=5,quality=.003,LK_window=31,LK_levels=4,FB_px=.6,NCC=.8,ring_dilate_px=6,glare_dilate_px=3,minimum_keyviews=3,merge_px=1.25,held_track_mod=5,seed_keys=list(range(16)),initialization_reference=8,initializer_min_points=20,triangulation_min_deg=1.,triangulation_max_px=2.,PnP_min_inliers=12,PnP_px=2.,BA_steps=100,BA_robust_px=1.,ring_weight=1.,ring_frame_holdout=[4,11],repeats=3,seed=20261016,scope='manual-confirmed static polyp+ring+background; fixed original16frames and ref8; no GT, no DA2, no Dxy measurements',acceptance=dict(min_registered=13,min_test_tracks=20,max_holdout_MAE_px=2.,min_positive_fraction=.95,max_rotation_step_deg=30.))
save('config.json',cfg)
manifest=json.loads((OLD/'inputs/manifest.json').read_text())
for i,row in enumerate(manifest):
 for kind,ext,key in [('images','jpg','image_sha256'),('masks','png','mask_sha256')]:
  p=OLD/f'inputs/{kind}/{i:03d}.{ext}';assert sha(p)==row[key];shutil.copyfile(p,R/f'inputs/{kind}/{i:03d}.{ext}')
 # Reuse verified 2D DXY observations; no old3D predictions used as new output.
 shutil.copyfile(OLD/f'observations/{i:03d}.npz',R/f'observations/{i:03d}.npz')
save('inputs/manifest.json',manifest)
save('preparation/reuse.json',dict(source_run=str(OLD),reused='strict RGB/INIT label caches and DXY2D ring observations, full torus code; prior B candidates only for global gauge initialization if needed; never a camera/point fallback',DXY_head=subprocess.check_output(['git','-C',str(DXY),'rev-parse','HEAD'],text=True).strip(),DXY_branch=subprocess.check_output(['git','-C',str(DXY),'branch','--show-current'],text=True).strip(),DXY_observation_hashes={str(OLD/f'observations/{i:03d}.npz'):sha(OLD/f'observations/{i:03d}.npz') for i in range(16)},segmentation_provenance=json.loads((OLD/'preparation/segmentation_provenance.json').read_text())))
protected={}
# Reuse the previous protected inventory, refresh actual current hashes and add entire V2.
base=json.loads((R.parent/'ring_first_v2_real_ba/metrics/protected.json').read_text())
paths=[Path(p) for p in base]
paths.extend(p for p in (R.parent/'ring_first_v2_real_ba').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for p in sorted(set(paths)):
 if p.is_file():protected[str(p.resolve())]=dict(sha256=sha(p),mtime_ns=p.stat().st_mtime_ns)
save('metrics/protected.json',protected)
save('metrics/git_before.json',{str(p):{k:subprocess.check_output(['git','-C',str(p),*args],text=True).rstrip('\n') for k,args in [('head',['rev-parse','HEAD']),('branch',['branch','--show-current']),('status',['status','--porcelain','--untracked-files=no'])]} for p in [PROJECT,DXY]})
freeze('inputs',[R/'config.json',R/'inputs/manifest.json',R/'preparation/reuse.json']+[p for p in (R/'inputs').rglob('*') if p.is_file()]+list((R/'observations').glob('*.npz')))
print('Setup complete protected',len(protected))

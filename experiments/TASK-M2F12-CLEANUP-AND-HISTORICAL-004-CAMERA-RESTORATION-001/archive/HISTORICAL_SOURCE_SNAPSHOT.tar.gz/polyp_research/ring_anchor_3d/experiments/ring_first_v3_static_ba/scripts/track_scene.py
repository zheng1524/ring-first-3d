"""Multi-source, two-direction LK over intervening raw frames, native keyframes fixed.
Only image evidence, no camera/ring pose/GT input. Key observations never on ring.
"""
from common import *
from scipy.spatial import cKDTree
cv2.setNumThreads(4)
def masks(i):
 im=cv2.resize(cv2.imread(str(R/f'inputs/images/{i:03d}.jpg')),(640,360),interpolation=cv2.INTER_AREA)
 lab=cv2.resize(cv2.imread(str(R/f'inputs/masks/{i:03d}.png'),0),(640,360),interpolation=cv2.INTER_NEAREST)
 glare=cv2.dilate(((im.min(2)>235)&(im.max(2)>248)).astype('uint8'),np.ones((7,7),np.uint8))>0
 valid=(cv2.dilate((lab==2).astype('uint8'),np.ones((13,13),np.uint8))==0)&(~glare)&(im.max(2)>45)
 # Exclude 4-pixel classification interface to avoid relabeling boundary points.
 interface=cv2.dilate((lab==1).astype('uint8'),np.ones((9,9),np.uint8))!=cv2.erode((lab==1).astype('uint8'),np.ones((9,9),np.uint8));valid&=~interface;valid[:8]=False;valid[-8:]=False;valid[:,:8]=False;valid[:,-8:]=False
 return valid.astype('uint8')*255,lab,im

def ncc(a,b,p,q):
 out=np.zeros(len(p),bool)
 for j,(x,y) in enumerate(zip(p,q)):
  pa=cv2.getRectSubPix(a,(11,11),tuple(map(float,x))).astype(float);pb=cv2.getRectSubPix(b,(11,11),tuple(map(float,y))).astype(float);pa-=pa.mean();pb-=pb.mean();v=np.linalg.norm(pa)*np.linalg.norm(pb);out[j]=v>1 and (pa*pb).sum()/v>=config()['NCC']
 return out

def main():
 conf=config();manifest=json.loads((R/'inputs/manifest.json').read_text());keys=np.array([r['frame_index'] for r in manifest]);timeline=sorted(set(range(int(keys[0]),int(keys[-1])+1,conf['raw_stride']))|set(keys.tolist()));index={int(n):i for i,n in enumerate(keys)};cache={};valid={};labels={}
 video=PROJECT/'smart_endoscope_20260805/raw'/conf['video'];assert sha(video)==json.loads((R/'preparation/reuse.json').read_text())['segmentation_provenance']['video_sha256'];cap=cv2.VideoCapture(str(video));target=set(timeline)
 for raw in range(int(keys[-1])+1):
  ok,bgr=cap.read();assert ok
  if raw in target:cache[raw]=cv2.cvtColor(cv2.resize(bgr,(640,360),interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2GRAY)
 cap.release()
 for i,k in enumerate(keys):v,l,im=masks(i);valid[i]=v;labels[i]=l;cache[int(k)]=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
 freeze('tracking_protocol',[Path(__file__),R/'config.json',R/'inputs/manifest.json'])
 records=[];logs=[]
 for direction in [1,-1]:
  order=timeline if direction==1 else timeline[::-1];active=[];p=np.empty((0,2),np.float32);prev=None
  for step,raw in enumerate(order):
   gray=cache[raw]
   if prev is not None and len(p):
    q,st,_=cv2.calcOpticalFlowPyrLK(cache[prev],gray,p.reshape(-1,1,2),None,winSize=(31,31),maxLevel=4,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01));back,st2,_=cv2.calcOpticalFlowPyrLK(gray,cache[prev],q,None,winSize=(31,31),maxLevel=4,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01));q=q.reshape(-1,2);back=back.reshape(-1,2);ok=st.ravel().astype(bool)&st2.ravel().astype(bool)&(np.linalg.norm(p-back,axis=1)<conf['FB_px'])&(q[:,0]>8)&(q[:,0]<632)&(q[:,1]>8)&(q[:,1]<352)
    inds=np.flatnonzero(ok);ok[inds]&=ncc(cache[prev],gray,p[inds],q[inds]);p=q[ok];active=[active[j] for j in np.flatnonzero(ok)]
   if raw in index:
    i=index[raw]
    if len(p):
     loc=np.rint(p).astype(int);ok=valid[i][loc[:,1],loc[:,0]]>0
     # Track category is fixed; geometry only sees actual ring-free observations.
     ok&=np.array([labels[i][y,x]==records[j]['category'] for j,(x,y) in zip(active,loc)])
     p=p[ok];active=[active[j] for j in np.flatnonzero(ok)]
     for j,q in zip(active,p):records[j]['xy'][i]=q
    seedmask=valid[i].copy()
    for q in p:cv2.circle(seedmask,tuple(np.rint(q).astype(int)),conf['minimum_spacing'],-0,thickness=-1)
    corners=cv2.goodFeaturesToTrack(gray,maxCorners=conf['corners_per_seed'],qualityLevel=conf['quality'],minDistance=conf['minimum_spacing'],mask=seedmask)
    new=[]
    if corners is not None:
     for q in corners.reshape(-1,2):
      x,y=np.rint(q).astype(int);j=len(records);xy=np.full((16,2),np.nan);xy[i]=q;records.append(dict(xy=xy,category=int(labels[i][y,x]),source=i,direction=direction));active.append(j);new.append(q)
     p=np.r_[p,np.asarray(new,dtype=np.float32).reshape(-1,2)]
    logs.append(dict(direction=direction,key=i,raw=raw,active=len(active),spawned=len(new)));print('TRACK',direction,i,'active',len(active),'spawn',len(new),flush=True)
   prev=raw
 # Deterministic merge physical-point candidates from overlapping source tracks.
 rawtracks=[r for r in records if np.isfinite(r['xy'][:,0]).sum()>=conf['minimum_keyviews']];xy=np.array([r['xy'] for r in rawtracks]);cat=np.array([r['category'] for r in rawtracks]);length=np.isfinite(xy[:,:,0]).sum(1);paircounts={}
 for i in range(16):
  ids=np.flatnonzero(np.isfinite(xy[:,i,0]));pts=xy[ids,i];pairs=cKDTree(pts).query_pairs(conf['merge_px'])
  for a,b in pairs:
   a,b=int(ids[a]),int(ids[b])
   if cat[a]!=cat[b]:continue
   paircounts[(a,b)]=paircounts.get((a,b),0)+1
 parent=np.arange(len(xy));groups=xy.copy();weight=np.isfinite(xy[:,:,0]).astype(float)
 def root(a):
  while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
  return a
 merged=0
 for (a,b),count in sorted(paircounts.items(),key=lambda x:(-x[1],x[0])):
  if count<2:continue
  a,b=root(a),root(b)
  if a==b:continue
  both=np.isfinite(groups[a,:,0])&np.isfinite(groups[b,:,0]);dist=np.linalg.norm(groups[a,both]-groups[b,both],axis=1)
  if both.sum()<2 or dist.max()>conf['merge_px']:continue
  va=np.nan_to_num(groups[a])*weight[a,:,None];vb=np.nan_to_num(groups[b])*weight[b,:,None];w=weight[a]+weight[b];groups[a]=np.divide(va+vb,w[:,None],out=np.full((16,2),np.nan),where=w[:,None]>0);weight[a]=w;parent[b]=a;merged+=1
 roots=np.array([i for i in range(len(xy)) if root(i)==i]);out=groups[roots];category=cat[roots];train=np.arange(len(roots))%5!=0
 # Reject any train/test near-duplicate with >=2 matching views (prevent leakage).
 duplicates=set()
 for a in np.flatnonzero(~train):
  for b in np.flatnonzero(train):
   both=np.isfinite(out[a,:,0])&np.isfinite(out[b,:,0]);dist=np.linalg.norm(out[a,both]-out[b,both],axis=1)
   if (dist<2.).sum()>=2:duplicates.add(a);break
 holdvalid=np.ones(len(out),bool);holdvalid[list(duplicates)]=False
 np.savez_compressed(R/'observations/tracks.npz',xy=out,category=category,train_track=train,holdout_eligible=holdvalid,source=roots,lengths=np.isfinite(out[:,:,0]).sum(1),raw_xy=xy)
 counts=[];edges=[]
 for i in range(16):
  seen=np.isfinite(out[:,i,0]);counts.append(dict(key=i,raw=int(keys[i]),tracks=int(seen.sum()),polyp=int((seen&(category==1)).sum()),background=int((seen&(category==0)).sum()),train=int((seen&train).sum()),holdout=int((seen&~train&holdvalid).sum())))
  for j in range(i+1,16):
   both=seen&np.isfinite(out[:,j,0]);edges.append(dict(a=i,b=j,total=int(both.sum()),polyp=int((both&(category==1)).sum()),background=int((both&(category==0)).sum())))
 save('metrics/tracking.json',dict(keyframes=counts,edges=edges,source_pass_logs=logs,raw_intermediate_count=len(timeline)-16,total_seeded=len(records),raw_long_tracks=len(rawtracks),merged=merged,tracks=len(out),train=int(train.sum()),holdout=int((~train&holdvalid).sum()),excluded_nearduplicate_holdouts=len(duplicates),category_1='polyp',category_0='background',GT_used=False,raw_ring_note='exact ring masks exclude all keyframe feature observations; intervening frames only propagate existing features using FB/NCC, never add geometric observations'))
 freeze('tracks',[R/'observations/tracks.npz',R/'metrics/tracking.json',Path(__file__),R/'config.json']);print('TRACKING COMPLETE',len(out),counts[8],flush=True)
if __name__=='__main__':main()

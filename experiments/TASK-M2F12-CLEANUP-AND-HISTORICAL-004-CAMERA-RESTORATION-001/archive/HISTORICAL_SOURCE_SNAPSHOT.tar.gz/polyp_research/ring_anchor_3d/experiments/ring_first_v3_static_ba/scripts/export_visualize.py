from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from run_ablation import contours
import csv,shutil

def ply(path,X,colors):
 with path.open('w') as f:
  f.write('ply\nformat ascii 1.0\nelement vertex '+str(len(X))+'\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n')
  for x,c in zip(X,colors):f.write(' '.join([*(f'{v:.7f}' for v in x),*(str(int(v)) for v in c)])+'\n')

def ring(ax):
 th=np.linspace(0,2*np.pi,180)
 for ph in [0,np.pi/2,np.pi,3*np.pi/2]:ax.plot((5.6+.6*np.cos(ph))*np.cos(th),(5.6+.6*np.cos(ph))*np.sin(th),np.full(len(th),.6*np.sin(ph)),c='black',lw=.6)
 ax.set(xlabel='ring X nominal mm',ylabel='ring Y nominal mm',zlabel='ring Z nominal mm')

def main():
 plt.rcParams.update({'font.size':8});V=R/'visualizations';cfg=config();p=np.load(R/'observations/tracks.npz');xy=p['xy'];cat=p['category'];track=json.loads((R/'metrics/tracking.json').read_text());results=json.loads((R/'metrics/results.json').read_text());diag=json.loads((R/'metrics/diagnostics.json').read_text());manifest=json.loads((R/'inputs/manifest.json').read_text());old=np.load(OLD/'observations/features.npz')['all_xy'];oldcount=np.isfinite(old[:,:,0]).sum(0);newcount=np.array([x['tracks'] for x in track['keyframes']]);bgcount=np.array([x['background'] for x in track['keyframes']]);polcount=newcount-bgcount
 def rgb(i):return cv2.resize(cv2.imread(str(R/f'inputs/images/{i:03d}.jpg')),(640,360),interpolation=cv2.INTER_AREA)[:,:,::-1]
 fig,axes=plt.subplots(2,2,figsize=(13,9),constrained_layout=True)
 axes[0,0].plot(range(16),oldcount,'o-',label='V2 first-frame polyp only');axes[0,0].plot(range(16),newcount,'o-',label='V3 all static scene multi-source');axes[0,0].axvline(8,c='red',ls='--');axes[0,0].set(yscale='log',xlabel='fixed keyframe index',ylabel='tracks >=3 key views (log)',title='Reference8: 3 ->1855 tracks');axes[0,0].legend()
 axes[0,1].bar(range(16),bgcount,label='background');axes[0,1].bar(range(16),polcount,bottom=bgcount,label='polyp');axes[0,1].set(xlabel='keyframe',ylabel='track observations',title='Static background supplies most correspondences');axes[0,1].legend()
 con=np.zeros((16,16))
 for e in track['edges']:con[e['a'],e['b']]=con[e['b'],e['a']]=e['total']
 im=axes[1,0].imshow(con,cmap='viridis');axes[1,0].set(title='Overlapping track graph (all classes)',xlabel='keyframe',ylabel='keyframe');fig.colorbar(im,ax=axes[1,0],label='shared tracks')
 axes[1,1].imshow(rgb(8));seen=np.isfinite(xy[:,8,0]);ids=np.flatnonzero(seen)
 for c,color,name in [(0,'cyan','background'),(1,'red','polyp')]:
  ii=ids[cat[ids]==c];ii=ii[::max(1,len(ii)//250)];axes[1,1].scatter(*xy[ii,8].T,s=5,c=color,label=name)
 axes[1,1].legend();axes[1,1].set(title='Fixed reference8/raw674: category labels retained');axes[1,1].axis('off');fig.suptitle('Same real video and fixed16 keyframes;270 intervening raw frames support tracking.');fig.savefig(V/'fig1_old_new_tracks.png',dpi=150);plt.close(fig)
 fig,axes=plt.subplots(2,1,figsize=(13,8),constrained_layout=True)
 for ax,j in zip(axes,[7,9]):
  ax.imshow(np.hstack([rgb(8),rgb(j)]));both=np.flatnonzero(np.isfinite(xy[:,8,0])&np.isfinite(xy[:,j,0]));sel=[]
  for c in [0,1]:
   ii=both[cat[both]==c];sel.extend(ii[::max(1,len(ii)//35)].tolist())
  for n in sel:
   a=xy[n,8];b=xy[n,j]+[640,0];color='cyan' if cat[n]==0 else 'red';ax.plot([a[0],b[0]],[a[1],b[1]],c=color,lw=.4,alpha=.6)
  ax.set(title=f'Reference8 -> {j}: {len(both)} shared tracks; cyan background/red polyp; fixed-stride display subset');ax.axis('off')
 fig.savefig(V/'fig2_reference8_matches.png',dpi=155);plt.close(fig)
 default='F980';repeat=0;A=np.load(R/f'predictions/A_{default}_{repeat}.npz');C=np.load(R/f'predictions/C_{default}_{repeat}.npz')
 fig=plt.figure(figsize=(14,7));ax=fig.add_subplot(121,projection='3d');ring(ax)
 for pp,color,name in [(A,'blue','A feature BA, shared ring scale'),(C,'orange','C feature + ring')]:
  cc=pp['c2w'][:,:3,3];ax.plot(*cc.T,'o-',c=color,label=name,lw=1,ms=3);ax.scatter(*cc[8],c=color,marker='*',s=100)
 ax.set_title('Same frozen initialization / same16 cameras; ref8 = star');ax.legend(fontsize=6);ax.view_init(25,-50)
 ax=fig.add_subplot(122,projection='3d');ring(ax);X=A['points'];cats=cat[A['point_ids']];target=np.isfinite(xy[A['point_ids'],8,0])&(cats==1)
 for mask,color,label in [(cats==0,'cyan','background auxiliary'),((cats==1)&~target,'pink','polyp other-view auxiliary'),(target,'red','reference8-visible polyp candidates')]:ax.scatter(*X[mask].T,c=color,s=2,label=label,alpha=.5)
 ax.plot(*A['c2w'][:,:3,3].T,c='blue',lw=.7);ax.set_title('Diagnostic candidates, NOT validated reconstruction');ax.legend(fontsize=6);ax.view_init(25,-50);fig.suptitle('One common ring coordinate system. Nominal mm != verified mm accuracy; no per-frame ICP.');fig.tight_layout();fig.savefig(V/'fig3_ring_cameras_classes.png',dpi=155);plt.close(fig)
 fig,axes=plt.subplots(1,3,figsize=(14,4),constrained_layout=True)
 for ax,key in zip(axes,['H70','F980','D70']):
  for m,color in [('A','blue'),('C','orange')]:
   a=results['methods'][key][m];ax.plot(range(3),[x['heldout']['error_px']['MAE'] for x in a],'o-',c=color,label=m);ax.plot(range(3),[x['heldout']['reference8_error_px']['MAE'] for x in a],':',c=color,alpha=.6)
  ax.set(title=key,xlabel='independent initialization pair index',ylabel='heldout reprojection MAE px',yscale='log',xticks=[0,1,2]);ax.axhline(2,c='black',ls='--',lw=.6);ax.legend()
 fig.suptitle('Solid=all605 heldout tracks, dotted=reference8 test. Same common observations, all failures retained.');fig.savefig(V/'fig4_AC_heldout.png',dpi=170);plt.close(fig)
 fig,axes=plt.subplots(2,3,figsize=(14,8),constrained_layout=True)
 for row,i in enumerate([8,11]):
  ax=axes[row,0];ax.imshow(rgb(i));ob=np.load(R/f'observations/{i:03d}.npz');q=ob['direct_work'];ax.scatter(*q.T,s=3,c='lime',label='trusted visible Ring observations');ax.set_title(f'Frame{i} raw{manifest[i]["frame_index"]}'+(' / whole-frame RING holdout' if i==11 else ' / reference'));ax.axis('off');ax.legend(fontsize=6)
  for col,(m,pp,color) in enumerate([('A',A,'blue'),('C',C,'orange')],1):
   ax=axes[row,col];ax.imshow(rgb(i));C0=pp['c2w'][i];curve=contours(C0[:3,3],C0[:3,:3],pp['K'],n=512)
   for cr in curve:ax.plot(*cr.T,c=color,lw=.8)
   ax.scatter(*q.T,c='lime',s=2);y,x=np.nonzero(ob['ring_mask']|ob['polyp_mask']);ax.set(xlim=(x.min()-20,x.max()+20),ylim=(y.max()+20,y.min()-20),title=m+' full torus silhouette, not GT');ax.axis('off')
 fig.suptitle('No unseen contour forced onto polyp boundary; no camera or surface GT in real video.');fig.savefig(V/'fig5_ring_reprojection.png',dpi=160);plt.close(fig)
 fig=plt.figure(figsize=(15,5))
 for n,key in enumerate(['H70','F980','D70']):
  ax=fig.add_subplot(1,3,n+1,projection='3d');ring(ax)
  for rr in range(3):
   for m,color,style in [('A','blue','-'),('C','orange','--')]:
    pp=np.load(R/f'predictions/{m}_{key}_{rr}.npz')['c2w'];cc=pp[:,:3,3];ax.plot(*cc.T,c=color,ls=style,lw=.7,alpha=.7,label=m if rr==0 else None)
  ax.set_title(key+' all3 initializations, no individual alignment');ax.view_init(25,-50);ax.legend(fontsize=6)
 fig.suptitle('Ring-frame stability: different solutions cannot be interpreted as GT position errors.');fig.tight_layout();fig.savefig(V/'fig6_initialization_sensitivity.png',dpi=145);plt.close(fig)
 fig,axes=plt.subplots(1,2,figsize=(13,5),constrained_layout=True)
 for ax,m in zip(axes,['A','C']):
  pp=np.load(R/f'predictions/{m}_F980_0.npz');s=results['methods']['F980'][m][0];X=pp['points'];ids=pp['point_ids'];valid=np.array([x['geometric_gate'] for x in s['point_records']]);vis=(cat[ids]==1)&np.isfinite(xy[ids,8,0]);pc=(X-pp['c2w'][8,:3,3])@pp['c2w'][8,:3,:3];u=pc@pp['K'].T;u=u[:,:2]/u[:,2:];ax.imshow(rgb(8));ax.scatter(*u[vis&valid].T,c='lime',s=12,label='positive,1deg,2px candidate');ax.scatter(*u[vis&~valid].T,c='red',marker='x',s=12,label='failed point gate');ax.set(xlim=(180,480),ylim=(300,70),title=f'{m}: reference-visible polyp candidates only; not accepted geometry');ax.legend(fontsize=6);ax.axis('off')
 fig.suptitle('Point gates do not replace independent validation; no hidden surface is completed.');fig.savefig(V/'fig7_target_sparse_candidates.png',dpi=160);plt.close(fig)
 # Export numerical candidates for every K/initialization, not only display example.
 source=PROJECT/'ring_anchor_3d/assets/ring_R10.obj';shutil.copyfile(source,R/'geometry/known_R10_torus.obj');rows=[]
 for key in ['H70','F980','D70']:
  for m in ['A','C']:
   for rr in range(3):
    pp=np.load(R/f'predictions/{m}_{key}_{rr}.npz');s=results['methods'][key][m][rr];X=pp['points'];ids=pp['point_ids'];cats=cat[ids];colors=np.where((cats==1)[:,None],np.array([[230,70,70]]),np.array([[50,160,230]]));ply(R/f'geometry/UNCERTAIN_{m}_{key}_{rr}_all.ply',X,colors);valid=np.array([x['geometric_gate'] for x in s['point_records']]);target=(cats==1)&np.isfinite(xy[ids,8,0])&valid;ply(R/f'geometry/UNCERTAIN_{m}_{key}_{rr}_reference_polyp.ply',X[target],colors[target])
    for i in range(16):rows.append(dict(method=m,K=key,repeat=rr,frame=i,raw_frame=manifest[i]['frame_index'],candidate_numeric=bool(pp['registered'][i]),basic_validated_run=s['basic_validation'],x=pp['c2w'][i,0,3],y=pp['c2w'][i,1,3],z=pp['c2w'][i,2,3],unit='shared_ring_model_nominal_mm',real_accuracy_mm=None))
    np.savez_compressed(R/f'geometry/ACCEPTED_{m}_{key}_{rr}.npz',c2w=pp['c2w'] if s['basic_validation'] else np.full((16,4,4),np.nan),points=X[target] if s['basic_validation'] else np.empty((0,3)),accepted=bool(s['basic_validation']))
 with (R/'geometry/camera_candidates.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 save('geometry/VALIDITY.json',dict(all_exports_diagnostic_candidates=True,accepted_runs=sum(z['basic_validation'] for k in results['methods'].values() for a in k.values() for z in a),trusted_target_reconstruction=False,no_hidden_completion=True,no_mesh=True,no_volume=True,reference8=8,reference_raw674=674,polyp_color=[230,70,70],background_color=[50,160,230],independent_mm_camera_GT=False,shared_scale_warning='A and C both share same ring-only global Sim3 scale/coordinate initialization; A not independently metric'))
 freeze('geometry_and_figures',[Path(__file__)]+list((R/'geometry').glob('*'))+list(V.glob('*.png')));print('EXPORTED 7figures and all candidate geometries')
if __name__=='__main__':main()

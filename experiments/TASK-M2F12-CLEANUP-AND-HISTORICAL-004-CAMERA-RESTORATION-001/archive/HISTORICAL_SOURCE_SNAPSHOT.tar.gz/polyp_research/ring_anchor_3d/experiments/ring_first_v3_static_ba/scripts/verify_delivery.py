from pathlib import Path
import hashlib,json,subprocess,ast,re,datetime
T=Path(__file__).resolve().parents[1]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
protected=json.loads((T/'metrics/protected.json').read_text());changes=[]
for p,entry in protected.items():
 p=Path(p)
 if not p.is_file():changes.append({'path':str(p),'reason':'missing'});continue
 if sha(p)!=entry['sha256'] or p.stat().st_mtime_ns!=entry['mtime_ns']:changes.append({'path':str(p),'reason':'content_or_mtime_changed'})
git=[]
for path,before in json.loads((T/'metrics/git_before.json').read_text()).items():
 now={k:subprocess.check_output(['git','-C',path,*args],text=True).rstrip('\n') for k,args in [('head',['rev-parse','HEAD']),('branch',['branch','--show-current']),('status',['status','--porcelain','--untracked-files=no'])]}
 git.append({'repo':path,'unchanged':all(now[k]==before[k].rstrip('\n') for k in now),'current':now})
freeze=[]
for m in sorted(T.rglob('freeze_*.json')):
 d=json.loads(m.read_text());bad=[]
 for p,h in d.get('files',{}).items():
  p=Path(p)
  if not p.is_file() or sha(p)!=h:bad.append(str(p))
 freeze.append({'manifest':str(m.relative_to(T)),'file_count':len(d.get('files',{})),'mismatch':bad})
syntax=[]
for p in sorted(T.rglob('*.py')):
 if 'runtime_cache' in p.parts:continue
 try:ast.parse(p.read_text())
 except Exception as e:syntax.append({'path':str(p),'reason':str(e)})
links=[]
for p in T.glob('*.md'):
 for dest in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not dest.startswith(('http','/','#')) and not (p.parent/dest.split('#')[0]).exists():links.append({'report':p.name,'target':dest})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protected_files_checked':len(protected),'protected_changes':changes,'git':git,'freeze_manifests':freeze,'python_syntax_failures':syntax,'report_missing_links':links,'old_asset_deletion_move_compression':False,'cleanup_candidates':0,'Dxy_code_measurements_or_results_modified':bool(changes or not git[1]['unchanged'])}
(T/'metrics/protection_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({'protected_checked':len(protected),'protected_changes':changes,'git_unchanged':[x['unchanged'] for x in git],'freeze_bad':[(x['manifest'],x['mismatch']) for x in freeze if x['mismatch']],'syntax':syntax,'missing_links':links},ensure_ascii=False))

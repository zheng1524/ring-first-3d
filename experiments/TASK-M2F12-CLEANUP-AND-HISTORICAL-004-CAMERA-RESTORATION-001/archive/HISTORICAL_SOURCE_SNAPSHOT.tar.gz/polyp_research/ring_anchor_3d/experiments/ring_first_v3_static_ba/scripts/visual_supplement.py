from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from export_visualize import ring
import csv

def main():
 d=json.loads((R/'metrics/results.json').read_text());p=np.load(R/'observations/tracks.npz');xy=p['xy'];cat=p['category'];rows=[]
 for k in ['H70','F980','D70']:
  for rr in range(3):
   for m in ['A','C']:
    h=d['methods'][k][m][rr]['heldout'];records=[x for x in h['tracks'] if x['category']==1 and 8 in x['test_frames']];vals=[x['test_errors'][x['test_frames'].index(8)] for x in records];rows.append(dict(K=k,repeat=rr,method=m,all_feature_MAE_px=h['error_px']['MAE'],polyp_MAE_px=h['polyp_error_px']['MAE'],background_MAE_px=h['background_error_px']['MAE'],ref8_polyp_n=len(vals),ref8_polyp_MAE_px=stats(vals)['MAE'],ref8_polyp_median_px=stats(vals)['median']))
 with (R/'metrics/class_paired_comparison.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 fig,axes=plt.subplots(2,3,figsize=(13,7),layout='constrained')
 for j,k in enumerate(['H70','F980','D70']):
  for m,c in [('A','blue'),('C','orange')]:
   r=[x for x in rows if x['K']==k and x['method']==m];axes[0,j].plot(range(3),[x['polyp_MAE_px'] for x in r],'o-',c=c,label=m+' polyp');axes[0,j].plot(range(3),[x['background_MAE_px'] for x in r],'--',c=c,label=m+' background');axes[1,j].plot(range(3),[x['ref8_polyp_MAE_px'] for x in r],'o-',c=c,label=m)
  axes[0,j].set(title=k+':23 polyp vs582 background heldout tracks',yscale='log',ylabel='MAE px');axes[0,j].legend(fontsize=6);axes[1,j].set(title='12 polyp heldout observations at fixed reference8',yscale='log',ylabel='MAE px',xlabel='initialization');axes[1,j].legend(fontsize=6)
 fig.suptitle('Local polyp validation sometimes improves; this does NOT establish metric shape accuracy or robust camera poses.');fig.savefig(R/'visualizations/fig8_class_specific_validation.png',dpi=160);plt.close(fig)
 A=np.load(R/'predictions/A_F980_0.npz');C=np.load(R/'predictions/C_F980_0.npz');fig=plt.figure(figsize=(13,7));ax=fig.add_subplot(121,projection='3d');ring(ax)
 for pp,color,name in [(A,'blue','A: shared ring scale + feature BA'),(C,'orange','C: same state + ring loss')]:
  cc=pp['c2w'][:,:3,3];ax.plot(*cc.T,'o-',c=color,label=name,lw=1,ms=3);ax.scatter(*cc[8],c=color,marker='*',s=100)
 ax.set_title('16 candidate cameras; star = fixed reference8',pad=12,fontsize=9);ax.legend(fontsize=6);ax.view_init(25,-50)
 ax=fig.add_subplot(122,projection='3d');ring(ax);X=A['points'];ids=A['point_ids'];cats=cat[ids];target=np.isfinite(xy[ids,8,0])&(cats==1)
 for mask,color,label in [(cats==0,'#409dcc','background auxiliary'),((cats==1)&~target,'pink','polyp outside reference8'),(target,'red','reference8-visible polyp')]:ax.scatter(*X[mask].T,c=color,s=2,label=label,alpha=.55)
 ax.plot(*A['c2w'][:,:3,3].T,c='blue',lw=.7);ax.set_title('Unvalidated sparse candidates; no surface completion',pad=12,fontsize=9);ax.legend(fontsize=6);ax.view_init(25,-50)
 fig.suptitle('Shared ring coordinates, nominal millimeters. No camera or surface GT.',y=.98,fontsize=12);fig.subplots_adjust(top=.87,bottom=.07,left=.03,right=.95,wspace=.18);fig.savefig(R/'visualizations/fig3b_ring_cameras_classes_clean.png',dpi=160);plt.close(fig)
 freeze('supplemental_visuals',[Path(__file__),R/'metrics/class_paired_comparison.csv',R/'visualizations/fig8_class_specific_validation.png',R/'visualizations/fig3b_ring_cameras_classes_clean.png']);print('Supplemental class metrics and readable figure produced')
if __name__=='__main__':main()

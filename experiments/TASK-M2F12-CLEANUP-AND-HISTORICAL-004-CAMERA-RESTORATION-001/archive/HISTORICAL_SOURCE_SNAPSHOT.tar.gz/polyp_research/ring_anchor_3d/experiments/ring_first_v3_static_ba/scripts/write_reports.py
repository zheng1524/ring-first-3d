from common import *
import csv,subprocess,ast
D=json.loads((R/'metrics/results.json').read_text());G=json.loads((R/'metrics/diagnostics.json').read_text());T=json.loads((R/'metrics/tracking.json').read_text());rows=list(csv.DictReader((R/'metrics/summary.csv').open()));classes=list(csv.DictReader((R/'metrics/class_paired_comparison.csv').open()))
AUDIT='''| 审计项目 | 必须汇报 |
| --- | --- |
| 目标组数 | 1组；同一视频、固定16帧、参考8/raw674；3内参×3初值×A/C |
| 本算法独立成功 | 数值候选1/1组；A、C各9/9次注册16/16含目标帧；通过预设完整验证0/1组 |
| 本算法失败 | A、C可靠性验证各9/9未通过；正式接受相机为NaN、可信目标点云为空；数值候选单独保留 |
| 历史测量值回退 | 0；不使用Dxy测量或旧相机/点云填补失败；明确授权的B环候选只参与共同坐标/尺度初始化 |
| 失败组及具体原因 | GP_Ip_12.0mm_closed_R10_single_refY：留出误差、分支不稳定，见[失败证据](FAILURES.md) |
| 最终统计样本 | 全部1组及18次A/C运行；每次605条整轨留出、2637测试观测；不只统计较好初值 |
| 是否使用 GT 选择算法 | 否；不读取真实相机/形态GT或Dxy真值；阶段输入、协议、预测及评价freeze哈希见metrics/ |
'''
def table(headers,lines):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(str,l))+' |' for l in lines)+'\n'
tracking=table(['帧','raw','V2首帧轨迹','V3轨迹','息肉','背景'],[(i,x['raw'],int(np.isfinite(np.load(OLD/'observations/features.npz')['all_xy'][:,i,0]).sum()),x['tracks'],x['polyp'],x['background']) for i,x in enumerate(T['keyframes'])])
paired=[];specific=[];failcount=0
for k in ['H70','F980','D70']:
 for rr in range(3):
  a=D['methods'][k]['A'][rr];c=D['methods'][k]['C'][rr];ha=a['heldout'];hc=c['heldout'];paired.append([k,rr,f"{ha['error_px']['MAE']:.3f}",f"{hc['error_px']['MAE']:.3f}",f"{ha['reference8_error_px']['MAE']:.3f}",f"{hc['reference8_error_px']['MAE']:.3f}",f"{a['ring_whole_frame_holdout']['error_px']['MAE']:.3f}",f"{c['ring_whole_frame_holdout']['error_px']['MAE']:.3f}"])
  specific.append([k,rr,f"{ha['polyp_error_px']['MAE']:.3f}",f"{hc['polyp_error_px']['MAE']:.3f}",f"{ha['background_error_px']['MAE']:.3f}",f"{hc['background_error_px']['MAE']:.3f}"])
full=table(['K','初值','方法','注册','候选点(息肉/背景)','几何门限点','留出中位/MAE/p95/最大px'],[[x['K'],x['repeat'],x['method'],x['registered']+'/16',x['points']+' ('+x['polyp_points']+'/'+x['background_points']+')',x['geometric_points'],'/'.join(f"{float(x[k]):.3f}" for k in ['heldout_median_px','heldout_MAE_px','heldout_p95_px','heldout_max_px'])] for x in rows])
tech='''# Ring-First V3：真实静态场景视觉定位与环联合优化

## 两个问题的回答

**Q1：加入背景与多源轨迹后，能否恢复固定参考帧8？** 数值定位取得明确进展：3种固定内参×3种参考帧初始化配对均注册全部16帧，包括原来无法注册的参考8/raw674。参考帧8轨迹由3增至1855（背景1781、息肉74）。但605条独立留出轨迹的评价仍未达到运行前固定的可靠性门限；不能把“16帧有位姿矩阵”写成已准确恢复。可交付的是带不确定性、分类标识的真实三角化候选，不是可信公制重建。

**Q2：已知参考环是否进一步改善尺度、一致性与稳定性？** 已知R10使整体坐标/尺度可被条件性锚定，但没有尺度GT验证。本轮A/C共享同一环尺度初始化，仅C增加环损失，因而共享尺度不算C的新增收益。共同留出总MAE仅3/9次下降；息肉类别MAE有7/9次下降、参考帧8的12个息肉测试观测有8/9次下降，是局部正向迹象；背景及整体几何并无稳定提升，一条分支严重失效。不能据此宣布真实形态或相机毫米精度改善。

## 继承、范围及只读边界

读取V2的TECHNICAL_REPORT.md、TECHNOLOGY_REUSE.md、FAILURES.md；在三维目录及下载目录未找到用户所列带时间戳同名副本，采用原实验目录的完整规范报告，未假装读到缺失副本。V2数据源为`ring_first_v2_real_ba/runs/continuous16`，此前DA2深度、TSDF及旧相机/点云不用于本轮预测。

人工确认环、息肉、背景为静态场景，本轮直接使用该条件，不开展背景动态判别。反光不是固定物理特征，仍做常规匹配及几何离群剔除。

唯一视频：`smart_endoscope_20260805/raw/GP_Ip_12.0mm_closed_R10_single_refY_004.mp4`。文件名12.0mm不作真值或尺度。固定16原始帧：82,156,230,304,378,452,526,600,674,748,822,896,970,1044,1118,1192。参考8始终为raw674，没有换组、换目标或只报成功帧。插入270个同视频原始帧辅助光流，共286个图像时刻；辅助帧不增加正式相机评价分母。

INIT分割缓存、可信小孔处理、环内外缘/中心线、检查及可见边缘采样结果均沿用核验过的V2同帧产物；本轮没有重复运行或重写DXY环拟合。来源为`dxy-mid-migration@991ea2017ef522decf76b4521b4ce7ea8d132121`。不改DXY Ring/P/Q、Mid、Gate/Fusion、模型、测量或评价；不调用Dxy值生成三维。具体源码/缓存哈希见preparation/reuse.json、TECHNOLOGY_REUSE.md。用户明确授权复用的5DoF环候选，仅作为全局环坐标初始化，不补缺失相机或特征点。

## 固定方法与数据协议

### 像素、内参和三维坐标

原图1280×720，工作图640×360。像素中心缩放`u_work=(u_native+0.5)/2-0.5`；工作主点(319.5,179.5)。固定原图焦距H70=914.014724、F980=980、D70=1048.692495px；方形像素、零畸变，仅做3个预先设定假设，不把70°标称视场或来源未确认的1080p K/D当真值，也未重新标定。

c2w相机轴向右/向下/向前。环中心为原点、平面XY、法向Z，R10中心线半径5.6mm、圆形截面半径0.6mm。轮廓来自完整torus，不是两条共面圆。沿法向轴内旋转不可从环Mask测得，输出规范以参考8相机右方向在环平面的投影定轴；正负法向采取等价规范，均非额外观测。

### 多源轨迹图

每个正式关键帧均可生成新特征，并按两个时间方向通过间隔最多4个原始视频帧的LK传播。每次最多600个Shi–Tomasi角点，质量0.003、间距5px，范围为息肉＋背景。正式关键帧排除精确Ring Mask的6px膨胀区、息肉分类边界4px、图边8px及明显饱和反光；类别固定为息肉1或背景0，类别变化/环区域不作为观测。

LK31窗口、4层金字塔、双向误差<0.6px、11×11块NCC≥0.8。中间原始帧仅传播现有点，不产生3D观测或新增分类标签，正式关键帧重新做精确Mask排除；因此不能声称中间帧每个像素都具有独立分割标签。断轨不凭深度恢复。跨来源至少2个重叠关键帧≤1.25px且所有共享观测无冲突才合并，允许局部轨迹相互连接而不要求贯穿全片。

共播种12025条候选，3664条至少跨3关键帧，合并98组后3566条。按合并后轨迹ID%5留出整条轨迹；额外排除109条与训练轨迹在至少两视图内相距<2px的近重复测试轨迹，防止泄漏。训练2852条，独立可用留出605条（背景582、息肉23），所有留出点不参与E、PnP、三角化初始化或BA。605轨迹产生2637测试观测（息肉123、背景2514）；参考8测试296观测，其中息肉只有12个。

本轮同时改变范围、时序密度和特征新增方式，新旧对比证明的是这个组合的作用，不是单独背景因素的完全因果消融。旧V2曲线包含首帧所有轨迹，新曲线仅保留至少3视图轨迹；参考8的3→1855比较不受其低长度差异影响。

### 视觉初始化：先参考8局部，再扩展

只用训练轨迹，从参考8与[7,9,6,10,5,11]估计本质矩阵（RANSAC1px），正深度、视差≥1°、重投影≤2px且至少20点才进入候选。按训练支持数量、视差确定性排序，三次分别用排名前3的局部初始化，实际均为[8,7]、[8,9]、[8,10]；不是从最终误差中挑三个最好解。

用E/PnP/OpenCV成熟实现和已有DLT几何。PnP阈值2px、至少12内点；每点最多尝试10个较长基线对，需至少3个正深度、≤2px观测且最大视差≥1°，再用内点DLT更新。最多6次扩展，全过程只使用RGB真实对应，不用DA2造点。9次均扩展到16帧。先进行共同的100步仅视觉BA，作为A/C共享的视觉解。

### 环尺度与坐标只做一次共同初始化

保持相机相对旋转、轨迹形状及点形状不变，使用不含整帧4/11的环观测拟合一个全局Sim3。5DoF候选提供初值，随后只改变整体旋转、平移、正尺度，最长120次函数评估、1px稳健核。目标是放入同一环坐标，不代表深度或轨迹变准。全局轴内方向按参考相机定规范。4/9报告优化器收敛、5/9到达迭代上限，全部保留；达到迭代上限的数值解也不冒称有效尺度。

共同初始化包含1条未满足现有开孔轮廓适用条件的H70/初值2分支。本轮完整保存其失败，不将其视为可靠环尺度。该分支暴露了初始化前适用条件门限的缺失；后续不能沿用当前“夹紧根号后仍求导”的处理作为有效几何。

### 严格A/C对照

A/C完全相同的共享初始化文件、16个注册相机、三维点ID、有效训练观测Mask和优化预算；运行时逐项断言点ID/观测相同。每个K/初值共同预处理后，从同一数组副本开始，A与C各100步LBFGS，学习率0.5、同样的1px伪Huber核、同样的正深度项；只有环项开关不同：

`L_A = mean rho(||project(K,T_i,X_j)-u_ij||) + 10 L_positive`

`L_C = L_A + L_ring`，`rho(e)=sqrt(1+e²)-1`。

环项复用V2完整torus的两条真实透视表观轮廓公式，每条128采样。观测到投影最近距离＋投影到证据距离场，息肉遮挡区删失；不拟合隐藏环边缘到息肉边界，不用中心线补全点作观测。每个数据项独立归一化，环权重固定1，不再调权。C整帧4/11完全不使用环数据，包含共同尺度初始化阶段；因此可真正评价未用过的环视角。

A的单目Sim3自由度在输出时按其自身初始化的参考相机和基线做一次全局规范化；C只规范化无法观测的整体环轴角。没有逐帧配准或按GT对齐。这些规范化不改变特征重投影，不算收益。A不是完全无环尺度的算法，正式标签为“纯视觉BA＋共享环尺度”；原始无尺度视觉结果另存visual_init_*及common_visual_*。

共9个视觉初始化、9次共同视觉BA及18次正式A/C BA。没有额外调参、训练、场景生成、TSDF或3DGS。

## 评价协议与实际结果

运行前config固定的完整验证条件：至少13/16相机、参考8存在、至少20条独立测试轨迹、留出总MAE≤2px、训练正深度比例≥95%、最大相邻相机旋转≤30°。该门限只是本实验的内部质量标准，不是医学准确性标准；本轮没有为了接受结果放宽它。

测试轨迹的两个端点观测（避开参考8）用于评价性三角化，其余观测只预测；不按误差或负深度剔除测试点。参考8因此是真正未用于该测试点三角化的观测。完整报告中位数、MAE、p95、最大值、覆盖率，全部支持集相同，主指标不删除坏点。

### 新旧轨迹与类别贡献

'''+tracking+'''

### A/C共同留出比较（所有18次运行）

每一行双方都包含16帧、605相同测试轨迹和2637相同测试观测，没有优化后裁掉困难观测再比较。所有数字是640×360工作图像素。

'''+table(['K','初值','A总MAE','C总MAE','A参考8 MAE','C参考8 MAE','A整帧环留出MAE','C整帧环留出MAE'],paired)+'''

### 息肉与背景分开评价

'''+table(['K','初值','A息肉MAE','C息肉MAE','A背景MAE','C背景MAE'],specific)+'''

7/9次息肉留出MAE下降，但背景仅2/9次下降。参考8的息肉12个测试观测8/9次MAE下降；例如预定展示F980/初值0由5.115→4.212px，全序列息肉7.689→3.627px，而背景2.640→2.763px。图中展示中间焦距/初值0不是按最好结果选样。样本只有23条息肉留出轨迹，不能由局部误差变化推广至真实毫米形态精度或全部息肉类型。

### 全分布、正深度、点数与失败保留

'''+full+'''

所有正式训练观测正深度比例100%，但C部分分支的测试正深度下降，H70/初值2最低约92.4%。训练正深度不是准确性的充分条件。A训练MAE约0.773—0.820px，C约0.933—25.816px；从低训练残差不能推断独立测试合格。数值点数2021—2250不是可信目标点数；F980/初值0 A有48个、C有34个参考8可见息肉点通过后验正深度/1°/2px门限，仍只能称候选，因为完整独立验证未通过。

9/9个A、9/9个C都未达到完整验证。`geometry/ACCEPTED_*.npz`因此全部保留NaN相机与空目标点云；`UNCERTAIN_*.ply`和camera_candidates.csv明确保留所有数值候选，不用旧结果补齐。

### 局部几何、退化与稳定性

参考8邻域留出Sampson误差：A在8→7约0.330—0.427px，其他邻近对多为1.07—1.37px。局部[6,7,8,9,10]深度重投影MAE约2.04—2.15px。局部相机候选具有图像几何支持，远非V2仅3条轨迹；但尚不足以宣称稳定准确。详见metrics/diagnostics.json；这些是预测冻结后的误差归因，不改变主接受标准。

H70/初值2 C最大相邻旋转46.47°、后验合格训练点0，并有9帧落到精确轮廓函数非法区，全部标失败。其他候选也受长链漂移、极弱/错误对应影响，某些测试点接近退化使最大误差达上万像素，未静默截断。另报“双方均正深度且两评价锚点视差≥1°”的共同辅助子集；不按误差选点，也不替换包含失败的主统计。

同环坐标初值间相机中心离均值（名义mm，不是GT误差）：F980 A均值8.531、C为8.527，未见稳定性实质改变；H70为15.259→16.473，D70为18.507→18.540。一次全序列Sim3消除规范后仍有轨迹形状差异，机器结果列出每次尺度/旋转/平移及误差。原始Sim3坐标/尺度选择的不稳定与真实轨迹形状不稳定分开解释，不把跨规范中心差当定位真值。

### 几何实现核验与归因限制

世界—相机—世界点回转最大差2.63e-13名义mm；有效区域内BA使用的torus公式与旧精确函数逐样点投影差为0px。因此未发现半像素或转置约定错误。对超适用区域的H70/初值2，三角函数夹紧不能修复几何，已标记失败；其他8条分支满足开孔必要条件，但必要条件不是完整可见性或真实环模型正确性的证明。

共同环Sim3通常仍有约3—7px训练残差，部分不收敛；可能涉及刚性标准环与真实固定形状失配、K/畸变不匹配、视觉轨迹漂移或观测噪声。当前不能唯一归因于任何一个，也没有证据称环实际变形已经确认。只观察3套K不足以确定真实K/D，本轮不开展新标定。

本轮A/C共享初始化、点集，故损失开关比较比V2更严格；结论仅对当前固定权重、采样轮廓和优化器成立。全球锚定未通过独立几何验证的一条分支不能作为理想环约束效果；将该失败纳入全体分母，但不宣称它证明正确环几何本身有害。

## 交付、复现与保护

人工报告：HUMAN_REPORT.md；失败证据：FAILURES.md；复用函数/哈希记录：TECHNOLOGY_REUSE.md。

- [新旧轨迹、类别和连接图](visualizations/fig1_old_new_tracks.png)
- [固定参考8匹配](visualizations/fig2_reference8_matches.png)
- [共同环坐标相机及分类三维候选](visualizations/fig3b_ring_cameras_classes_clean.png)
- [A/C整体留出](visualizations/fig4_AC_heldout.png)
- [参考与留出环投影](visualizations/fig5_ring_reprojection.png)
- [全部初值/内参轨迹](visualizations/fig6_initialization_sensitivity.png)
- [参考可见息肉候选及失效标记](visualizations/fig7_target_sparse_candidates.png)
- [息肉/背景分类留出证据](visualizations/fig8_class_specific_validation.png)

几何目录保存原始尺寸R10模型、18份全场景候选点云与18份参考可见息肉候选点云，息肉红、背景蓝；另外18份接受结果为空/NaN。所有候选均非GT，不闭合、不补隐藏表面、不计算体积。

主环境`ring_anchor_3d/.venv/bin/python`，使用已有OpenCV/NumPy/SciPy/PyTorch/matplotlib，无新安装。模型推理没有重复执行，缓存SHA及其原始权重/分割函数来源继承V2并在setup逐帧核验。

在新的独立实验目录保留scripts结构后依序执行（不要覆盖冻结目录；setup要求没有config）：

```bash
PY=/home/liu/polyp_research/ring_anchor_3d/.venv/bin/python
$PY scripts/setup.py
$PY scripts/track_scene.py
$PY scripts/visual_initialize.py
$PY scripts/run_ablation.py
$PY scripts/evaluate.py
$PY scripts/diagnostics_safe.py
$PY scripts/export_visualize.py
$PY scripts/visual_supplement.py
$PY scripts/write_reports.py
```

源码和输入来源在preparation及metrics/freeze_*.json，完整预测在predictions，原始日志也保留。最初视觉进程在轨迹文件尚未写完时启动报缺文件，原日志另存attempt00后按依赖顺序重跑；几何诊断第一次遇非法轮廓退出，保留冻结源码/日志，安全版本只记录非法帧，没有重跑或修改预测；第一张3D图标题重叠，保留原图并新增3b清晰版本。均未调算法权重或读取GT。

所有新增文件仅在本目录。保护核验及原有未提交修改状态见metrics/protection_verification.json；DXY及历史三维保持只读，未删除、移动或压缩旧文件。清理候选0，失败材料仍有归因价值。真实相机/形态GT均缺失，ATE、毫米定位误差、中位绝对相对误差等记录unknown/NaN，不能用Dxy结果代替。

## 下一轮仅建议两项

1. 对同一固定数据做环投影适用条件与全局锚定的验证：把非法分支在初始化前拒绝，检验刚性模型/K先验下环轮廓是否能解释视觉轨迹；保留固定的整帧环留出，不增大损失权重。本轮不执行新的优化版本。
2. 对已经连通的静态轨迹分析长链漂移及息肉低纹理误配，优先验证局部组件连接的一致性和少数留出息肉点的物理身份。先改善独立图像几何检验，再考虑可见表面融合。

不训练环初始化网络：现在特征图连接得到改善，但整体视觉误差、环投影适用条件、模型与K耦合仍未分离，失败尚未证明仅由环姿态初始化导致。不恢复DA2公制映射调参、不启动3DGS。

## 固定审计表

'''+AUDIT
(R/'TECHNICAL_REPORT.md').write_text(tech)
# Reuse audit includes source+function hashes inherited without importing old execution code.
reuse=json.loads((R/'preparation/reuse.json').read_text());oldsrc=json.loads((OLD/'preparation/technical_reuse.json').read_text());supp=json.loads((R.parent/'ring_first_v2_real_ba/preparation/segmentation_reuse_supplement.json').read_text());old3d=json.loads((OLD/'preparation/3d_solver_reuse.json').read_text())
save('preparation/function_sources.json',dict(DXY=oldsrc,segmentation=supp,geometry=old3d,current_scripts={p.name:sha(p) for p in (R/'scripts').glob('*.py')},warning='DXY API functions were executed in V2; V3 reuses verified same-RGB same-mask same-observation caches, does not claim re-execution'))
reuse_report='''# 技术复用记录

本轮DXY保持只读。实际版本`dxy-mid-migration@991ea2017ef522decf76b4521b4ce7ea8d132121`；不默认main已合并。当前16帧与V2完全相同，因此复用经过SHA核验的INIT Mask及二维环观测缓存，**未声称本轮重新执行了DXY分割、RANSAC或测量**。

| 上游函数/资产 | 来源/输入输出契约 | 本轮使用与边界 |
| --- | --- | --- |
| segmentation.INITSegmentation.__init__/predict | 同RGB原图 → 0背景/1息肉/2环标签 | 16个同帧缓存逐一SHA验证；没有重新训练或换帧借用Mask |
| _engine.ring_holes.run | 标签 → 原规则可信小孔与诊断 | 继承处理结果；填孔及补全区域不当直接可见证据 |
| ring_component.recover/ring_points/validate及原RANSAC | 原Ring → 内外缘、椭圆、中心线及有效性 | 不重写；只复用原可见采样，推断椭圆/中心线直接观测权重0 |
| v81_components.existing_ring_check、selection.evaluate | 图像/标签 → 原有效性、质量检查 | V2已执行16/16有效；本轮不改Gate或Dxy候选/聚合 |
| V2 observations/000…015.npz | 同帧二维可信边缘+Mask → 三维轮廓损失 | setup逐文件SHA验证；原有息肉遮挡接口/填孔邻域已排除 |
| V2 B_H70/F980/D70.json | 本组同RGB的环5DoF候选 | 人工明确授权复用，仅提供共享全局Sim3初值；不是本轮相机/点云预测，也不回填失败 |
| ring_anchor_3d/scripts/geometry.py::torus_contours | c2w、K、R/r → 完整torus真实透视轮廓 | AST复用函数，未导入旧场景/GT；BA沿用V2相同公式，并独立逐点一致性核验 |
| V2 E/PnP/DLT及Torch BA工具 | RGB点对应 → 相机/三角点/鲁棒重投影 | 新增参考8优先、多源轨迹和严格共享初值；已有环数学不改 |

函数及文件完整SHA：preparation/function_sources.json，源缓存哈希：preparation/reuse.json，原始来源manifest与权重SHA仍可追踪。INIT权重为`981aa596e8906edc4457219581c606d4a5a22bfc6f7e4924d3d9a4b9aff64464`，本轮未调用网络推理。

新的三维点只来自本轮RGB多视图DLT及训练BA；没有旧点云、旧DA2深度或Dxy直径参与预测。背景辅助点保留类别，不扩大最终参考可见息肉目标。不使用Mid像素/mm代替相机模型，不使用P/Q隐藏补全点作环接触真值。所有代码修改限于本独立目录。

## 固定审计表

'''+AUDIT
(R/'TECHNOLOGY_REUSE.md').write_text(reuse_report)
fail='''# Ring-First V3失败与不确定性

唯一组：GP_Ip_12.0mm_closed_R10_single_refY；固定参考8/raw674。数值定位1/1组成功，但可靠性验证0/1组通过；A/C全部9+9次均保留，不以最好初值替代。

| 步骤/失败 | 全部分母及证据 | 结论/处置 |
| --- | --- | --- |
| V2首帧断轨 | [新旧轨迹图](visualizations/fig1_old_new_tracks.png)：参考3→1855，包含1781背景点 | 本轮真实改善连接，但多源/密时序/背景同时改变，不能只归因于一种因素 |
| 参考8/整段几何验证 | [全18次统计](metrics/summary.csv)：9/9 A、9/9 C均注册16帧，但全体未过预定2px留出MAE门限 | 正式接受相机NaN、目标点云空；未把数值注册当准确位姿 |
| 息肉仍弱 | 605留出轨迹中仅23条息肉、123观测，参考8只12个息肉测试点 | [分类证据](visualizations/fig8_class_specific_validation.png)；局部正向结果7/9或8/9，不能推广为真实形态准确 |
| 联合整体不稳定 | 总MAE只3/9次下降；部分背景误差加重 | [整体留出](visualizations/fig4_AC_heldout.png)，不增加权重、不继续调参 |
| H70初值2非法分支 | 共同Sim3到120评估上限、环MAE13.624px且开孔必要条件不满足；C精确轮廓非法帧5,6,7,8,9,10,12,14,15 | [多初值轨迹](visualizations/fig6_initialization_sensitivity.png)、metrics/diagnostics.json；这一分支不可解释为正确torus几何。夹紧三角函数不足以使其有效，需未来初始化前拒绝 |
| 全局环锚定不稳定 | 9次中4次优化器收敛、5次到上限；训练环残差约3—13.6px | metrics/alignment_*.json；不选择较好尺度替代坏初值，未知GT毫米精度 |
| 极端留出误差 | 错误/弱基线或接近零深度的测试点导致上万px最大误差 | metrics/results.json逐轨迹记录正深度/视差；原分母不剔除。几何门限共同子集仅作为归因辅助 |
| K/环模型/长链漂移耦合 | 三个固定K均有失败；环投影仍系统性不吻合 | 未确认哪个是主因，不宣布已证实非刚性变形，也不重新开展标定 |
| 无独立GT | 没有真实相机与表面GT | ATE、形状mm误差、绝对相对误差unknown/NaN；Dxy值不替代 |

工程失败原件：metrics/visual_initialization_attempt00.log是轨迹写入未完成时启动导致缺输入，按依赖顺序重跑未改参数；scripts/diagnostics.py及metrics/diagnostics_attempt00.log记录遇非法轮廓退出，diagnostics_safe.py仅让诊断保留非法标志，未重算预测；第一版fig3标题挤压，保留原图并新增3b清晰版。当前全部失败都有日志、逐帧/逐点证据或图像，不借历史预测回填。

目前不把候选作为后续可信深度/TSDF输入。不训练环初始化网络：虽然静态背景连接充分，但误差并未被归因成“只差环姿态初值”。下一步只核查环投影前提、共同锚定及长链误配，见技术报告两项建议。无删除/移动/压缩；清理候选0。

## 固定审计表

'''+AUDIT
(R/'FAILURES.md').write_text(fail)
human='''背景与多源轨迹恢复了16帧及目标帧候选，但未通过验证。环局部有收益，整体不稳定；先核查几何约束，不训练网络。

|审计项目|必须汇报|
|---|---|
|目标组数|1|
|本算法独立成功|候选1|
|本算法失败|验证1|
|历史测量值回退|0|
|失败组及具体原因|[留出误差](FAILURES.md)|
|最终统计样本|全18次|
|是否使用 GT 选择算法|否|
'''
assert len(human)<=200,len(human)
(R/'HUMAN_REPORT.md').write_text(human)
freeze('reports_and_source',[R/n for n in ['TECHNICAL_REPORT.md','HUMAN_REPORT.md','TECHNOLOGY_REUSE.md','FAILURES.md']]+list((R/'scripts').glob('*.py'))+[R/'preparation/function_sources.json'])
print('Reports complete, human characters',len(human),'technical',len(tech))

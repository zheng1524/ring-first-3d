"""Whole DEV tracks held out; no real camera GT. No failed/error observations discarded."""
from common import *
from geometry_safe import *
from itertools import combinations
import csv,ast,itertools
# Reuse exactly V3 held-track protocol and point/pose diagnostics.
ns=globals();old=PROJECT/'ring_anchor_3d/experiments/ring_first_v3_static_ba/scripts/evaluate.py'
for node in ast.parse(old.read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name in ['holdout','geometry','simalign']:exec(compile(ast.Module(body=[node],type_ignores=[]),str(old),'exec'),ns)

def conditioning(poses,K,xy,records):
 # Normalize arbitrary units and translate to reference8 before computing DLT spectra.
 center=poses[8,:3,3];active=np.isfinite(poses[:,0,0]);length=np.median(np.linalg.norm(poses[active,:3,3]-center,axis=1));pp=poses.copy();pp[active,:3,3]=(pp[active,:3,3]-center)/length;out=[]
 for rec in records:
  j=rec['track'];A=[]
  for i in rec['anchors']:
   P=np.linalg.inv(pp[i])[:3];u=np.linalg.solve(K,np.r_[xy[j,i],1.]);A.extend([u[0]*P[2]-P[0],u[1]*P[2]-P[1]])
  s=np.linalg.svd(A,compute_uv=False);out.append(dict(track=j,category=rec['category'],nonzero_condition=float(s[0]/max(s[2],1e-15)),nullspace_gap=float(s[2]/max(s[3],1e-15))))
 return dict(nonzero_condition=stats([x['nonzero_condition'] for x in out]),nullspace_gap=stats([x['nullspace_gap'] for x in out]),records=out,normalization='whole trajectory translated to reference8 / median camera baseline; dimensionless DLT; descriptive only')

def ring_eval(P,K):
 records=[]
 for i in range(16):
  ob=np.load(R/f'observations/{i:03d}.npz');p=ob['visible_region'];q=ob['raw_boundary'];q=q[np.linspace(0,len(q)-1,min(512,len(q)),dtype=int)]
  try:
   cr=contours(P[i,:3,3],P[i,:3,:3],K,n=1024);e=inclusion(cr,p);d=cKDTree(cr.reshape(-1,2)).query(q)[0];records.append(dict(frame=i,legal=True,whole_frame_holdout=i in config()['ring_frame_holdout'],positive_inclusion_px=stats(e),positive_coverage=float((e==0).mean()),unclassified_boundary_distance_diagnostic_px=stats(d),certified_visible_contour_MAE_px=None))
  except ValueError as ex:records.append(dict(frame=i,legal=False,reason=str(ex),whole_frame_holdout=i in config()['ring_frame_holdout'],positive_inclusion_px=stats([]),positive_coverage=None,certified_visible_contour_MAE_px=None))
 return records

def main():
 cfg=config();tr=np.load(R/'observations/tracks.npz');xy=tr['xy'];cat=tr['category'];held=np.flatnonzero(~tr['train_track']&tr['holdout_eligible']);results={};rows=[];summary=[];paired=[]
 for kc in cfg['intrinsics']:
  key=kc['name']
  for rr in range(3):
   tag=f'{key}_{rr}';support={}
   for m in ['A','B','C']:
    path=R/f'predictions/{m}_{tag}.npz';name=m+'_'+tag
    if not path.exists():
     results[name]=dict(success=False,reason='no output; see run_status.json',basic_validation=False)
     for i in range(16):rows.append(dict(method=m,K=key,repeat=rr,frame=i,raw=cfg['raw_frames'][i],registered=False,reference8=i==8,basic_validation=False,heldout_n=0,heldout_MAE_px=None,pose_error_mm=None))
     continue
    p=np.load(path);P=p['c2w'];g=geometry(p,xy,cat);h=holdout(P,p['K'],xy,held,cat);cond=conditioning(P,p['K'],xy,h['tracks']);rg=ring_eval(P,p['K']) if m!='A' else None;ac=cfg['acceptance'];valid=bool(len(g['registered'])>=ac['min_registered'] and g['reference8'] and h['testable_tracks']>=ac['min_test_tracks'] and h['error_px']['MAE']<=ac['max_holdout_MAE_px'] and g['positive_fraction']>=ac['min_positive_fraction'] and g['largest_rotation_step_deg']<=ac['max_rotation_step_deg']);g.update(success=True,basic_validation=valid,heldout=h,conditioning=cond,ring=rg,metric_scale='arbitrary mono units' if m=='A' else 'candidate Ring mm; not verified real mm accuracy');results[name]=g;support[m]=p
    byframe=[[] for _ in range(16)];bycat=[[[] for _ in range(2)] for _ in range(16)]
    for t in h['tracks']:
     for i,e in zip(t['test_frames'],t['test_errors']):byframe[i].append(e);bycat[i][t['category']].append(e)
    for i in range(16):
     ee=stats(byframe[i]);r=rg[i] if rg else {};rows.append(dict(method=m,K=key,repeat=rr,frame=i,raw=cfg['raw_frames'][i],registered=i in g['registered'],reference8=i==8,basic_validation=valid,heldout_n=ee['n'],heldout_median_px=ee['median'],heldout_MAE_px=ee['MAE'],heldout_p95_px=ee['p95'],heldout_max_px=ee['max'],polyp_heldout_MAE_px=stats(bycat[i][1])['MAE'],background_heldout_MAE_px=stats(bycat[i][0])['MAE'],ring_holdout_frame=i in cfg['ring_frame_holdout'],ring_identity_coverage=r.get('positive_coverage'),ring_inclusion_MAE_px=r.get('positive_inclusion_px',{}).get('MAE'),ring_certified_contour_MAE_px=None,ring_unclassified_boundary_diagnostic_MAE_px=r.get('unclassified_boundary_distance_diagnostic_px',{}).get('MAE'),ring_projection_legal=r.get('legal'),positive_fraction=g['positive_fraction'],held_positive_track_fraction=h['positive_track_fraction'],held_parallax_median_deg=h['anchor_parallax_deg']['median'],DLT_nonzero_condition_median=cond['nonzero_condition']['median'],DLT_nullspace_gap_median=cond['nullspace_gap']['median'],valid_training_points=g['geometric_points'],training_polyp_points=g['polyp_points'],training_background_points=g['background_points'],pose_error_mm=None,point_error_mm=None,median_absolute_relative_pose_error=None))
    summary.append(dict(method=m,K=key,repeat=rr,registered=len(g['registered']),reference8=g['reference8'],points=g['candidate_points'],polyp_points=g['polyp_points'],geometric_points=g['geometric_points'],held_MAE=h['error_px']['MAE'],held_median=h['error_px']['median'],held_p95=h['error_px']['p95'],held_max=h['error_px']['max'],ref8_MAE=h['reference8_error_px']['MAE'],polyp_MAE=h['polyp_error_px']['MAE'],background_MAE=h['background_error_px']['MAE'],positive=g['positive_fraction'],held_positive=h['positive_track_fraction'],parallax=h['anchor_parallax_deg']['median'],condition=cond['nonzero_condition']['median'],nullgap=cond['nullspace_gap']['median'],max_rotation=g['largest_rotation_step_deg'],basic_validation=valid))
   if 'B' in support and 'C' in support:
    b,c=support['B'],support['C'];same_ids=np.array_equal(b['point_ids'],c['point_ids']);same_obsmask=np.array_equal(b['observation_mask'],c['observation_mask']);assert same_ids and same_obsmask
    paired.append(dict(K=key,repeat=rr,same_ids=True,same_support=True,common_registered=list(set(np.flatnonzero(np.isfinite(b['c2w'][:,0,0])))&set(np.flatnonzero(np.isfinite(c['c2w'][:,0,0])))),held_C_minus_B=results['C_'+tag]['heldout']['error_px']['MAE']-results['B_'+tag]['heldout']['error_px']['MAE'],reference8_C_minus_B=results['C_'+tag]['heldout']['reference8_error_px']['MAE']-results['B_'+tag]['heldout']['reference8_error_px']['MAE']))
 stability={}
 for key in [x['name'] for x in cfg['intrinsics']]:
  for m in ['A','B','C']:
   paths=[R/f'predictions/{m}_{key}_{rr}.npz' for rr in range(3)]
   if not all(p.exists() for p in paths):continue
   P=[np.load(p)['c2w'] for p in paths];base=np.median(np.linalg.norm(P[0][:,:3,3]-P[0][8,:3,3],axis=1));sims=[simalign(p,P[0]) for p in P[1:]];orientation=[]
   for p,s in zip(P[1:],sims):
    U=np.array(s['rotation']);orientation.extend(np.degrees(Rotation.from_matrix(np.einsum('nji,njk->nik',P[0][:,:3,:3],U@p[:,:3,:3])).magnitude()).tolist())
   stability[m+'_'+key]=dict(one_global_Sim3_to_repeat0=sims,center_RMSE_over_median_baseline=[np.sqrt(np.mean(np.square([np.linalg.norm(s['scale']*np.array(s['rotation'])@p[i,:3,3]+s['translation']-P[0][i,:3,3]) for i in range(16)])))/base for p,s in zip(P[1:],sims)],orientation_disagreement_deg=stats(orientation),not_GT_accuracy=True)
 save('metrics/results.json',dict(methods=results,paired=paired,stability=stability,summary=summary,GT_available=False,target_groups=1,expected_runs=27,median_absolute_relative_metric_error=None))
 fields=list(dict.fromkeys(k for row in rows for k in row))
 with (R/'REAL_EVALUATION.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 with (R/'metrics/summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 freeze('evaluation',[Path(__file__),R/'REAL_EVALUATION.csv',R/'metrics/results.json',R/'metrics/summary.csv']);print(json.dumps(clean(summary),indent=2))
if __name__=='__main__':main()

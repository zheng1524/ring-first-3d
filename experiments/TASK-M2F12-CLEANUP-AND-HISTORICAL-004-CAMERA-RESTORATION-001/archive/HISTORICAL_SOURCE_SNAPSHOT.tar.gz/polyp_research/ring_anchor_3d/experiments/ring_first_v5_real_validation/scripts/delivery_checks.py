from common import *
import csv,ast,re,importlib.metadata

def main():
 rows=list(csv.DictReader((R/'REAL_EVALUATION.csv').open()));assert len(rows)==432;assert len({(x['method'],x['K'],x['repeat'],x['frame']) for x in rows})==432;assert all(x['registered']=='True' for x in rows);assert not any(x['basic_validation']=='True' for x in rows)
 for p in (R/'scripts').glob('*.py'):ast.parse(p.read_text())
 for p in R.glob('*.md'):
  for label in ['目标组数','本算法独立成功','本算法失败','历史测量值回退','失败组及具体原因','最终统计样本','是否使用 GT 选择算法']:assert label in p.read_text(),(p,label)
  for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
   if not target.startswith(('http','#')):assert (R/target.split('#')[0]).exists(),(p,target)
 assert len((R/'HUMAN_SUMMARY.md').read_text())<=200
 packages={p:importlib.metadata.version(p) for p in ['numpy','scipy','torch','matplotlib']};packages['cv2']=cv2.__version__
 save('RUN_MANIFEST.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),root=str(R),environment=dict(python=sys.version,executable=sys.executable,packages=packages),source_video='smart_endoscope_20260805/raw/GP_Ip_12.0mm_closed_R10_single_refY_004.mp4',input_sources='inputs/source_manifest.json and DXY_reuse.json',data_partition='DEV only; all other unknown groups reserved',actual_run_logs=sorted(p.name for p in (R/'logs').glob('*')),actual_commands='TECHNICAL_REPORT.md reproducibility block',network_training=False,synthetic_stage=False,DXY_modified=False,deletions=False,cleanup_candidates=0))
 freeze('final_reports',list(R.glob('*.md'))+[R/'REAL_EVALUATION.csv',R/'RUN_MANIFEST.json',R/'metrics/gate1.json']+list((R/'scripts').glob('*.py')))
 print('DELIVERY CHECK PASS: 432 rows, 27 numeric runs, zero reliability pass, human <=200 chars, all reports and links valid')
if __name__=='__main__':main()

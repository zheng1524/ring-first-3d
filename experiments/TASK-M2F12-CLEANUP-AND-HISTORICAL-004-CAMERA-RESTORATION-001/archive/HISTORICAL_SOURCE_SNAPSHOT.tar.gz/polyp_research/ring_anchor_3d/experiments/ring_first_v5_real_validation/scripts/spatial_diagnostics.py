from common import *
from geometry_safe import *
from evaluate_real import holdout

def main():
 tr=np.load(R/'observations/tracks.npz');xy=tr['xy'];cat=tr['category'];held=np.flatnonzero(~tr['train_track']&tr['holdout_eligible']);res=json.loads((R/'metrics/results.json').read_text());out={}
 for name,g in res['methods'].items():
  if not g['success']:continue
  pp=np.load(R/f'predictions/{name}.npz');P=pp['c2w'];X=pp['points'];ids=pp['point_ids'];base=np.median(np.linalg.norm(P[:,:3,3]-P[8,:3,3],axis=1));item={}
  for cl,label in [(0,'background'),(1,'polyp')]:
   mask=cat[ids]==cl;local=(X[mask]-P[8,:3,3])@P[8,:3,:3]/base;recs=[r for r in g['point_records'] if r['category']==cl];test=[r for r in g['heldout']['tracks'] if r['category']==cl];ref=xy[ids[mask],8];ref=ref[np.isfinite(ref[:,0])];area=float(cv2.contourArea(cv2.convexHull(ref.astype(np.float32)))) if len(ref)>=3 else 0.
   item[label]=dict(candidate_count=int(mask.sum()),geometric_gate_count=sum(r['geometric_gate'] for r in recs),reference8_observed_points=len(ref),reference8_image_convex_hull_area_fraction=area/(640*360),camera8_XYZ_over_median_baseline_percentiles=np.percentile(local,[5,50,95],axis=0).tolist() if len(local) else None,held_positive_fraction=float(np.mean([r['positive'] for r in test])) if test else None,held_below_1deg_fraction=float(np.mean([r['parallax_deg']<1 for r in test])) if test else None,held_parallax_deg=stats([r['parallax_deg'] for r in test]))
  item['local_reference_neighborhood_heldout']=holdout(P,pp['K'],xy,held,cat,[6,7,8,9,10]);out[name]=item
 save('metrics/spatial_diagnostics.json',out);freeze('spatial_diagnostics',[Path(__file__),R/'metrics/spatial_diagnostics.json']);print('spatial diagnostics',len(out))
if __name__=='__main__':main()

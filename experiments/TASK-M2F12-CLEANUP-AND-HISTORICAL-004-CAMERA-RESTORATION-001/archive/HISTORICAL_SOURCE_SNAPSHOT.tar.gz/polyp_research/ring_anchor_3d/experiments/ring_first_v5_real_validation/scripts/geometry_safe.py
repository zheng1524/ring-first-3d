from common import *
import ast
from scipy.spatial.transform import Rotation
from scipy.spatial import cKDTree
from matplotlib.path import Path as PolygonPath
source=PROJECT/'ring_anchor_3d/scripts/geometry.py';ns={'np':np,'cv2':cv2}
node=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='torus_contours');exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
def contours(C,rot,K,n=256):
 if not np.isfinite(C).all() or np.linalg.norm(C)<=6.2 or abs(C[2])/np.linalg.norm(C)<=.6/5.6+.001:raise ValueError('invalid open-hole torus regime')
 q=ns['torus_contours'](C,rot,K,R=5.6,r=.6,n=n)
 if not np.isfinite(q).all() or np.max(abs(q))>1e5:raise ValueError('invalid projection')
 return q

def inside(curves,points):
 areas=[abs(cv2.contourArea(c.astype(np.float32))) for c in curves];o=int(np.argmax(areas));return PolygonPath(curves[o]).contains_points(points)&~PolygonPath(curves[1-o]).contains_points(points)

def inclusion(curves,points):return cKDTree(curves.reshape(-1,2)).query(points)[0]*(~inside(curves,points))

def transform(P,X,U,s,t):
 pp=P.copy();ok=np.isfinite(P[:,0,0]);pp[ok,:3,:3]=U@P[ok,:3,:3];pp[ok,:3,3]=s*(P[ok,:3,3]@U.T)+t;return pp,s*(X@U.T)+t

def prediction_guard():
 def audit(event,args):
  if event!='open' or not isinstance(args[0],(str,bytes)):return
  p=Path(args[0]).resolve();parts=p.parts
  if 'private_gt' in parts or 'debug_inputs' in parts or ('predictions' in parts and R not in p.parents):raise PermissionError('GT / historical predicted cameras prohibited: '+str(p))
 sys.addaudithook(audit)

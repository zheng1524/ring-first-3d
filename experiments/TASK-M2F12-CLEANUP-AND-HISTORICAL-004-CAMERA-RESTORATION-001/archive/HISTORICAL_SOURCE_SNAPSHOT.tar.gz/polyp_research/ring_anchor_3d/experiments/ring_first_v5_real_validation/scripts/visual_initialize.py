"""Reference8-first incremental SfM; OpenCV robust E/PnP and observed DLT.
No ring geometry or previous predicted cameras used in this visual initializer.
"""
from common import *
from itertools import combinations
cv2.setNumThreads(4)
def pair_initial(xy,K,other):
 ids=np.flatnonzero(np.isfinite(xy[:,8,0])&np.isfinite(xy[:,other,0]));audit=dict(pair=[8,other],matches=len(ids))
 if len(ids)<20:return None,audit
 p,q=xy[ids,8],xy[ids,other];E,mask=cv2.findEssentialMat(p,q,K,method=cv2.RANSAC,prob=.999,threshold=1.)
 if E is None:return None,audit
 result=[]
 for e in np.asarray(E).reshape(-1,3,3):
  count,rot,t,m=cv2.recoverPose(e,p,q,K,mask=mask.copy());p0=np.eye(4);p1=np.eye(4);p1[:3,:3]=rot.T;p1[:3,3]=-rot.T@t.ravel();X=np.array([triangle([a,b],[p0,p1],K) for a,b in zip(p,q)]);uv0,z0=project(X,np.array([p0]),np.zeros(len(X),int),K);uv1,z1=project(X,np.array([p1]),np.zeros(len(X),int),K);pa=angle(X,p0[:3,3],p1[:3,3]);good=(m.ravel()>0)&(pa>=1)&(z0>0)&(z1>0)&(np.linalg.norm(uv0-p,axis=1)<=2)&(np.linalg.norm(uv1-q,axis=1)<=2);audit.update(E_positive=int(count),valid_points=int(good.sum()),parallax=stats(pa[good]))
  if good.sum()>=20:result.append(dict(other=other,pose=p1,points=X[good],ids=ids[good],score=int(good.sum()),parallax=float(np.median(pa[good]))))
 return (max(result,key=lambda x:x['score']) if result else None),audit

def triangulate(xy,poses,K):
 active=np.flatnonzero(np.isfinite(poses[:,0,0]));points=[];pointids=[];masks=[]
 for j,t in enumerate(xy):
  frames=[int(i) for i in active if np.isfinite(t[i,0])]
  if len(frames)<3:continue
  # RANSAC over up to10 longest estimated camera baselines; no GT.
  pairs=sorted(combinations(frames,2),key=lambda ab:np.linalg.norm(poses[ab[0],:3,3]-poses[ab[1],:3,3]),reverse=True)[:10];best=None
  for a,b in pairs:
   P=triangle(t[[a,b]],poses[[a,b]],K)
   if not np.isfinite(P).all():continue
   u,z=project(np.tile(P,(len(frames),1)),poses,np.array(frames),K);e=np.linalg.norm(u-t[frames],axis=1);good=(z>0)&(e<2);fg=np.array(frames)[good]
   if len(fg)<3:continue
   pa=max(float(angle(P,poses[x,:3,3],poses[y,:3,3])) for x,y in combinations(fg,2))
   if pa<1:continue
   if best is None or good.sum()>best[0]:best=(int(good.sum()),fg,P)
  if best is None:continue
  fg=best[1];P=triangle(t[fg],poses[fg],K);u,z=project(np.tile(P,(len(frames),1)),poses,np.array(frames),K);good=(z>0)&(np.linalg.norm(u-t[frames],axis=1)<2)
  if good.sum()<3:continue
  mask=np.zeros(16,bool);mask[np.array(frames)[good]]=True;points.append(P);pointids.append(j);masks.append(mask)
 return np.array(points).reshape(-1,3),np.array(pointids,int),np.array(masks,bool).reshape(-1,16)

def main():
 conf=config();f=np.load(R/'observations/tracks.npz');globalids=np.flatnonzero(f['train_track']);xy=f['xy'][globalids];results={};freeze('visual_protocol',[Path(__file__),R/'config.json',R/'observations/tracks.npz'])
 for kc in conf['intrinsics']:
  name=kc['name'];ff=kc['fx_native']/2;K=np.array([[ff,0,319.5],[0,ff,179.5],[0,0,1.]]);results[name]=[]
  for repeat in range(3):
   cv2.setRNGSeed(conf['seed']+repeat);candidates=[];audits=[]
   for other in [7,9,6,10,5,11]:
    candidate,audit=pair_initial(xy,K,other);audits.append(audit)
    if candidate is not None:candidates.append(candidate)
   poses=np.full((16,4,4),np.nan);points=np.empty((0,3));ids=np.empty(0,int);obsmask=np.empty((0,16),bool);status=dict(initialization_attempts=audits,success=False,reason='no >=20-point positive1deg reference8 initializer')
   if candidates:
    candidates.sort(key=lambda x:(x['score'],x['parallax']),reverse=True);chosen=candidates[min(repeat,len(candidates)-1)];base=chosen['other'];poses[8]=np.eye(4);poses[base]=chosen['pose'];points=chosen['points'];ids=chosen['ids'];history=[]
    for step in range(6):
     pending=[i for i in range(16) if not np.isfinite(poses[i,0,0])];pending.sort(key=lambda i:np.isfinite(xy[ids,i,0]).sum(),reverse=True);added=0
     for i in pending:
      ok=np.isfinite(xy[ids,i,0]);X=points[ok];q=xy[ids[ok],i]
      if len(X)<12:continue
      success,rv,tv,inliers=cv2.solvePnPRansac(X,q,K,None,iterationsCount=300,reprojectionError=2,confidence=.999,flags=cv2.SOLVEPNP_EPNP)
      if success and inliers is not None and len(inliers)>=12:
       ii=inliers.ravel();rv,tv=cv2.solvePnPRefineLM(X[ii],q[ii],K,None,rv,tv);rot=cv2.Rodrigues(rv)[0];cam=np.eye(4);cam[:3,:3]=rot.T;cam[:3,3]=-rot.T@tv.ravel();u,z=project(X[ii],np.array([cam]),np.zeros(len(ii),int),K)
       if (z>0).mean()<.95:continue
       poses[i]=cam;added+=1;history.append(dict(step=step,frame=i,PnP_inliers=len(ii),median_px=float(np.median(np.linalg.norm(u-q[ii],axis=1)))))
     newpoints,newids,newmask=triangulate(xy,poses,K)
     if len(newpoints)>=3:points,ids,obsmask=newpoints,newids,newmask
     if not added:break
    if len(obsmask)!=len(points):points,ids,obsmask=triangulate(xy,poses,K)
    status.update(success=len(points)>=20,reason=None if len(points)>=20 else 'insufficient3view triangulated points',chosen_pair=[8,base],registered=np.flatnonzero(np.isfinite(poses[:,0,0])).tolist(),point_count=len(points),incremental_log=history,available_initializers=len(candidates))
   np.savez_compressed(R/f'predictions/visual_init_{name}_{repeat}.npz',c2w=poses,points=points,point_ids=globalids[ids],observation_mask=obsmask,K=K,registered=np.isfinite(poses[:,0,0]),independent_mm_scale=False)
   results[name].append(status);save('metrics/visual_initialization.json',results);print('VISUAL',name,repeat,status.get('registered',[]),'points',len(points),'success',status['success'],flush=True)
 freeze('visual_initialization',list((R/'predictions').glob('visual_init_*.npz'))+[R/'metrics/visual_initialization.json',Path(__file__)]);print('VISUAL_INITIALIZATION_COMPLETE')
if __name__=='__main__':
 from geometry_safe import prediction_guard
 prediction_guard();main()

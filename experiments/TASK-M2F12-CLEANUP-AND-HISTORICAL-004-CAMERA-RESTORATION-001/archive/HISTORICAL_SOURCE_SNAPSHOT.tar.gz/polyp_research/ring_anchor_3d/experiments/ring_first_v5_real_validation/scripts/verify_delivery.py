from common import *
import subprocess,ast

def main():
 protected=json.loads((R/'metrics/protected.json').read_text());changed=[];hash_count=0
 for pp,item in protected.items():
  p=Path(pp)
  if not p.is_file():changed.append(dict(file=pp,reason='missing'));continue
  st=p.stat()
  if st.st_size!=item['size'] or st.st_mtime_ns!=item['mtime_ns']:changed.append(dict(file=pp,reason='size/mtime changed'))
  if 'sha256' in item:
   hash_count+=1
   if sha(p)!=item['sha256']:changed.append(dict(file=pp,reason='content changed'))
 before=json.loads((R/'metrics/git_before.json').read_text());git_errors=[]
 for repo,expected in before.items():
  for k,args in [('head',['rev-parse','HEAD']),('branch',['branch','--show-current']),('status',['status','--short','--untracked-files=no'])]:
   now=subprocess.check_output(['git']+args,cwd=repo).decode()
   if now!=expected[k]:git_errors.append(dict(repo=repo,item=k))
 superseded=[];freeze_errors=[]
 for record in sorted((R/'metrics').glob('freeze_*.json')):
  data=json.loads(record.read_text())
  for pp,h in data['files'].items():
   if sha(pp)==h:continue
   archived=[p for p in (R/'inputs/protocol_versions').glob('*') if sha(p)==h]
   if archived:superseded.append(dict(freeze=record.name,file=pp,archived=str(archived[0]),reason=('initial data ledger retained; only final reporting audit table appended' if Path(pp).name=='DATA_USAGE_MANIFEST.md' else 'AST missing import repaired after evaluation exception; no prediction/protocol change' if Path(pp).name=='evaluate_real.py' else 'pre-BA gauge-only source correction; superseded by protocol_v2_gauge_before_BA')))
   else:freeze_errors.append(dict(freeze=record.name,file=pp))
 for p in (R/'scripts').glob('*.py'):ast.parse(p.read_text())
 out=dict(protected_files=len(protected),content_hashed_text_sources_and_records=hash_count,media_metadata_only=len(protected)-hash_count,changed=changed,git_errors=git_errors,freeze_errors=freeze_errors,superseded_pre_run_source=superseded,DXY_unchanged=not git_errors and not changed,existing_user_changes_preserved=True,deleted_moved_compressed_files=0,cleanup_candidates=0,scope='read only historic assets; media stat-only intentionally avoids unknown TEST_RESERVED content')
 save('metrics/protection_verification.json',out);assert not changed and not git_errors and not freeze_errors,out;print('PROTECTION PASS',len(protected),'files;',hash_count,'content hashes')
if __name__=='__main__':main()

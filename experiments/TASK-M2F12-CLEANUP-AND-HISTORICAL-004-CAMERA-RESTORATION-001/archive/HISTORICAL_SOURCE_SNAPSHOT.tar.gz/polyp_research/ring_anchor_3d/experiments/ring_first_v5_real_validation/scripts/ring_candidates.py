"""Original V4/Contact decoder/seeds/multistart. Real loss uses positive identity only."""
from common import *
from geometry_safe import *
from scipy.optimize import least_squares
import ast
source=PROJECT/'ring_anchor_3d/experiments/ring_pose_contact_v1/scripts/recover.py'
ns=dict(np=np,cv2=cv2,Rotation=Rotation,least_squares=least_squares,cKDTree=cKDTree,n=256,rad=5.6,tube=.6)
for node in ast.parse(source.read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name in ['decode','image_seeds','solve']:exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)

def configure(K):
 cfg=config();ns.update(K=K,cfg=dict(seed_depth_factors=[.85,1.,1.2],seed_inclinations_deg=[0,35,60],seed_azimuths_deg=[0,90,180,270],seed_retain=cfg['ring_seed_retain'],max_nfev=cfg['ring_max_nfev'],huber_px=1.,numerical_success_max_training_px=3.))
 def residual(a,ref,observations):
  center,Q=ns['decode'](a,ref);C=-Q.T@center;rot=Q.T
  try:return np.concatenate([inclusion(contours(C,rot,K),ob['positive']) for ob in observations])
  except ValueError:return np.full(sum(len(ob['positive']) for ob in observations),1000.)
 ns['residual']=residual

def main():
 prediction_guard();fits=json.loads((R/'observations/dxy_original_fits.json').read_text())
 for kc in config()['intrinsics']:
  name=kc['name'];f=kc['fx_native']/2;K=np.array([[f,0,319.5],[0,f,179.5],[0,0,1.]]);configure(K);out=[]
  for i in range(16):
   a=np.load(R/f'observations/{i:03d}.npz');ob=dict(mask=a['ring_mask'],positive=a['positive']);seeds=ns['image_seeds'](ob)
   # Original DXY Mid is ONLY an initializer, not a target or observed silhouette.
   e=fits[i]['geometry'].get('centerline')
   if e:
    z=5.6*K[0,0]/(e['major_radius']/2);xy=((np.array([e['cx'],e['cy']])+.5)/2-.5-K[:2,2])/np.diag(K)[:2];inc=np.arccos(np.clip(e['minor_radius']/e['major_radius'],0,1));az=np.deg2rad(e['angle_deg'])
    for sign in [-1,1]:seeds.append(np.r_[xy,np.log(z),sign*inc*np.cos(az),sign*inc*np.sin(az)])
   result=ns['solve']([ob],np.eye(4),seeds);result.update(frame=i,scope='candidate only; positive identity inclusion is necessary not sufficient; spin and unknown occlusion retained',certified_pose=False);out.append(result)
   print('Ring candidate',name,i,'loss',round(result['loss'],3),'alternatives',len(result['ambiguity_alternatives']),flush=True)
  save(f'predictions/ring_candidates_{name}.json',out)
 freeze('ring_candidates',list((R/'predictions').glob('ring_candidates_*.json')))
if __name__=='__main__':main()

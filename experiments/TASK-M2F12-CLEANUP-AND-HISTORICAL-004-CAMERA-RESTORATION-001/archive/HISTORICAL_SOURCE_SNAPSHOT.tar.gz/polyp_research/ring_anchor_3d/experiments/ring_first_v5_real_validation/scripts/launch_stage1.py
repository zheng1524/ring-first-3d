from pathlib import Path
import subprocess,time
r=Path(__file__).resolve().parents[1];py=r.parents[2]/'ring_anchor_3d/.venv/bin/python'
# Execution dependency only; this process yields its PTY immediately.
for n in range(120):
 if (r/'metrics/freeze_visual_initialization.json').exists() and (r/'metrics/freeze_ring_candidates.json').exists():break
 time.sleep(2)
else:raise RuntimeError('initialization prerequisite timed out')
for name in ['run_real.py','evaluate_real.py','diagnostics.py','visualize.py']:
 with (r/'logs'/f'{name}.log').open('w') as f:
  result=subprocess.run([str(py),str(r/'scripts'/name)],stdout=f,stderr=subprocess.STDOUT)
 if result.returncode:raise RuntimeError(name+' failed; inspect retained log')
 print(name,'complete',flush=True)

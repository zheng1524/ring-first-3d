from common import *
from geometry_safe import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import csv
plt.rcParams.update({'font.size':9,'figure.facecolor':'white','savefig.facecolor':'white'})

def image(i):
 p=R.parent/f'ring_first_v3_static_ba/inputs/images/{i:03d}.jpg';return cv2.cvtColor(cv2.resize(cv2.imread(str(p)),(640,360)),cv2.COLOR_BGR2RGB)
def finish(fig,name):
 fig.savefig(R/'visualizations'/name,dpi=160,bbox_inches='tight',facecolor='white');plt.close(fig)
def torus(ax):
 th=np.linspace(0,2*np.pi,200);ax.plot(5.6*np.cos(th),5.6*np.sin(th),th*0,'k-',lw=1)

def main():
 result=json.loads((R/'metrics/results.json').read_text());cfg=config();track=np.load(R/'observations/tracks.npz');xy=track['xy'];cat=track['category'];keys=[x['name'] for x in cfg['intrinsics']]
 # All nine C outcomes, not a best chosen case; repeat0 only annotated reference example.
 fig,axs=plt.subplots(3,3,figsize=(15,9))
 for row,key in enumerate(keys):
  for rr in range(3):
   ax=axs[row,rr];ax.imshow(image(8));ob=np.load(R/'observations/008.npz');ax.scatter(*ob['positive'].T,s=1,c='lime',label='visible Ring identity')
   for method,color in [('B','cyan'),('C','orange')]:
    p=R/f'predictions/{method}_{key}_{rr}.npz'
    if not p.exists():continue
    pp=np.load(p)
    try:
     cr=contours(pp['c2w'][8,:3,3],pp['c2w'][8,:3,:3],pp['K'],1024)
     for j,c in enumerate(cr):ax.plot(*c.T,color=color,lw=.9,label=method+' full torus (not visible mask)' if j==0 else None)
    except ValueError:ax.text(10,30,method+' INVALID',color=color)
   ax.set_title(f'{key} / init {rr} / ref8 raw674');ax.set_xlim(0,640);ax.set_ylim(360,0)
   if row==0 and rr==0:ax.legend(fontsize=6)
 fig.suptitle('All fixed runs: visible Ring identity retained; occlusion order unknown');fig.tight_layout();finish(fig,'fig1_real_ring_all_initializations.png')
 fig=plt.figure(figsize=(15,12))
 for row,key in enumerate(keys):
  for col,m in enumerate(['A','B','C']):
   ax=fig.add_subplot(3,3,row*3+col+1,projection='3d')
   if m!='A':torus(ax)
   for rr,color in enumerate(['#2166ac','#f4a582','#1b7837']):
    p=R/f'predictions/{m}_{key}_{rr}.npz'
    if not p.exists():continue
    pp=np.load(p);P=pp['c2w'];C=P[:,:3,3];ax.plot(*C.T,'o-',ms=2,c=color,label='init'+str(rr));ax.scatter(*C[8],c='red',s=22)
   ax.set_title(f'{m} {key} '+('arbitrary units' if m=='A' else 'Ring candidate mm; no GT'));ax.set_xlabel('X');ax.set_ylabel('Y');ax.set_zlabel('Z');ax.legend(fontsize=6);ax.set_box_aspect((1,1,1))
 fig.suptitle('All initialization trajectories; red = reference8. Numeric pose is not validated pose.');fig.tight_layout();finish(fig,'fig2_trajectories_all_runs.png')
 fig,axs=plt.subplots(2,2,figsize=(13,8));summ=result['summary']
 for ax,field,title in zip(axs.ravel(),['held_MAE','ref8_MAE','polyp_MAE','background_MAE'],['Held RGB MAE','Reference8 held MAE','Polyp held MAE','Background held MAE']):
  for off,m,color in [(-.2,'A','#7570b3'),(0,'B','#1b9e77'),(.2,'C','#d95f02')]:
   data=[next((s[field] for s in summ if s['K']==k and s['repeat']==r and s['method']==m),np.nan) for k in keys for r in range(3)];ax.plot(np.arange(9)+off,data,'o-',label=m,c=color)
  ax.axhline(2,color='k',ls='--',lw=.7,label='V3 total-MAE threshold (only total metric)');ax.set_xticks(range(9),[f'{k}/{r}' for k in keys for r in range(3)],rotation=40);ax.set_ylabel('work-image px');ax.set_title(title);ax.legend(fontsize=6)
 fig.suptitle('Independent whole-track holdout; every initialization retained');fig.tight_layout();finish(fig,'fig3_independent_evaluation.png')
 # Predeclared F980 repeat0 diagnostic, not selected by final score.
 key='F980';rr=0;fig=plt.figure(figsize=(15,5))
 for col,m in enumerate(['B','C']):
  ax=fig.add_subplot(1,3,col+1,projection='3d');p=R/f'predictions/{m}_{key}_{rr}.npz'
  if not p.exists():ax.set_title(m+' failed');continue
  pp=np.load(p);X=pp['points'];ids=pp['point_ids'];C=pp['c2w'][:,:3,3];ref=pp['c2w'][8];uv,z=project(X,pp['c2w'],np.full(len(X),8),pp['K']);vis=np.isfinite(xy[ids,8,0]);limit=np.percentile(np.linalg.norm(X-C[8],axis=1),95);near=vis&(np.linalg.norm(X-C[8],axis=1)<=limit)
  for v,color,label in [(0,'#377eb8','background'),(1,'#e41a1c','polyp')]:
   ok=near&(cat[ids]==v);ax.scatter(*X[ok].T,s=3,c=color,label=label)
  ax.plot(*C.T,c='black',lw=1);torus(ax);ax.scatter(*C[8],c='orange',s=25);ax.set_title(f'{m} F980 init0: ref8-observed points\n95% display crop only; all points in exports');ax.legend(fontsize=7);ax.set_box_aspect((1,1,1))
  colors=np.where(cat[ids,None]==1,np.array([235,50,50]),np.array([50,100,235]));out=R/f'exports/{m}_F980_0_points.ply'
  with out.open('w') as f:
   f.write('ply\nformat ascii 1.0\nelement vertex '+str(len(X))+'\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n')
   for x,c in zip(X,colors):f.write(' '.join(map(str,[*x,*c]))+'\n')
 ax=fig.add_subplot(1,3,3);ax.imshow(image(8));ok=np.isfinite(xy[:,8,0]);
 for v,c,label in [(0,'cyan','background'),(1,'red','polyp')]:
  q=xy[ok&(cat==v),8];ax.scatter(*q.T,s=2,c=c,label=f'{label}: {len(q)}')
 ax.set_title('Same frozen RGB tracks at reference8');ax.set_xlim(0,640);ax.set_ylim(360,0);ax.legend(fontsize=7);fig.tight_layout();finish(fig,'fig4_ref8_points_and_RGB.png')
 fig,axs=plt.subplots(1,3,figsize=(15,5));ob=np.load(R/'observations/008.npz');im=image(8);axs[0].imshow(im);q=ob['raw_boundary'];axs[0].scatter(*q.T,s=.6,c='yellow');axs[0].set_title('All visible Mask boundary: NOT all self-contour')
 axs[1].imshow(im);p=ob['positive'];axs[1].scatter(*p.T,s=3,c='lime');q=ob['ambiguous_boundary'];axs[1].scatter(*q.T,s=.7,c='magenta');axs[1].set_title('Positive Ring samples / unknown interface')
 axs[2].imshow(im)
 fits=json.loads((R/'observations/dxy_original_fits.json').read_text());e=fits[8]['geometry']
 for name,c in [('inner','cyan'),('outer','orange'),('centerline','lime')]:
  p=e[name];th=np.linspace(0,2*np.pi,300);a=np.deg2rad(p['angle_deg']);U=np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]]);q=(np.c_[p['major_radius']*np.cos(th),p['minor_radius']*np.sin(th)]@U.T+np.array([p['cx'],p['cy']])+.5)*.5-.5;axs[2].plot(*q.T,c=c,label=name)
 axs[2].set_title('Original DXY fits: initialization only');axs[2].legend(fontsize=7)
 for ax in axs:ax.set_xlim(0,640);ax.set_ylim(360,0)
 fig.tight_layout();finish(fig,'fig5_observation_roles_not_blank.png')
 integrity=[]
 for p in (R/'visualizations').glob('*.png'):
  im=cv2.imread(str(p),cv2.IMREAD_UNCHANGED);assert im is not None and im.std()>5;alpha=None if im.shape[2]<4 else [int(im[:,:,3].min()),int(im[:,:,3].max())];integrity.append(dict(file=p.name,width=im.shape[1],height=im.shape[0],std=float(im[:,:,:3].std()),nonwhite_pixels=int((im[:,:,:3]<245).any(2).sum()),alpha=alpha));assert alpha is None or alpha==[255,255]
 save('metrics/PNG_INTEGRITY.json',integrity);print('figures',len(integrity))
if __name__=='__main__':main()

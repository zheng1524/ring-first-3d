from common import *
files=list((R/'scripts').glob('*.py'))+[R/'config.json',R/'DATA_USAGE_MANIFEST.md']+list((R/'inputs').glob('*'))+list((R/'observations').glob('*'))
for p in [PROJECT/'ring_anchor_3d/scripts/geometry.py',PROJECT/'ring_anchor_3d/experiments/ring_pose_contact_v1/scripts/recover.py'] :files.append(p)
freeze('protocol',files);print('FROZEN',len(files),'inputs/source paths; no GT')

"""Reproduce numeric experiment in a NEW sibling directory; existing outputs never overwritten."""
from pathlib import Path
import argparse,shutil,subprocess

def main():
 p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);a=p.parse_args();src=Path(__file__).resolve().parents[1];dst=a.destination.resolve();assert dst.parent==src.parent,'use a new sibling experiment for fixed source paths';dst.mkdir(exist_ok=False)
 for name in ['scripts','inputs','observations']:shutil.copytree(src/name,dst/name)
 for name in ['config.json','DATA_USAGE_MANIFEST.md']:shutil.copy2(src/name,dst/name)
 for name in ['predictions','metrics','logs','visualizations','exports']:(dst/name).mkdir()
 py=src.parents[2]/'ring_anchor_3d/.venv/bin/python'
 for name in ['freeze_protocol.py','visual_initialize.py','ring_candidates.py','run_real.py','evaluate_real.py','diagnostics.py','spatial_diagnostics.py','visualize.py']:
  with (dst/'logs'/f'{name}.log').open('w') as log:subprocess.run([str(py),str(dst/'scripts'/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Numeric reproduction complete:',dst,'; does not overwrite or copy predictions')
if __name__=='__main__':main()

from common import *
from geometry_safe import *
import ast
ns=globals();old=PROJECT/'ring_anchor_3d/experiments/ring_first_v3_static_ba/scripts/diagnostics_safe.py'
node=next(x for x in ast.parse(old.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='epipolar');exec(compile(ast.Module(body=[node],type_ignores=[]),str(old),'exec'),ns)
def F_error(F,p,q):
 x=np.c_[p,np.ones(len(p))];y=np.c_[q,np.ones(len(q))];a=x@F.T;b=y@F;return abs(np.sum(y*a,axis=1))/np.sqrt(np.maximum(np.sum(a[:,:2]**2,1)+np.sum(b[:,:2]**2,1),1e-20))
def main():
 tr=np.load(R/'observations/tracks.npz');xy=tr['xy'];train=tr['train_track'];held=~train&tr['holdout_eligible'];pairs=[]
 for a,b in [(7,8),(8,9),(6,10),(0,15)]:
  ok=np.isfinite(xy[:,a,0])&np.isfinite(xy[:,b,0]);ti=np.flatnonzero(ok&train);hi=np.flatnonzero(ok&held);cv2.setRNGSeed(20261016);F,inl=cv2.findFundamentalMat(xy[ti,a],xy[ti,b],cv2.FM_RANSAC,1.,.999,10000);err=F_error(F,xy[hi,a],xy[hi,b]);d=dict(pair=[a,b],train_matches=len(ti),train_F_inliers=int(inl.sum()),held_matches=len(hi),held_F_sampson=stats(err),polyp_held_F=stats(err[tr['category'][hi]==1]),background_held_F=stats(err[tr['category'][hi]==0]),camera_epipolar={})
  for p in sorted((R/'predictions').glob('[ABC]_*.npz')):
   pp=np.load(p);e=epipolar(pp['c2w'],pp['K'],a,b,xy[hi,a],xy[hi,b]);d['camera_epipolar'][p.stem]=stats(e)
  pairs.append(d)
 # Coordinate-only and optimizer equivariance audit on actually produced A/common arrays.
 audits=[]
 for kc in config()['intrinsics']:
  key=kc['name']
  for rr in range(3):
   path=R/f'predictions/shared_{key}_{rr}.npz'
   if not path.exists():continue
   before=np.load(R/f'predictions/common_{key}_{rr}.npz');after=np.load(path);a=json.loads((R/f'metrics/alignment_{key}_{rr}.json').read_text());U=np.array(a['rotation']);s=a['scale_mm_per_visual_unit'];t=np.array(a['translation']);back=(after['points']-t)@U/s;uv0,z0=project(before['points'],before['c2w'],np.full(len(back),8),before['K']);uv1,z1=project(after['points'],after['c2w'],np.full(len(back),8),after['K']);audits.append(dict(K=key,repeat=rr,roundtrip_max_visual_units=float(np.max(abs(back-before['points']))),projection_change_max_px=float(np.max(abs(uv1-uv0))),alignment_changes_geometry=False))
 save('metrics/failure_diagnostics.json',dict(epipolar=pairs,global_coordinate_checks=audits,interpretation='F uses train only, fixed pairs; held Sampson is correspondence compatibility, not proof of parallax or correct 3D identity. No output is corrected or selected.'))
 freeze('diagnostics',[Path(__file__),R/'metrics/failure_diagnostics.json']);print(json.dumps(clean(pairs),indent=2))
if __name__=='__main__':main()

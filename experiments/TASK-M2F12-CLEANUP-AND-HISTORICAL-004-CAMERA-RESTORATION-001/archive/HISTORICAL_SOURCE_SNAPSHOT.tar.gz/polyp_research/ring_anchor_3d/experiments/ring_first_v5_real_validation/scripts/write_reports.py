from common import *
import shutil

def main():
 data=json.loads((R/'metrics/results.json').read_text());diag=json.loads((R/'metrics/failure_diagnostics.json').read_text());spatial=json.loads((R/'metrics/spatial_diagnostics.json').read_text());cfg=config();summ=data['summary'];passes=sum(x['basic_validation'] for x in summ);improved=sum(x['held_C_minus_B']<0 for x in data['paired']);assert len(summ)==27
 audit='''
| 审计项目 | 必须汇报 |
| --- | --- |
| 目标组数 | 1个DEV视频，固定16帧；3种K×3初值×3方法=27次，不是27个独立样本 |
| 本算法独立成功 | 1/1组产生新预测；27/27次均数值注册16/16及参考8；通过可靠性门槛0/27 |
| 本算法失败 | 可信重建失败1/1组；27次留出MAE均>2px；真实位姿/点精度及认证轮廓误差NaN |
| 历史测量值回退 | 0；仅复用原观测/代码，E/PnP和全部BA本轮重跑，没有旧相机/点云回填 |
| 失败组及具体原因 | 同一DEV视频全部9个K/初值对照，详见[FAILURES.md](FAILURES.md)、[逐帧数据](REAL_EVALUATION.csv)及fig1—5 |
| 最终统计样本 | 全27次及432个方法/帧记录；605条独立留出轨迹/2637观测；0个独立泛化测试组 |
| 是否使用 GT 选择算法 | 否；本轮无真实三维GT，不读Blender GT；源码/参数/观测先冻结，未按误差选初值/换视频/调权；见metrics/freeze_protocol*.json |
'''
 cmd='''
实际运行使用既有 `ring_anchor_3d/.venv/bin/python`，工作目录为本独立实验目录。原资产见 `inputs/source_manifest.json`、`inputs/DXY_reuse.json`、`observations/dxy_original_fits.json`。本轮命令：

```bash
PY=/home/liu/polyp_research/ring_anchor_3d/.venv/bin/python
$PY scripts/prepare.py
$PY scripts/freeze_protocol.py
$PY scripts/visual_initialize.py
$PY scripts/ring_candidates.py
$PY scripts/run_real.py
$PY scripts/evaluate_real.py
$PY scripts/diagnostics.py
$PY scripts/spatial_diagnostics.py
$PY scripts/visualize.py
$PY scripts/write_reports.py
$PY scripts/verify_delivery.py
```

首次评价缺少AST函数依赖`itertools`，没有产出评价文件；仅补导入后使用同一冻结预测重跑。错误日志`logs/evaluate_real.py.log`与成功日志`logs/evaluate_real_retry1.log`均保留。`launch_stage1.py`首次执行在该错误处停止，没有悄悄覆盖或重跑预测。

不要在本轮目录再次运行有写入的求解命令。安全复现数字结果：

```bash
$PY scripts/reproduce.py --destination ../ring_first_v5_reproduce_fresh
```

目标目录必须不存在；脚本只复制源码/固定观测/配置，不复制历史预测，再重新运行。相邻目录结构用于找到只读旧代码与DEV RGB，不能把实验目录孤立搬走后忽略路径依赖。预测防误用钩子拒绝任何外部`predictions`及`private_gt/debug_inputs`读取；它是程序防误用机制，不是OS隔离。
'''
 table='| K / 初值 | A留出MAE px | B留出MAE px | C留出MAE px | C−B px | C参考8 MAE px | C留出p95 / 最大 px | 可靠性 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |\n'
 for k in ['H70','F980','D70']:
  for rr in range(3):
   a,b,c=[next(x for x in summ if x['K']==k and x['repeat']==rr and x['method']==m) for m in 'ABC'];table+=f"| {k}/{rr} | {a['held_MAE']:.3f} | {b['held_MAE']:.3f} | {c['held_MAE']:.3f} | {c['held_MAE']-b['held_MAE']:+.3f} | {c['ref8_MAE']:.3f} | {c['held_p95']:.3f} / {c['held_max']:.3f} | 失败：总留出>2px |\n"
 stability='| K | A跨初值轨迹RMSE/基线 | B | C | C跨初值旋转MAE° |\n| --- | --- | --- | --- | ---: |\n'
 for k in ['H70','F980','D70']:
  vals=[]
  for m in 'ABC':vals.append('/'.join(f'{v:.3f}' for v in data['stability'][m+'_'+k]['center_RMSE_over_median_baseline']))
  stability+=f"| {k} | {vals[0]} | {vals[1]} | {vals[2]} | {data['stability']['C_'+k]['orientation_disagreement_deg']['MAE']:.3f} |\n"
 cover='| K / 初值 | B全帧身份覆盖 | C | B整帧留出包含MAE px | C |\n| --- | ---: | ---: | ---: | ---: |\n'
 for k in ['H70','F980','D70']:
  for rr in range(3):
   vals=[]
   for m in 'BC':
    rg=data['methods'][f'{m}_{k}_{rr}']['ring'];vals.append((np.mean([v['positive_coverage'] for v in rg]),np.mean([v['positive_inclusion_px']['MAE'] for v in rg if v['whole_frame_holdout']])))
   cover+=f'| {k}/{rr} | {vals[0][0]:.3%} | {vals[1][0]:.3%} | {vals[0][1]:.3f} | {vals[1][1]:.3f} |\n'
 ftable='| 固定帧对 | 留出匹配数 | 自由F留出Sampson中位 / MAE / p95 px |\n| --- | ---: | --- |\n'
 for p in diag['epipolar']:
  e=p['held_F_sampson'];ftable+=f"| {p['pair']} | {p['held_matches']} | {e['median']:.3f} / {e['MAE']:.3f} / {e['p95']:.3f} |\n"
 report='''# Ring-First V5：真实DEV验证与停止决定

本轮实际重跑固定真实视频，未启动外观合成。结论：16/16帧可产生数值位姿，但27次A/B/C实验均未通过V3冻结的独立可靠性门槛。完整Ring身份正区域约束使8/9次C相对B的留出RGB误差下降，出现有限的一致性增益；尚不能成为可靠相机/表面重建的证据，更不能声称毫米定位精度。

## 任务解释与继承

实际任务来自用户粘贴的Ring-First V5，优先真实验证。附件《搜索与执行建议报告》作为参考，其600帧/外观资源搜索建议不覆盖V5条件关口。用户列出的带时间戳/“(2)”别名在下载目录未找到对应副本，实际阅读项目V4规范TECHNICAL_REPORT.md、RING_OBSERVATION_AUDIT.md、TECHNOLOGY_REUSE.md及下载目录无“(2)”的建议报告；不把未核验的文献/许可证描述当作本轮实验事实。

V4已验证合成开孔视角投影与基础求解；没有拿合成GT代替真实评价。复用DXY-MID原Ring内/外/Mid拟合及质量缓存、V4完整Mask和几何函数、V3冻结多源轨迹/E/PnP/DLT/BA。新增的是安全真实区域适配、A/B/C对照和独立诊断，没有另造椭圆拟合、改Dxy或深度网络。

## 输入与数据隔离

唯一原视频：`smart_endoscope_20260805/raw/GP_Ip_12.0mm_closed_R10_single_refY_004.mp4`。使用既有16帧[82,156,230,304,378,452,526,600,674,748,822,896,970,1044,1118,1192]，参考索引8/raw674。原1280×720图与INIT标签逐帧SHA对原manifest核验，算法工作640×360。未重新筛组、换帧或网络推理。

先创建DATA_USAGE_MANIFEST.md再接触允许内容；只有这一个重复开发组标DEV。其他未知真实组默认TEST_RESERVED，不打开其图像/视频/纹理，不为内容哈希而读未知媒体；没有新增VAL或泛化测试。相同实物在其他组的关联与INIT训练是否含该实物unknown，因此不作跨样本泛化论断。文件名12mm不是GT。内部研究授权来自用户，不推定可公开再分发。

现有3566轨迹、2852训练轨迹不变；605条允许独立留出，合计2637测试观测，582背景/23息肉留出轨迹，息肉123个测试观测。参考8保留1855观测（1781背景/74息肉），296个独立留出测试观测，其中12个息肉。整轨迹不参加E/PnP/BA；每条留出轨迹用不含参考8的最早/最晚两个观测三角化，其余观测测试。负深度、高误差、退化轨迹不从主评价中删除。

## 坐标、相机与环身份合同

OpenCV相机x右/y下/z前，c2w从相机到当前世界；Ring坐标原点为中心、法向Z，R=5.6mm、r=0.6mm圆形截面完整torus。法向符号和绕轴角均有对称性；任何人为坐标规范不算可观测信息。

三种原生焦距H70=914.014724、F980=980、D70=1048.692495，工作焦距分别457.007362/490/524.346247，主点(319.5,179.5)，D=0仅假设。70°厂商视场轴向未明，不当标定真值，不重拟合旧棋盘。原生像素转换`(u+.5)*.5-.5`，保留像素中心约定。

完整原始Ring Mask共391983身份像素全部保存。原DXY拟合逐帧16/16有效；V4已发现被三维旧适配器错误排除的14699/21987边缘候选（66.85%）不再删除。真实Ring邻接息肉仍保留身份，但Ring/Polyp及Ring/Background的前后顺序没有独立认证，不能把Mask全边界强制当torus自身轮廓，也不把补全Mid/椭圆当真实隐藏观测。

每帧保存完整Mask、最多1200可见区域点；实际损失固定300个正区域点，不因距息肉近而排除。没有背景负样本、没有未认证轮廓贴合损失。整帧4/11从Ring初始化的汇总和C损失完全留出；这两帧候选仅单独保存诊断，不进入全局锚定。

**认证留出Ring自身轮廓误差为NaN**，因为本轮没有独立真实边界角色标签。替代报告整帧留出身份包含误差与覆盖率；另保留全边界到投影的诊断距离，但明确不能叫可见轮廓正确率。未知遮挡区域没有负约束，投影落入非Ring区域也不能自动视为错误。

## 方法与公平性

5DoF候选复用旧decoder/image_seeds/multistart solve；原DXY Mid仅增加初值。三K各16帧，保留8候选、多解和最多120次函数评估，预测只按安全身份损失排序，不读旧相机预测或任何三维GT。48/48产生数值候选，但H70/F980/D70各13/13/14帧保留明显法向歧义；低包含误差只是必要条件，不能认证位姿。

E/PnP/DLT本轮从冻结RGB轨迹重新运行。先共同100步视觉BA；然后：

- A：再100步仅视觉BA，任意单目尺度，不读Ring。
- B：共同视觉几何只施加一个由本轮Ring候选与正区域拟合的全局Sim3，再100步仅视觉BA；获得候选毫米规范，不新增联合Ring项。
- C：从B同一个冻结初始相机、三维点、训练ID和观测Mask开始100步BA，唯一新增项为Ring正身份包含。

B的全局变换不能修正相对轨迹/形状。坐标转换反投影检查：全部9次最大回环误差1.78e-14视觉单位、最大投影变化3.41e-13px。A/B同预算的后续数值优化可能走向略有差异；这不是全局Ring坐标变换的几何收益。B/C支持集逐项一致、全部共同帧16、共同留出605条，未按优化结果裁剪支持集。

共同视觉损失`mean(sqrt(1+||projection-observation||²)-1)`，另有正深度罚。C新增`mean rho(distance(q, projected_torus) * 1[q outside annular projection])`，权重1，不用“背景必在环后”的负项，不调权制造效果。投影采样每条256，评价1024；约束均为图像身份不等式，不复制环深度给息肉，也不强迫接触。

BA仍为V3 float64 Torch LBFGS（100步、lr0.5、strong_wolfe），只将平移/点更新按同一轨迹中位基线归一化，避免毫米单位改变优化尺度。A/B在优化后只按自身初始化固定全局Sim3规范，C只固定不可观测轴内角。开孔视角必要条件、正投影深度和相机远离环作为合法性检查；不靠acos夹紧把非法分支当成功。本轮18个B/C输出的全部288帧通过该必要检查，不能据此认定完整位姿正确。

源码先冻结。BA开始前发现纯视觉自由Sim3需要按自身初始规范恢复，已保存旧源码并发布`freeze_protocol_v2_gauge_before_BA.json`，没有依据评价结果调参。之后仅修复评价AST缺失导入，不改预测/指标。所有版本保存在inputs/protocol_versions与冻结链中。有限采样、最近顶点距离、区域包含开关存在非光滑性；Jacobian奇异值不能当连续物理可观测性证据，尤其不能据数值满秩推断轴内角可观测。

## 全部真实结果

所有误差为640×360工作图像像素；原生像素约为两倍。没有ATE、毫米三维点误差或相对GT误差，均标NaN。主判定沿用V3：≥13注册帧且参考8、≥20测试轨迹、留出MAE≤2px、训练正深度≥0.95、最大相邻旋转≤30°。

'''+table+'''
A/B/C九次留出MAE的中位分别2.856/2.942/2.643px；这些是跨运行中位，不能当作独立样本置信区间。C相对B在8/9次总留出和参考8留出均降低，1/9恶化；C最差留出最大误差15802px必须保留。C训练MAE约0.812—1.005px，与留出2.484—12.359px存在明显差距。所有27次训练正深度比例=1，但留出轨迹正深度最低约0.982；“正深度好看”不能覆盖留出失败。

C留出误差中位约1.836—2.990px、p95约6.549—22.711px，最大约17.551—15802.491px。完整逐方法/帧见REAL_EVALUATION.csv；其空值按CSV缺失/NaN解释。真实中位绝对相对误差因无GT不可计算，不能使用文件名或Dxy替代。

### Ring带来什么

'''+cover+'''
全部9次全帧身份覆盖均升高，整帧4/11留出包含误差7/9次降低，2/9升高。这表明安全Ring身份项确实激活并为部分留出一致性提供信息，不只是坐标变换；但包含关系不是准确轮廓，局部提升尚不能证明真实相机或息肉形态改善。B提供的是候选毫米尺度和环坐标初始化；A保持尺度不可辨识。没有无GT方法可验证其绝对毫米准确性。

H70初值2的参考相机到环候选距离约13.96mm，另两次约35—36mm；F980约37—38mm、D70约38—41mm。固定端点0—15的候选基线H70约6.45—27.38mm。它们不是GT误差，但相同视频几何在不同解分支下明显不一致。不同初值的“毫米/视觉单位”本身不能直接比较，因为初始化单位基线不同；这里用同一参考距离与同一端点对比较。

### 稳定性与内参敏感性

用每个K的初值0为基准，每个其他初值只做一次全序列Sim3进行相对结构稳定性诊断；不是逐帧配准，不生成预测，也不是GT精度。

'''+stability+'''
预设补充门槛轨迹RMSE/基线≤0.05、跨初值旋转MAE≤5°均未满足，且C_H70仍有约0.85基线的形状差异。H70/D70某些初值严重退化，F980表现相对稳定仍无一次通过总留出门槛，不挑F980初值2作为全组成功。K/D真实适用性未确认，但现有证据不能单独把失败归咎焦距或外观。

### 三角化、点类别与空间分布

每次初始三角点2021—2250个，57—99个息肉，其余背景；C现有正深度/≥3帧/≥1°/最大重投影≤2px诊断门后剩1558—1975点。门仅用于“可信点数量”诊断，不从留出主指标删除任何点。原观测1855条参考8轨迹与这些三角化/有效点数不同。

留出端点估计视差中位约5.24—8.35°，归一化DLT非零奇异值条件数中位约3.51—4.12，零空间间隔中位约171—295；前者越大越差，后者越大越可分。按全轨迹中位基线归一化再计算，避免任意单目尺度影响数字。大多数点并非统一低视差失败，但估计视差依赖当前相机，不能作真实运动GT。局部弱点、近负深度和长尾仍存在。

固定示例F980/初值0，A的息肉/背景有效点71/1948，C为69/1875；C改善留出同时有效训练点减少，不能只展示较干净点云。C该例息肉留出MAE4.297px、背景2.453px，息肉明显更难。空间统计按类别给出参考图像凸包覆盖、相机8归一化XYZ的5/50/95分位及视差分布，见metrics/spatial_diagnostics.json。开放点云只画有参考8观测的可见点；图4的95%距离显示裁剪明确标出，全部原点仍在NPZ/PLY，不在指标中裁剪。

固定参考邻域6—10的辅助留出使用相同轨迹：例如C_F980_0局部MAE2.021px、参考8 MAE2.917px，局部缩短时间跨度也未使参考8可靠。它是预定义描述性诊断，不能用来替换失败的全序列主指标。

## 失败归因与Gate 1

'''+ftable+'''
自由F只由训练轨迹估计，表中留出点从未参与F拟合。7—8附近有260个留出对应，中位Sampson0.259px，说明视觉观测并非全面失效；8—9有真实噪声/不一致长尾，但无法单独区分匹配、镜头畸变和非理想成像。0—15仅3个留出且全局联系弱，其自由F结果不能作为强几何判据或外观归因。

| 原因 | 当前证据 | 能否定为主因 |
| --- | --- | --- |
| B1 K/D | 3个未标定K、D=0，初值结果对K有敏感性，历史1080p/720p模式仍未证实一致 | 尚未隔离；保留相机模型不确定性，不强行套旧标定 |
| B2 实物Ring | 未独立测量三维形变，标准torus只是刚性近似 | unknown，不声称已有变形证据 |
| B3 观测/遮挡 | 全身份已保留，但认证自身轮廓缺失；正区域仅提供单侧包含，40/48帧候选保留歧义 | 明确的信息/认证缺口；不是仍在误删66.85%边缘 |
| B4 真实外观/跟踪 | 某些留出对应有噪声，但近参考有大量亚像素Sampson对应；无同几何、仅换外观的真实受控证据 | 不能证明是主因；尚不足触发合成外观分支 |
| B5 视差 | 当前估计多数有5—8°端点视差；弱点/远距离连接和长尾存在 | 不能称全场景纯旋转/无视差，局部条件仍有限 |
| B6 初始化/BA | 同K多初值出现明显形状分支；全局锚定13.96/35—36mm矛盾；训练低残差与留出差距；部分有限采样非光滑性 | 直接支持，应优先定位而非加Ring权重或训练网络 |

Gate 1停止在第一阶段失败审计：既未达到可靠表面重建条件，也没有把主要失败定位为B4。不下载结肠Mesh，不提取其他视频纹理，不生成S0/S1，不训练、不3DGS。是否存在低成本且授权可用的结肠资产本轮未核验，结论为unknown；不拿附件中描述当作已运行事实。

## 图与可复核资产

1. [完整Ring观测及所有初值重投影](visualizations/fig1_real_ring_all_initializations.png)：全部9个C对照，不挑最好案例。
2. [三K/三初值/A-B-C轨迹](visualizations/fig2_trajectories_all_runs.png)：A任意单位、B/C候选毫米，红点为参考8，不能按轨迹外观宣称正确。
3. [独立误差与息肉/背景分解](visualizations/fig3_independent_evaluation.png)。
4. [参考8点云与原RGB](visualizations/fig4_ref8_points_and_RGB.png)：息肉红色、背景蓝色，B/C F980初值0是预设例图，不是指标最优选择。
5. [可检查fig5：真实身份、未知交界及DXY原椭圆](visualizations/fig5_observation_roles_not_blank.png)：直接保留相邻Ring，不强迫切边为轮廓。

PNG程序检查5/5非空、alpha全255，fig5约89万个非白像素；已实际查看fig2/4/5。所有原始数值点在predictions，B/C预设例点云PLY在exports。没有完整息肉网格、隐藏面补全或未经验证体积。

## 最终回答与后续

A：不够可靠；27/27数值成功，0/27通过独立门槛。B：Ring建立候选公制尺度/坐标，并在8/9配对降低留出一致性误差，尚未证明真实定位/三维形态精度。C：主要可证实问题是初始化/几何分支不稳定及遮挡约束不充分，外观不是已证实主因。D：本轮不需要启动高真实性合成。E：条件未触发，低成本结肠资产/纹理收益未核验，不能承诺。

只建议两步：①在同一冻结DEV数据检查环锚定多解与BA参数化/非光滑性，先验证轴内规范不变性和训练支持，继续保留全部初值；②用少量固定留出对应和既有K候选分离K/D系统误差与跟踪误差，不重标定、不换测试组。在这些问题解决前，不进入局部稠密曲面或外观数据扩建。

## 复现、版本与资产保护

'''+cmd+'''
所有新增文件只在本目录。核验5101个历史文件（2436个文本/源码内容哈希，其余媒体仅元数据，不为保护核验读取未知TEST像素）；主仓库14处原未提交修改和DXY只读状态保持。没有修改Dxy、删除、移动或压缩旧资产，清理候选0，不把共享模型/数据列为候选。最终独立核验见metrics/protection_verification.json。

## 固定审计表

'''+audit
 (R/'TECHNICAL_REPORT.md').write_text(report)
 decision='''# Gate 1决定

**停止于真实验证后的失败归因，不启动第二阶段。**

本轮27次实际A/B/C运行均数值注册16/16及参考8，但独立可靠性0/27。C相对B在8/9配对的留出RGB误差下降，跨运行MAE中位2.942→2.643px；原阈值2px仍全部失败。环区域覆盖增加不等于认证轮廓/三维精度，真实位姿误差unknown。

直接证据指向B6初始化/解分支及B3单侧身份信息不足；B1相机模型不确定、B2实物形变unknown。存在匹配噪声，但没有把主要瓶颈独立定位到外观B4；不因真实失败自动合成。多数估计端点有视差，不以更多纹理替代几何可观测性。

因此不下载/搜索新结肠资产，不生成高真实性视频，不训练，不3DGS，不使用保留测试。外部资产低成本可用性未核验，不能给肯定答案。

下一轮最多两项：同一冻结观测的环多解/BA数值不变性核验；固定留出对应的K/D与匹配误差分离。完成这两项前暂停稠密表面扩展。

运行命令、资产、全部失败见[技术报告](TECHNICAL_REPORT.md)、[逐帧CSV](REAL_EVALUATION.csv)、[FAILURES](FAILURES.md)。DXY及历史文件只读、清理候选0。

'''+audit
 (R/'DECISION.md').write_text(decision)
 failures='''# 失败记录

唯一目标组为固定DEV视频`GP_Ip_12.0mm_closed_R10_single_refY_004.mp4`。下表全部9个初值组合均失败，不另择视频或目标帧。每行A/B/C共3次，分母27。

'''+table+'''
1. 参考8均有数值相机，但C参考留出MAE3.557—6.972px，未证明可靠定位。证据：[全初值投影](visualizations/fig1_real_ring_all_initializations.png)、[独立误差](visualizations/fig3_independent_evaluation.png)。
2. C_H70_2比B总留出MAE恶化约1.131px、参考8恶化0.924px。其余8次改善仍未过门槛。不能把8次改善概括为普遍成功。
3. C_D70_1整体MAE降了约6.955px，但最大错误反而从8145px升至15802px，训练有效点下降1835→1558；改进均值不能掩盖严重局部失败。没有滤掉负深度或极端误差留出轨迹。
4. H70初值2出现距Ring约13.96mm候选，与另两次35—36mm明显不同；单帧多解+全局锚定分支不稳，不能视为正确毫米定位。证据：[全轨迹](visualizations/fig2_trajectories_all_runs.png)。
5. 安全正身份区域不能排除所有隐藏环投影，未认证真实自身轮廓，不把Ring/Background背景当恒定后方；认证轮廓误差NaN。证据：[fig5](visualizations/fig5_observation_roles_not_blank.png)。
6. 数值Jacobian含有限轮廓采样/最近顶点/包含切换效应，不代表连续几何可观测性；轴内角仍不可观测。无实际Ring形变GT、无真实相机/点GT，不能报告毫米误差。
7. 工程错误：首次评价AST复用漏import itertools，在输出前报NameError；原错误日志和原源码保留。只修复导入重评冻结预测，无重新求解/调权。BA开始前另有纯视觉规范恢复修正，保存原版、更新时间冻结；不是看结果后选择方法。

全部主评价、辅助Sampson、条件数和空间统计分别在metrics/results.json、failure_diagnostics.json、spatial_diagnostics.json。运行与资产来源见[技术报告](TECHNICAL_REPORT.md)。未修改DXY，未删除旧文件，清理候选0。

'''+audit
 (R/'FAILURES.md').write_text(failures)
 # Publish usage outcome table, preserving exact before-content-read ledger and its initial freeze.
 old=R/'DATA_USAGE_MANIFEST.md';archive=R/'inputs/protocol_versions/DATA_USAGE_MANIFEST_pre_run.md';
 if not archive.exists():shutil.copy2(old,archive)
 old.write_text(archive.read_text()+'\n## 本轮完成后用途与分母核验\n\nDEV分配、未知媒体保护范围保持不变；仅补充执行结果。无VAL/TEST读取、无纹理提取/网络训练；详细运行命令与哈希见TECHNICAL_REPORT.md及metrics/。\n\n'+audit)
 # Human text is <200 Chinese characters; compact fixed audit table included for repository contract.
 human='16帧数值位姿；环约束8/9次改善，但可信验证0/27。先查分支，不合成。Dxy及旧文件未改。\n\n|审计项目|必须汇报|\n|---|---|\n|目标组数|1|\n|本算法独立成功|数值1，可信0|\n|本算法失败|1，精度NaN|\n|历史测量值回退|0|\n|失败组及具体原因|见FAILURES.md|\n|最终统计样本|27/27|\n|是否使用 GT 选择算法|否|\n\n源/命令见技术报告；清理候选0。\n'
 (R/'HUMAN_SUMMARY.md').write_text(human)
 save('metrics/report_checks.json',dict(human_body_characters=len(human.split('\n\n')[0]),human_total_characters=len(human),human_chinese_characters=sum('\u4e00'<=c<='\u9fff' for c in human),csv_rows=432,verified_runs=27,passes=passes,paired_improvements=improved,not_independent_generalization=True))
 print('reports written; human body chars',len(human.split('\n\n')[0]))
if __name__=='__main__':main()

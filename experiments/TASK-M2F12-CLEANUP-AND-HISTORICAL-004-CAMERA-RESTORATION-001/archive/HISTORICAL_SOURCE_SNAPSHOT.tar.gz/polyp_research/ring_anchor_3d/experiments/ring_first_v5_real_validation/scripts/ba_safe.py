"""V3 BA feature implementation reused; only real-safe positive Ring inclusion added.
Coordinates/variable updates normalized by visual median baseline for A/B conditioning parity.
"""
from common import *
import torch

def optimize(poses,X,xy,ids,obsmask,K,ring_enabled=False,steps=None):
 torch.set_num_threads(4);dtype=torch.float64;cfg=config();active=np.flatnonzero(np.isfinite(poses[:,0,0]));N=len(active);lookup={int(f):j for j,f in enumerate(active)}
 length=np.median(np.linalg.norm(poses[active,:3,3]-poses[8,:3,3],axis=1));assert length>1e-12
 C0=torch.tensor(poses[active,:3,3]/length,dtype=dtype);R0=torch.tensor(poses[active,:3,:3],dtype=dtype);kt=torch.tensor(K,dtype=dtype);delta=torch.zeros((N,6),dtype=dtype,requires_grad=True);X0=torch.tensor(X/length,dtype=dtype);offset=torch.zeros_like(X0,requires_grad=True)
 rows=np.array([(n,lookup[int(i)],*xy[j,i]) for n,j in enumerate(ids) for i in active if obsmask[n,i] and np.isfinite(xy[j,i,0])]);pi=torch.tensor(rows[:,0],dtype=torch.long);fi=torch.tensor(rows[:,1],dtype=torch.long);uv=torch.tensor(rows[:,2:],dtype=dtype)
 ringids=[];positive=[]
 for local,i in enumerate(active):
  if ring_enabled and i not in cfg['ring_frame_holdout']:ringids.append(local);positive.append(torch.tensor(np.load(R/f'observations/{i:03d}.npz')['positive'],dtype=dtype))
 th=torch.arange(cfg['ring_contour_samples'],dtype=dtype)*2*np.pi/cfg['ring_contour_samples'];co,si=th.cos(),th.sin();history=[]
 def state():
  w=delta[:,:3];zero=torch.zeros(N,dtype=dtype);skew=torch.stack([zero,-w[:,2],w[:,1],w[:,2],zero,-w[:,0],-w[:,1],w[:,0],zero],1).reshape(N,3,3)
  return C0+delta[:,3:],torch.matrix_exp(skew)@R0,X0+offset
 def rho(e):return torch.sqrt(1+e*e)-1
 def membership(cr,points):
  cr=cr.reshape(2,-1,2);areas=(cr[:,:,0]*torch.roll(cr[:,:,1],-1,1)-cr[:,:,1]*torch.roll(cr[:,:,0],-1,1)).sum(1).abs();oi=int(areas.argmax().detach());ans=[]
  for curve in cr:
   a=curve;b=torch.roll(curve,-1,0);px=points[:,0,None];py=points[:,1,None];cross=((a[None,:,1]>py)!=(b[None,:,1]>py))&(px<(b-a)[None,:,0]*(py-a[None,:,1])/((b-a)[None,:,1]+1e-12)+a[None,:,0]);ans.append(cross.sum(1)%2==1)
  return ans[oi]&~ans[1-oi]
 def loss():
  Cn,rot,points=state();cam=torch.bmm((points[pi]-Cn[fi])[:,None],rot[fi]).squeeze(1);p=cam@kt.T;pred=p[:,:2]/torch.clamp(p[:,2:],min=1e-8);feature=rho(torch.linalg.vector_norm(pred-uv,dim=1)).mean();positive_z=10*torch.relu(.01-cam[:,2]).square().mean();ringloss=feature*0;invalid=feature*0
  if ring_enabled:
   C=Cn*length;aa=C[:,0,None]*co+C[:,1,None]*si-5.6;bb=C[:,2,None];phi=torch.atan2(bb,aa)[:,None,:]+torch.tensor([-1.,1.],dtype=dtype)[None,:,None]*torch.acos(torch.clamp(.6/torch.sqrt(aa*aa+bb*bb),-1+1e-8,1-1e-8))[:,None,:];ring=torch.stack([(5.6+.6*phi.cos())*co,(5.6+.6*phi.cos())*si,.6*phi.sin()],-1).reshape(N,-1,3);rc=torch.bmm(ring-C[:,None],rot);rq=rc@kt.T;proj=rq[:,:,:2]/torch.clamp(rq[:,:,2:],min=.01);terms=[]
   for i,q in zip(ringids,positive):
    distance=torch.cdist(q,proj[i]).min(1).values;terms.append(rho(distance*(~membership(proj[i],q))).mean())
   ringloss=torch.stack(terms).mean()
   # Legal-view barrier; numerical acos clamp is never interpreted as geometric success.
   nn=torch.linalg.vector_norm(C,dim=1);vv=C[:,2].abs()/nn;invalid=1000*(torch.relu(.6/5.6+.001-vv[ringids]).square().mean()+torch.relu(6.2-nn[ringids]).square().mean()+torch.relu(.01-rc[ringids,:,2]).square().mean())
  return feature+positive_z+ringloss+invalid,feature,ringloss,positive_z,invalid
 optim=torch.optim.LBFGS([delta,offset],lr=.5,max_iter=steps or cfg['BA_steps'],line_search_fn='strong_wolfe',tolerance_grad=1e-7,tolerance_change=1e-9)
 def closure():
  optim.zero_grad();total,feature,ring,pos,invalid=loss();total.backward();history.append(dict(total=float(total.detach()),feature=float(feature.detach()),ring=float(ring.detach()),positive=float(pos.detach()),invalid=float(invalid.detach())));return total
 optim.step(closure);C,rot,points=state();out=poses.copy();out[active,:3,3]=C.detach().numpy()*length;out[active,:3,:3]=rot.detach().numpy();return out,points.detach().numpy()*length,history

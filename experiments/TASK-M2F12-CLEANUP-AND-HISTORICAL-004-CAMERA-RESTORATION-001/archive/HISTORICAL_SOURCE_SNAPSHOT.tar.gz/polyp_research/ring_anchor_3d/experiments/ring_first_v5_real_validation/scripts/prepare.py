from common import *
import shutil
cfg=config();manifest=json.loads((R/'inputs/source_manifest.json').read_text());old=R.parent/'ring_first_v3_static_ba'
counts=[]
for i,item in enumerate(manifest):
 for kind,key in [('images','image'),('masks','mask')]:
  p=old/f'inputs/{kind}/{i:03d}.{ "jpg" if key=="image" else "png"}'
  assert sha(p)==item[f'{key}_sha256'],(i,key)
 ob=np.load(R/f'observations/native_{i:03d}.npz');dest={k:ob[k] for k in ob.files}
 for k in ['visible_region','background_region','raw_boundary','ambiguous_boundary','ring_train','ring_heldout','inner','outer','old_accepted','new_supported_DXY_edges']:
  if k in dest:dest[k]=(dest[k]+.5)*.5-.5
 for k in ['ring_mask','polyp_mask','background_mask']:
  if k in dest:dest[k]=cv2.resize(dest[k].astype(np.uint8),(640,360),interpolation=cv2.INTER_NEAREST)>0
 # Full native identity mask remains immutable; 300 deterministic positive samples in loss.
 dest['positive']=dest['visible_region'][np.linspace(0,len(dest['visible_region'])-1,300,dtype=int)]
 np.savez_compressed(R/f'observations/{i:03d}.npz',**dest)
 counts.append(dict(frame=i,raw=item['frame_index'],ring_native=int(ob['ring_mask'].sum()),available_positive=len(dest['visible_region']),loss_positive=300,certified_self_contour=0,background_negatives=0))
save('metrics/observation_contract.json',dict(frames=counts,full_mask_preserved=True,old_proximity_filter=False,ambiguous_edges_retained_as_identity_only=True,certified_real_self_contour_unavailable=True))
print('prepared',sum(x['ring_native'] for x in counts),'native Ring identity pixels')

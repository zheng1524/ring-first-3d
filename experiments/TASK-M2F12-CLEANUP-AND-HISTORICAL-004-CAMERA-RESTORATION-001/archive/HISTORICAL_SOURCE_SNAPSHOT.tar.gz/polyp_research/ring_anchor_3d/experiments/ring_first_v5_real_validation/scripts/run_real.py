from common import *
from geometry_safe import *
from ba_safe import optimize
from scipy.optimize import least_squares

def align_ring(P,X,K,key):
 candidates=json.loads((R/f'predictions/ring_candidates_{key}.json').read_text());active=[int(i) for i in np.flatnonzero(np.isfinite(P[:,0,0])) if i not in config()['ring_frame_holdout']];aa=[];yy=[];normals=[]
 for i in active:
  v=P[i,:3,:3]@np.array(candidates[i]['center']);aa.append(np.c_[np.eye(3),-v]);yy.append(P[i,:3,3]);n=P[i,:3,:3]@np.array(candidates[i]['normal']);n=n if not normals or n@normals[0]>=0 else -n;normals.append(n)
 aa=np.vstack(aa);yy=np.concatenate(yy);a=np.linalg.lstsq(aa,yy,rcond=None)[0]
 if not np.isfinite(a).all() or a[3]<=1e-6:raise ValueError('nonpositive global Ring scale from observed candidates; no fallback')
 s=1/a[3];n=np.mean(normals,0);n/=np.linalg.norm(n);U=Rotation.align_vectors([[0,0,1]],[n])[0].as_matrix();t=-s*U@a[:3];pp,_=transform(P,X[:1],U,s,t)
 if pp[8,2,3]<0:H=np.diag([1.,-1.,-1.]);U=H@U;t=H@t
 params=np.r_[Rotation.from_matrix(U).as_rotvec(),t,np.log(s)];obs={i:np.load(R/f'observations/{i:03d}.npz')['positive'] for i in active}
 def decode(a):return Rotation.from_rotvec(a[:3]).as_matrix(),np.exp(a[6]),a[3:6]
 def residual(a):
  U,s,t=decode(a);pp,_=transform(P,X[:1],U,s,t);out=[]
  for i,p in obs.items():
   try:out.extend(inclusion(contours(pp[i,:3,3],pp[i,:3,:3],K),p))
   except ValueError:out.extend(np.full(len(p),1000.))
  return np.asarray(out)
 fit=least_squares(residual,params,loss='soft_l1',f_scale=1.,max_nfev=config()['scale_fit_nfev'],bounds=(np.r_[np.full(6,-np.inf),-8],np.r_[np.full(6,np.inf),8]))
 U,s,t=decode(fit.x);pp,xx=transform(P,X,U,s,t)
 invalid=[]
 for i in active:
  try:contours(pp[i,:3,3],pp[i,:3,:3],K)
  except ValueError:invalid.append(i)
 if invalid:raise ValueError('Ring anchoring invalid torus views '+str(invalid))
 yaw=-np.arctan2(pp[8,1,0],pp[8,0,0]);Y=Rotation.from_rotvec([0,0,yaw]).as_matrix();pp,xx=transform(pp,xx,Y,1.,np.zeros(3))
 return pp,xx,dict(scale_mm_per_visual_unit=s,rotation=(Y@U).tolist(),translation=(Y@t).tolist(),yaw=yaw,success=bool(fit.success),nfev=int(fit.nfev),identity_inclusion_residual_px=stats(residual(fit.x)),jac_singular=np.linalg.svd(fit.jac,compute_uv=False).tolist(),linear_scale_condition=float(np.linalg.cond(aa)),used_frames=active,changed_relative_trajectory=False,metric_accuracy_unknown=True)

def packsave(name,P,X,ids,mask,K,**extra):np.savez_compressed(R/f'predictions/{name}.npz',c2w=P,points=X,point_ids=ids,observation_mask=mask,K=K,**extra)

def normalize_visual_gauge(P,X,initial):
 # A/B have a free global Sim3. Fix ONLY their own initial reference pose and longest baseline.
 ref=8;base=int(np.argmax(np.linalg.norm(initial[:,:3,3]-initial[ref,:3,3],axis=1)));U=initial[ref,:3,:3]@P[ref,:3,:3].T;s=np.linalg.norm(initial[base,:3,3]-initial[ref,:3,3])/np.linalg.norm(P[base,:3,3]-P[ref,:3,3]);t=initial[ref,:3,3]-s*U@P[ref,:3,3];return transform(P,X,U,s,t)

def main():
 prediction_guard();cfg=config();tracks=np.load(R/'observations/tracks.npz');xy=tracks['xy'];status=[]
 for kc in cfg['intrinsics']:
  key=kc['name']
  for repeat in range(3):
   tag=f'{key}_{repeat}';init=np.load(R/f'predictions/visual_init_{tag}.npz');P=init['c2w'];X=init['points'];ids=init['point_ids'];mask=init['observation_mask'];K=init['K'];record=dict(K=key,repeat=repeat)
   try:
    if len(X)<20 or not np.isfinite(P[8,0,0]):raise ValueError('visual initialization failed')
    # Common visual preparation, then all three arms receive 100 steps.
    P,X,history=optimize(P,X,xy,ids,mask,K,False);packsave('common_'+tag,P,X,ids,mask,K);save('metrics/common_'+tag+'.json',history)
    pa,xa,ha=optimize(P.copy(),X.copy(),xy,ids,mask,K,False);pa,xa=normalize_visual_gauge(pa,xa,P);packsave('A_'+tag,pa,xa,ids,mask,K,ring_scale=False);save('metrics/A_'+tag+'_history.json',ha);print('A',tag,ha[-1],flush=True)
    try:pb,xb,alignment=align_ring(P,X,K,key)
    except Exception as e:
     record.update(success=False,reason=str(e),stage='Ring global initialization',A_numeric=True);status.append(record);save('metrics/run_status.json',status);print('B/C FAILED',tag,str(e),flush=True);continue
    packsave('shared_'+tag,pb,xb,ids,mask,K);save('metrics/alignment_'+tag+'.json',alignment);freeze('shared_'+tag,[R/f'predictions/shared_{tag}.npz',R/f'metrics/alignment_{tag}.json'])
    for method,enabled in [('B',False),('C',True)]:
     pp,xx,h=optimize(pb.copy(),xb.copy(),xy,ids,mask,K,enabled)
     if method=='B':pp,xx=normalize_visual_gauge(pp,xx,pb)
     else:
      yaw=-np.arctan2(pp[8,1,0],pp[8,0,0]);pp,xx=transform(pp,xx,Rotation.from_rotvec([0,0,yaw]).as_matrix(),1.,np.zeros(3))
     packsave(method+'_'+tag,pp,xx,ids,mask,K,ring_scale=True);save('metrics/'+method+'_'+tag+'_history.json',h);print(method,tag,h[-1],flush=True)
    record.update(success=True,frames=int(np.isfinite(P[:,0,0]).sum()),points=len(X),same_B_C_initial=True,same_B_C_support=True,BA_steps=100);status.append(record);save('metrics/run_status.json',status)
   except Exception as e:
    record.update(success=False,reason=str(e));status.append(record);save('metrics/run_status.json',status);print('RUN FAILED',tag,repr(e),flush=True)
 freeze('predictions',list((R/'predictions').glob('*'))+[R/'metrics/run_status.json']);print('REAL_RUNS_COMPLETE',flush=True)
if __name__=='__main__':main()

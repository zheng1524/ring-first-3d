"""Explicit independent 3D schedule; frozen DXY-MID segmentation API, no measurements."""
from common import *
sys.path.insert(0,str(OLD/'experiments/ring_depth_v3/vendor'))
import os
os.environ['HF_MODULES_CACHE']=str(R/'runtime_cache/hf_modules');os.environ['HF_HOME']=str(R/'runtime_cache/hf');sys.path.insert(0,str(DXY/'src'))
from dxy_mid.segmentation import INITSegmentation
from PIL import Image
import torch
conf=config();video=REPO/'smart_endoscope_20260805/raw'/conf['video'];assert video.is_file();source_model=REPO/'experiments/v8_5_cross_ring_pipeline_audit_20261014/freeze/model';cap=cv2.VideoCapture(str(video));fps=cap.get(cv2.CAP_PROP_FPS);count=int(cap.get(cv2.CAP_PROP_FRAME_COUNT));indices=np.rint(np.linspace(82,1192,16)).astype(int);assert indices.max()<count
freeze('sampling_protocol',[R/'config.json',Path(__file__),R/'scripts/common.py']);torch.set_num_threads(4);model=INITSegmentation(source_model,'cuda' if torch.cuda.is_available() else 'cpu');rows=[]
for i,index in enumerate(indices):
 cap.set(cv2.CAP_PROP_POS_FRAMES,int(index));ok,image=cap.read();assert ok;ip=R/'inputs/images'/f'{i:03d}.jpg';mp=R/'inputs/masks'/f'{i:03d}.png';cv2.imwrite(str(ip),image,[cv2.IMWRITE_JPEG_QUALITY,95]);label=model.predict(ip);Image.fromarray(label,mode='L').save(mp);rows.append(dict(source_id=f'real3d-{int(index)}',group=conf['group'],video=conf['video'],ring_mm=10.,frame_index=int(index),timestamp_sec=float(index/fps),image_sha256=sha(ip),mask_sha256=sha(mp),image_path=str(ip),mask_path=str(mp)));print('DECODE_SEGMENT',i,int(index),flush=True)
cap.release();save('inputs/manifest.json',rows);save('preparation/segmentation_provenance.json',dict(source=str(source_model),weights_sha256=sha(source_model/'model.safetensors'),model_class='DXY-MID INITSegmentation unmodified official local API',video=str(video),video_sha256=sha(video),fps=float(fps),frame_count=count,actual_frames=indices.tolist(),schedule_frozen_before_segmentation=True,no_Dxy_measurements=True))
freeze('inputs',list((R/'inputs').rglob('*.jpg'))+list((R/'inputs').rglob('*.png'))+[R/'inputs/manifest.json',R/'config.json']+list((R/'scripts').glob('*.py')));print('CONTINUOUS16_INPUTS_COMPLETE')

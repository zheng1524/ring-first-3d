"""Frame-level audit of exclusion witnesses, restricted to post-freeze diagnosis."""
from vh_common import *
from hull import *
import visualize as vis
plt=vis.plt

def main():
    verify('FORMAL_PREDICTIONS_BEFORE_GT');counts=[];witnesses=[];ledgers=[]
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];data=dict(np.load(R/f'diagnostics/{tag}_GT_surface_samples.npz'));P=data['GT_points_mm'];schedule=load(R/f'inputs/{tag}_schedule.json')['ALL']
        allframes=load(R/f'inputs/{tag}_frames.json');frames={f['index']:f for f in allframes};sc=o3scene(vis.ring)
        for j,index in enumerate(schedule):
            ev=data['events'][:,j];neg=np.isin(ev,[4,5]);v=make_view(frames[index],e['K'],sc)
            counts.append(dict(id=tag,index=index,raw_frame=frames[index]['raw_frame'],GT_surface_denominator=len(P),negative_GT_count=int(neg.sum()),clear_background_negative=int((ev==4).sum()),ring_front_negative=int((ev==5).sum()),ring_behind_UNKNOWN=int((ev==6).sum()),mismatch_UNKNOWN=int((ev==7).sum()),scope='ORACLE_DIAGNOSTIC; disagreement can include camera/Mask/Oracle alignment error'))
            uv,z=project(P,v['pose'],v['K']);ids=np.flatnonzero(neg)
            # All negative witnesses retained, no cherry-picked success subset.
            for i in ids:
                x,y=np.rint(uv[i]).astype(int)
                witnesses.append(dict(id=tag,GT_sample_id=int(i),index=index,raw_frame=frames[index]['raw_frame'],event='CLEAR_BACKGROUND_NEGATIVE' if ev[i]==4 else 'RING_FRONT_NEGATIVE',u=float(uv[i,0]),v=float(uv[i,1]),GT_candidate_axial_z_mm=float(z[i]),CAD_first_hit_z_mm=float(v['ring_z'][y,x]),observed_label=int(v['labels'][y,x]),distance_to_visible_Polyp_px=float(v['polyp_distance'][y,x]),X_mm=float(P[i,0]),Y_mm=float(P[i,1]),Z_mm=float(P[i,2]),scope='ORACLE_DIAGNOSTIC'))
        ranked=sorted([x for x in counts if x['id']==tag],key=lambda x:x['negative_GT_count'],reverse=True)
        fig,ax=plt.subplots(2,3,figsize=(17,11))
        for col,r in enumerate(ranked[:3]):
            f=frames[r['index']];v=make_view(f,e['K'],sc);uv,_=project(P,v['pose'],v['K']);ev=data['events'][:,schedule.index(r['index'])];n=np.isin(ev,[4,5]);p=uv[n]
            rgb=cv2.imread(f['RGB'])[:,:,::-1]
            ax[0,col].imshow(rgb);ax[0,col].scatter(p[:,0],p[:,1],s=.5,c='#e92230',alpha=.5);ax[0,col].axis('off');ax[0,col].set_title(f'idx{r["index"]} raw{r["raw_frame"]}: {r["negative_GT_count"]} GT negatives\nOracle GT projection, not visible tissue proof',fontsize=10)
            lab=v['labels'];ax[1,col].imshow(lab,cmap=vis.ListedColormap(['#d4d8dc','#f5a9bd','#354b68']),vmin=0,vmax=2);ax[1,col].scatter(p[:,0],p[:,1],s=1,c='red',alpha=.7)
            if len(p):
                a,b=np.percentile(p,[2,98],axis=0);ax[1,col].set_xlim(max(0,a[0]-15),min(640,b[0]+15));ax[1,col].set_ylim(min(360,b[1]+15),max(0,a[1]-15))
            ax[1,col].axis('off');ax[1,col].set_title(f'Background negatives {r["clear_background_negative"]}\nRing-front negatives {r["ring_front_negative"]}',fontsize=10)
        vis.done(fig,f'Fig9_{tag}_Exclusion_Witnesses','Fig9 '+tag+' : frames responsible for residual H2 exclusion','ORACLE_DIAGNOSTIC: all candidate GT surface projections; residual causes cannot separate pose, segmentation and Oracle mapping without independent GT pose')
        ledgers.append(dict(id=tag,step='silhouette intersection / residual geometric inconsistency',reason='H2 false-excludes Oracle-aligned GT and still reaches ROI; all conflict points retained',worst_frame_indices=[x['index'] for x in ranked[:3]],worst_raw_frames=[x['raw_frame'] for x in ranked[:3]],evidence=f'visualizations/Fig9_{tag}_Exclusion_Witnesses.png',real_end_to_end_geometry='NaN (no independent GT pose)',numerical_Hull='SUCCESS',safe_deletion='FAILED',complete_geometry='FAILED'))
    csvwrite('metrics/FAILURE_VIEW_COUNTS.csv',counts);csvwrite('diagnostics/ALL_GT_NEGATIVE_WITNESSES.csv',witnesses);save('metrics/FAILURE_LEDGER.json',ledgers);csvwrite('metrics/FAILURE_LEDGER.csv',ledgers)
    # Native-GT cross-section zoom isolates an actual recess from the same fixed scene.
    tag='CONTROL_V4';vol=dict(np.load(R/f'voxels/{tag}_nALL.npz'));solid=np.load(R/f'diagnostics/{tag}_GT_solid.npz')['solid'];axis=np.arange(-15.375,15.5,.25);iy=np.argmin(abs(axis));fig,ax=plt.subplots(1,3,figsize=(16,6))
    for a,method in zip(ax,['H1','H2','H2']):
        a.imshow(vol[method][:,iy,:].T,origin='lower',extent=[-15.5,15.5,-15.5,15.5],cmap=vis.ListedColormap(['white',COLORS[method]]),alpha=.5,interpolation='nearest')
        a.contour(axis,axis,solid[:,iy,:].T,levels=[.5],colors='black',linewidths=2)
        a.set(xlim=(-3,4),ylim=(-7.25,-1.5),xlabel='Ring x / mm',ylabel='Ring z / mm',aspect='equal');a.grid(alpha=.2);a.set_title(method+' / black native GT recess')
    extra=(vol['H2']&~solid)[:,iy,:];ax[2].imshow(extra.T,origin='lower',extent=[-15.5,15.5,-15.5,15.5],cmap=vis.ListedColormap([(1,1,1,0),(1,.65,.05,.7)]),interpolation='nearest');ax[2].set_title('Gold: feasible extra space fills real recess')
    vis.done(fig,'Fig7c_CONTROL_Concavity_Closeup','Fig7c CONTROL: H2 protects hidden tissue but does not recover the native concavity','Known camera frame / original Blender BVH solid / evaluation-only zoom selected to show the recess; no parameter change')
    verify('FORMAL_PREDICTIONS_BEFORE_GT');print('FAILURE_EVIDENCE_COMPLETE',len(witnesses),flush=True)
if __name__=='__main__':main()

"""Deterministic display subset and focused original-geometry views; never replace full Hull."""
from vh_common import *
from hull import extract
import visualize as vis
plt=vis.plt

def main():
    verify('FORMAL_PREDICTIONS_BEFORE_GT');rows=[]
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];vol=dict(np.load(R/f'voxels/{tag}_nALL.npz'));parts={}
        for method in ['H1','H2']:
            display=dict(vol);display[method]=vol[method]&(vol['positive']>=cfg()['min_support_views'])
            m,rec=extract(display,method)
            for k in ['face_support_count','face_unknown_count','face_ROI_cap']:rec.pop(k,None)
            path=R/f'meshes/{tag}_{method}_DISPLAY_POSITIVE2_NOT_OCCUPIED.ply';m.export(path);parts[method]=m
            rows.append(dict(id=tag,method=method,selection='display only: full feasible set intersect >=2 visible Polyp projections; threshold frozen before GT',replaces_formal_Hull=False,**rec))
            sc=trimesh.Scene();vis.scene_add(sc,m,method+'_DISPLAY_POSITIVE2_NOT_OCCUPIED');vis.scene_add(sc,vis.ring,'Known_Ring_CAD',COLORS['ring']);sc.metadata.update(units='m',display_subset_only=True,full_Hull_in_separate_file=True);sc.export(R/f'scenes/{tag}_{method}_DISPLAY_POSITIVE2.glb')
        fig,ax=plt.subplots(2,3,figsize=(17,11))
        for row,method in enumerate(['H1','H2']):
            for a,ang,name in zip(ax[row],vis.ANGLES,vis.NAMES):
                vis.view(a,[(parts[method],COLORS[method],1),(vis.ring,COLORS['ring'],1)],radius=19,angle=ang);a.set_title(method+' '+name+'\n>=2 positive projections DISPLAY SUBSET')
        vis.done(fig,f'Fig2b_{tag}_Supported_Display','Fig2b '+tag+' : supported cone shape separated from zero-support/FOV UNKNOWN slabs','DISPLAY ONLY: >=2 positive silhouette projections do not prove solid tissue; full feasible sets remain in Fig2/3')
        # The same transparent overlay focused on the head underside and the top/side.
        h0=vis.mesh(tag,'H0');fig,ax=plt.subplots(2,3,figsize=(17,11))
        for row,(center,ang,label) in enumerate([((0,0,-2),(-65,5),'underside / lower component'),((0,0,0),(-65,65),'top / side envelope')]):
            for a,method in zip(ax[row],['H0','H1','H2']):
                pp=[(h0,COLORS['H0'],1),(vis.ring,COLORS['ring'],1)]
                if method!='H0':pp.append((parts[method],COLORS[method],.3))
                vis.view(a,pp,center=center,radius=8.5,angle=ang);a.set_title(tag+' '+method+' : '+label+'\nlocal display crop; original mesh unchanged')
        vis.done(fig,f'Fig4b_{tag}_Head_And_Side_Closeup','Fig4b '+tag+' : original open HERO and supported Hull cone in close view','DISPLAY SUBSET: removed zero/one-positive projection space from display only; no prediction points deleted, no geometry recovered')
    save('metrics/DISPLAY_SUBSETS.json',rows);verify('FORMAL_PREDICTIONS_BEFORE_GT')
    print('DETAIL_DISPLAY_COMPLETE',flush=True)
if __name__=='__main__':main()

"""One report only, generated from actual frozen results and relative figure paths."""
from vh_common import *

def fmt(x,n=3):return 'NaN' if x is None or not np.isfinite(x) else f'{x:.{n}f}'
def pct(x):return fmt(100*x,2)+'%' if x is not None else 'NaN'
def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def image(path,alt):return f'![{alt}]({path})\n'
def link(path,title):return f'[{title}]({path})'

def main():
    rr=load(R/'metrics/REAL_HULLS.json');gt=load(R/'metrics/GT_REAL.json');control=load(R/'metrics/GT_CONTROL.json');ps=load(R/'metrics/HERO_STATES.json');gp=load(R/'metrics/GT_POINTS.json');h0=load(R/'metrics/H0_SAME_GT_COMPARISON.json');sp=load(R/'metrics/CAMERA_SPANS.json');failure=load(R/'metrics/FAILURE_LEDGER.json');audit=load(R/'metrics/CAMERA_AUDIT.json')
    freezeinfo=load(R/'provenance/FORMAL_PREDICTIONS_BEFORE_GT.json');gain=load(R/'metrics/CONTROL_PAIRED.json')
    allr=[q for q in rr if q['view_label']=='ALL'];allg=[q for q in gt if q['view_label']=='ALL'];allc=[q for q in control if q['view_label']=='ALL']
    statsrows=[]
    for q in allg:
        d=q['Hull_uncapped_to_GT_mm'];statsrows.append(dict(id=q['id'],method=q['method'],mode='ORACLE_DIAGNOSTIC',surface='full Hull except explicitly identified ROI cap faces; UNKNOWN boundaries still included',sampled_uncapped_surface_points=d['n'],median_mm=d['median'],MAE_mm=d['MAE'],p95_mm=d['p95'],max_mm=d['max'],median_ARE_to_GT_bboxdiag=q['median_absolute_relative_error_to_GT_bboxdiag'],GT_surface_denominator=30000,GT_surface_feasible_fraction=q['GT_surface_feasible_fraction'],GT_surface_boundary_coverage025=q['GT_surface_within025_of_Hull_boundary']))
    for q in h0:
        d=q['prediction_to_GT_mm'];statsrows.append(dict(id=q['id'],method='H0',mode='ORACLE_DIAGNOSTIC',surface='original open mesh',sampled_uncapped_surface_points=d['n'],median_mm=d['median'],MAE_mm=d['MAE'],p95_mm=d['p95'],max_mm=d['max'],median_ARE_to_GT_bboxdiag=q['median_absolute_relative_error_to_GT_bboxdiag'],GT_surface_denominator=30000,GT_surface_boundary_coverage025=q['GT_boundary_coverage025']))
    csvwrite('metrics/SUMMARY_STATISTICS.csv',statsrows)
    parts=[]
    parts.append('# Occlusion-Aware Visual Hull：实际三维形状、Ring 遮挡与 HERO 约束\n\n日期：2026-10-24，Asia/Shanghai。独立目录 `ring_anchor_3d/experiments/occlusion_visual_hull_20261024/`。\n')
    parts.append('**结论：H2 能保护 Ring 后方的可行空间；目前不能把 Hull 表面作为恢复完成的息肉，也不能据此自动删除 HERO 点。** 两段视频得到的是倾斜的厚剪影锥/柱状包络，004 仍有明显拉长与尖顶，005 顶部和侧面仍拉伸；完整可行域还含图像外 UNKNOWN 薄板和 ROI 截断壁。受控场景证明了遮挡逻辑有效，真实相机与 Mask 的剩余误差仍足以误排除真实形状。\n')
    parts.append(image('visualizations/Fig0_Review_Overview.png','实际侧视三维形状：H0、H1、H2'))
    parts.append('上图 H1/H2 为**仅用于看形状的 ≥2 帧 Polyp 投影支持子集**，阈值在 GT 前固定。它不替换正式完整 Hull，不能当作组织占据。全部 UNKNOWN、碎片和 ROI 壁保留在 Fig2/3 与完整 GLB。三维渲染使用实际全部三角面，无平滑、补洞、GT 修形或生成式图像。\n')
    parts.append('## 固定审计表\n')
    parts.append(table(['审计项目','必须汇报'],[
      ['目标组数','真实 1 组 G01，2 段独立视频 004/005；另有 1 个既有 Blender 受控场景，单独列示，不混作第 2 个真实组'],
      ['本算法独立成功','H1/H2 各 1/1 真实组、2/2 视频数值输出；每视频 2/4/8/ALL 共 4 个视角条件。受控场景另 1/1。数值输出不等于正确重建'],
      ['本算法失败','Hull 数值输出失败 0/2；完整真实形状与安全删点均未认证 2/2；真实独立端到端精度 2/2 为 NaN，因为缺少独立 GT 姿态映射'],
      ['历史测量值回退','0；未将 S0、历史 V2、旧照片直径或别路线预测作为 Hull 构建/补齐输入；历史文件只做未改写哈希核验。按用户授权复用相机、底层 Mask、Known Ring 与 H0 HERO 对照资产'],
      ['失败组及具体原因',link('metrics/FAILURE_LEDGER.csv','逐视频失败台账')+'；004 主要见 raw748/1191/303，005 见 raw785/655/516，图证见 Fig9'],
      ['最终统计样本','全部 1/1 真实组、2/2 视频，共同成功配对比较；每视频同一 GT 表面 30,000 个面积采样点。两视频同一息肉，不是两个独立统计组；所有失败和 NaN 均保留'],
      ['是否使用 GT 选择算法','否。正式参数/输入/预测/源码 SHA256 于 '+freezeinfo['UTC']+' 冻结，之后才加载 GT 几何评分。历史 GT 已在旧报告中暴露，本轮不宣称全新盲测；冻结见 '+link('provenance/FORMAL_PREDICTIONS_BEFORE_GT.json','证据')]
    ])+'\n')
    parts.append('## 输入复用、坐标与实验范围\n')
    camrows=[]
    for e in load(R/'inputs/entries.json'):
        aa=[a for a in audit if a['video']==e['video']];ss=next(s for s in sp if s['id']==e['id'])
        camrows.append([e['id'],len(aa),sum(a['inherited_qualified'] for a in aa),sum(a['qualified'] for a in aa),ss['training_views'],sum(a['qualified'] and a['heldout'] for a in aa),fmt(ss['candidate_camera_direction_span_deg'],2),fmt(ss['max_baseline_mm'],2)])
    parts.append(table(['视频','目标帧','继承通过','加 CAD 检查后通过','构建帧','留出帧','候选方向跨度 °','最大基线 mm'],camrows)+'\n')
    parts.append('004 主参考 index8/raw676，辅助 raw303/raw1043；005 主参考 index10/raw459，辅助 raw57/raw745。共保留 6 份原始逐像素 HERO 点云和开放 Mesh，未融合跨参考预测。004、005 从未共用相机或拼接坐标。没有增加其他组：两段已可检验本轮逻辑，额外组多数缺少合格多视角。\n\nK 在 640×360 下 fx=fy=490、cx=319.5、cy=179.5，OpenCV 相机轴向 Z，单位 mm。保留原冻结位姿的实际逆矩阵进行投影，未悄悄正交化继承 BA 的轻微非正交矩阵。PLY/NPZ 为 mm，GLB 严格乘 0.001 转 m。Known R10 环面中心线半径 5.6 mm、截面半径 0.6 mm；环平面不是息肉基底。\n')
    parts.append('复用代码：`ring_first_v1/scripts/common.py` 的 project/unproject/depth_mesh，`surface_fusion_v3/scripts/v3_common.py` 的 o3scene/cast；未重做 Ring-First、HERO、U-Net。Open3D 0.19 首交射线与距离、scikit-image 0.24 Lewiner Marching Cubes、Trimesh 5.1.1 导出。官方接口依据：[Open3D RaycastingScene](https://www.open3d.org/docs/release/python_api/open3d.t.geometry.RaycastingScene.html)、[scikit-image marching_cubes](https://scikit-image.org/docs/stable/api/skimage.measure.html#skimage.measure.marching_cubes)。输入账本和哈希：'+link('inputs/entries.json','来源')+'、'+link('provenance/REUSE.json','复用清单')+'。\n')
    parts.append(image('visualizations/Fig1_RGB_Masks_Cameras.png','Fig1 RGB、可见 Mask 和构建相机'))
    parts.append('## 冻结的 H1/H2 定义与 UNKNOWN\n')
    parts.append('主 ROI 各轴 [-15.5,15.5] mm，来自 `2.5×Ring 外半径6.2`，不由 HERO 或 GT 边界决定。体素 0.25 mm，124³=1,906,624 个中心。扩大 ROI 各轴 [-21.75,21.75] mm、同分辨率，用于截断敏感性检查。Mask 外 2 px 留作不确定带；可见 Ring 腐蚀 2 px，首交前保留 0.5 mm 余量。相机除继承通过标记，还须可见 CAD/Mask IoU≥0.60、观测环边界至 CAD 边界 p95≤6 px。004 index1/2/11 因边界不符新增拒绝；005 继承拒绝的 7 帧继续 UNKNOWN。\n')
    parts.append(table(['每帧证据','H1 标准','H2 遮挡感知'],[
      ['可见 Polyp Mask 内','可行；只记录投影支持','相同；不证明整条射线是组织'],
      ['Mask 外 ≤2 px','UNKNOWN','UNKNOWN'],
      ['可靠可见 Ring 核心，且 CAD 有首交','当作 Mask 外雕刻整条射线','只雕刻首交前 >0.5 mm 的空间；后方 UNKNOWN，允许真实息肉在环后'],
      ['CAD 投影与可见 Ring 身份不一致/边缘','Mask 外则雕刻','UNKNOWN'],
      ['远离 Ring 的背景类别0','按完整剪影假设雕刻','同样条件性雕刻；没有背景深度或基底模型'],
      ['图像外、相机未通过、无可靠遮挡关系','UNKNOWN','UNKNOWN']
    ])+'\n')
    parts.append('H2 的背景负证据仍依赖“非 Ring 区域的可见剪影完整”这一条件。真实若还存在其他遮挡物或漏分割，该条件会失效；本轮没有凭 Mask=0 认证整条射线为物理自由空间。没有背景深度时，也无法进一步判断一般背景后方是否藏有息肉。H2 必须视为 **Ring 遮挡模型下的条件性可行域**，不是任意遮挡下的严格形状上界。\n\nH1/H2 使用相同构建视角、容差和 ROI；逐体素断言 H1⊆H2。格外空间与 UNKNOWN 全部保留，不只取最大连通域。Marching Cubes 是体素中心结果的离散表面，网格面并不具有连续几何的精确证书；原始点分类重新调用连续投影谓词，不靠网格最近面符号。\n')
    parts.append('## 实际三维形状：Fig2–Fig6\n')
    parts.append(image('visualizations/Fig2_G01_004_Hull_Three_Views.png','Fig2 004 完整 H2 正面、侧面、顶部'))
    parts.append(image('visualizations/Fig2b_G01_005_Supported_Display.png','005 H1/H2 有投影支持的三维部分'))
    parts.append('完整视图中，绿色是 H2 包络，金色为支持不足的边界，紫色是人为 ROI 壁；深灰为 Known Ring。004 中央包络正面类似宽柱，侧面则是沿主视线拉长的斜锥，不能读成精确头部/蒂部。005 顶视较接近剪影范围，侧视仍有厚重延长，H2 在环附近增加了一圈允许隐藏组织存在的空间。远离主体的板状体是 FOV/全未知空间与 ROI 的交界，不是恢复出的解剖结构。\n\n在有 ≥2 次可见 Polyp 投影的显示子集中，004 H2 体积仍达 2554.22 mm³、005 达 2013.84 mm³；这只是显示集合大小。将没有投影支持的远处板移出显示，也不会把头部尖锥变成真实圆头，或把厚柱变成细蒂。\n')
    parts.append(image('visualizations/Fig4_G01_004_HERO_Hull_Overlay.png','Fig4 004 原始开放 Mesh 与半透明 H1/H2'))
    parts.append('**004 头部下方与蒂部：** 原始 HERO 的下方开放片、间隙和零散点原样保留。H2 允许环后的连接空间存活，能包住一部分缺失区域；它同时把大块尚未观测空间填成宽柱/斜锥，没有独立恢复头下凹面、细蒂半径或真实连接。**005 顶部与侧面：** H2 扩大顶部侧面的可行范围，但仍没有决定曲面应处在锥内哪一个深度；原始 HERO 错层没有被修复。'+link('visualizations/Fig4b_G01_004_Head_And_Side_Closeup.png','004 近景')+'、'+link('visualizations/Fig4b_G01_005_Head_And_Side_Closeup.png','005 近景')+'。\n')
    parts.append(image('visualizations/Fig6_G01_004_Ring_Occlusion.png','Fig6 Ring 遮挡与局部三维形状'))
    parts.append('## 受控 Blender：遮挡逻辑成立，表面仍不可辨识\n')
    parts.append('只在正式真实预测冻结后运行既有 `ring_first_v4_synthetic_audit` 场景：同一原 Ip 网格、R10、16 帧 GT 相机和理想实例标签。没有为本轮重新摆放模型/相机。原标签中的 255 表示场景无交点，出现在最后 3 帧，独立控制适配器将其保留 UNKNOWN；不作为背景雕刻。真实 H1/H2 不受此适配影响。\n\n实体覆盖使用旧实验已审计的 **原始 Blender BVHTree 原生多边形奇偶射线实体**，同一 ROI、同一 0.25 mm 网格，GT 实体体素体积 501.703125 mm³。边界距离/面积采样使用原冻结三角导出，三角化相对原生射线曾检出最高约 0.037 mm 差异；不把两者混成完全同一精度的 GT。这里没有 Oracle 姿态对齐，属于已知坐标受控验证，不能当作真实视频端到端成绩。\n')
    parts.append(table(['方法','真实实体体素保留','GT 表面可行','误排真实体积 mm³','额外可行空间 mm³','GT距Hull边界≤0.25mm'],[[q['method'],pct(q['GT_solid_coverage']),pct(q['GT_surface_feasible_fraction']),fmt(q['wrong_excluded_GT_volume_mm3']),fmt(q['extra_feasible_volume_mm3']),pct(q['GT_surface_within025_of_Hull_boundary'])]for q in allc])+'\n')
    parts.append(f'H2 相对 H1 增加 {gain["added_feasible_voxels"]} 个可行体素，其中 {gain["added_true_GT_voxels"]} 个是真实组织体素，{gain["added_extra_voxels"]} 个是额外空间。H1 对至少一帧被 Ring 遮挡的 GT 表面误排 100%；H2 在此控制中为 0%。保护隐藏区域的代价是更松的包络，而非得到这些区域的精确表面。'+link('metrics/GT_CONTROL.csv','完整控制指标')+'。\n')
    parts.append(image('visualizations/Fig7_CONTROL_V4_GT_Diagnostic.png','Fig7 受控 GT、Hull 与 HERO 缺失部位'))
    parts.append(image('visualizations/Fig7c_CONTROL_Concavity_Closeup.png','受控真实凹陷被 Hull 额外可行空间填充'))
    parts.append('黑色为原生 GT 截面的真实凹陷，金色为 H2 额外空间；即使相机/Mask 理想，剪影锥也没有恢复该凹陷。控制中原始单参考完美可见深度未覆盖的 GT 表面，有 100% 被 H2 允许，但只有 16.55% 距 H2 边界 ≤0.25 mm。允许存在和表面被恢复必须分开。\n')
    parts.append('## 真实 GT 诊断：共享旧 P0 Oracle H，禁止宣称端到端精度\n')
    parts.append('可信同名原模型是 `01p型/01p-12-/息肉.blend` 的“球体”。当前 SHA 与既有 Blender 导出审计一致，作者单位转 mm、模型身份和拓扑来自原导出；见 '+link('provenance/GT_ASSET_IDENTITY_AUDIT.json','身份审计')+'。真实视频到 GT 作者坐标没有独立姿态映射。这里只复用前轮由 **原 H0/P0** 获得的每视频一次刚性 Oracle H，不运行新 ICP、不缩放、不为 H1/H2 单独对齐、不把 GT 带入构建。全部以下真实形状数字均为 `ORACLE_DIAGNOSTIC`。H 由 H0 拟合产生，含对 H0 的配准偏好，不能把对照表当作独立真实绝对精度认证。\n\nOracle 对齐的模型朝向及头/蒂对应未获独立解剖认证；图中的上下方是 Ring 世界/展示方向。CSV 中 GT 作者 Z 上下四分位只是代理区域，不能称为真实视频的头部/蒂部定量分区。\n')
    parts.append(table(['视频','方法','GT 表面可行','误排真实表面','GT实体体素覆盖','额外空间 mm³','GT距边界≤0.25mm'],[[q['id'],q['method'],pct(q['GT_surface_feasible_fraction']),pct(q['GT_surface_wrongly_excluded_fraction']),pct(q['GT_solid_coverage']),fmt(q['extra_feasible_volume_mm3']),pct(q['GT_surface_within025_of_Hull_boundary'])] for q in allg])+'\n')
    parts.append(image('visualizations/Fig7_G01_004_GT_Diagnostic.png','Fig7 004 Oracle GT 对照'))
    parts.append('H2 比 H1 更少误切 Ring 后方表面，但 004/005 仍分别误排 16.03%/22.28% GT 表面；被 Ring 至少遮挡过一次的 GT 表面子集里，H2 仍误排 17.00%/29.54%，因为其他视角仍可能提供不可靠的背景负证据。H2 表面靠近 GT 的面积比例没有改善：004 为 22.12%，005 为 14.90%；原 H0 完整 GT 面积覆盖仅 22.29%/15.52%，两者均不足以代表完整实体恢复。'+link('visualizations/Fig7_G01_005_GT_Diagnostic.png','005 GT 对照')+'。\n')
    parts.append('### 误差分布与共同成功配对\n\n距离为点到连续三角面最近距离。表中 H1/H2 为**完整可行域边界，去掉明确 ROI cap 面后**的面积采样，仍含未知空间边界；H0 为原开放可见面。各自采样面集合不同，不能仅凭一个方向的均值选择算法。ARE 定义为距离/GT包围盒对角线，中位数为下表中位绝对相对误差；不是 Dxy 或物理量误差。GT→Hull 方向与所有 cap 面统计完整保存在 CSV/JSON。\n')
    parts.append(table(['视频','方法','有效采样点','中位ARE','中位 mm','MAE mm','p95 mm','最大 mm'],[[s['id'],s['method'],s['sampled_uncapped_surface_points'],pct(s['median_ARE_to_GT_bboxdiag']),fmt(s['median_mm']),fmt(s['MAE_mm']),fmt(s['p95_mm']),fmt(s['max_mm'])] for s in sorted(statsrows,key=lambda s:(s['id'],s['method']))])+'\n')
    pair=[]
    for tag in ['G01_004','G01_005']:
        a=next(q for q in allg if q['id']==tag and q['method']=='H1');b=next(q for q in allg if q['id']==tag and q['method']=='H2')
        pair.append([tag,fmt(100*(b['GT_surface_feasible_fraction']-a['GT_surface_feasible_fraction']),2),fmt(b['Hull_uncapped_to_GT_mm']['MAE']-a['Hull_uncapped_to_GT_mm']['MAE']),fmt(100*(b['GT_surface_within025_of_Hull_boundary']-a['GT_surface_within025_of_Hull_boundary']),2)])
    parts.append(table(['共同成功视频','H2−H1 GT表面可行率 pp','H2−H1 边界MAE mm','H2−H1 近GT边界覆盖 pp'],pair)+'\n')
    parts.append('同一真实组、同一 Oracle H、同一 30,000 GT 点配对；不把两视频平均当作跨病例提升。H0 为原始单参考 HERO 开放 Mesh，对照不含历史融合。'+link('metrics/SUMMARY_STATISTICS.csv','扁平统计 CSV')+'、'+link('metrics/GT_REAL.json','完整双向指标')+'。\n')
    parts.append('## HERO 点云：内部、外部、证据不足，全部保留\n')
    parts.append('INSIDE-compatible：无 H2 负证据且至少 2 个可见 Polyp 投影，只说明剪影相容。OUTSIDE-candidate：至少 2 个合格构建相机提供负证据，且这两条观察方向相对点夹角至少 2°；不是独立测量认证。UNKNOWN：证据不足、单视角冲突或视差不足。`mathematically_outside_H2` 另记任何单次负证据，因此 UNKNOWN 中仍可能包含数学上在 Hull 外但不足以稳定判定的点。三类与严格 Hull 内外位应区别阅读。\n')
    parts.append(table(['视频/参考','原始点','内部相容','外部候选','UNKNOWN','自动删除'],[[q['id']+'/'+q['reference'],q['total_points'],q['inside_compatible'],q['outside_candidate'],q['UNKNOWN'],0]for q in ps])+'\n')
    parts.append(image('visualizations/Fig5_G01_004_HERO_Point_States.png','Fig5 004 全部原始点分类'))
    parts.append(table(['视频/参考','外部候选','其中距GT≤0.25mm','距GT>0.25mm','条件性错误点精确率'],[[q['id']+'/'+q['reference'],q['outside_candidate'],q['candidate_GT_supported'],q['candidate_GT_wrong'],pct(q['conditional_bad_point_precision'])]for q in gp])+'\n')
    parts.append('004 主参考 223 个候选中 39 个受 Oracle GT 支持，005 的 155 个中有 26 个；即使两视角与 2° 间隔也没有形成安全删除证书。辅助 raw57 的错误候选精确率较高，但仍有 24 个 GT 支持点，不按 GT 结果挑选某参考部署。全 6 份点云不作跨参考拼接统计；各自保留原视频/帧/像素身份。'+link('metrics/GT_POINTS.csv','逐参考诊断')+'。\n')
    parts.append('## 视角数量、ROI 截断与缺失恢复\n')
    parts.append(table(['视频','视角数','H1 可行体积 mm³','H2 可行体积 mm³','H2 GT表面可行','H2 GT近边界覆盖'],[[tag,n,fmt(next(q for q in rr if q['id']==tag and q['method']=='H1' and q['view_label']==label)['feasible_volume_mm3']),fmt(next(q for q in rr if q['id']==tag and q['method']=='H2' and q['view_label']==label)['feasible_volume_mm3']),pct(next(q for q in gt if q['id']==tag and q['method']=='H2' and q['view_label']==label)['GT_surface_feasible_fraction']),pct(next(q for q in gt if q['id']==tag and q['method']=='H2' and q['view_label']==label)['GT_surface_within025_of_Hull_boundary'])]for tag in ['G01_004','G01_005']for label,n in [(q['view_label'],q['n_views'])for q in rr if q['id']==tag and q['method']=='H2' and q['view_label']!='EXPANDED_ROI']])+'\n')
    parts.append('选择顺序仅由相机方向最远点法给出，是嵌套 2/4/8/ALL；没有根据 GT 误差选视角。更多视角减少可行空间，也可能累积误排。受控 H2 的 GT 表面可行率在 2/4/8/16 帧均 100%，近边界覆盖仅从 16.12% 增到 18.67%，无法用增加类似角度视图解决所有凹陷。真实构建留出各 3 帧 Polyp Mask，H2 高召回但低 IoU；详细见 '+link('metrics/HELDOUT.csv','留出结果')+'。相机估计曾用这些帧 RGB/Ring，因此不称端到端独立留出。\n')
    parts.append(table(['视频','方法','主ROI可行 mm³','扩大ROI可行 mm³','均触边界'],[[q['id'],q['method'],fmt(q['feasible_volume_mm3']),fmt(next(v for v in rr if v['id']==q['id'] and v['method']==q['method'] and v['view_label']=='EXPANDED_ROI')['feasible_volume_mm3']),'是']for q in allr])+'\n')
    parts.append('真实同名 GT 水密模型体积约 958.10 mm³，仅作参考定义；主 ROI 的 H2 是 4992.64/5238.89 mm³，扩大 ROI 后为 28440.50/27943.80 mm³，说明体积强烈依赖截断和完全未知空间。不能把任一 Hull 体积、支持子集体积或 cap 面当成息肉真实体积/表面积。本轮不提取 Dxy、高度、面积、体积测量预测，也不研究背景基底。\n')
    parts.append(table(['视频','原HERO缺失GT样本/30000','缺失GT中H2允许','缺失GT中距H2边界≤0.25mm','HERO或H2边界近GT覆盖（诊断）'],[[q['id'],q['GT_missing_from_HERO_count'],pct(q['GT_missing_but_Hull_compatible_fraction']),pct(q['GT_missing_and_Hull_boundary_within025_fraction']),pct(next(v for v in h0 if v['id']==q['id'])['H2_or_HERO_union_boundary_coverage025_diagnostic'])]for q in allg if q['method']=='H2'])+'\n')
    parts.append('H2 的确给部分 HERO 缺失区域提供了接近 GT 的候选边界；但它还生成大量错误外包空间，上表“或”覆盖只表示两个边界集合中至少一个靠近 GT，没有生成融合 Mesh，也不证明安全补面。尤其头下凹陷、细蒂与不见侧面，没有从剪影中获得唯一深度。\n')
    parts.append('## 逐视频失败、可见证据和局限\n')
    parts.append(table(['对象','失败步骤/具体原因','帧证据'],[[f['id'],'H2 仍排除 Oracle GT；主要负证据来自远环背景剪影冲突，亦含少量 Ring 前方冲突。完整可行域触 ROI，不能闭合为可信息肉。相机/Mask/Oracle映射误差尚不能独立拆分。',','.join('raw'+str(i) for i in f['worst_raw_frames'])+'；'+link(f['evidence'],'Fig9')]for f in failure]+[['CONTROL_V4','H1 将 Ring 后方真实区域排除；H2 保住真实实体，但仍额外包含6973.34 mm³，凹陷被包络填满。',link('visualizations/Fig7c_CONTROL_Concavity_Closeup.png','凹陷证据')]])+'\n')
    parts.append('每个构建帧的负证据数量见 '+link('metrics/FAILURE_VIEW_COUNTS.csv','逐帧计数')+'，全部 GT 点×视角负证据保存在 '+link('diagnostics/ALL_GT_NEGATIVE_WITNESSES.csv','逐点/像素/首交见证')+'；不能由某一帧的负证据直接认定 GT 位姿已认证。\n')
    if (R/'provenance/AUDIT_FIX_REPRODUCIBILITY.json').exists():
        parts.append('实现审计保留两个初始问题：① 第一次正式输出完成后，旧资产哈希核验被 GT 防火墙拦截，移到独立验证进程；在读取 GT 几何之前重跑，44 个几何文件哈希逐字节相同。② 首次受控适配遇到 255 无场景标签而停止，后续只在控制评价适配器将这些像素记 UNKNOWN；真实冻结预测和阈值未改。原脚本、初始清单与日志保留，见 '+link('provenance/AUDIT_FIX_REPRODUCIBILITY.json','重跑证据')+'、'+link('logs/evaluate_attempt00_invalid255.log','控制适配失败日志')+'。后续控制/显示源码为独立文件，没有替换冻结预测器。\n\n局限：真实仅一个 Ip/R10 组，不支持 Is/IIa/R5 外推；Ring 本身对绕轴方位的约束不足；可见性条件和同模型相关误差没有因视角数增加而自动独立。不存在经认证的真实 6DoF/GT 解剖映射。没有以错误点数量、体积或某组 GT 误差挑参数，也没有训练或新推理。\n')
    else:
        parts.append('本次复现直接使用已修复的审计进程和控制标签适配器。正式算法与参数在 GT 前冻结，真实预测在评分后保持不变。初次开发的故障记录仅在原交付目录中保留，不在新运行中伪造历史日志。\n')

    parts.append('## 三维文件、图片索引与复现\n')
    parts.append(table(['视频','完整分层场景','独立 H1','独立 H2'],[[tag,link(f'scenes/{tag}_H0_H1_H2_LAYERED.glb','H0/H1/H2/Ring/冲突点'),link(f'scenes/{tag}_H1_STANDALONE.glb','H1完整Hull'),link(f'scenes/{tag}_H2_STANDALONE.glb','H2完整Hull')]for tag in ['G01_004','G01_005']])+'\n')
    parts.append('完整场景按对象命名包含 Known Ring、Original HERO Mesh、Standard Hull、Occlusion-Aware Hull、冲突点、UNKNOWN 点、ROI cap 和原始辅助参考 Mesh。GLB 本身保留独立节点；在 Blender 导入后于 Outliner 单独开关查看。冲突点另含半径0.055 mm的红色显示球标记，方便不显示POINTS图元的查看器识别；这些球不是息肉重建几何。半透明 H1/H2 均为 BLEND 材质；全量独立 Hull 使用不透明证据着色，避免透明排序误读。**不要把两个 GLB 直接叠成共同注册场景。** ≥2 投影支持显示子集 GLB 另存 `*_DISPLAY_POSITIVE2.glb`，只是展示裁集。\n')
    parts.append('原始和 Hull PLY 位于 `meshes/`，全原始点 PLY/NPZ 位于 `points/`；NPZ 保留 XYZ、像素、帧、逐视角事件、负证据角度及三态分类，未自动删点。体素状态位于 `voxels/`。所有图片相对路径如下：\n')
    figrows=[]
    for p in sorted((R/'visualizations').glob('*.png')):
        figrows.append([p.stem.split('_')[0],link(str(p.relative_to(R)),p.name)])
    parts.append(table(['图','实际 PNG 相对路径'],figrows)+'\n')
    parts.append('复现依赖现有只读底层资产和本仓库 `ring_anchor_3d/.venv`，无需安装/训练/下载模型。使用一个**新的空输出目录**，避免覆盖本轮冻结结果：\n\n```bash\nVH_OUT=/absolute/path/to/a_new_hull_run \\\n  bash ring_anchor_3d/experiments/occlusion_visual_hull_20261024/code/reproduce.sh\n```\n\n算法与复现代码见 '+link('code/hull.py','hull.py')+'、'+link('code/run_real.py','run_real.py')+'、'+link('code/evaluate_diagnostics.py','独立评价')+'、'+link('code/reproduce.sh','完整命令')+'。复核：'+link('metrics/GEOMETRY_TESTS.json','坐标/首交/三态回归检查')+'、'+link('metrics/FINAL_VALIDATION.json','最终资产核验')+'。核验覆盖旧文件保护、原 HERO 顶点面逐项一致、44 文件重复运行一致、全部像素身份、H1⊆H2、GLB 节点/透明材质/米单位、PNG 非空和报告相对链接。\n')
    parts.append('## 六个最终问题与停止决定\n')
    parts.append(table(['问题','本轮回答'],[
      ['1. 实际恢复什么形状？','有限视角的倾斜厚剪影锥/柱状外包络；004尖顶和拉长、005顶部侧面延长，并有 UNKNOWN 板与 ROI 壁。它是可行域，不是完整息肉表面。'],
      ['2. H2 是否更合理？','遮挡逻辑更合理：受控 GT 实体保留从88.12%到100%，真实 Oracle GT表面可行率也增加；表面位置和凹陷并未因此正确。'],
      ['3. 能安全排除 HERO 错点？','能标出多数有错误嫌疑的点；主参考候选仍分别误排39/26个GT支持点，不能自动删除。本轮删除0点。'],
      ['4. 哪些真实结构被误排？','H1严重切除Ring后头部/侧面；H2仍有Oracle对齐的局部外缘、头部侧面和下部表面冲突，见Fig7/9。真实蒂部语义对应未认证，不能冒充精确解剖分区。'],
      ['5. 能恢复缺失头部、侧面、蒂部？','能恢复部分允许存在的空间，少量候选边界接近GT；不能认证真实头下凹陷、细蒂和不可见侧面的唯一曲面，不能据此安全补洞。'],
      ['6. 值得进入正式主线？','适合作为人工审阅的三态几何诊断层。当前不把Hull边界补为正式Mesh，不默认删点，不将Hull体积用于物理测量。']
    ])+'\n')
    parts.append('**本轮完成并停止。保留 H0、完整 H1/H2、全部冲突点和失败证据，交人工审核；不继续跨视频配准、HERO 修改、训练或物理指标研究。**\n')
    (R/'TECHNICAL_REPORT.md').write_text('\n'.join(parts))
    print('REPORT_WRITTEN',len('\n'.join(parts)),len(figrows),flush=True)
if __name__=='__main__':main()

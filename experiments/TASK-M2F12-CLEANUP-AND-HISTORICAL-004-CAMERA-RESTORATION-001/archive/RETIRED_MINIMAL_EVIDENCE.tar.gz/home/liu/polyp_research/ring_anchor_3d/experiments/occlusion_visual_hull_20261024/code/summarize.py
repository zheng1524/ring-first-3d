from vh_common import *
import visualize as vis

def main():
    verify('FORMAL_PREDICTIONS_BEFORE_GT');rows=[]
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];data=dict(np.load(R/f'diagnostics/{tag}_GT_surface_samples.npz'));gt=trimesh.load(R/f'diagnostics/{tag}_GT_ORACLE_DIAGNOSTIC.ply',process=False);m=vis.mesh(tag,'H0')
        p,_=sample_surface(m,cfg()['GT_samples']);D=distance(gt,p);scale=float(data['GT_scale_bboxdiag_mm']);back=data['HERO_distance_mm']
        row=dict(id=tag,method='H0',scope='ORACLE_DIAGNOSTIC',prediction_to_GT_mm=stats(D),GT_to_prediction_mm=stats(back),median_absolute_relative_error_to_GT_bboxdiag=float(np.median(D)/scale),GT_boundary_coverage025=float((back<=.25).mean()),all_full_GT_samples=cfg()['GT_samples'])
        for method in ['H1','H2']:
            hd=data[method+'_boundary_distance_mm'];row[method+'_or_HERO_union_boundary_coverage025_diagnostic']=float(((hd<=.25)|(back<=.25)).mean())
        rows.append(row)
    save('metrics/H0_SAME_GT_COMPARISON.json',rows);csvwrite('metrics/H0_SAME_GT_COMPARISON.csv',rows)
    # Audit the exact original Blender asset identity used by the reused trusted mesh.
    auditpath=E/'multigroup_surface_gt_vnext/gt_mapping/GT_ASSET_AUDIT.json';a=next(q for q in load(auditpath)['groups'] if q['group']=='G01');assert sha(a['source'])==a['SHA256']
    save('provenance/GT_ASSET_IDENTITY_AUDIT.json',dict(original_source=a['source'],original_SHA256=a['SHA256'],original_current_hash_matches=True,selected_object=a['selected_object'],prior_export_audit=str(auditpath),prior_export_audit_SHA256=sha(auditpath),scale_to_mm=a['world_to_mm'],original_extent_mm=a['extent_mm'],reused_after_prediction_freeze=True,no_new_ICP=True,real_camera_to_GT_mapping_independently_known=False))
    # Fixed camera-angle and baseline summary is context, not an absolute pose accuracy score.
    summaries=[]
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];frames=load(R/f'inputs/{tag}_frames.json');schedule=load(R/f'inputs/{tag}_schedule.json')['ALL'];C=np.array([frames[i]['pose'] for i in schedule])[:,:3,3]
        angles=np.degrees(np.arccos(np.clip(unit(C)@unit(C).T,-1,1)));baseline=np.linalg.norm(C[:,None]-C[None],axis=-1)
        summaries.append(dict(id=tag,training_views=len(schedule),candidate_camera_direction_span_deg=float(angles.max()),max_baseline_mm=float(baseline.max()),independent_GT_accuracy=False))
    save('metrics/CAMERA_SPANS.json',summaries)
    fig,ax=vis.plt.subplots(2,3,figsize=(17,11))
    for row,e in enumerate(load(R/'inputs/entries.json')):
        tag=e['id'];models=[vis.mesh(tag,'H0')]+[trimesh.load(R/f'meshes/{tag}_{method}_DISPLAY_POSITIVE2_NOT_OCCUPIED.ply',process=False) for method in ['H1','H2']]
        for a,m,method in zip(ax[row],models,['H0','H1','H2']):
            vis.view(a,[(m,COLORS[method],1),(vis.ring,COLORS['ring'],1)],radius=16,center=(0,0,-2),angle=(0,8));a.set_title(tag+' '+method+(' original OPEN HERO' if method=='H0' else ' >=2-positive DISPLAY ONLY'))
    vis.done(fig,'Fig0_Review_Overview','Review: actual three-dimensional shapes, same SIDE view and metric scale','Hull display subset shown for clarity; full Hull, UNKNOWN slabs and ROI walls remain in Fig2/3. No geometry fused or points deleted.')
    verify('FORMAL_PREDICTIONS_BEFORE_GT');print('SUMMARY_COMPLETE',flush=True)
if __name__=='__main__':main()

"""Give conflict points a small explicit display marker for GLB viewers that hide POINTS."""
from vh_common import *

def main():
    verify('FORMAL_PREDICTIONS_BEFORE_GT');manifest=load(R/'metrics/GLB_MANIFEST.json')
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];path=R/f'scenes/{tag}_H0_H1_H2_LAYERED.glb';sc=trimesh.load(path,force='scene',process=False)
        d=np.load(R/f'points/{tag}_canonical.npz');P=d['XYZ_mm'][d['state']==1]/1000
        name='Hull_HERO_CONFLICT_DISPLAY_SPHERES_radius_0p055mm_NOT_RECONSTRUCTION'
        # The points and original geometry remain intact; these spheres are only display glyphs.
        if any(name in n for n in sc.graph.nodes_geometry):continue
        glyph=trimesh.creation.icosphere(subdivisions=1,radius=.000055)
        vertices=np.concatenate([glyph.vertices+p for p in P])
        faces=np.concatenate([glyph.faces+j*len(glyph.vertices) for j in range(len(P))])
        m=trimesh.Trimesh(vertices,faces,process=False);m.visual.face_colors=np.r_[np.array(COLORS['outside'])*255,255].astype(np.uint8)
        sc.add_geometry(m,node_name=name,geom_name=name);sc.metadata.update(conflict_marker_radius_m=.000055,marker_geometry_is_not_polyp_surface=True)
        sc.export(path)
        for record in manifest:
            if record['file']==str(path.relative_to(R)):
                record['named_nodes']=list(sc.graph.nodes_geometry);record['conflict_marker_radius_mm']=.055;record['markers_are_display_only']=True
    save('metrics/GLB_MANIFEST.json',manifest);verify('FORMAL_PREDICTIONS_BEFORE_GT');print('CONFLICT_MARKERS_EXPORTED',flush=True)
if __name__=='__main__':main()

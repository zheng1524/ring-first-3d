from vh_common import *
from hull import *
import shutil

def main():
    assert not (R/'provenance/FORMAL_PREDICTIONS_BEFORE_GT.json').exists(), 'Frozen outputs; use a new VH_OUT'
    verify('INPUTS_AND_ALGORITHM');firewall()
    ring=trimesh.load(REPO/'ring_anchor_3d/assets/ring_R10.obj',process=False);ring_scene=o3scene(ring)
    rows=[];audits=[];pointrows=[];heldrows=[];fail=[]
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];frames=load(R/f'inputs/{tag}_frames.json');views=[make_view(f,e['K'],ring_scene) for f in frames]
        audits += [dict(video=e['video'],**v['audit']) for v in views]
        save(f'inputs/{tag}_view_audit.json',[v['audit'] for v in views])
        np.savez_compressed(R/f'inputs/{tag}_ring_ray_cache.npz',ring_z_mm=np.array([v['ring_z'] for v in views]),camera_qualified=[v['qualified'] for v in views])
        try: ordered=view_schedule(views)
        except AssertionError as err:
            fail.append(dict(id=tag,step='camera_gate',reason=str(err),result='NaN'));save('metrics/FAILURES.json',fail);continue
        selected={n:ordered[:min(n,len(ordered))] for n in [2,4,8] if n<len(ordered)}
        selected['ALL']=ordered
        save(f'inputs/{tag}_schedule.json',{str(k):[v['index'] for v in vs] for k,vs in selected.items()})
        full=None
        for n,vs in selected.items():
            vol=solve(vs)
            for method in ['H1','H2']:
                m,rec=extract(vol,method)
                np.savez_compressed(R/f'diagnostics/{tag}_{method}_n{n}_faces.npz',**{k:rec.pop(k) for k in ['face_support_count','face_unknown_count','face_ROI_cap']}) if not rec['empty'] else None
                m.export(R/f'meshes/{tag}_{method}_n{n}.ply')
                rows.append(dict(id=tag,video=e['video'],method=method,n_views=len(vs),view_label=str(n),selected_indices=[v['index'] for v in vs],**rec))
                print('HULL',tag,n,method,rec.get('feasible_volume_mm3'),rec.get('ROI_truncated'),flush=True)
            np.savez_compressed(R/f'voxels/{tag}_n{n}.npz',**vol)
            if n=='ALL':full=vol
        # ROI sensitivity fixed in advance; no GT or HERO defines either ROI.
        expanded=solve(ordered,bounds=cfg()['expanded_bounds_mm'])
        for method in ['H1','H2']:
            _,rec=extract(expanded,method)
            for k in ['face_support_count','face_unknown_count','face_ROI_cap']:rec.pop(k,None)
            rows.append(dict(id=tag,video=e['video'],method=method,n_views=len(ordered),view_label='EXPANDED_ROI',**rec))
        np.savez_compressed(R/f'voxels/{tag}_expanded.npz',**expanded)
        canonical=dict(np.load(e['pack']));assert np.allclose(canonical['pose'],np.array(e['pose']))
        packs=[dict(tag='canonical',data=canonical,RGB=e['RGB'],original_mesh=e['mesh'],raw_frame=frames[e['reference']]['raw_frame'])]
        for aux in e['auxiliary_views']:
            packs.append(dict(tag=aux['id'],data=dict(np.load(aux['pack'])),RGB=aux['RGB'],original_mesh=None,raw_frame=frames[aux['camera_index']]['raw_frame']))
        for p in packs:
            pack=p['data'];y,x=np.nonzero(pack['labels']==1);uv=np.c_[x,y];z=pack['depth_mm'][y,x]
            valid=np.isfinite(z)&(z>0);assert valid.all(), 'Invalid raw depths must be handled explicitly'
            P=unproject(z,pack['pose'],uv,pack['K']);state=point_states(P,ordered)
            keys={k:v for k,v in state.items() if v is not None}
            np.savez_compressed(R/f'points/{tag}_{p["tag"]}.npz',XYZ_mm=P,pixel_uv=uv,raw_depth_mm=z,point_id=np.arange(len(P)),raw_frame=p['raw_frame'],camera_pose=pack['pose'],selected_view_indices=[v['index'] for v in ordered],**keys)
            cols=np.array([COLORS['inside'],COLORS['outside'],COLORS['unknown']])[state['state']]
            trimesh.points.PointCloud(P,colors=(255*cols).astype(np.uint8)).export(R/f'points/{tag}_{p["tag"]}_classified.ply')
            if p['original_mesh']:
                m=trimesh.load(p['original_mesh'],process=False)
            else:
                rgb=cv2.imread(p['RGB'])[:,:,::-1];m=depth_mesh(pack['depth_mm'],pack['labels']==1,pack['pose'],pack['K'],rgb)
            m.export(R/f'meshes/{tag}_H0_{p["tag"]}_OPEN.ply')
            pointrows.append(dict(id=tag,reference=p['tag'],raw_frame=p['raw_frame'],total_points=len(P),inside_compatible=int((state['state']==0).sum()),outside_candidate=int((state['state']==1).sum()),UNKNOWN=int((state['state']==2).sum()),single_or_more_negative=int(state['mathematically_outside_H2'].sum()),points_outside_ROI=int((~occupancy_at(full['H2'],P,cfg()['bounds_mm'],cfg()['voxel_mm'])[1]).sum()),automatically_deleted=0))
        # Heldout silhouettes score a voxel Hull projection, with known Ring depth occluding it.
        y,x=np.mgrid[:360:2,:640:2];uv=np.c_[x.ravel(),y.ravel()]
        for method in ['H1','H2']:
            mm=trimesh.load(R/f'meshes/{tag}_{method}_nALL.ply',process=False);scene=o3scene(mm)
            for v in views:
                if not v['qualified'] or not v['heldout']:continue
                hz=cast(scene,v['pose'],v['K'],uv);rz=v['ring_z'][y.ravel(),x.ravel()]
                projected=np.isfinite(hz)&(~np.isfinite(rz)|(hz<rz-.1));gtmask=v['labels'][y.ravel(),x.ravel()]==1
                heldrows.append(dict(id=tag,method=method,index=v['index'],raw_frame=v['raw_frame'],pixel_stride=2,IoU=int((projected&gtmask).sum())/max(1,int((projected|gtmask).sum())),mask_recall=int((projected&gtmask).sum())/max(1,int(gtmask.sum())),not_end_to_end_unseen_RGB=True))
        save('metrics/REAL_HULLS.json',rows);save('metrics/HERO_STATES.json',pointrows)
    save('metrics/REAL_HULLS.json',rows);csvwrite('metrics/REAL_HULLS.csv',rows)
    save('metrics/HERO_STATES.json',pointrows);csvwrite('metrics/HERO_STATES.csv',pointrows)
    save('metrics/CAMERA_AUDIT.json',audits);csvwrite('metrics/CAMERA_AUDIT.csv',audits)
    save('metrics/HELDOUT.json',heldrows);csvwrite('metrics/HELDOUT.csv',heldrows);save('metrics/FAILURES.json',fail)
    paths=[R/'config.json']+list((R/'inputs').glob('*'))+list((R/'meshes').glob('*'))+list((R/'voxels').glob('*'))+list((R/'points').glob('*'))+list((R/'diagnostics').glob('*'))+list(CODE.glob('*.py'))+list((R/'metrics').glob('*'))
    freeze('FORMAL_PREDICTIONS_BEFORE_GT',paths,GT_used=False,final_Hull_reads_HERO=False)
    # Old-asset hash verification includes GT files, so perform it only in the separate validator.
    print('REAL_PREDICTIONS_FROZEN',len(rows),flush=True)
if __name__=='__main__':main()

from vh_common import *
import subprocess

def main():
    assert not (R/'provenance/FORMAL_PREDICTIONS_BEFORE_GT.json').exists(), 'Use VH_OUT for a fresh run'
    for d in ['inputs','provenance','voxels','meshes','points','metrics','diagnostics','visualizations','scenes','logs']:(R/d).mkdir(parents=True,exist_ok=True)
    conf=dict(seed=20261024,voxel_mm=.25,roi_CAD_outer_radius_factor=2.5,
      bounds_mm=[[-15.5,15.5]]*3,expanded_bounds_mm=[[-21.75,21.75]]*3,
      mask_tolerance_px=2.,ring_margin_mm=.5,ring_erode_px=2,
      max_ring_boundary_p95_px=6.,min_ring_visible_IoU=.60,
      min_support_views=2,point_min_negative_views=2,point_min_negative_angle_deg=2.,
      heldout_modulo=4,view_counts=[2,4,8,'ALL'],GT_samples=30000,GT_tolerance_mm=.25,
      camera_policy='existing qualified flag AND independent visible-CAD-vs-label gate; no true pose GT',
      H1='qualified in-frame silhouette complement carves, including ring pixels; FOV and bad cameras UNKNOWN',
      H2='outside silhouette: matched visible ring carves only in front of first CAD hit; behind UNKNOWN; CAD/label mismatch UNKNOWN; ring-clear background carves conditional on silhouette completeness',
      hidden_geometry='feasible set only, not occupied tissue',background_depth_used=False,
      GT_for_real_prediction=False,HERO_for_Hull_generation=False,automatic_deletion=False,
      ROI_from_HERO_or_GT=False,real_groups=1,real_videos=['004','005'],only_one_markdown=True)
    save('config.json',conf)
    src=E/'pointcloud_surface_filter_vnext/inputs/entries.json'
    entries=[e for e in load(src) if e['group']=='G01']
    assert len(entries)==2
    sources={src,REPO/'AGENTS.md',REPO/'ring_anchor_3d/assets/ring_R10.obj'}
    for e in entries:
        cam=dict(np.load(e['camera_file']));poses=cam['c2w'];frames=[]
        assert len(poses)==len(e['ledger'])==len(e['camera_qualified'])
        for j,(v,pose) in enumerate(zip(e['ledger'],poses)):
            for key,hkey in [('RGB_path','RGB_SHA256'),('Mask_path','Mask_SHA256')]:
                assert sha(v[key])==v[hkey], (e['id'],j,key)
                sources.add(Path(v[key]))
            frames.append(dict(index=j,id=v['id'],RGB=v['RGB_path'],Mask=v['Mask_path'],raw_frame=v['raw_frame'],pose=pose,qualified=bool(e['camera_qualified'][j]),heldout=j%conf['heldout_modulo']==0 and j!=e['reference']))
        save('inputs/'+e['id']+'_frames.json',frames)
        sources.update(Path(e[k]) for k in ['camera_file','mesh','pack','depth_source','RGB','Mask'])
        sources.update(Path(v['pack']) for v in e['auxiliary_views'])
    save('inputs/entries.json',entries)
    save('provenance/REUSE.json',dict(functions={str(p):n for p,n in REUSE.items()},libraries=dict(open3d=o3d.__version__,trimesh=trimesh.__version__,numpy=np.__version__),mask_lineage='frozen U-Net labels 0=background,1=polyp,2=visible ring; verified byte hashes from previous ledger',HERO_lineage='canonical frozen axial depth, original pixel identities, no fusion used to fill Hull',ring='known CAD 5.6/0.6 mm',GT_history_exposure=True))
    dirty=subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=REPO,text=True)
    (R/'provenance/git_status_before.txt').write_text(dirty)
    protected=set(sources)
    for line in dirty.splitlines():
        p=REPO/line[3:]
        if p.is_file():protected.add(p)
    # Hash all prior non-vendor experiment products; no historical file is written.
    for root in [E/'pointcloud_surface_filter_vnext',E/'ring_vh_v1']:
        protected.update(p for p in root.rglob('*') if p.is_file() and 'vendor' not in p.parts and '__pycache__' not in p.parts)
    freeze('PROTECTED_OLD_ASSETS',protected)
    freeze('INPUTS_AND_ALGORITHM',sources|set(REUSE)|set(CODE.glob('*.py'))|set((R/'inputs').glob('*.json'))|{R/'config.json'},GT_selection=False)
    print('PREPARED',R,len(entries),len(protected),flush=True)
if __name__=='__main__':main()

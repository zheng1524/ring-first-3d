"""Delivery and immutable-source validation; no new predictions or parameter selection."""
from vh_common import *
from PIL import Image
import struct,re

def main():
    verify('FORMAL_PREDICTIONS_BEFORE_GT');verify('PROTECTED_OLD_ASSETS')
    assert load(R/'metrics/GEOMETRY_TESTS.json')['all_pass']
    auditfix=R/'provenance/AUDIT_FIX_REPRODUCIBILITY.json'
    if auditfix.exists():assert not load(auditfix)['changed_files']
    manifests=[]
    for p in sorted((R/'scenes').glob('*.glb')):
        sc=trimesh.load(p,force='scene',process=False);names=list(sc.graph.nodes_geometry)
        assert len(sc.geometry)>0 and np.isfinite(sc.bounds).all()
        assert np.max(abs(sc.bounds))<.1, (p,sc.bounds) # glTF meters
        if 'LAYERED' in p.name:
            for required in ['Known_Ring','Original_HERO_Mesh','Standard_Hull','Occlusion_Aware_Hull','Hull_HERO_CONFLICT_POINTS']:
                assert any(required in n for n in names),(p,required,names)
            with p.open('rb') as f:raw=f.read()
            n,typ=struct.unpack('<II',raw[12:20]);j=json.loads(raw[20:20+n]);materials=j.get('materials',[])
            assert sum(m.get('alphaMode')=='BLEND' for m in materials)>=2
        manifests.append(dict(file=str(p.relative_to(R)),named_nodes=names,geometry_count=len(sc.geometry),bounds_m=sc.bounds,SHA256=sha(p)))
    pngs=[]
    for p in sorted((R/'visualizations').glob('*.png')):
        a=np.asarray(Image.open(p));assert min(a.shape[:2])>=900 and a.std()>10
        if a.shape[-1]==4:assert (a[:,:,-1]==255).all()
        pngs.append(dict(file=str(p.relative_to(R)),width=a.shape[1],height=a.shape[0],std=float(a.std()),SHA256=sha(p)))
    # All original pixel identities and triangles retained; no automatic point deletion.
    checks=[]
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];m=trimesh.load(R/f'meshes/{tag}_H0_canonical_OPEN.ply',process=False);old=trimesh.load(e['mesh'],process=False)
        assert np.array_equal(m.faces,old.faces) and np.array_equal(m.vertices,old.vertices)
        d=np.load(R/f'points/{tag}_canonical.npz');pack=np.load(e['pack']);assert len(d['point_id'])==int((pack['labels']==1).sum())
        rr=load(R/f'inputs/{tag}_frames.json');assert all(e['video'] in f['id'] for f in rr)
        vol=np.load(R/f'voxels/{tag}_nALL.npz');assert np.all(~vol['H1']|vol['H2'])
        sums=[r for r in load(R/'metrics/HERO_STATES.json') if r['id']==tag]
        assert all(r['inside_compatible']+r['outside_candidate']+r['UNKNOWN']==r['total_points'] and r['automatically_deleted']==0 for r in sums)
        checks.append(dict(id=tag,original_vertices_and_faces_identical=True,all_canonical_pixel_ids_retained=True,H2_superset_H1=True,separate_video_camera_binding=True))
    report=R/'TECHNICAL_REPORT.md';links=[]
    if report.exists():
        text=report.read_text()
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if target.startswith(('http:','https:','#')):continue
            target=target.split('#')[0];assert (R/target).exists(),target;links.append(target)
        for term in ['目标组数','本算法独立成功','本算法失败','历史测量值回退','失败组及具体原因','最终统计样本','是否使用 GT 选择算法']:assert term in text,term
        md=list(R.rglob('*.md'));assert md==[report],md
    save('metrics/PNG_QC.json',pngs);save('metrics/GLB_QC.json',manifests)
    rec=dict(success=True,protected_old_assets_unchanged=True,formal_predictions_unchanged_after_GT=True,GT_independent_real_accuracy='NaN: independent real-to-GT pose absent',original_pixel_and_mesh_checks=checks,PNG_count=len(pngs),GLB_count=len(manifests),report_relative_links_checked=len(links),only_one_Markdown=report.exists(),automatic_deletions=0,historical_measurement_fallback=0,byte_equivalent_rerun_geometry_files=load(auditfix)['checked_geometry_files'] if auditfix.exists() else None)
    save('metrics/FINAL_VALIDATION.json',rec);freeze('DELIVERY',[p for p in R.rglob('*') if p.is_file() and '/logs/' not in str(p) and '/__pycache__/' not in str(p) and p!=R/'provenance/DELIVERY.json'])
    print(json.dumps(clean(rec),ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()

"""Evaluation-only GT process after immutable real predictions. No ICP is performed."""
from vh_common import *
from hull import *
import hull as core

REAL_EVIDENCE = core.evidence
def control_evidence(P,v):
    a,b,c,e=REAL_EVIDENCE(P,v)
    uv,z=project(P,v['pose'],v['K']);xy=np.rint(np.nan_to_num(uv)).astype(int)
    h,w=v['labels'].shape
    inside=(xy[:,0]>=0)&(xy[:,0]<w)&(xy[:,1]>=0)&(xy[:,1]<h)
    ii=np.flatnonzero(inside);invalid=ii[v['labels'][xy[ii,1],xy[ii,0]]==255]
    a[invalid]=False;b[invalid]=False;c[invalid]=False;e[invalid]=0
    return a,b,c,e

def transform(H,P):return P@H[:3,:3].T+H[:3,3]

def score(tag,gt,H,views,volumes,h0,scope,solid_override=None):
    gt_local=gt.copy();gt_local.apply_transform(np.linalg.inv(H))
    gt_local.export(R/f'diagnostics/{tag}_GT_{scope}.ply')
    GP,_=sample_surface(gt,cfg()['GT_samples']);P=transform(np.linalg.inv(H),GP)
    ev=classify(P,views,True);distH0=distance(h0,P);scale=float(np.linalg.norm(gt.extents))
    diag=dict(GT_points_mm=P,HERO_distance_mm=distH0,GT_scale_bboxdiag_mm=scale,**{k:v for k,v in ev.items() if v is not None})
    rows=[]
    for label,vol in volumes.items():
        bounds=np.asarray(vol['bounds_mm']);step=float(vol['voxel_mm']);XX,shape=grid(bounds,step)
        solid=None
        if solid_override is not None and label=='ALL':
            solid=solid_override
            assert solid.shape==shape
        elif gt.is_watertight:
            Q=transform(H,XX);insidebbox=((Q>=gt.bounds[0])&(Q<=gt.bounds[1])).all(1)
            solid=np.zeros(len(Q),bool)
            solid[insidebbox]=o3scene(gt).compute_occupancy(o3d.core.Tensor(Q[insidebbox].astype(np.float32)),nthreads=2,nsamples=3).numpy()>.5
            solid=solid.reshape(shape)
        if label=='ALL' and solid is not None:np.savez_compressed(R/f'diagnostics/{tag}_GT_solid.npz',solid=solid,bounds_mm=bounds,voxel_mm=step,scope=scope)
        for method in ['H1','H2']:
            m=trimesh.load(R/f'meshes/{tag}_{method}_n{label}.ply',process=False)
            ds=distance(m,P);inside,valid=occupancy_at(vol[method],P,bounds,step)
            if label=='ALL':
                diag[method+'_boundary_distance_mm']=ds;diag[method+'_voxel_inside']=inside
                # Continuous point constraints are the authoritative surface exclusion test.
                neg=ev['negative_'+method]>0
            else:
                selected=load(R/f'inputs/{tag}_schedule.json')[label]
                vv=[v for v in views if v['index'] in selected];local=classify(P,vv);neg=local['negative_'+method]>0
            sp,fi=sample_surface(m,cfg()['GT_samples']);cap=np.load(R/f'diagnostics/{tag}_{method}_n{label}_faces.npz')['face_ROI_cap']
            pd=distance(gt,transform(H,sp));uncap=~cap[fi]
            missing=distH0>cfg()['GT_tolerance_mm']
            back=ev['ring_unknown']>0
            zq=np.quantile(GP[:,2],[.25,.75]);regions={'GT_author_lower_quarter_PROXY':GP[:,2]<=zq[0], 'GT_author_upper_quarter_PROXY':GP[:,2]>=zq[1], 'ring_occluded_any_view':back}
            rec=dict(id=tag,method=method,view_label=label,scope=scope,GT_surface_denominator=len(P),
              independent_end_to_end_accuracy=False if scope.startswith('ORACLE') else True,
              GT_surface_feasible_fraction=float((~neg).mean()),GT_surface_wrongly_excluded_fraction=float(neg.mean()),
              GT_surface_voxel_containment=float(inside.mean()),GT_surface_outside_ROI=int((~valid).sum()),
              GT_surface_within025_of_Hull_boundary=float((ds<=.25).mean()),
              GT_to_Hull_boundary_mm=stats(ds),Hull_to_GT_boundary_mm=stats(pd),Hull_uncapped_to_GT_mm=stats(pd[uncap]),
              median_absolute_relative_error_to_GT_bboxdiag=float(np.median(pd[uncap])/scale) if uncap.any() else np.nan,
              GT_missing_from_HERO_count=int(missing.sum()),GT_missing_but_Hull_compatible_fraction=float((~neg)[missing].mean()) if missing.any() else np.nan,
              GT_missing_and_Hull_boundary_within025_fraction=float((ds[missing]<=.25).mean()) if missing.any() else np.nan,
              GT_hidden_by_ring_count=int(back.sum()),ring_hidden_GT_wrongly_excluded_fraction=float(neg[back].mean()) if back.any() else np.nan,
              true_GT_mesh_watertight=bool(gt.is_watertight),GT_shape_volume_mm3=float(abs(gt.volume)) if gt.is_watertight else np.nan,
              GT_bboxdiag_mm=scale,GT_tessellation='frozen trusted Blender triangle export; synthetic native BVH solid separately reused',
              GT_solid_voxels=int(solid.sum()) if solid is not None else None,
              GT_solid_ROI_volume_mm3=float(solid.sum()*step**3) if solid is not None else None,
              GT_solid_coverage=float(vol[method][solid].mean()) if solid is not None and solid.any() else np.nan,
              extra_feasible_volume_mm3=float((vol[method]&~solid).sum()*step**3) if solid is not None else np.nan,
              wrong_excluded_GT_volume_mm3=float((~vol[method]&solid).sum()*step**3) if solid is not None else np.nan)
            rec['regions']={name:dict(n=int(mask.sum()),wrongly_excluded_fraction=float(neg[mask].mean()),boundary_coverage025=float((ds[mask]<=.25).mean())) for name,mask in regions.items() if mask.any()}
            rows.append(rec)
    np.savez_compressed(R/f'diagnostics/{tag}_GT_surface_samples.npz',**diag)
    return rows

def real_evaluation():
    rows=[];pts=[];sources=[]
    prev=E/'multigroup_surface_gt_vnext'
    for e in load(R/'inputs/entries.json'):
        tag=e['id'];q=prev/f'gt_mapping/{e["group"]}_TRUSTED_GT.npz';hp=prev/f'gt_mapping/{tag}_ORACLE_H.json'
        g=np.load(q);gt=trimesh.Trimesh(g['vertices_mm'],g['faces'],process=False);H=np.array(load(hp)['H'])
        sources += [dict(id=tag,GT_source=str(q),GT_SHA256=sha(q),H_source=str(hp),H_SHA256=sha(hp),alignment='historical P0-only rigid Oracle transform frozen before this experiment; no new ICP; no Hull fitting',scope='ORACLE_DIAGNOSTIC')]
        ring=trimesh.load(REPO/'ring_anchor_3d/assets/ring_R10.obj',process=False)
        views=[make_view(f,e['K'],o3scene(ring)) for f in load(R/f'inputs/{tag}_frames.json')]
        schedule=load(R/f'inputs/{tag}_schedule.json');allviews=[v for v in views if v['index'] in schedule['ALL']]
        volumes={k:dict(np.load(R/f'voxels/{tag}_n{k}.npz')) for k in schedule}
        h0=trimesh.load(R/f'meshes/{tag}_H0_canonical_OPEN.ply',process=False)
        rows+=score(tag,gt,H,allviews,volumes,h0,'ORACLE_DIAGNOSTIC')
        for pf in (R/'points').glob(tag+'_*.npz'):
            d=dict(np.load(pf));D=distance(gt,transform(H,d['XYZ_mm']));good=D<=.25;candidate=d['state']==1
            candD=D[candidate];np.savez_compressed(R/f'diagnostics/{pf.stem}_Oracle_point_eval.npz',distance_mm=D,GT_supported025=good,outside_candidate=candidate)
            pts.append(dict(id=tag,reference=pf.stem[len(tag)+1:],scope='ORACLE_DIAGNOSTIC',total=len(D),outside_candidate=int(candidate.sum()),GT_supported025=int(good.sum()),candidate_GT_supported=int((good&candidate).sum()),candidate_GT_wrong=int((~good&candidate).sum()),conditional_bad_point_precision=float((~good)[candidate].mean()) if candidate.any() else np.nan,GT_supported_false_exclusion_rate=float(candidate[good].mean()) if good.any() else np.nan,candidate_GT_distance_mm=stats(candD),point_error_mm=stats(D)))
        print('EVAL_REAL',tag,[(r['method'],r['GT_surface_feasible_fraction'],r['GT_surface_within025_of_Hull_boundary']) for r in rows if r['id']==tag and r['view_label']=='ALL'],flush=True)
    save('metrics/GT_INPUT_SOURCES.json',sources);save('metrics/GT_REAL.json',rows);csvwrite('metrics/GT_REAL.csv',rows)
    save('metrics/GT_POINTS.json',pts);csvwrite('metrics/GT_POINTS.csv',pts)

def synthetic_control():
    syn=E/'ring_first_v4_synthetic_audit';tag='CONTROL_V4'
    cam=dict(np.load(syn/'private_gt/scene.npz'));K=cam['K']
    ring=trimesh.load(syn/'private_gt/models/ring.obj',process=False);ring_scene=o3scene(ring);views=[]
    for i,pose in enumerate(cam['c2w']):
        source=syn/f'inputs/labels/{i:03d}.png';lab=cv2.imread(str(source),0)
        assert set(np.unique(lab))<=set([0,1,2,255])
        tmp=R/f'diagnostics/CONTROL_visible_labels_{i:03d}.png';cv2.imwrite(str(tmp),np.where(lab==255,0,lab).astype(np.uint8))
        v=make_view(dict(index=i,id=f'CONTROL_{i:02d}',RGB=str(syn/f'inputs/rgb/{i:03d}.png'),Mask=str(tmp),pose=pose,qualified=True,heldout=False,raw_frame=i),K,ring_scene)
        v['labels']=lab;v['audit']['invalid255_UNKNOWN_pixels']=int((lab==255).sum());views.append(v)
    ordered=view_schedule(views);schedule={'2':[v['index'] for v in ordered[:2]],'4':[v['index'] for v in ordered[:4]],'8':[v['index'] for v in ordered[:8]],'ALL':[v['index'] for v in ordered]}
    save(f'inputs/{tag}_schedule.json',schedule);save('metrics/CONTROL_CAMERA_AUDIT.json',[v['audit'] for v in views])
    vols={};results=[]
    for n in schedule:
        vs=[v for v in views if v['index'] in schedule[n]];vol=solve(vs);vols[n]=vol
        np.savez_compressed(R/f'voxels/{tag}_n{n}.npz',**vol)
        for method in ['H1','H2']:
            m,rec=extract(vol,method);arrays={k:rec.pop(k) for k in ['face_support_count','face_unknown_count','face_ROI_cap']}
            np.savez_compressed(R/f'diagnostics/{tag}_{method}_n{n}_faces.npz',**arrays);m.export(R/f'meshes/{tag}_{method}_n{n}.ply')
            results.append(dict(id=tag,method=method,view_label=n,n_views=len(vs),scope='CONTROL_KNOWN_GT_CAMERA_ID_MASK',**rec))
    ob=np.load(syn/'private_gt/008.npz');h0=depth_mesh(ob['depth'],ob['labels']==1,cam['c2w'][8],K,cv2.imread(str(syn/'inputs/rgb/008.png'))[:,:,::-1]);h0.export(R/f'meshes/{tag}_H0_canonical_OPEN.ply')
    # Original native Blender BVH solid evaluated at the exact same CAD-defined .25mm grid.
    solid_path=E/'ring_vh_v1/evaluation/GT_native_solids.npz';oldcfg=load(E/'ring_vh_v1/config.json')
    assert np.allclose(oldcfg['roi_mm'],cfg()['bounds_mm']) and oldcfg['voxel_mm']==cfg()['voxel_mm']
    solid=np.load(solid_path)['solid_GT']
    gt=trimesh.load(E/'ring_vh_v1/evaluation/GT_polyp_blender_triangles.obj',process=False)
    rows=score(tag,gt,np.eye(4),ordered,vols,h0,'CONTROL_KNOWN_FRAME',solid)
    # The native BVH solid is authoritative for every view-count subset.
    for r in rows:
        occ=vols[r['view_label']][r['method']];r.update(GT_solid_voxels=int(solid.sum()),GT_solid_ROI_volume_mm3=float(solid.sum()*.25**3),GT_solid_coverage=float(occ[solid].mean()),extra_feasible_volume_mm3=float((occ&~solid).sum()*.25**3),wrong_excluded_GT_volume_mm3=float((~occ&solid).sum()*.25**3),solid_method='audited original Blender BVHTree native polygons; no Oracle alignment')
    full=vols['ALL'];added=full['H2']&~full['H1'];gain=dict(added_feasible_voxels=int(added.sum()),added_true_GT_voxels=int((added&solid).sum()),added_extra_voxels=int((added&~solid).sum()),H2_superset_H1=bool(np.all(~full['H1']|full['H2'])),native_GT_solid_source=str(solid_path),native_GT_solid_SHA256=sha(solid_path),native_GT_surface_approximation_max_ray_discrepancy_mm=.037)
    save('metrics/CONTROL_HULLS.json',results);save('metrics/GT_CONTROL.json',rows);csvwrite('metrics/GT_CONTROL.csv',rows);save('metrics/CONTROL_PAIRED.json',gain)
    print('EVAL_CONTROL',[(r['method'],r['GT_solid_coverage'],r['GT_surface_feasible_fraction']) for r in rows if r['view_label']=='ALL'],flush=True)

def main():
    verify('FORMAL_PREDICTIONS_BEFORE_GT')
    freeze('EVALUATION_PROTOCOL_BEFORE_GT',[Path(__file__),R/'config.json',R/'provenance/FORMAL_PREDICTIONS_BEFORE_GT.json',CODE/'hull.py',CODE/'vh_common.py'])
    # Ideal-camera scene tests the Ring logic; it does not select real parameters or replace real outputs.
    # Old synthetic assets have 255=no scene hit in three frames. These are UNKNOWN,
    # never background/free-space; adapter is confined to evaluation-only controls.
    core.evidence=control_evidence
    synthetic_control()
    core.evidence=REAL_EVIDENCE
    real_evaluation()
    verify('FORMAL_PREDICTIONS_BEFORE_GT');verify('PROTECTED_OLD_ASSETS')
    freeze('EVALUATION_OUTPUTS',list((R/'metrics').glob('GT*'))+list((R/'metrics').glob('CONTROL*'))+list((R/'diagnostics').glob('*GT*'))+[Path(__file__)])
if __name__=='__main__':main()

"""Actual mesh ray renders, scientific figures, and named multi-object GLBs."""
from vh_common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.lines import Line2D
from PIL import Image

plt.rcParams.update({'font.size':10,'axes.titleweight':'medium','figure.facecolor':'white'})
ENT=load(R/'inputs/entries.json')
ring=trimesh.load(REPO/'ring_anchor_3d/assets/ring_R10.obj',process=False)
ANGLES=[(-90,8),(0,8),(-90,90)]
NAMES=['Front (Ring -Y)','Side (Ring +X)','Top (Ring +Z)']

def mesh(tag,method):
    name=f'{tag}_H0_canonical_OPEN.ply' if method=='H0' else f'{tag}_{method}_nALL.ply'
    return trimesh.load(R/'meshes'/name,process=False)

def basis(angle):
    a,e=np.radians(angle);eye=np.array([np.cos(e)*np.cos(a),np.cos(e)*np.sin(a),np.sin(e)])
    di=-eye;up0=[0,0,1] if abs(di[2])<.99 else [0,1,0]
    right=unit(np.cross(di,up0));up=np.cross(right,di);return eye,right,up

def render(parts,center=(0,0,0),radius=20,angle=(-65,24),n=650,cloud=None):
    """Orthographic first-hit rendering per layer, sorted transparency; all triangles participate."""
    eye,right,up=basis(angle);di=-eye
    xx,yy=np.meshgrid(np.linspace(-radius,radius,n),np.linspace(radius,-radius,n))
    orig=np.array(center)+100*eye+xx[...,None]*right+yy[...,None]*up
    rays=o3d.core.Tensor(np.c_[orig.reshape(-1,3),np.tile(di,(n*n,1))].astype(np.float32))
    layers=[]
    for m,color,alpha in parts:
        if not len(m.faces):continue
        out=o3scene(m).cast_rays(rays,nthreads=2);t=out['t_hit'].numpy();fid=out['primitive_ids'].numpy();normal=out['primitive_normals'].numpy();valid=np.isfinite(t)
        col=np.zeros((n*n,3))
        c=np.asarray(m.visual.face_colors[:,:3]/255 if color is None else color)
        if c.ndim==1:col[valid]=c
        else:col[valid]=c[fid[valid]]
        shade=.50+.50*abs(normal@eye);col*=shade[:,None]
        layers.append((t,col,np.where(valid,alpha,0)))
    im=np.ones((n*n,3))
    if layers:
        ts=np.stack([l[0] for l in layers]);cs=np.stack([l[1] for l in layers]);aa=np.stack([l[2] for l in layers]);order=np.argsort(ts,axis=0)[::-1];cols=np.arange(n*n)
        for k in range(len(layers)):
            ids=order[k];al=aa[ids,cols];im=cs[ids,cols]*al[:,None]+im*(1-al[:,None])
    im=(np.clip(im.reshape(n,n,3),0,1)*255).astype(np.uint8)
    if cloud is not None:
        P,C=cloud;Q=P-np.array(center);u=(Q@right/radius+1)/2*(n-1);v=(1-Q@up/radius)/2*(n-1)
        # X-ray point overlay is explicitly labelled in figures; no hidden conflicts are suppressed.
        ids=np.argsort(Q@eye)
        for j in ids:
            if 0<=u[j]<n and 0<=v[j]<n:cv2.circle(im,(int(u[j]),int(v[j])),1,tuple(map(int,C[j]*255)),-1,cv2.LINE_AA)
    # An actual metric scale bar in the orthographic render.
    length=5 if radius<=24 else 10;pix=int(length/(2*radius)*(n-1))
    cv2.line(im,(25,n-30),(25+pix,n-30),(25,30,40),3,cv2.LINE_AA)
    cv2.putText(im,f'{length} mm',(25,n-43),cv2.FONT_HERSHEY_SIMPLEX,.5,(25,30,40),1,cv2.LINE_AA)
    return im

def view(ax,parts,**kwargs):ax.imshow(render(parts,**kwargs));ax.axis('off')
def done(fig,name,title,sub='REAL / independent LOCAL Ring coordinates; 004 and 005 never registered; no GT used to build Hull'):
    fig.suptitle(title+'\n'+sub,fontsize=13)
    fig.tight_layout(rect=[0,.045,1,.94])
    fig.text(.015,.012,'Pink HERO | Blue H1 | Green H2 | Amber insufficient silhouette support | Magenta ROI wall (not anatomy) | Dark Known Ring',fontsize=9)
    fig.savefig(R/f'visualizations/{name}.png',dpi=160,facecolor='white');plt.close(fig)
    print('FIG',name,flush=True)

def cameras(ax,e):
    frames=load(R/f'inputs/{e["id"]}_frames.json');audits=load(R/f'inputs/{e["id"]}_view_audit.json');s=load(R/f'inputs/{e["id"]}_schedule.json')['ALL'];cc=np.array([f['pose'] for f in frames])[:,:3,3]
    ax.plot(*cc.T,color='.65',lw=1)
    for f,a,c in zip(frames,audits,cc):
        col='tab:blue' if f['index'] in s else 'tab:orange' if a['qualified'] else '.7'
        ax.scatter(*c,c=col,s=17);ax.text(*c,str(f['index']),fontsize=6)
        if f['index'] in s:
            end=c+unit(-c)*4;ax.plot(*np.array([c,end]).T,c=col,lw=.7)
    rr=ring.vertices[::80];ax.scatter(*rr.T,c='black',s=.5)
    ax.set(xlabel='x / mm',ylabel='y / mm',zlabel='z / mm');ax.view_init(26,-65);ax.set_box_aspect((1,1,1))
    ax.set_title(e['id']+f' : {len(s)} training views\nblue train / gold heldout / gray rejected',fontsize=10)

def input_figures():
    fig=plt.figure(figsize=(18,11))
    for row,e in enumerate(ENT):
        fs=load(R/f'inputs/{e["id"]}_frames.json');s=load(R/f'inputs/{e["id"]}_schedule.json')['ALL'];idx=[s[0],e['reference'],s[1]]
        for j,i in enumerate(idx):
            f=fs[i];rgb=cv2.imread(f['RGB'])[:,:,::-1];lab=cv2.imread(f['Mask'],0)
            a=fig.add_subplot(4,4,row*8+j+1);a.imshow(rgb);a.axis('off');a.set_title(f'{e["video"]} idx{i} / raw{f["raw_frame"]}')
            a=fig.add_subplot(4,4,row*8+j+5);a.imshow(rgb);overlay=np.zeros((*lab.shape,4));overlay[lab==1]=[.15,.85,.4,.42];overlay[lab==2]=[.2,.45,1,.6];a.imshow(overlay);a.axis('off');a.set_title('Green visible Polyp / blue visible Ring')
        a=fig.add_subplot(2,4,row*4+4,projection='3d');cameras(a,e)
    done(fig,'Fig1_RGB_Masks_Cameras','Fig1 Actual RGB, frozen U-Net observations and cameras used')

def hull_figures():
    for e in ENT:
        tag=e['id'];h1=mesh(tag,'H1');h2=mesh(tag,'H2');h0=mesh(tag,'H0')
        fig,ax=plt.subplots(1,3,figsize=(16,6))
        for a,ang,name in zip(ax,ANGLES,NAMES):
            view(a,[(h2,None,1),(ring,COLORS['ring'],1)],radius=24,angle=ang);a.set_title(name+' / FULL ROI')
        done(fig,f'Fig2_{tag}_Hull_Three_Views','Fig2 '+tag+' : independent H2 three-dimensional feasibility boundary')
        fig,ax=plt.subplots(2,3,figsize=(16,11))
        for row,(m,method) in enumerate([(h1,'H1 standard'),(h2,'H2 occlusion-aware')]):
            for a,ang,name in zip(ax[row],ANGLES,NAMES):
                view(a,[(m,None,1),(ring,COLORS['ring'],1)],radius=24,angle=ang);a.set_title(method+' : '+name)
        done(fig,f'Fig3_{tag}_H1_H2','Fig3 '+tag+' : H1 and H2, same projection and scale; ROI walls exposed')
        fig,ax=plt.subplots(3,3,figsize=(16,15))
        for col,(ang,name) in enumerate(zip([(-65,24),(0,10),(-90,90)],['Oblique','Side','Top'])):
            for row,(parts,title) in enumerate([
                ([(h0,COLORS['H0'],1),(ring,COLORS['ring'],1)],'H0 original OPEN mesh'),
                ([(h0,COLORS['H0'],1),(h1,COLORS['H1'],.23),(ring,COLORS['ring'],1)],'H0 + transparent H1'),
                ([(h0,COLORS['H0'],1),(h2,COLORS['H2'],.23),(ring,COLORS['ring'],1)],'H0 + transparent H2')]):
                view(ax[row,col],parts,radius=14,center=(0,0,-2),angle=ang);ax[row,col].set_title(title+' / '+name+'\nlocal display crop; FULL Hull in Fig2/3')
        done(fig,f'Fig4_{tag}_HERO_Hull_Overlay','Fig4 '+tag+' : raw open HERO versus semi-transparent Hull surfaces')
        raw=dict(np.load(R/f'points/{tag}_canonical.npz'));palette=np.array([COLORS['inside'],COLORS['outside'],COLORS['unknown']]);color=palette[raw['state']]
        fig,ax=plt.subplots(1,3,figsize=(16,6))
        for a,ang,name in zip(ax,ANGLES,NAMES):
            view(a,[(ring,COLORS['ring'],1)],radius=14,center=(0,0,-2),angle=ang,cloud=(raw['XYZ_mm'],color));a.set_title(name+'\nALL raw points, X-ray display')
        done(fig,f'Fig5_{tag}_HERO_Point_States','Fig5 '+tag+' : green INSIDE-compatible / red OUTSIDE-candidate / gold UNKNOWN')
        # Observable contact neighborhood picked by raw source pixel distance to visible Ring, no GT.
        pack=dict(np.load(e['pack']));lab=pack['labels'];uv=raw['pixel_uv'];d=cv2.distanceTransform((lab!=2).astype(np.uint8),cv2.DIST_L2,5);near=d[uv[:,1],uv[:,0]]<10
        center=np.median(raw['XYZ_mm'][near],axis=0) if near.any() else np.zeros(3)
        ij=np.flatnonzero(near);p=uv[ij];cx,cy=np.median(p,axis=0).astype(int) if len(p) else (320,180)
        fig,ax=plt.subplots(2,3,figsize=(16,10));rgb=cv2.imread(e['RGB'])[:,:,::-1]
        ax[0,0].imshow(rgb);ax[0,0].set_xlim(max(0,cx-90),min(640,cx+90));ax[0,0].set_ylim(min(360,cy+80),max(0,cy-80));ax[0,0].axis('off');ax[0,0].set_title('RGB near visible Ring (source-driven crop)')
        ax[0,1].imshow(lab,cmap=ListedColormap(['#d4d8dc','#f5a9bd','#354b68']),vmin=0,vmax=2);ax[0,1].set_xlim(max(0,cx-90),min(640,cx+90));ax[0,1].set_ylim(min(360,cy+80),max(0,cy-80));ax[0,1].axis('off');ax[0,1].set_title('Frozen visible labels, not hidden contour')
        delta=load(R/'metrics/HERO_STATES.json');rr=next(q for q in delta if q['id']==tag and q['reference']=='canonical')
        ax[0,2].axis('off');ax[0,2].text(.02,.9,'All original points retained\n\n'+f'Inside-compatible: {rr["inside_compatible"]}\nOutside candidates: {rr["outside_candidate"]}\nUNKNOWN: {rr["UNKNOWN"]}\n\nRing back: UNKNOWN\nRing front: negative only with CAD hit\nContact boundary is not anatomical contour',va='top',fontsize=12)
        for a,m,title in zip(ax[1],[h1,h2,h2],['H1 standard: Ring cuts the feasible volume','H2: Ring rear region can survive','H2 + HERO, conflicts shown in red (X-ray)']):
            parts=[(m,COLORS['H1'] if m is h1 else COLORS['H2'],.85 if a is not ax[1,2] else .25),(ring,COLORS['ring'],1)]
            if a is ax[1,2]:parts.append((h0,COLORS['H0'],.9))
            view(a,parts,center=center,radius=5.5,angle=(-65,8),cloud=(raw['XYZ_mm'][near],color[near]) if a is ax[1,2] else None);a.set_title(title+'\nfixed near-Ring crop')
        done(fig,f'Fig6_{tag}_Ring_Occlusion','Fig6 '+tag+' : Ring-neighborhood geometry; hidden continuation remains a possibility')

def gt_figures():
    for tag in [e['id'] for e in ENT]+['CONTROL_V4']:
        scope='CONTROL_KNOWN_FRAME' if tag=='CONTROL_V4' else 'ORACLE_DIAGNOSTIC'
        gt=trimesh.load(R/f'diagnostics/{tag}_GT_{scope}.ply',process=False);h1=mesh(tag,'H1');h2=mesh(tag,'H2');h0=mesh(tag,'H0')
        d=dict(np.load(R/f'diagnostics/{tag}_GT_surface_samples.npz'));P=d['GT_points_mm'];nearest=cKDTree(P).query(gt.triangles_center)[1]
        neg1=d['negative_H1']>0;neg2=d['negative_H2']>0;missing=d['HERO_distance_mm']>.25
        col=np.tile([.15,.7,.42],(len(P),1));col[missing]=[.94,.65,.12];col[neg2]=[.9,.12,.15]
        gtcolor=col[nearest];excluded=np.tile([.15,.7,.42],(len(P),1));excluded[neg1]=[.9,.12,.15]
        fig,ax=plt.subplots(2,4,figsize=(20,10))
        for row,(ang,name) in enumerate([((-65,20),'Oblique'),((0,5),'Side')]):
            parts=[([(gt,[.58,.61,.67],1),(ring,COLORS['ring'],1)],'Trusted GT shape'),
                   ([(gt,excluded[nearest],1),(h1,COLORS['H1'],.20),(ring,COLORS['ring'],1)],'GT + H1; red GT excluded by H1'),
                   ([(gt,gtcolor,1),(h2,COLORS['H2'],.20),(ring,COLORS['ring'],1)],'GT + H2; red GT excluded by H2'),
                   ([(gt,gtcolor,1),(h0,COLORS['H0'],.25),(ring,COLORS['ring'],1)],'Gold: >0.25mm from original HERO')]
            for a,(pp,title) in zip(ax[row],parts):
                view(a,pp,radius=14,center=(0,0,-2),angle=ang);a.set_title(title+'\n'+name+' / local crop',fontsize=10)
        sub='CONTROL: known camera frame, ideal Blender instance labels; not a real-video accuracy score' if tag=='CONTROL_V4' else 'ORACLE_DIAGNOSTIC: one old P0-only rigid GT alignment; no Hull ICP, no end-to-end precision claim'
        done(fig,f'Fig7_{tag}_GT_Diagnostic','Fig7 '+tag+' : actual GT geometry, excluded real shape and missing HERO regions',sub)
        # A metric section makes concavities and the coarse filled cone directly visible.
        vol=dict(np.load(R/f'voxels/{tag}_nALL.npz'));solid=np.load(R/f'diagnostics/{tag}_GT_solid.npz')['solid']
        extent=[-15.5,15.5,-15.5,15.5];fig,ax=plt.subplots(1,3,figsize=(17,6));idx=int(np.argmin(abs(np.arange(-15.375,15.5,.25))))
        for a,meth in zip(ax,['H1','H2','difference']):
            if meth!='difference':
                a.imshow(vol[meth][:,idx,:].T,origin='lower',extent=extent,cmap=ListedColormap(['white',COLORS[meth]]),alpha=.55,interpolation='nearest')
                a.contour(np.linspace(-15.375,15.375,124),np.linspace(-15.375,15.375,124),solid[:,idx,:].T,levels=[.5],colors='black',linewidths=1.4)
                a.set_title(meth+' feasible section; black = GT section')
            else:
                v=np.zeros((124,124),np.uint8);v[(vol['H2']&~vol['H1'])[:,idx,:]]=1;v[(solid&~vol['H1'])[:,idx,:]]=2;v[(solid&~vol['H2'])[:,idx,:]]=3
                a.imshow(v.T,origin='lower',extent=extent,cmap=ListedColormap(['white','#8ccfb7','#e7ae37','#d82329']),vmin=0,vmax=3,interpolation='nearest');a.set_title('Green H2 gain / gold GT lost by H1\nred GT still lost by H2')
            a.set(xlabel='Ring x / mm',ylabel='Ring z / mm',aspect='equal');a.axhline(0,color='.65',lw=.7);a.grid(alpha=.15)
        done(fig,f'Fig7b_{tag}_Metric_Section','Fig7b '+tag+' : y approximately 0 mm; cones fill missing cavities and ROI walls are artificial',sub)

def scene_add(sc,m,name,color=None,alpha=1):
    if not len(m.faces):return
    q=m.copy();q.remove_unreferenced_vertices();q.vertices/=1000
    colors=q.visual.face_colors.copy() if color is None else np.tile(np.r_[np.asarray(color)*255,255],(len(q.faces),1))
    colors[:,3]=int(255*alpha);q.visual.face_colors=colors.astype(np.uint8)
    # Vertex colors plus material alpha are honored by glTF viewers; preserve semantic named nodes.
    if alpha<1:
        vc=q.visual.to_texture();vc.material=trimesh.visual.material.PBRMaterial(baseColorFactor=[255,255,255,int(255*alpha)],alphaMode='BLEND',doubleSided=True,roughnessFactor=.8);q.visual=vc
    sc.add_geometry(q,node_name=name,geom_name=name)

def export_scenes():
    manifest=[]
    for e in ENT:
        tag=e['id'];sc=trimesh.Scene();h0=mesh(tag,'H0');h1=mesh(tag,'H1');h2=mesh(tag,'H2')
        scene_add(sc,ring,'Known_Ring_R10_CAD',COLORS['ring'])
        scene_add(sc,h0,'Original_HERO_Mesh_OPEN_ALL_FACES',COLORS['H0'])
        scene_add(sc,h1,'Standard_Hull_H1_FEASIBLE_NOT_TISSUE',COLORS['H1'],.22)
        scene_add(sc,h2,'Occlusion_Aware_Hull_H2_FEASIBLE_NOT_TISSUE',COLORS['H2'],.22)
        for method in ['H1','H2']:
            cap=np.load(R/f'diagnostics/{tag}_{method}_nALL_faces.npz')['face_ROI_cap'];m=mesh(tag,method)
            sub=trimesh.Trimesh(m.vertices,m.faces[cap],process=False);scene_add(sc,sub,method+'_ROI_CAPS_NOT_ANATOMY',COLORS['roi'],.5)
        raw=dict(np.load(R/f'points/{tag}_canonical.npz'));P=raw['XYZ_mm']
        for state,name,color in [(0,'HERO_INSIDE_COMPATIBLE',COLORS['inside']),(1,'Hull_HERO_CONFLICT_POINTS_ALL_RETAINED',COLORS['outside']),(2,'HERO_UNKNOWN_ALL_RETAINED',COLORS['unknown'])]:
            mask=raw['state']==state;pc=trimesh.points.PointCloud(P[mask]/1000,colors=np.tile(np.r_[np.array(color)*255,255],(int(mask.sum()),1)).astype(np.uint8));sc.add_geometry(pc,node_name=name,geom_name=name)
        for p in (R/'meshes').glob(tag+'_H0_*.ply'):
            if 'canonical' not in p.name:scene_add(sc,trimesh.load(p,process=False),p.stem+'_SEPARATE_RAW_REFERENCE',[.76,.63,.68],.6)
        sc.metadata.update(units='m',source_units='mm',scale_from_mm=.001,scope='REAL_LOCAL_UNREGISTERED',actual_video=e['video'],GT_used=False,all_original_points_retained=True,Hull_is_feasible_space=True,roi_bounds_mm=cfg()['bounds_mm'])
        path=R/f'scenes/{tag}_H0_H1_H2_LAYERED.glb';sc.export(path)
        # Fully opaque standalone hulls avoid viewer transparency ambiguity.
        for method in ['H1','H2']:
            one=trimesh.Scene();scene_add(one,mesh(tag,method),method+'_ALL_COMPONENTS_WITH_ROI_AND_UNKNOWN_COLORS');scene_add(one,ring,'Known_Ring_CAD',COLORS['ring']);one.metadata.update(units='m',Hull_is_feasible_space=True);one.export(R/f'scenes/{tag}_{method}_STANDALONE.glb')
        manifest.append(dict(file=str(path.relative_to(R)),unit='m',actual_video=e['video'],named_nodes=list(sc.graph.nodes_geometry),coordinates='independent Ring gauge; never combine 004 and 005',layer_control='select/toggle named objects in Blender or a scene-tree GLB viewer'))
    save('metrics/GLB_MANIFEST.json',manifest)

def view_count_figure():
    rr=load(R/'metrics/REAL_HULLS.json');gg=load(R/'metrics/GT_REAL.json');fig,ax=plt.subplots(2,3,figsize=(17,10))
    for row,e in enumerate(ENT):
        for method,col in [('H1',COLORS['H1']),('H2',COLORS['H2'])]:
            ds=[r for r in rr if r['id']==e['id'] and r['method']==method and r['view_label']!='EXPANDED_ROI'];n=[r['n_views'] for r in ds]
            ax[row,0].plot(n,[r['feasible_volume_mm3'] for r in ds],'o-',c=col,label=method)
            es=[r for r in gg if r['id']==e['id'] and r['method']==method];ax[row,1].plot(n,[100*r['GT_surface_wrongly_excluded_fraction'] for r in es],'o-',c=col,label=method)
            ax[row,2].plot(n,[100*r['GT_surface_within025_of_Hull_boundary'] for r in es],'o-',c=col,label=method)
        for a in ax[row]:a.set_xlabel('training view count');a.grid(alpha=.2);a.legend()
        ax[row,0].set(ylabel='feasible ROI volume / mm3',title=e['id']+' : all views still ROI-truncated')
        ax[row,1].set(ylabel='excluded GT surface / %',title='ORACLE_DIAGNOSTIC, same frozen H')
        ax[row,2].set(ylabel='GT near Hull boundary <=0.25mm / %',title='Containment is not surface reconstruction')
    done(fig,'Fig8_View_Counts','Fig8 Fixed camera-only nested view schedule; no per-group GT parameter selection')

def main():
    verify('FORMAL_PREDICTIONS_BEFORE_GT')
    input_figures();hull_figures();gt_figures();view_count_figure();export_scenes()
    qc=[]
    for p in (R/'visualizations').glob('*.png'):
        a=np.array(Image.open(p).convert('RGB'));assert a.std()>10
        qc.append(dict(file=str(p.relative_to(R)),shape=a.shape,std=float(a.std()),SHA256=sha(p)))
    save('metrics/PNG_QC.json',qc);verify('FORMAL_PREDICTIONS_BEFORE_GT')
    print('VISUALIZATION_COMPLETE',len(qc),flush=True)
if __name__=='__main__':main()

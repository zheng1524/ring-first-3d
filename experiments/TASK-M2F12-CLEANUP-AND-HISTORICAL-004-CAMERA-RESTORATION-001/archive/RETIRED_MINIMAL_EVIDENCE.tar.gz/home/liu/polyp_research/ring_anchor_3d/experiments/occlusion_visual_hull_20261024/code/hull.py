"""Tri-state silhouette constraints. No depth or shape GT is imported here."""
from vh_common import *

EVENT={'OUT_OF_VIEW':0,'BAD_CAMERA':1,'POLYP':2,'BOUNDARY_UNKNOWN':3,
       'CLEAR_BACKGROUND_NEGATIVE':4,'RING_FRONT_NEGATIVE':5,'RING_BEHIND_UNKNOWN':6,
       'CAD_MASK_MISMATCH_UNKNOWN':7}

def make_view(f,K,ring_scene):
    v=dict(f);v['pose']=np.array(f['pose']);v['K']=np.array(K)
    lab=cv2.imread(str(f['Mask']),0);assert lab is not None and set(np.unique(lab))<=set([0,1,2])
    v['labels']=lab; h,w=lab.shape;y,x=np.mgrid[:h,:w];uv=np.c_[x.ravel(),y.ravel()]
    rz=cast(ring_scene,v['pose'],v['K'],uv).reshape(h,w)
    cad=np.isfinite(rz);obs=lab==2;visible_cad=cad&(lab!=1)
    union=(obs|visible_cad).sum();iou=(obs&visible_cad).sum()/max(1,union)
    border=lambda m:m^cv2.erode(m.astype(np.uint8),np.ones((3,3),np.uint8)).astype(bool)
    bb=border(visible_cad);ob=border(obs);dt=cv2.distanceTransform((~bb).astype(np.uint8),cv2.DIST_L2,5)
    d=dt[ob];p95=np.percentile(d,95) if len(d) else np.inf
    # Inherited BA rotations may carry slight nonorthogonality. Reuse their actual affine inverse;
    # do not silently orthogonalize and invalidate the original HERO coordinate relation.
    A=v['pose'][:3,:3];valid_pose=np.isfinite(v['pose']).all() and abs(np.linalg.det(A))>.5
    v['qualified']=bool(f['qualified'] and valid_pose and iou>=cfg()['min_ring_visible_IoU'] and p95<=cfg()['max_ring_boundary_p95_px'])
    v['ring_z']=rz
    tol=cfg()['mask_tolerance_px']
    v['polyp_distance']=cv2.distanceTransform((lab!=1).astype(np.uint8),cv2.DIST_L2,5)
    v['ring_core']=cv2.erode(obs.astype(np.uint8),np.ones((2*cfg()['ring_erode_px']+1,)*2,np.uint8))>0
    v['near_ring']=cv2.dilate((obs|cad).astype(np.uint8),np.ones((2*int(np.ceil(tol))+1,)*2,np.uint8))>0
    v['audit']=dict(index=f['index'],id=f['id'],raw_frame=f['raw_frame'],inherited_qualified=f['qualified'],qualified=v['qualified'],heldout=f['heldout'],ring_visible_IoU=iou,ring_boundary_p95_px=p95,det_rotation=np.linalg.det(A),orthogonality_norm=np.linalg.norm(A.T@A-np.eye(3)),RGB=f['RGB'],Mask=f['Mask'])
    return v

def evidence(P,v):
    n=len(P);event=np.zeros(n,np.uint8);neg1=np.zeros(n,bool);neg2=neg1.copy();pos=neg1.copy()
    if not v['qualified']:
        event[:]=EVENT['BAD_CAMERA'];return neg1,neg2,pos,event
    uv,z=project(P,v['pose'],v['K']);h,w=v['labels'].shape
    good=np.isfinite(uv).all(1)&(z>0)&(uv[:,0]>=1)&(uv[:,0]<w-1)&(uv[:,1]>=1)&(uv[:,1]<h-1)
    ii=np.flatnonzero(good);xy=np.rint(uv[ii]).astype(int);x,y=xy.T
    lab=v['labels'][y,x];inside=lab==1;dist=v['polyp_distance'][y,x]
    pos[ii[inside]]=True;event[ii[inside]]=EVENT['POLYP']
    boundary=~inside&(dist<=cfg()['mask_tolerance_px']);event[ii[boundary]]=EVENT['BOUNDARY_UNKNOWN']
    outside=~inside&~boundary;ids=ii[outside]
    neg1[ids]=True
    rz=v['ring_z'][y,x];core=v['ring_core'][y,x]
    ring_match=outside&core&np.isfinite(rz)
    front=ring_match&(z[ii]<rz-cfg()['ring_margin_mm']);behind=ring_match&~front
    neg2[ii[front]]=True;event[ii[front]]=EVENT['RING_FRONT_NEGATIVE'];event[ii[behind]]=EVENT['RING_BEHIND_UNKNOWN']
    clear=outside&(lab==0)&~v['near_ring'][y,x]
    neg2[ii[clear]]=True;event[ii[clear]]=EVENT['CLEAR_BACKGROUND_NEGATIVE']
    unknown=outside&~ring_match&~clear;event[ii[unknown]]=EVENT['CAD_MASK_MISMATCH_UNKNOWN']
    return neg1,neg2,pos,event

def classify(P,views,details=False):
    n=len(P);n1=np.zeros(n,np.uint8);n2=n1.copy();pos=n1.copy();unknown=n1.copy();ringunknown=n1.copy()
    events=np.zeros((n,len(views)),np.uint8) if details else None
    for j,v in enumerate(views):
        a,b,c,e=evidence(P,v);n1+=a;n2+=b;pos+=c;unknown+=np.isin(e,[0,1,3,6,7]);ringunknown+=e==6
        if details:events[:,j]=e
    return dict(negative_H1=n1,negative_H2=n2,positive=pos,unknown=unknown,ring_unknown=ringunknown,events=events)

def solve(views,bounds=None,step=None):
    bounds=cfg()['bounds_mm'] if bounds is None else bounds;step=cfg()['voxel_mm'] if step is None else step
    P,shape=grid(bounds,step);arrays={k:np.zeros(len(P),np.uint8) for k in ['negative_H1','negative_H2','positive','unknown','ring_unknown']}
    for start in range(0,len(P),160000):
        c=classify(P[start:start+160000],views)
        for k in arrays:arrays[k][start:start+160000]=c[k]
    out={k:a.reshape(shape) for k,a in arrays.items()}
    out.update(H1=out['negative_H1']==0,H2=out['negative_H2']==0,bounds_mm=np.array(bounds),voxel_mm=step)
    assert np.all(~out['H1']|out['H2']), 'H2 must not carve anything H1 would keep'
    return out

def extract(vol,method):
    occ=vol[method];step=float(vol['voxel_mm']);bounds=np.asarray(vol['bounds_mm'])
    if not occ.any():return trimesh.Trimesh(),dict(empty=True)
    # Padding exposes ROI walls. They are retained but explicitly identified; never counted as observed surface.
    v,f,_,_=marching_cubes(np.pad(occ.astype(np.float32),1),.5,spacing=(step,)*3,allow_degenerate=False)
    v+=bounds[:,0]-step/2
    m=trimesh.Trimesh(v,f,process=False)
    center=m.triangles_center;ix=np.clip(np.floor((center-bounds[:,0])/step).astype(int),0,np.array(occ.shape)-1)
    support=vol['positive'][tuple(ix.T)];unknown=vol['unknown'][tuple(ix.T)]
    roi=((abs(center-bounds[:,0])<step*.55)|(abs(center-bounds[:,1])<step*.55)).any(1)
    colors=np.tile(COLORS[method],(len(f),1));colors[support<cfg()['min_support_views']]=COLORS['unknown'];colors[roi]=COLORS['roi']
    m.visual.face_colors=np.c_[colors*255,np.full(len(f),255)].astype(np.uint8)
    caps=[]
    for j in range(3):
        caps+= [bool(np.take(occ,0,axis=j).any()),bool(np.take(occ,-1,axis=j).any())]
    rec=dict(empty=False,feasible_voxels=int(occ.sum()),feasible_volume_mm3=float(occ.sum()*step**3),
      supported_2views_volume_mm3=float((occ&(vol['positive']>=cfg()['min_support_views'])).sum()*step**3),
      no_positive_volume_mm3=float((occ&(vol['positive']==0)).sum()*step**3),
      roi_boundary_touched=caps,ROI_truncated=any(caps),vertices=len(v),faces=len(f),
      ROI_cap_area_mm2=float(m.area_faces[roi].sum()),candidate_surface_area_mm2=float(m.area),
      surface_evidence='silhouette feasibility boundary, not observed polyp surface',
      volume_is_true_polyp_volume=False,all_components_retained=True)
    return m,dict(**rec,face_support_count=support,face_unknown_count=unknown,face_ROI_cap=roi)

def view_schedule(views):
    usable=[v for v in views if v['qualified'] and not v['heldout']]
    assert len(usable)>=2, 'Insufficient qualified training cameras; do not backfill'
    # Nested farthest-point schedule in camera viewing direction; does not see HERO or GT.
    centers=np.array([v['pose'][:3,3] for v in usable]);directions=unit(centers)
    first=0;order=[first]
    while len(order)<len(usable):
        D=1-directions@directions[order].T;d=D.min(1);d[order]=-1;order.append(int(d.argmax()))
    return [usable[i] for i in order]

def point_states(P,views):
    d=classify(P,views,details=True);n=d['negative_H2'];events=d['events']
    state=np.full(len(P),2,np.uint8) # UNKNOWN
    state[(n==0)&(d['positive']>=cfg()['min_support_views'])]=0 # INSIDE_COMPATIBLE
    # OUTSIDE is conditional on >=2 reliable views with angular separation, never automatically deleted.
    neg=np.isin(events,[4,5]);maxang=np.zeros(len(P))
    for j in range(len(views)):
        for k in range(j):
            both=neg[:,j]&neg[:,k]
            if not both.any():continue
            angle=np.degrees(np.arccos(np.clip(np.sum(unit(P[both]-views[j]['pose'][:3,3])*unit(P[both]-views[k]['pose'][:3,3]),1),-1,1)))
            maxang[both]=np.maximum(maxang[both],angle)
    outside=(n>=cfg()['point_min_negative_views'])&(maxang>=cfg()['point_min_negative_angle_deg'])
    state[outside]=1
    d.update(state=state,max_negative_angle_deg=maxang,mathematically_outside_H2=n>0)
    return d

"""Non-GT regression checks before freezing: convention, first hit, and tri-state logic."""
from vh_common import *
from hull import evidence, EVENT, classify

def main():
    K=np.array([[490.,0,319.5],[0,490.,179.5],[0,0,1.]])
    pose=np.eye(4);pose[:3,:3]=np.diag([1,-1,-1]);pose[:3,3]=[0,0,30]
    uv=np.array([[319.5,179.5],[410.97,179.5],[200.,80.]])
    z=np.array([20.,29.4,30.]);p=unproject(z,pose,uv,K);uu,zz=project(p,pose,K)
    assert np.max(abs(uu-uv))<1e-9 and np.max(abs(zz-z))<1e-9
    ring=trimesh.load(REPO/'ring_anchor_3d/assets/ring_R10.obj',process=False)
    hit=cast(o3scene(ring),pose,K,np.array([[319.5+490*5.6/30,179.5],[319.5,179.5]]))
    assert np.isfinite(hit[0]) and np.isnan(hit[1]), hit
    # Exact vertical CAD first hit at x=5.6 is z=.6 => axial Z29.4.
    exact=cast(o3scene(ring),pose,K,np.array([[319.5+490*5.6/29.4,179.5]]))[0]
    assert abs(exact-29.4)<.002,exact
    labels=np.zeros((360,640),np.uint8);labels[170:190,400:430]=2
    v=dict(pose=pose,K=K,qualified=True,labels=labels,polyp_distance=np.full(labels.shape,100.),ring_core=labels==2,near_ring=labels==2,ring_z=np.full(labels.shape,29.4))
    uv0=np.tile([412.,179.],(2,1));P=unproject(np.array([28.,31.]),pose,uv0,K)
    a,b,c,ev=evidence(P,v)
    assert a.tolist()==[True,True] and b.tolist()==[True,False]
    assert ev.tolist()==[EVENT['RING_FRONT_NEGATIVE'],EVENT['RING_BEHIND_UNKNOWN']]
    v['qualified']=False;a,b,c,ev=evidence(P,v);assert not (a|b|c).any() and (ev==1).all()
    rec=dict(roundtrip_max_px=float(abs(uu-uv).max()),CAD_vertical_first_hit_error_mm=float(abs(exact-29.4)),ring_front_carved=True,ring_back_UNKNOWN=True,unreliable_camera_UNKNOWN=True,all_pass=True)
    save('metrics/GEOMETRY_TESTS.json',rec);print(rec,flush=True)
if __name__=='__main__':main()

"""Read-only reuse of existing metric geometry and mature mesh/ray tools."""
from pathlib import Path
import os, sys, json, csv, ast, hashlib, datetime
import numpy as np
import cv2, trimesh
from scipy.ndimage import map_coordinates
from scipy.spatial import cKDTree

CODE = Path(__file__).resolve().parent
E = CODE.parents[1]
REPO = E.parent.parent
R = Path(os.environ.get('VH_OUT', str(CODE.parent))).resolve()
for p in [E/'surface_fusion_v3/vendor', E/'ring_depth_v3/vendor']:
    sys.path.insert(0, str(p))
import open3d as o3d
from skimage.measure import marching_cubes

REUSE = {
    E/'ring_first_v1/scripts/common.py': ['project', 'unproject', 'depth_mesh'],
    E/'surface_fusion_v3/scripts/v3_common.py': ['o3scene', 'cast'],
}
for p, names in REUSE.items():
    for node in ast.parse(p.read_text()).body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            exec(compile(ast.Module(body=[node], type_ignores=[]), str(p), 'exec'), globals())

def cfg():
    c = load(R/'config.json')
    c['mesh_max_depth_jump_mm'] = .75
    return c

def load(p): return json.loads(Path(p).read_text())
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576), b''): h.update(b)
    return h.hexdigest()
def clean(x):
    if isinstance(x, dict): return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x, (list,tuple)): return [clean(v) for v in x]
    if isinstance(x, np.ndarray): return clean(x.tolist())
    if isinstance(x, (np.integer,np.bool_)): return x.item()
    if isinstance(x, (float,np.floating)): return float(x) if np.isfinite(x) else None
    if isinstance(x,Path): return str(x)
    return x
def save(p,d):
    p=R/p; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(clean(d),ensure_ascii=False,indent=2,allow_nan=False))
def csvwrite(p, rows):
    p=R/p; p.parent.mkdir(parents=True,exist_ok=True)
    keys=list(dict.fromkeys(k for x in rows for k in x))
    with p.open('w') as f:
        w=csv.DictWriter(f,keys);w.writeheader()
        for x in rows:w.writerow({k:json.dumps(clean(v),ensure_ascii=False) if isinstance(v,(list,tuple,dict,np.ndarray)) else clean(v) for k,v in x.items()})
def freeze(name, paths, **extra):
    save('provenance/'+name+'.json', dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={str(Path(p).resolve()):sha(p) for p in sorted(set(map(Path,paths)))},historical_measurement_fallback=0,**extra))
def verify(name):
    d=load(R/f'provenance/{name}.json');bad=[p for p,h in d['files'].items() if sha(p)!=h]
    assert not bad, bad
def firewall():
    def guard(event,args):
        if event!='open' or not isinstance(args[0],(str,bytes)):return
        p=str(Path(args[0]).resolve())
        if any(t in p for t in ['/gt_mapping/','/private_gt/','/evaluation_exports/','/debug_inputs/']) or p.endswith('.blend'):
            raise PermissionError('Formal Hull GT firewall: '+p)
    sys.addaudithook(guard)
def unit(v):return v/np.maximum(np.linalg.norm(v,axis=-1,keepdims=True),1e-12)
def stats(d):
    d=np.asarray(d);d=d[np.isfinite(d)]
    return dict(n=len(d),median=np.median(d) if len(d) else np.nan,MAE=np.mean(abs(d)) if len(d) else np.nan,p95=np.percentile(abs(d),95) if len(d) else np.nan,max=np.max(abs(d)) if len(d) else np.nan)
def sample_surface(m,n,seed=20261024):
    gen=np.random.default_rng(seed);ids=gen.choice(len(m.faces),n,p=m.area_faces/m.area)
    uv=gen.random((n,2));uv[uv.sum(1)>1]=1-uv[uv.sum(1)>1]
    t=m.triangles[ids];p=t[:,0]+uv[:,:1]*(t[:,1]-t[:,0])+uv[:,1:]*(t[:,2]-t[:,0])
    return p,ids
def distance(m,p):
    if not len(m.faces):return np.full(len(p),np.nan)
    return o3scene(m).compute_distance(o3d.core.Tensor(np.asarray(p,np.float32)),nthreads=2).numpy()
def grid(bounds,step):
    axes=[np.arange(a+step/2,b,step) for a,b in bounds]
    return np.stack(np.meshgrid(*axes,indexing='ij'),-1).reshape(-1,3),tuple(map(len,axes))
def occupancy_at(occ,p,bounds,step):
    ix=np.floor((p-np.asarray(bounds)[:,0])/step).astype(int)
    valid=(ix>=0).all(1)&(ix<np.array(occ.shape)).all(1)
    ans=np.zeros(len(p),bool);ans[valid]=occ[tuple(ix[valid].T)]
    return ans,valid

COLORS={'H0':[.79,.39,.48],'H1':[.20,.46,.88],'H2':[.10,.70,.55], 'ring':[.15,.19,.24], 'inside':[.09,.66,.37], 'outside':[.90,.15,.17], 'unknown':[.95,.63,.12], 'roi':[.77,.19,.75]}

# REPRODUCE
1. `PYTHONPATH=code python code/reproduce_offline.py`  (writes results/OFFLINE_REPRODUCTION.json)
2. `PYTHONPATH=code python -m unittest discover -s tests`  → 11/11
3. Full controlled suite needs the workspace: `python code/synthetic_cases.py`.

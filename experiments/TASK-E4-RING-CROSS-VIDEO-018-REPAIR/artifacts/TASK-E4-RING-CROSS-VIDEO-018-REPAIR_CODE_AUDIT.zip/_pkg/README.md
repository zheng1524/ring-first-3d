# CODE AUDIT — TASK-E4-RING-CROSS-VIDEO-018-REPAIR
Level 1: `PYTHONPATH=code python code/reproduce_offline.py` and `python -m unittest discover -s tests` (11 tests).
Expected B: yaw_median 47.24, MAD 1.29, frac 0.816. A: 33.42, 6.79, 0.40.

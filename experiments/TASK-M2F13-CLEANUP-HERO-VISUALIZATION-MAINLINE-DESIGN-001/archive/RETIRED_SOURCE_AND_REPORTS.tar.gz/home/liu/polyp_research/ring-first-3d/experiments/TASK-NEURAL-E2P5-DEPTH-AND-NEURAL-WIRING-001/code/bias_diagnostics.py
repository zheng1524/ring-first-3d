"""P1-C: source-bias hypotheses and identifiability, without correcting HERO."""
from common import *

def main():
    assert load(R/'metrics/P1_DEPTH_GATE.json')['status'].startswith('PASS')
    cfg=load(R/'config/PREREGISTERED.json');pair=list(csv.DictReader((R/'metrics/HERO_PAIRWISE_DEPTH_CONFLICTS.csv').open()))
    ringrows=list(csv.DictReader((R/'metrics/RING_DEPTH_RESIDUALS.csv').open()));ring={x['source']:x for x in ringrows if x['tier']=='RING_INTERIOR_INCIDENCE'}
    rows=[];designs=[];counter=[]
    for scene,refs in selected().items():
        X=[]
        for A in refs:
            outgoing=[x for x in pair if x['A']==A and x['region']=='ALL' and x['tier']=='LOOSE_PROJECTIVE_CANDIDATE']
            incoming=[x for x in pair if x['B']==A and x['region']=='ALL' and x['tier']=='LOOSE_PROJECTIVE_CANDIDATE']
            vals=[float(x['median_signed']) for x in outgoing if int(x['N'])>=cfg['bias_min_comparisons']]
            rev=[-float(x['median_signed']) for x in incoming if int(x['N'])>=cfg['bias_min_comparisons']]
            stable=len(vals)==len(rev)==2 and (all(x>cfg['bias_signed_threshold_mm'] for x in vals+rev) or all(x< -cfg['bias_signed_threshold_mm'] for x in vals+rev))
            rr=ring[A];rv=float(rr['median_signed']) if rr['median_signed'] else None
            rhalves=[float(rr[k]) if rr[k] else None for k in ['tile_half0_median','tile_half1_median']]
            ring_stable=all(x is not None for x in rhalves) and np.sign(rhalves[0])==np.sign(rhalves[1]) and abs(rhalves[0]-rhalves[1])<=.25
            rows.append(dict(scene=scene,source=A,diagnosis='POSSIBLE_REFERENCE_BIAS' if stable else 'NO_STABLE_REFERENCE_BIAS',
                outgoing_medians_mm=vals,incoming_sign_reversed_medians_mm=rev,
                local_centered_MAD_mm=[float(x['MAD']) for x in outgoing],raw_median_absolute_mm=[float(x['median_abs']) for x in outgoing],
                native_Ring_median_mm=rv,Ring_spatial_half_medians_mm=rhalves,Ring_spatially_stable=ring_stable,
                Ring_bias_within_preregistered_1mm_bound=rv is not None and abs(rv)<=1.,
                absolute_bias_identified=False,confounders='frozen-camera error, projective identity/cycle and HERO material/shape error',
                HERO_modified=False))
            for B in refs:
                if A==B:continue
                z=np.load(R/'local_results/depth_pairs'/(A+'__'+B+'.npz'))
                n=len(z['residual']);stride=max(1,int(np.ceil(n/300)));k=z['bias_J_A'][::stride]
                xx=np.zeros((len(k),3));xx[:,refs.index(A)]=k;xx[:,refs.index(B)]-=1;X.append(xx)
                rA=ring[A];rB=ring[B];ba=float(rA['tile_half0_median']) if rA['tile_half0_median'] else None;bb=float(rB['tile_half0_median']) if rB['tile_half0_median'] else None
                legal=ba is not None and bb is not None and abs(ba)<=1 and abs(bb)<=1
                raw=residual_stats(z['residual'])
                hypothetical=z['residual']-(z['bias_J_A']*ba-bb) if legal else np.array([])
                stat=residual_stats(hypothetical)
                counter.append(dict(scene=scene,A=A,B=B,raw_median_abs_mm=raw['median_abs'],Ring_anchor_A_half0_mm=ba,Ring_anchor_B_half0_mm=bb,
                    within_bound=legal,hypothetical_residual_median_abs_mm=stat['median_abs'],
                    hypothetical_residual_signed_median_mm=stat['median_signed'],
                    diagnostic_only=True,association_policy='fixed pixel association linearization; no resampling/real depth correction',
                    used_for_neural_input=False))
        X=np.concatenate(X);sv=np.linalg.svd(X,compute_uv=False);rank=int((sv>sv[0]*1e-8).sum());cond=float(sv[0]/sv[-1])
        designs.append(dict(scene=scene,linearized_design_N=len(X),singular_values=sv.tolist(),numerical_rank=rank,
            condition_number=cond,smallest_over_largest=float(sv[-1]/sv[0]),
            geometry='e_AB ≈ k_AB*b_A - b_B, fixed source-pixel association',
            mathematical_status='WEAK_OR_GAUGE_SENSITIVE' if cond>100 or rank<3 else 'NUMERICALLY_CONDITIONED_UNDER_FIXED_CAMERAS',
            physical_bias_identifiable=False,reason='camera/extrinsic and correspondence uncertainty not independently calibrated; shared HERO parents; Ring-to-Polyp transfer unverified',
            fitted_depth_parameters_N=0,HERO_modified=False))
    table('metrics/DEPTH_BIAS_DIAGNOSTICS.csv',rows);table('metrics/BIAS_DESIGN_IDENTIFIABILITY.csv',designs)
    table('metrics/RING_BIAS_EXPLANATION_COUNTERFACTUAL.csv',counter)
    possible=sum(x['diagnosis']=='POSSIBLE_REFERENCE_BIAS' for x in rows)
    improvements=sum(bool(x['within_bound']) and x['hypothetical_residual_median_abs_mm']<x['raw_median_abs_mm'] for x in counter)
    (R/'docs/DEPTH_CORRECTION_DECISION.md').write_text(f'''# 深度处理决定（P1完成，先于真实网络检查）

本轮只诊断原生HERO，不修改深度。两个视频独立，12个方向不能视作12个独立物理样本。

1. 系统/局部问题：6个参考中{possible}个满足预注册的方向稳定条件，标为POSSIBLE_REFERENCE_BIAS；这不是实际偏移量认证。逐源局部MAD、空间连通冲突和宽残差分布见CSV，不能用一个中位数消除局部误差。
2. Ring证据：使用原生Ring Mask、独立Ring资格与固定CAD首交点，不使用E2的Polyp集合或M3小残差筛选。Ring材质/高光/边界和相机误差仍是混杂因素。Ring半区中位数仅作为有界诊断锚点；12方向中{improvements}个的固定对应线性反事实中位绝对残差下降，不能认作校正后真实精度。
3. 相机/对应：可能是主要限制之一；所有相机冻结，本轮没有独立相机真值。投影候选和循环/法向条件子集分别报告；未认证对应保留为未知，不强迫纳入物理误差。设计矩阵的数值秩不能解决相机与深度偏移的物理混淆。
4. 首轮方案：保留D0原生HERO和D1现有稳健/来源权重；权重1/0.25和相关分量归一不随预测表现调整。它们足以作为可证伪的初始监督合同，不保证能化解统一SDF上的所有深度矛盾。
5. D2：本轮不建立正式校正输入，不拟合自由scale+shift，不进行逐像素修正。绝对Polyp参考偏移仍不可辨识。当前不建议将D2纳入首轮正式MVP；若未来独立相机证据和Ring到Polyp误差迁移得到支持，才另行预注册±1mm单常数偏移消融，保留原生对照。

因此当前结论是：存在条件性的系统偏移迹象及局部/对应冲突，不能归结为全部需要“校正HERO”；D2目前证据不足。完整数值见metrics/DEPTH_BIAS_DIAGNOSTICS.csv、BIAS_DESIGN_IDENTIFIABILITY.csv和RING_BIAS_EXPLANATION_COUNTERFACTUAL.csv。
''')
    save('metrics/P1_GATE.json',dict(P1_complete=True,DEPTH_CONSISTENCY='PASS_CONDITIONAL_RESIDUAL_DIAGNOSTICS',
        RING_DEPTH_DIAGNOSTIC=load(R/'metrics/P1_RING_GATE.json'),BIAS_IDENTIFIABILITY='NOT_IDENTIFIED_PHYSICALLY; conditional hypotheses only',
        possible_reference_bias_N=possible,D2='NOT_RECOMMENDED_FOR_FIRST_MVP',HERO_modified=False,
        permission_next='P2 official neural CPU forward/backward explicitly authorized',GPU='NOT_AUTHORIZED'))
    freeze('P1_IMPLEMENTATION_AND_RESULTS.json',dict(stage='P1 complete, P2 not run',neural_forward_N=0))
    print('P1_COMPLETE',possible,'possible reference biases;',improvements,'Ring linearized improvements; no corrected input, no physical bias identified')

if __name__=='__main__':main()

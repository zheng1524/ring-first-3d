# MonoSDF 充分训练再验证：执行中报告

2026-11-03。状态：**IN_PROGRESS，非最终验收**。历史/官方流程审查、当前输入冻结和资源测量已完成；研究者决定先 ref08 M0/M1 各200000步，再审阅三 CORE 安排。本任务尚未完成，不能回答长程科学效果。

## 1. 版本和历史事实

本分支从 `388142e5244ea24ce2e7feeee16dc42b96f81f83` 独立建立。原关键技术版本v1.0不改，新增 [SDF 候选记录](../../docs/KEY_TECHNICAL_VERSION_E3_SDF_CANDIDATE_v0.1.md)。历史报告/当前接口 SHA 见 [回执](provenance/HISTORY_AND_INTERFACE_RECEIPTS.json)。

E3-A 的身份/DAG，E3-B 的原生 B0/B1，E3-C 的支持/合法遮挡/自由空间代理，E3-D0 的公制相机/原生深度接口直接继承。没有用 F1/F2/F3、NeuralFusion 或 Open3D 预测生成本轮训练输入，也没有用融合 Mesh 认证相机。

E2.5 已诊断 HERO 跨源差异，不能直接认证常数深度校正；E2.6 说明高 opacity 不等于前表面过零。E2.7 实际在 **G01_005** 每臂仅一次 Adam 更新，固定128单元采样而非官方自适应/完整渲染；负区代理体积约损失66%，HERO/初始零点漂移接近1mm，弱锚点加权梯度仅基础联合约2.27%。当时为覆盖硬门槛停机，没有数值/硬件故障。该事实不是本轮 G01_004 的长程结果，更不能据此淘汰 MonoSDF。

最新 N0 已完整执行官方 NeuralFusion 26次正逆序前缀；G01 ref08 首层一致性从73.52%降至0.47%，总体覆盖改善不能掩盖原主面退化。其真实 SDF/Mesh 与全部失败只作为历史审查，不参与新网络初始化或监督。

## 2. 三 CORE 当前输入与资格

顺序固定 ref08/ref13/ref03；无 G01_005、其他视频或跨视频坐标。采用当前 N0 的 V6 基线 + N0 固定 A2 派生输入，保持已有 crop/ID/K/c2w/CAD，不再清理。三个 CORE 相比最初 V6 又有历史 N0 9/30/9 点屏蔽，必须公开；不把 N0 全部后处理冒称单独人工认证。原始清理记录与文件保持只读。

|来源|分区|最新资格|当前保留原生点|训练合格 crop 观测|独立原生 ID 数|固定原始可见评价分母|
|---|---|---|---:|---:|---:|---:|
|ref08|B3|INSUFFICIENT_EVIDENCE|13370|14234|12873|13250|
|ref13|B5|INSUFFICIENT_EVIDENCE|12378|14044|12049|12400|
|ref03|B2|INSUFFICIENT_EVIDENCE|23230|15567|15567|22991|

crop 重采样观测数不是独立原生点数。原始合格 Polyp 共50265，CAD 后1624单列，固定可见48641。单参考训练只读 ref08 为优化样本；ref13/ref03 作同源诊断，不称独立盲测。两个臂完全相同分母，不因清理/未命中减少评价分母。

同一 Ring 世界物理立方域边长20.106mm，中心(-.1629098423,.3603562896,-5.3599203716)mm，s=10.053mm/unit，MonoSDF中心化域[-1,1]³。轴向 Z 与欧氏射线距离分别转换；实际 CAD 外径12.4mm。原生锚点逆变换误差≤1.34e−15mm；真实射线方向与官方单位方向最大差2.37e−7。见 [原生坐标审计](metrics/NATIVE_ANCHOR_AND_COORDINATE_VALIDATION.csv)。

## 3. 官方实现、法向及 M0/M1

所选官方 commit `12513009cd20a08b35ddc2c55a7e42da2c7baf43`，plain ImplicitNetwork、完整 ErrorBoundSampler、RenderingNetwork、LaplaceDensity 和 volume rendering。网络670395参数。数据/有限段/CAD/尺度/无效 cue 的端口与配置偏离逐项列在 [官方复用记录](OFFICIAL_REUSE_AND_ADAPTATIONS.md)，不能声称官方原数据配置逐字不变。

M0 保留官方损失组件；M1 增加来源可靠性加权的原生 HERO 零面、公制首次深度、实际原生射线前方弱自由空间和稳定正 Mask 约束。两者相同初始化、骨干、采样、renderer、1024 rays、预算和1000步 warmup。法向只从同源真实 XYZ 四邻导数估计，邻居/跳变/原生边缘资格不足时不监督。不是独立法向 GT。

已真实执行四组各25次资源更新；全链计数、有限梯度/采样范围通过，峰值分配4.22GiB。另1次不更新 GPU 防护核查，以及1次仅初始化的官方 SDF/Mesh 提取。预训练/资源结果不参与正式初始化。

正式入口复用官方 `MonoSDFTrainRunner.run` 的原更新块，移植单卡数据、日志/恢复、epoch与实际步数映射；官方 zero_grad→forward→loss→backward→Adam→scheduler 次序不改。每 epoch 一批，将200000实际更新显式绑定，不误用1图×2000 epoch。官方 `get_surface_trace` 浮点 MC 仅增原场保存及禁止 Trimesh 自动 processing，保留所有原始面/组件；128³阶段、512³最终。提取和 runner diff 随代码保存。

## 4. 固定训练、资源与恢复

[预注册](config/PREREGISTERED.json) 在资源测试前冻结；[单参考执行冻结](config/FORMAL_STAGE_FROZEN.json) 与 [源码/输入冻结](provenance/BEFORE_FORMAL_TRAINING.json) 在正式更新前保存。检查点为0/1/10/100/1k/5k/10k/25k/50k/100k/150k/200k，另外每1000步保存最近完整恢复状态。正式 M0 完成后自动串行 M1，三 CORE 不自动启动。

不以几何退化停机；首次100次更新不是充分训练判定。只有数值、真实硬件/有效性合同故障中断。参数/Adam/scheduler/损失步数/RNG 与输入 SHA 一起存储，最新状态原子替换，关键检查点永存。几何诊断不改变训练 RNG。低学习率候选最多一个、另存，不自动启动未计入资源的新完整实验。

完整四配置估算80–110h；研究者已选先单参考约40–55h。详细测量和局限见 [资源估算](RESOURCE_ESTIMATE.md)。大检查点/原场留本地，GitHub仅索引。当前实时步数见 `metrics/single_M0_STATUS.json`、`single_M1_STATUS.json`，不能把本文静态描述当运行完成记录。

## 5. 评价与图像

每个关键点保存原始 SDF、毫米 Mesh、固定原生首次 hit/MISS、首层误差/一致率、清理点及原面保留、Mask 越界、CAD 遮挡、≥4真实交点多层代理、负区体积代理、连通性及观测/推断/未知面标签。命中误差与包含MISS的分位状态分开；物理GT误差均 NOT_EVALUABLE。全部面不因标签删除。

`render_progress.py` 根据已保存真实检查点生成四图，未运行臂显式标记 NOT_RUN；最终图与局部解释仍需训练完成后审阅。物理连续/光滑/闭合不代表真实准确。当前 [资源预检图](figures/PREFLIGHT_Inputs_And_Resources.png) 只展示真实输入和资源测量，不冒充学习结果。

已保存进度图：[训练曲线](figures/Fig1_Training_Progress.png)、[毫米Mesh比较](figures/Fig2_Metric_Geometry_Comparison.png)、[真实图像/首层](figures/Fig3_Real_Image_First_Surface.png)、[原始SDF切片](figures/Fig4_Raw_SDF_Local_Diagnostics.png)。它们标注实际检查点步数，可能早于当前实时训练；不是最终200k验收图。

真实执行核查见 [OFFICIAL_RUNTIME_ACCEPTANCE](metrics/OFFICIAL_RUNTIME_ACCEPTANCE.json)：0/1/10/100步原场CPU重放MC，原三角面顺序完全一致，毫米逆映射<2e−6mm；首步37个参数张量均真正变化。空零面诊断另有控制测试，MISS被保留且不会因没有Mesh触发科学停止。

## 6. 固定审计表

|审计项目|必须汇报|
|---|---|
|目标组数|物理G01一组，仅G01_004；当前授权单参考两个配置，三 CORE待后审|
|本算法独立成功|充分训练科学验收尚为0/1；短程计算/真实提取接线通过不等于表面学习成功|
|本算法失败|充分训练结论未产生，不记作失败；未完成/物理指标NaN/NOT_EVALUABLE|
|历史测量值回退|0；其他路线预测未用于本轮训练、初始化或填补输出|
|失败组及具体原因|[FAILURE_LEDGER](FAILURE_LEDGER.md)；当前主要未完成项是长程执行与最终验收|
|最终统计样本|目标1，最终科学样本尚0；原生固定分母50265/可见48641，单参考ref08可见13250|
|是否使用GT选择算法|否；输入/官方版本/配置/代码冻结先于正式更新，GT读取0|

物理 MedARE、MAE、p95、max 和共同成功组物理配对比较全部 NOT_EVALUABLE；不能拿 HERO 一致误差代替物理真值。

## 7. 八个问题：当前阶段回答

1. **完整官方流程？** 已接入并核查官方计算链、官方 runner 更新块和官方零面提取；完整200k执行尚待完成，不能提前回答全程已完成。
2. **充分训练完成？** 未完成。每模型200k预算没有缩短；单参考正在按授权执行。
3. **首步收缩解决？** 尚不能认证；与E2.7的不同视频/尺度/采样/损失不能冒充一因素因果对照。
4. **单参考稳定拟合HERO？** 待 M0/M1 完整训练及逐参考固定分母评价。
5. **三 CORE 可信统一表面？** NOT_RUN，等待单参考结果后研究者审阅资源安排。
6. **M1保护有效？** 仅梯度和接线已证明有限；几何保护收益待充分训练比较。
7. **观测与推断？** 输入原生 ID/真实视图/CAD 次序冻结；输出原始面按邻近原生深度证据标记代理，保留推断/未知。所有标签均非真值。
8. **是否值得继续？** 历史一步不足以淘汰路线；本轮应完成授权的充分训练再判断，不依据短测宣判。

此报告随阶段完成补充，不是任务完成通知。[复现入口](REPRODUCE.md)。

import bpy,numpy as np,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parents[1];V=R.parent/'ring_first_v4_synthetic_audit';bpy.ops.wm.open_mainfile(filepath=str(V/'private_gt/models/scene.blend'));o=bpy.data.objects['Ip_original_mesh'];verts=[o.matrix_world@v.co for v in o.data.vertices];faces=[tuple(p.vertices) for p in o.data.polygons];bvh=BVHTree.FromPolygons(verts,faces);g=np.load(V/'private_gt/008.npz');ca=np.load(V/'private_gt/scene.npz');pose=ca['c2w'][8];K=ca['K'];y,x=np.nonzero(g['labels']==1);sel=np.arange(0,len(x),max(1,len(x)//128));out=[]
for yy,xx in zip(y[sel],x[sel]):
 ray=pose[:3,:3]@np.array([(xx-K[0,2])/K[0,0],(yy-K[1,2])/K[1,1],1.]);l=np.linalg.norm(ray);hit,no,idx,dist=bvh.ray_cast(Vector(pose[:3,3]),Vector(ray/l),2000.);out.append(dist/l if hit is not None else np.nan)
out=np.array(out);e=out-g['depth'][y[sel],x[sel]];record={'native_Blender_BVHTree_axisZ_vs_stored_GT_n':len(e),'MAE_mm':float(abs(e).mean()),'max_mm':float(abs(e).max()),'p95_mm':float(np.percentile(abs(e),95)),'native_GT_generator_reproduced':True,'mesh_source_readonly':True,'passed':bool(abs(e).max()<0.01)};(R/'evaluation/Blender_native_geometry_check.json').write_text(json.dumps(record,indent=2));print(record)

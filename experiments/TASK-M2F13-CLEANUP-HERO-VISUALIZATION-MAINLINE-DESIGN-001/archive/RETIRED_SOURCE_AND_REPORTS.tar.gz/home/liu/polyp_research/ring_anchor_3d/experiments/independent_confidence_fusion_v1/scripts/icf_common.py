from pathlib import Path
import sys,os,json,csv,datetime,hashlib,ast
import numpy as np,cv2,trimesh
from scipy.spatial import cKDTree
R=Path(__file__).resolve().parents[1];E=R.parent;REPO=E.parent.parent
F1=E/'surface_fusion_v1';F2=E/'surface_fusion_v2';F3=E/'surface_fusion_v3';V6=E/'ring_first_v6_local_reconstruction';V13=E/'ring_first_v13_multisource';RASR=E/'ring_anchored_sparse_registration_v2';LAST=E/'mast3r_group_consensus_bias_v1'
sys.path.insert(0,str(F3/'vendor'));sys.path.insert(0,str(F3/'scripts'));import v3_common as old
project,unproject,depth_mesh,sha,clean,stats=old.project,old.unproject,old.depth_mesh,old.sha,old.clean,old.stats
K=np.array([[490.,0,319.5],[0,490.,179.5],[0,0,1.]])
def load(p):return json.loads(Path(p).read_text())
def save(p,d):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(clean(d),ensure_ascii=False,indent=2,allow_nan=False))
def csvwrite(p,rows):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);keys=list(dict.fromkeys(k for x in rows for k in x))
 with p.open('w')as f:
  w=csv.DictWriter(f,keys);w.writeheader();w.writerows([{k:json.dumps(clean(v),ensure_ascii=False)if isinstance(v,(dict,list,tuple,np.ndarray))else clean(v)for k,v in x.items()}for x in rows])
def freeze(n,paths):save('reproducibility/'+n+'.json',dict(UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={str(Path(p).resolve()):sha(p)for p in sorted(set(map(Path,paths)))},GT_used=False))
def verify():
 d=load(R/'reproducibility/protected.json');bad=[p for p,h in d['files'].items()if sha(p)!=h];assert not bad,bad
def cfg():return load(R/'config.json')
def cases():return load(R/'inputs/references.json')
def data(c):return dict(np.load(R/f"depths/{c['tag']}.npz"))
def image(c):return cv2.imread(c['frame']['RGB_path'])[:,:,::-1].copy()
def labels(c):return cv2.imread(c['frame']['Mask_path'],0)
def object_mask(p,obj):
 l=p['labels'];return l==1 if obj=='Polyp'else ((l==0)&(cv2.dilate((l>0).astype(np.uint8),np.ones((81,81),np.uint8))>0))
def unit(x):return x/np.maximum(np.linalg.norm(x,axis=-1,keepdims=True),1e-12)
def export(m,p):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);m.export(p)
def scene_cast(m,pose,uv):return old.cast(old.o3scene(m),pose,K,uv)

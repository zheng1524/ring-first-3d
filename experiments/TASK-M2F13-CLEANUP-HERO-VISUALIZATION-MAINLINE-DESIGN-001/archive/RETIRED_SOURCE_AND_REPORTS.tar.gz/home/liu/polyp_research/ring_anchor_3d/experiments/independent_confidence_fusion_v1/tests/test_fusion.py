from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from confidence_fusion import *
from tsdf_compare import support_bits
class FusionTests(unittest.TestCase):
 def inputs(self):
  P=np.array([[.01,.01,.01],[.04,.03,.02],[.02,.02,.04],[1.,1.,1.] ]);N=np.tile([0,0,1.],(4,1));rgb=np.ones((4,3))*100;source=np.array([0,1,1,0]);uv=np.zeros((4,2));diag=dict(support_views=np.full(4,2),status=np.full(4,2),residuals_mm=np.zeros((4,2)));return P,N,rgb,source,uv,diag
 def test_supported_merge_and_unmatched_retention(self):
  P,N,rgb,s,uv,d=self.inputs();Q,c,mp,info=merge_supported(P,N,rgb,s,uv,np.zeros(4,bool),d);self.assertEqual(len(Q),2);self.assertEqual(len(mp),4);self.assertEqual(info['merged_clusters'],1);self.assertTrue(np.array_equal(Q[mp[3]],P[3]));self.assertLessEqual(np.max(info['max_source_displacement_mm']),np.sqrt(3)*.15)
 def test_boundary_never_moves(self):
  P,N,rgb,s,uv,d=self.inputs();protected=np.ones(4,bool);Q,c,mp,info=merge_supported(P,N,rgb,s,uv,protected,d);np.testing.assert_array_equal(Q[mp],P)
 def test_conflict_not_deleted_or_forced(self):
  P,N,rgb,s,uv,d=self.inputs();d['status'][:]=3;Q,c,mp,info=merge_supported(P,N,rgb,s,uv,np.zeros(4,bool),d);np.testing.assert_array_equal(Q[mp],P);self.assertEqual(len(Q),4)
 def test_view_density_balanced(self):
  P,N,rgb,s,uv,d=self.inputs();Q,c,mp,info=merge_supported(P,N,rgb,s,uv,np.zeros(4,bool),d);np.testing.assert_allclose(Q[mp[0]],(P[0]+P[[1,2]].mean(0))/2)
 def test_faces_no_new_triangles(self):
  ff=np.array([[0,1,2],[1,2,3],[0,2,3]]);mp=np.array([0,0,1,2]);out,bits,fm=remap_faces(ff,mp,np.array([1,2,4],np.uint32));self.assertEqual(len(out),1);self.assertEqual(fm[0],-1);self.assertEqual(int(bits[0]),6);self.assertLessEqual(len(out),len(ff))
 def test_axial_depth_roundtrip_and_raycast(self):
  pose=np.eye(4);uv=np.array([[319.5,179.5],[360.,199.]]);z=np.array([20.,20.]);P=unproject(z,pose,uv,K);q,zz=project(P,pose,K);np.testing.assert_allclose(q,uv);np.testing.assert_allclose(zz,z);m=trimesh.Trimesh([[-10,-10,20],[10,-10,20],[10,10,20],[-10,10,20]],[[0,1,2],[0,2,3]],process=False);out=scene_cast(m,pose,uv);np.testing.assert_allclose(out,z,atol=1e-5)
 def test_tsdf_requires_same_observed_identity(self):
  z=np.ones((360,640))*20;lab=np.zeros((360,640),np.uint8);lab[175:185,315:325]=1;p=dict(depth_mm=z,labels=lab,pose=np.eye(4));P=unproject(np.array([20.,20.,22.]),np.eye(4),np.array([[319,179],[100,100],[319,179]]),K);bits=support_bits(P,[p],'Polyp');np.testing.assert_array_equal(bits,[1,0,0])
 def test_nonmanifold_adjacency_is_counted_not_hidden(self):
  import importlib.util
  p=Path(__file__).resolve().parents[1]/'scripts/evaluate.py';spec=importlib.util.spec_from_file_location('icf_evaluation_tests',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);m=trimesh.Trimesh([[0,0,0],[1,0,0],[0,1,0],[0,0,1],[0,-1,0]],[[0,1,2],[0,1,3],[0,1,4]],process=False);t=module.topology(m);self.assertEqual(t['components'],1);self.assertEqual(t['nonmanifold_edges'],1)
if __name__=='__main__':unittest.main(verbosity=2)

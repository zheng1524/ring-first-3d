from common import *
import subprocess,shutil
assert not (R/'metrics/protection_start.json').exists()
protected={}
for root,ds,fs in __import__('os').walk(P):
 ds[:]=[d for d in ds if d not in ['.venv','vendor','__pycache__','.git','node_modules'] and str(Path(root)/d)!=str(R)]
 for name in fs:
  p=Path(root)/name
  if p.is_symlink():continue
  st=p.stat();protected[str(p)]=[st.st_size,st.st_mtime_ns,sha(p) if st.st_size<4000000 else None]
repos={}
for repo in [REPO,Path('/home/liu/new-polyp-dxy')]:
 status=subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=repo,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0');hs={str(repo/f):sha(repo/f) for f in tracked if f and (repo/f).is_file() and (repo/f).stat().st_size<4000000};repos[str(repo)]={'HEAD':head,'status':status,'hashes_under4MB':hs}
save('metrics/protection_start.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'threeD_history':protected,'git':repos})
manifest={}
def cp(src,dst):
 src=Path(src);dst=R/dst;dst.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(src,dst);manifest[str(dst.relative_to(R))]={'source':str(src),'sha256':sha(src),'role':'input'}
for i in range(16):
 cp(V4/f'inputs/rgb/{i:03d}.png',f'inputs/rgb_{i:03d}.png');cp(V4/f'inputs/labels/{i:03d}.png',f'inputs/labels_{i:03d}.png')
 g=np.load(V4/f'private_gt/{i:03d}.npz');np.savez_compressed(R/f'debug_inputs/complete_{i:03d}.npz',polyp=np.isfinite(g['polyp_depth_alone']))
 manifest[f'debug_inputs/complete_{i:03d}.npz']={'source':str(V4/f'private_gt/{i:03d}.npz'),'source_sha256':sha(V4/f'private_gt/{i:03d}.npz'),'role':'S0 diagnostic-only complete silhouette'}
g=np.load(V4/'private_gt/scene.npz');np.savez_compressed(R/'debug_inputs/GT_camera.npz',c2w=g['c2w'],K=g['K'])
for rr in [0,1]:cp(V4/f'predictions/C2_{rr}.npz',f'inputs/pred_camera_{rr}.npz')
cp(V4/'observations/rgb_tracks.npz','inputs/rgb_tracks.npz')
for rr in [0,1]:cp(V2/f'inputs/real_camera_{rr}.npz',f'inputs/real_camera_{rr}.npz')
cp(V2/'inputs/real_tracks.npz','inputs/real_tracks.npz');cp(V2/'inputs/DXY_reuse.json','inputs/DXY_reuse.json');cp(V2/'meshes/R10_ring.obj','inputs/R10_ring.obj')
save('inputs/source_manifest.json',manifest)
freeze('protocol',list((R/'scripts').glob('*.py'))+[R/'config.json',E/'ring_depth_v3/scripts/visual_hull.py',E/'ring_first_v1/scripts/common.py',E/'ring_first_v3_static_ba/scripts/common.py'])
freeze('inputs',list((R/'inputs').glob('*'))+list((R/'debug_inputs').glob('*')))
print('PREPARED',len(protected),'protected historical files',flush=True)

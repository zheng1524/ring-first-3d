from common import *
from solve import frames_data

def main():
 verify('predictions');records={}
 for scope,condition in [('S1_GT','GT'),('S2_0','0'),('S2_1','1')]:
  aa=np.load(R/f'predictions/{scope}_VH1_verified_reference.npz');bb=np.load(R/f'predictions/{scope}_VH2_verified_reference.npz');poses=aa['c2w'];K=aa['K'];fr=cfg()['training_views'];plane=np.load(R/f'predictions/{scope}_VH1_volume.npz')['background_plane'];obs,gates=frames_data(poses,K,fr,False,plane);record={};maps=[]
  for label,a in [('before_VH1',aa),('after_VH2',bb)]:
   y,x=np.nonzero(a['valid']);P=unproject(a['depth_min'][y,x],poses[8],np.c_[x,y],K);bad=np.zeros(len(P),bool);applicable=np.zeros(len(P),bool);support=np.zeros(len(P),np.uint8)
   for ob in obs:
    uv,z=project(P,poses[ob['frame']],K);q=np.rint(uv).astype(int);inside=(q[:,0]>=0)&(q[:,0]<640)&(q[:,1]>=0)&(q[:,1]<360)&(z>0);q[:,0]=q[:,0].clip(0,639);q[:,1]=q[:,1].clip(0,359);rz=ob['ring_depth'][q[:,1],q[:,0]];valid=inside&ob['ring'][q[:,1],q[:,0]]&np.isfinite(rz);violate=valid&(z<rz-cfg()['ring_free_margin_mm']);bad|=violate;applicable|=valid;support+=valid
   badmap=np.zeros(a['valid'].shape,bool);appmap=badmap.copy();badmap[y,x]=bad;appmap[y,x]=applicable;maps.append((badmap,appmap));record[label]={'target_valid_pixels':len(P),'ring_applicable_ref_surface_points':int(applicable.sum()),'violating_ref_surface_points':int(bad.sum()),'violation_rate_among_applicable':float(bad.sum()/max(1,applicable.sum())),'violation_rate_of_all_valid':float(bad.sum()/max(1,len(P))),'supporting_ring_views_count':stats(support[applicable]),'note':'evaluated at ray-sampled points; small residual violations can remain within a feasible voxel (quantization), even if voxel centers meet the rule'}
  np.savez_compressed(R/f'evaluation/{scope}_constraint_activation.npz',violation_before=maps[0][0],applicable_before=maps[0][1],violation_after=maps[1][0],applicable_after=maps[1][1],label='Ring-front free-space check, no contact interpretation');records[scope]=record
 save('metrics/constraint_activation.json',records);print('CONSTRAINT_ACTIVATION',clean(records),flush=True)
if __name__=='__main__':main()

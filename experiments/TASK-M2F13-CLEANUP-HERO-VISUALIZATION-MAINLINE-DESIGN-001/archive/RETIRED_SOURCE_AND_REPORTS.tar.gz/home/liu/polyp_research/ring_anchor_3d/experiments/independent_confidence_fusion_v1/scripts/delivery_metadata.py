from icf_common import *
def main():
 registry=load(R/'metrics/queries_full.json');records=[]
 for video in cfg()['videos']:
  refs=[c for c in cases()if c['video']==video]
  for obj in ['Polyp','Background']:
   p=np.load(R/f'provenance/{video}_{obj}_fusion.npz')
   for i,c in enumerate(refs):
    use=p['source_view']==i;uv=p['source_uv'][use];status=np.zeros((360,640),np.uint8);support=np.zeros((360,640),np.uint8);front=np.zeros((360,640),np.uint8);unknown=np.ones((360,640),bool);status[uv[:,1],uv[:,0]]=p['status'][use];support[uv[:,1],uv[:,0]]=p['support_views'][use];front[uv[:,1],uv[:,0]]=p['front_conflicts'][use].sum(1)+p['Ring_front_conflicts'][use].sum(1);unknown[uv[:,1],uv[:,0]]=False;np.savez_compressed(R/f"depths/{c['tag']}_{obj}_reliability.npz",status=status,support_views=support,front_conflicts=front,unknown=unknown,status_definition='1 model-only,2 model-consistent,3 front-conflict,4 mixed; NOT GT confidence')
   good=[q for q in registry if q['video']==video and q['method']=='C_fused'and q['object']==obj and q['supported']];P=np.array([q['point_mm']for q in good]).reshape(-1,3);path=f'points/{video}_{obj}_C_sparse_feature_supported.ply';export(trimesh.points.PointCloud(P,colors=np.tile([30,215,100,255],(len(P),1))),path);records.append(dict(video=video,object=obj,queries=len(good),distinct_family_track_ids=len(set(q['track_id']for q in good)),file=path,status='SPARSE_FEATURE_SUPPORTED_POSE_CONDITIONAL',not_independent_material_ID_GT=True,no_propagation_to_mesh_faces=True))
  for c in refs:
   lab=labels(c);rgb=image(c);cv2.imwrite(str(R/f"inputs/{c['tag']}_PolypMask.png"),(lab==1).astype(np.uint8)*255);cv2.imwrite(str(R/f"inputs/{c['tag']}_RingMask.png"),(lab==2).astype(np.uint8)*255);overlay=rgb.copy();overlay[lab==1]=(.55*rgb[lab==1]+.45*np.array([220,105,145])).astype(np.uint8);overlay[lab==2]=(.4*rgb[lab==2]+.6*np.array([65,190,245])).astype(np.uint8);cv2.imwrite(str(R/f"inputs/{c['tag']}_MaskOverlay.png"),overlay[:,:,::-1])
 save('metrics/sparse_supported_point_exports.json',records);freeze('delivery_metadata',[Path(__file__)]+list((R/'depths').glob('*reliability*'))+list((R/'points').glob('*sparse_feature_supported*'))+list((R/'inputs').glob('*Mask*.png'))+[R/'metrics/sparse_supported_point_exports.json']);verify();print('METADATA_COMPLETE',records,flush=True)
if __name__=='__main__':main()

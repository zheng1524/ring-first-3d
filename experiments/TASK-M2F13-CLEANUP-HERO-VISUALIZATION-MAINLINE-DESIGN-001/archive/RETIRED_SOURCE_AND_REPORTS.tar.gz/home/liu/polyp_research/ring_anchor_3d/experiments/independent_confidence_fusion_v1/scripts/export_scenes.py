from icf_common import *
from confidence_fusion import diagnose
import open3d as o3d

COL={'004':[.20,.61,.87],'005':[.94,.48,.22],'Background':[.40,.65,.44],'Ring':[.10,.11,.12]}
def getmesh(video,obj,method):
 name={'B':'B_raw_multiref','C':'C_confidence_fused','D':'D_TSDF_open'}[method];return trimesh.load(R/f'meshes/{video}_{obj}_{name}.ply',process=False)
def add_mesh(scene,m,name,color):
 q=m.copy();q.visual.face_colors=np.r_[np.asarray(color)*255,255].astype(np.uint8);q.vertices/=1000;scene.add_geometry(q,node_name=name,geom_name=name)
def cameras(scene,video,H=np.eye(4)):
 ds=load(R/'inputs/datasets.json')[video];po=np.load(ds['camera_files'][0])['c2w'];cc=[]
 for i,p in enumerate(po):
  c=(H@p)[:3,3];cc.append(c);m=trimesh.creation.icosphere(subdivisions=1,radius=.15);m.vertices+=c;add_mesh(scene,m,video+'_'+ds['ledger'][i]['id']+'_CAMERA_CANDIDATE',COL[video])
 # Segment geometry has no relation to reconstructed tissue; separately labelled.
 for i,(a,b)in enumerate(zip(cc[:-1],cc[1:])):
  if np.linalg.norm(a-b)<1e-6:continue
  line=trimesh.creation.cylinder(radius=.025,segment=[a,b],sections=6);add_mesh(scene,line,f'{video}_TRAJECTORY_{i}',COL[video])
def main():
 verify();ring=trimesh.load(F2/'inputs/R10_ring.obj',process=False);manifest=[];account=[];tsdfruns=load(R/'metrics/tsdf_runs.json')
 for video in cfg()['videos']:
  for method in ['B','C','D']:
   sc=trimesh.Scene()
   for obj in ['Polyp','Background']:add_mesh(sc,getmesh(video,obj,method),f'{video}_{obj}_{method}_MODEL_PREDICTED_LOCAL',COL[video]if obj=='Polyp'else COL['Background'])
   add_mesh(sc,ring,video+'_KnownRing_PHYSICAL_PRIOR',COL['Ring']);cameras(sc,video);sc.metadata.update(unit='m',status='LOCAL_MODEL_PREDICTED_NO_GT',source_mm_to_GLTF_m=.001,no_hidden_completion=True,method=method);name=f'{video}_{method}_LOCAL_SCENE.glb';sc.export(R/'scenes'/name);manifest.append(dict(file=name,scope=video,method=method,status='EXPERIMENTAL_FUSED_NONMANIFOLD'if method=='C'else'LOCAL_MODEL_PREDICTED',unit='m',geometry_scaled_only_for_GLTF_units=True))
  # Confidence display retains every Polyp triangle; colors annotate rather than remove.
  prov=np.load(R/f'provenance/{video}_Polyp_fusion.npz');m=getmesh(video,'Polyp','C');source_map=prov['source_to_fused'];state=np.zeros(len(m.vertices),np.uint8);np.maximum.at(state,source_map,prov['status']);palette=np.array([[.5,.5,.5],[.82,.64,.25],[.15,.70,.52],[.86,.20,.24],[.69,.24,.70]]);m.visual.vertex_colors=np.c_[palette[state]*255,np.ones(len(state))*255].astype(np.uint8);q=m.copy();q.vertices/=1000;sc=trimesh.Scene();sc.add_geometry(q,geom_name=video+'_ALL_POLYP_FACES_CONFIDENCE_LABELS');add_mesh(sc,ring,video+'_KnownRing',COL['Ring']);sc.metadata.update(status='CONFIDENCE_IS_MODEL_CONSISTENCY_NOT_GT',unit='m');sc.export(R/f'scenes/{video}_C_CONFIDENCE_LABELS.glb')
  for obj in ['Polyp','Background']:
   p=np.load(R/f'provenance/{video}_{obj}_fusion.npz');fm=p['source_face_to_fused_face'];counts=np.bincount(fm[fm>=0]);account.append(dict(video=video,object=obj,input_faces=len(fm),output_faces=len(counts),collapsed_faces=int((fm<0).sum()),duplicate_face_observations=int(np.maximum(counts-1,0).sum()),total_face_count_reduction=int(len(fm)-len(counts)),source_point_identities=len(p['source_to_fused']),point_identities_deleted=0,notes='authoritative counts; fusion_runs.faces_collapsed_or_duplicate counted duplicate groups, not all duplicate observations'))
 cross=[]
 for cand in load(R/'inputs/H_frozen.json'):
  H=np.array(cand['H']);sc=trimesh.Scene()
  for video in cfg()['videos']:
   T=H if video=='005'else np.eye(4)
   for obj in ['Polyp','Background']:
    m=getmesh(video,obj,'C');m.apply_transform(T);add_mesh(sc,m,f'{video}_{obj}_LOCAL_FUSED_LAYER_UNVERIFIED',COL[video]if obj=='Polyp'else ([.33,.55,.38]if video=='004'else[.55,.72,.48]))
   r=ring.copy();r.apply_transform(T);add_mesh(sc,r,video+'_KnownRing_UNVERIFIED_RELATION',COL['Ring']);cameras(sc,video,T)
  name=cand['tag']+'_NEW_LOCAL_FUSION_LAYERS_UNVERIFIED.glb';sc.metadata.update(status='UNVERIFIED_NO_CROSS_VIDEO_FUSION',unit='m',H005_to004_translation_unit='mm',H005_to004=H.tolist(),no_cross_video_welding=True);sc.export(R/'scenes'/name);manifest.append(dict(file=name,status='UNVERIFIED',unit='m',H005_to004_mm=H,local_fusion='C',cross_video_geometry='separate layers only',no_ICP=True))
  for source,other in [('004','005'),('005','004')]:
   m=getmesh(source,'Polyp','C');target=getmesh(other,'Polyp','C');T=H if source=='005'else np.eye(4);U=H if other=='005'else np.eye(4);m.apply_transform(T);target.apply_transform(U);P=m.triangles_center;normal=m.face_normals;scene=old.o3scene(target);nearest=scene.compute_closest_points(o3d.core.Tensor(np.asarray(P,np.float32)));D=np.linalg.norm(P-nearest['points'].numpy(),axis=1);dot=np.abs(np.sum(normal*nearest['primitive_normals'].numpy(),axis=1));near=(D<=.3)&(dot>=np.cos(np.deg2rad(30)));refs=[c for c in cases()if c['video']==other];packs=[data(c)for c in refs]
   for p in packs:p['pose']=U@p['pose']
   ringdepth=[np.load(R/f"depths/{c['tag']}_KnownRing_ray_depth.npz")['depth_mm']for c in refs];diag=diagnose(P,np.full(len(P),-1),refs,packs,'Polyp',ringdepth);mask_candidate=np.any(diag['projected_same_object'],axis=1);positive_conflict=np.any(diag['front_conflicts'],axis=1);behind=np.any(diag['behind_or_depth_conflict'],axis=1);state=np.zeros(len(P),np.uint8);state[near]=1;state[~near&positive_conflict]=2;state[~near&~positive_conflict&mask_candidate]=3;state[~near&~mask_candidate]=4;area=m.area_faces;classrecords={str(i):dict(faces=int((state==i).sum()),observed_source_area_sum_mm2=float(area[state==i].sum()),area_fraction=float(area[state==i].sum()/area.sum()))for i in [1,2,3,4]};cross.append(dict(candidate=cand['tag'],source=source,target=other,source_faces=len(P),nearest_other_model_distance_mm=stats(D),classes=classrecords,meaning={'1':'near_other_model<=.3mm and normal-compatible; overlap candidate','2':'in_front_of_other_observed_prediction; potential conflict','3':'other same-object projection, occlusion or depth inconsistency unknown','4':'not_same_object_observed; source-only MODEL fragment, not verified new coverage'},true_new_area=None,status='UNVERIFIED',Ring_center_offset_mm=float(np.linalg.norm(H[:3,3])),Ring_normal_angle_deg=float(np.degrees(np.arccos(np.clip(abs(H[2,2]),-1,1))))));np.savez_compressed(R/f'provenance/{cand["tag"]}_{source}_cross_analysis.npz',source_face_centers_mm=P,source_face_area_mm2=area,nearest_other_mm=D,source_class=state,source_face_count=len(P),GT_coverage_unknown=True)
 save('metrics/fusion_face_accounting.json',account);save('metrics/cross_exploratory.json',cross);save('scenes/SCENE_MANIFEST.json',manifest);freeze('exported_scenes',list((R/'scenes').glob('*'))+[R/'metrics/cross_exploratory.json',R/'metrics/fusion_face_accounting.json']+list((R/'provenance').glob('*cross_analysis*')));verify();print('EXPORTED',len(manifest)+2,'GLB scenes; new local fusion data, not old GLB rerenders',flush=True)
if __name__=='__main__':main()

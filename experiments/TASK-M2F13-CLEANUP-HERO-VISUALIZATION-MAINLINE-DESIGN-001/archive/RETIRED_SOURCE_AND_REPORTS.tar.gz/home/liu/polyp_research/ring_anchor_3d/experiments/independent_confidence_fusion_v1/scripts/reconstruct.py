from icf_common import *
import time,traceback,gc
def main():
 freeze('reconstruction_protocol',[R/'config.json',R/'PROTOCOL.md',R/'inputs/references.json']+list((R/'scripts').glob('*.py')));runs=[];wrapper=None
 for c in cases():
  st=time.monotonic();record=dict(tag=c['tag'],success=False,reused=c['reused'],new_HERO_forward=not c['reused'],reference=c['frame']['id'],sources=[load(R/'inputs/datasets.json')[c['video']]['ledger'][i]['id']for i in c['sources']])
  try:
   if c['reused']:
    pack=np.load(c['cache']);z=pack[c['depth_key']].copy();assert z.shape==(360,640);pose=np.array(c['pose']);native_path=c['cache'];native_K=K
   else:
    import torch
    sys.path.insert(0,str(F1/'scripts'));import run_mvs_adapter3 as adapter
    torch.set_num_threads(4);torch.manual_seed(cfg()['seed']);wrapper,info=adapter.load_official(cfg()['target_size']);L=load(R/'inputs/datasets.json')[c['video']]['ledger'];cam=np.load(load(R/'inputs/datasets.json')[c['video']]['camera_files'][0]);poses=cam['c2w'].copy();poses[:,:3,3]/=1000;k=np.eye(4);k[:3,:3]=K;k[:2,2]+=.5;source=c['sources'];torch.cuda.reset_peak_memory_stats()
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.float16):out=wrapper.preprocess_and_run(cur_image=image(c),src_image=[cv2.imread(L[i]['RGB_path'])[:,:,::-1].copy()for i in source],cur_pose=poses[c['index']],src_pose=poses[source],cur_intrinsics=k.copy(),src_intrinsics=np.repeat(k[None],len(source),axis=0),depth_range=None,num_refinement_steps=1,target_image_size=cfg()['target_size'],device='cuda')
    torch.cuda.synchronize();ar={k:v.float().cpu().numpy()for k,v in out.items()if torch.is_tensor(v)};native=ar.pop('depth')*1000;native_K=K.copy();native_K[:2,2]+=.5;native_K[0]*=native.shape[1]/640;native_K[1]*=native.shape[0]/360;native_K[:2,2]-=.5;native_path=str(R/f"raw/{c['tag']}_native.npz");np.savez_compressed(native_path,depth_mm=native,K_index_native=native_K,K_full=K,reference=c['index'],sources=source,c2w_mm=cam['c2w'],**ar);z=cv2.resize(native.astype(float),(640,360),interpolation=cv2.INTER_LINEAR);pose=np.array(c['pose']);record.update(model_info=info,peak_GPU_GB=torch.cuda.max_memory_allocated()/1e9,native_shape=native.shape);del wrapper,out;wrapper=None;gc.collect();torch.cuda.empty_cache()
   label=labels(c);im=image(c);valid=np.isfinite(z)&(z>0);np.savez_compressed(R/f"depths/{c['tag']}.npz",depth_mm=z,labels=label,valid=valid,pose=pose,K=K,reference=c['index'],sources=c['sources'],native_source=native_path,unit='mm',depth_definition='axis_Z',confidence_status='MODEL_PREDICTED_NOT_GT_CONFIDENCE');cv2.imwrite(str(R/f"inputs/{c['tag']}_RGB.png"),im[:,:,::-1]);cv2.imwrite(str(R/f"inputs/{c['tag']}_labels.png"),label);save(f"inputs/{c['tag']}_camera.json",dict(c2w_mm=pose,K=K,unit='mm',gauge='local_'+c['video']+'_Ring',distortion='UNKNOWN_NOT_REFIT',reference_frame=c['frame']))
   parts={}
   for obj in ['Polyp','Background']:
    mask=object_mask(dict(labels=label),obj);ok=mask&valid;m=depth_mesh(z,ok,pose,K,im);export(m,f"meshes/{c['tag']}_{obj}_A.ply");y,x=np.nonzero(ok);P=unproject(z[ok],pose,np.c_[x,y],K);export(trimesh.points.PointCloud(P,colors=im[ok]),f"points/{c['tag']}_{obj}_raw.ply");q,zq=project(P,pose,K);roundtrip=np.max(np.linalg.norm(q-np.c_[x,y],axis=1))if len(P)else np.nan;assert roundtrip<1e-7;np.savez_compressed(R/f"points/{c['tag']}_{obj}_source.npz",points_mm=P,uv=np.c_[x,y],rgb=im[ok],original_faces=m.faces,point_count_denominator=int(mask.sum()),pose_mm=pose,K=K,source_view=c['frame']['id']);parts[obj]=dict(target_pixels=int(mask.sum()),numeric_points=len(P),mesh_vertices=len(m.vertices),mesh_faces=len(m.faces),unreferenced_vertices=len(P)-len(np.unique(m.faces)),roundtrip_max_px=roundtrip)
   record.update(success=True,parts=parts,depth_positive_fraction=float(valid.mean()),real_GT_available=False)
  except Exception:record['failure']=traceback.format_exc();print(record['failure'],flush=True)
  record['seconds']=time.monotonic()-st;runs.append(record);save('metrics/reconstruction_runs.json',runs);print('RECONSTRUCT',record,flush=True)
 freeze('depth_and_raw_mesh',[R/'metrics/reconstruction_runs.json']+list((R/'depths').glob('*'))+list((R/'points').glob('*'))+list((R/'meshes').glob('*_A.ply'))+list((R/'raw').glob('*')));verify()
if __name__=='__main__':main()

from icf_common import *
def main():
 checks=[];verify();checks.append(dict(check='historical_and_user_dirty_files_unchanged',files=len(load(R/'reproducibility/protected.json')['files']),passed=True))
 for name in ['depth_and_raw_mesh','C_fusion_predictions','D_TSDF_predictions','evaluation_outputs','exported_scenes','visualizations','delivery_metadata','reports']:
  files=load(R/f'reproducibility/{name}.json')['files'];bad=[p for p,h in files.items()if sha(p)!=h];assert not bad,(name,bad);checks.append(dict(check=name,files=len(files),passed=True))
 runs=load(R/'metrics/reconstruction_runs.json');assert len(runs)==6 and all(r['success']for r in runs);assert sum(r['new_HERO_forward']for r in runs)==1;new=next(x for x in runs if x['new_HERO_forward']);assert new['reference']=='v005_00745';assert len(new['sources'])==3;checks.append(dict(check='six_reference_depths_one_actual_new_HERO',passed=True))
 for c in cases():
  p=data(c);assert p['depth_mm'].shape==(360,640);np.testing.assert_array_equal(p['pose'],np.array(c['pose']));np.testing.assert_array_equal(p['K'],K);assert sha(c['frame']['RGB_path'])==c['frame']['RGB_SHA256'];assert sha(c['frame']['Mask_path'])==c['frame']['Mask_SHA256']
 checks.append(dict(check='all_RGB_Mask_depth_camera_bindings_exact',passed=True))
 for video in cfg()['videos']:
  for obj in ['Polyp','Background']:
   p=np.load(R/f'provenance/{video}_{obj}_fusion.npz');raw=p['source_points_mm'];mp=p['source_to_fused'];Q=p['fused_points_mm'];protected=p['protected_boundary'];assert len(mp)==len(raw);assert np.isfinite(Q).all();assert mp.min()>=0 and mp.max()<len(Q);assert np.max(np.linalg.norm(Q[mp][protected]-raw[protected],axis=1))==0;assert np.max(np.linalg.norm(Q[mp]-raw,axis=1))<=np.sqrt(3)*cfg()['fusion_voxel_mm']+1e-8;ff=p['source_faces'];fm=p['source_face_to_fused_face'];actual=trimesh.load(R/f'meshes/{video}_{obj}_C_confidence_fused.ply',process=False);assert len(fm)==len(ff);assert fm.max()==len(actual.faces)-1
   good=fm>=0;mapped=np.sort(mp[ff[good]],axis=1);target=np.sort(actual.faces[fm[good]],axis=1);np.testing.assert_array_equal(mapped,target);checks.append(dict(check='source_provenance_no_new_triangles_boundary_preserved',video=video,object=obj,source_points=len(raw),source_faces=len(ff),passed=True))
 queries=load(R/'metrics/queries_full.json');registry=load(R/'metrics/query_registry.json');assert len(registry)==541;assert len(queries)==2705
 for video in cfg()['videos']:
  for obj in ['Polyp','Background']:
   rr=[x for x in queries if x['video']==video and x['object']==obj];keys=[{x['query_id']for x in rr if x['method']==method}for method in ['A_single','B_combined','C_fused','D_TSDF','HISTORICAL']];assert all(k==keys[0]for k in keys)
 checks.append(dict(check='all_methods_same_full_queries_NaN_not_removed',query_denominator=541,records=2705,passed=True))
 ring=trimesh.load(F2/'inputs/R10_ring.obj',process=False);np.testing.assert_allclose(ring.extents,[12.4,12.4,1.2],atol=.001)
 for candidate in load(R/'inputs/H_frozen.json'):
  oldh=next(x['H']for x in load(LAST/'inputs/baselines.json')if x['tag']==candidate['tag']);np.testing.assert_array_equal(candidate['H'],oldh);H=np.array(candidate['H']);sc=trimesh.load(R/f"scenes/{candidate['tag']}_NEW_LOCAL_FUSION_LAYERS_UNVERIFIED.glb",force='scene',process=False)
  for video in cfg()['videos']:
   T=H if video=='005'else np.eye(4)
   for obj in ['Polyp','Background']:
    expected=trimesh.load(R/f'meshes/{video}_{obj}_C_confidence_fused.ply',process=False);expected.apply_transform(T);node=f'{video}_{obj}_LOCAL_FUSED_LAYER_UNVERIFIED';mat,key=sc.graph[node];actual=sc.geometry[key].copy();actual.apply_transform(mat);actual.vertices*=1000;assert len(actual.vertices)==len(expected.vertices)and len(actual.faces)==len(expected.faces);np.testing.assert_allclose(actual.vertices,expected.vertices,atol=1e-4)
   node=video+'_KnownRing_UNVERIFIED_RELATION';mat,key=sc.graph[node];actual=sc.geometry[key].copy();actual.apply_transform(mat);actual.vertices*=1000;expected=ring.copy();expected.apply_transform(T);np.testing.assert_allclose(actual.vertices,expected.vertices,atol=1e-4)
   ds=load(R/'inputs/datasets.json')[video];poses=np.load(ds['camera_files'][0])['c2w']
   for frame,pose in zip(ds['ledger'],poses):
    node=video+'_'+frame['id']+'_CAMERA_CANDIDATE';mat,key=sc.graph[node];camera=sc.geometry[key].copy();camera.apply_transform(mat);actual_center=camera.vertices.mean(0)*1000;np.testing.assert_allclose(actual_center,(T@pose)[:3,3],atol=1e-4)
  checks.append(dict(check='cross_scene_same_frozen_H_for_all_objects_Ring_units',candidate=candidate['tag'],passed=True))
 assert np.isnan(np.load(R/'scenes/FORMAL_CROSS_SOURCE_TRANSFORM.npz')['H']).all();assert len(list((R/'scenes').glob('*.glb')))==10;assert len(list((R/'visualizations').glob('*.png')))==9;log=(R/'logs/tests_final.log').read_text();assert 'Ran 8 tests'in log and '\nOK\n'in log;checks.append(dict(check='10_GLB_9_PNG_8_tests_formal_transform_NaN',passed=True));save('metrics/FINAL_INTEGRITY.json',checks);freeze('FINAL_DELIVERY',[Path(__file__),R/'metrics/FINAL_INTEGRITY.json',R/'tests/test_fusion.py',R/'logs/tests_final.log']+list((R/'scripts').glob('*.py')));print(json.dumps(clean(checks),ensure_ascii=False,indent=2));print('ALL_INTEGRITY_CHECKS_PASSED',flush=True)
if __name__=='__main__':main()

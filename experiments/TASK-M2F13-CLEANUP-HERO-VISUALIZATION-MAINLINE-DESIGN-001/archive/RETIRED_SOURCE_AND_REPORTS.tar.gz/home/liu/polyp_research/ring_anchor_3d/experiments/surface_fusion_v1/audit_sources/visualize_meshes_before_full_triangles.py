from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

def panel(ax,vertices,faces,pose,K,scope,title,limits):
 f=faces[np.linspace(0,len(faces)-1,min(len(faces),12000)).astype(int)] if len(faces) else faces
 if len(f):
  centroid=vertices[f].mean(1);uv,z=project(centroid,pose,K);color=sample(image(scope,8).mean(2),uv)/255.;fc=plt.cm.viridis(np.clip(color,0,1));ax.add_collection3d(Poly3DCollection(vertices[f],facecolors=fc,edgecolors='none',alpha=1.))
 t=np.linspace(0,2*np.pi,150);ph=np.linspace(0,2*np.pi,14);T,F=np.meshgrid(t,ph);ax.plot_wireframe((5.6+.6*np.cos(F))*np.cos(T),(5.6+.6*np.cos(F))*np.sin(T),.6*np.sin(F),rstride=3,cstride=8,color='black',linewidth=.35)
 for i,(lo,hi) in enumerate(limits):[ax.set_xlim,ax.set_ylim,ax.set_zlim][i](lo,hi)
 ax.set_box_aspect(np.diff(limits,axis=1).ravel());ax.view_init(25,-65);ax.set(xlabel='Ring X mm',ylabel='Ring Y mm',zlabel='Ring Z mm',title=title)

def main():
 verify('evaluation');fig=plt.figure(figsize=(16,10));ps=[]
 for c in ['0','1']:
  for v in ['F0_S0','F2_S0','F0_S1']:
   n=f'MVS_real_{c}_E0_r08_{v}';ps.append((n,np.load(R/f'predictions/{n}.npz')))
 allv=np.concatenate([p['vertices'] for _,p in ps]+[np.array([[-6.2,-6.2,-.6],[6.2,6.2,.6]])]);mn=allv.min(0);mx=allv.max(0);limits=np.c_[mn-.5,mx+.5]
 for j,(n,p) in enumerate(ps):panel(fig.add_subplot(2,3,j+1,projection='3d'),p['vertices'],p['faces'],p['pose'],p['K'],'real',n.replace('MVS_real_','')+f'\n{len(p["faces"]):,} open triangles',limits)
 fig.suptitle('Actual open meshes: raw / F2 constraints / minimal smoothing; shared bounds; MODEL_PREDICTED\nF2 is a no-op for uncertified real poses. No surface ICP or hidden completion.');fig.savefig(R/'visualizations/fig8_real_raw_constrained_smoothed_open_meshes.png',dpi=150,bbox_inches='tight',facecolor='white');plt.close(fig)
 # Every synthetic camera input, same world frame after one Ring-symmetry gauge.
 res=json.loads((R/'metrics/results.json').read_text())['methods'];GT=np.load(V4/'private_gt/008.npz')['depth'];cam=camera('synth','GT');mesh=depth_mesh(GT,labels('synth',8)==1,cam['c2w'][8],cam['K'],image('synth',8));items=[('GT visible surface',mesh.vertices,mesh.faces,cam['c2w'][8],cam['K'])]
 for c in ['GT','0','1']:
  n=f'MVS_synth_{c}_E0_r08_F0_S0';p=np.load(R/f'predictions/{n}.npz');U=np.array(res[n]['GT']['global_Ring_symmetry_rotation']);po=p['pose'].copy();po[:3,:3]=U@po[:3,:3];po[:3,3]=U@po[:3,3];items.append((n,p['vertices']@U.T,p['faces'],po,p['K']))
 allv=np.concatenate([q[1] for q in items]+[np.array([[-6.2,-6.2,-.6],[6.2,6.2,.6]])]);limits=np.c_[allv.min(0)-.5,allv.max(0)+.5];fig=plt.figure(figsize=(14,10))
 for j,(n,v,f,po,K) in enumerate(items):panel(fig.add_subplot(2,2,j+1,projection='3d'),v,f,po,K,'synth',n,limits)
 fig.suptitle('GT visible surface vs MVSAnywhere: GT / predicted0 / predicted1 cameras\nShared Ring gauge and bounds. Texture display is not geometry validation.');fig.savefig(R/'visualizations/fig9_synthetic_open_surface_geometry.png',dpi=150,bbox_inches='tight',facecolor='white');plt.close(fig)
 print('ACTUAL_MESH_FIGURES_COMPLETE',flush=True)
if __name__=='__main__':main()

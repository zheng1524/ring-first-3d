from icf_common import *
import torch,time,gc,traceback
import open3d as o3d
from open3d import core as o3c
SRC=E/'surface_benchmark_v1/vendor/mvsanywhere_minimal/src/mvsanywhere/tools/fusers_helper.py'
def official_fuser():
 ns=dict(np=np,torch=torch,trimesh=trimesh,o3d=o3d,o3c=o3c)
 for n in ast.parse(SRC.read_text()).body:
  if isinstance(n,ast.ClassDef)and n.name in ['DepthFuser','Open3DFuser','CustomOpen3dFuser']:exec(compile(ast.Module(body=[n],type_ignores=[]),str(SRC),'exec'),ns)
 return ns['CustomOpen3dFuser'](fusion_resolution=cfg()['tsdf_voxel_mm']/1000,max_fusion_depth=cfg()['max_depth_mm']/1000,fuse_color=False,extended_neg_truncation=False)
def support_bits(P,packs,obj):
 bits=np.zeros(len(P),np.uint32)
 for j,p in enumerate(packs):
  uv,z=project(P,p['pose'],K);xy=np.rint(uv).astype(int);ok=(xy[:,0]>=0)&(xy[:,0]<640)&(xy[:,1]>=0)&(xy[:,1]<360)&(z>0);ii=np.flatnonzero(ok);x,y=xy[ii].T;yes=object_mask(p,obj)[y,x]&np.isfinite(p['depth_mm'][y,x])&(abs(z[ii]-p['depth_mm'][y,x])<=cfg()['tsdf_truncation_mm']);bits[ii[yes]]|=np.uint32(1<<j)
 return bits
def main():
 freeze('TSDF_protocol',[Path(__file__),R/'config.json',R/'PROTOCOL.md',SRC,R/'reproducibility/depth_and_raw_mesh.json']);runs=[]
 for video in cfg()['videos']:
  packs=[data(c)for c in cases()if c['video']==video and (R/f"depths/{c['tag']}.npz").exists()]
  for obj in ['Polyp','Background']:
   st=time.monotonic();rec=dict(video=video,object=obj,success=False,official_custom_Open3D_unmodified=True,voxel_mm=cfg()['tsdf_voxel_mm'],truncation_mm=cfg()['tsdf_truncation_mm'])
   try:
    f=official_fuser();counts=[]
    for p in packs:
     ok=object_mask(p,obj)&p['valid'];z=np.where(ok,p['depth_mm']/1000,0).astype(np.float32);pose=p['pose'].copy();pose[:3,3]/=1000;k=np.eye(4,dtype=np.float32);k[:3,:3]=K;f.fuse_frames(torch.tensor(z[None,None],device='cuda'),torch.tensor(k[None],device='cuda'),torch.tensor(np.linalg.inv(pose).astype(np.float32)[None],device='cuda'),None);counts.append(int(ok.sum()))
    native=f.get_mesh(trim_tsdf_using_confience=False);P=native.vertex.positions.cpu().numpy()*1000;faces=native.triangle.indices.cpu().numpy();raw=trimesh.Trimesh(P,faces,process=False);raw.visual.face_colors=[170,125,190,255];export(raw,f'meshes/{video}_{obj}_D_TSDF_RAW_UNKNOWN.ply');vb=support_bits(P,packs,obj);fb=vb[faces[:,0]]&vb[faces[:,1]]&vb[faces[:,2]];keep=fb>0;opened=trimesh.Trimesh(P,faces[keep],process=False);opened.visual.face_colors=[170,125,190,255];export(opened,f'meshes/{video}_{obj}_D_TSDF_open.ply');np.savez_compressed(R/f'provenance/{video}_{obj}_D_TSDF_support.npz',vertex_view_bits=vb,raw_faces=faces,face_view_bits=fb,kept_face=keep,interpolated_not_realGT=True);rec.update(success=len(opened.faces)>0,input_pixels=counts,raw_vertices=len(P),raw_faces=len(faces),open_faces=len(opened.faces),unobserved_interpolation_faces=int((~keep).sum()),status='MODEL_INTERPOLATED_POSE_CONDITIONAL',weight_threshold=f.weight_threshold);del f,native;gc.collect();o3d.core.cuda.release_cache();torch.cuda.empty_cache()
   except Exception:rec['failure']=traceback.format_exc();print(rec['failure'],flush=True);gc.collect();torch.cuda.empty_cache()
   rec['seconds']=time.monotonic()-st;runs.append(rec);save('metrics/tsdf_runs.json',runs);print('TSDF',rec,flush=True)
 freeze('D_TSDF_predictions',[R/'metrics/tsdf_runs.json']+list((R/'meshes').glob('*D_TSDF*'))+list((R/'provenance').glob('*D_TSDF*')));verify()
if __name__=='__main__':main()

#!/usr/bin/env bash
set -euo pipefail
# Supply an empty absolute VH_OUT to preserve the delivered experiment.
: "${VH_OUT:?Set VH_OUT to a NEW empty output directory}"
repo_dir=/home/liu/polyp_research
script_dir="$repo_dir/ring_anchor_3d/experiments/occlusion_visual_hull_20261024/code"
python_bin="$repo_dir/ring_anchor_3d/.venv/bin/python"
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
mkdir -p "$VH_OUT"
for step in prepare test_geometry run_real evaluate_diagnostics visualize presentation_detail failure_evidence summarize scene_markers build_report validate; do
  "$python_bin" "$script_dir/$step.py"
done

# FAILURES：完整失败及未确定区域

## 部署失败与修复证据

1. 权重首次分段下载6次SSL EOF：`logs/hero_download.log`、`logs/hero_download_repair_00.log`、`metrics/checkpoint_fetch_attempt00.json`。仅补缺段；最终完整MD5通过，不使用残缺/随机权重。
2. 首次loader分辨率固定pixel-grid mismatch：`logs/inference_synth_GT.log`、`metrics/primary_queue_initial_loader_failure.json`、`metrics/adapter_buffer_fix.json`。3个非学习buffer重建；学习权重无改动。
3. adapter1的抗混叠构造器重复pretrained参数：`logs/inference_adapter1_synth_GT.log`及`primary_queue_adapter1_failure.json`。adapter2抑制冗余初始化，所有535学习tensor从HERO载入。
4. adapter2输入负步长数组，尚未前向：`logs/inference_adapter2_synth_GT.log`、`primary_queue_adapter2_failure.json`，单case的失败json保存在`metrics/*attempt2.json`。adapter3仅复制连续RGB。此前冻结脚本和日志保留，未将错误输出冒充成功。
5. 远程GPU已有SSH连接被断开，未改远程/本地核心环境；本机6GB已完成全部14次前向，峰值1.508GB，无OOM、无硬件回退尺寸。

## 同一真实DEV组：完整4个主条件

- 候选0 E0：4486留出图像对应，MAE4.338px，800/14029参考像素通过筛查，头部560/8471。
- 候选0 E1：MAE4.117px，1014像素通过，头部781；稍好并不证明真实mm更准。
- 候选1 E0：MAE4.732px，598像素通过，头部354。
- 候选1 E1：MAE5.244px，317像素通过，头部231；额外视差反而变差。源深度内部通过率5.45%，没有用其他方法深度填充。

同一条件其余未支持像素仍输出MODEL_PREDICTED，不填补UNKNOWN；状态2为相机条件下筛查而非GT认证。真实K/D与Ring姿态未认证，导致无法分离相机误差和模型失真。frame10未输入新深度网络，但旧BA使用该帧其他训练特征；不能将其报告为完整pipeline未见测试。独立frame15尚保留，未声称已评价。

## 合成失败区域

4个主条件100%数值深度不等于100%准确。原始完整目标MAE0.488—0.945mm，局部max约19—22mm，严重偏差未被均值/p95或色阶隐藏，见`metrics/all_methods.csv`和图2/7/9。重新渲染网格只有约95.0%—97.3%GT可见覆盖；网格误差统计必须带分母。不同预测相机有误差抵消，pred0网格MAE可比GT相机E0更低，不能据此认为预测相机优于GT。

F1/F2仅删除可信前方自由空间违反点，不改变任何保留点；ROI之外112—235点仍保留未知而非夹到边界。额外Ring约束只增1—2个拒绝点/条件，未证实独立形态收益。GT真实表面若与误差相机/Mask边缘相冲突，硬拒绝也可能损伤正确点，因此不把该做法移用于未认证真实相机。

## 竞争/平滑的负面结果

M2在全部4种条件保留失败：合成0可见深度，真实候选1为0，候选0只有约0.05%数值且无有效曲面。M0真实覆盖仅约8.98%/1.45%；其局部较准不能覆盖完整头部。DA3虽100%数值覆盖，合成E0 GT视角MAE6.178mm；native尺度及K/外参不同，另列未认证，不用GT补齐。S1粗糙度下降但共同GT误差变化不足0.001mm，含变差，不能当精度提升。

## 跨资产未执行分母

找到第二视频与3照片共4个扩展资产。第二视频仅有界采样9帧、每帧背景3D关联最多6，三张照片分别14/1/2；均不足20个训练关联的冻结PnP门槛。照片1080p、视频720p，模式尚未证明。E2和3照片深度均未执行，结果NaN；未用Ring对称几何强拼。12张实际匹配图与`metrics/extra_asset_audit.json`为证据，不能把有界检查称为穷尽所有视频帧。

## 仍未知

隐藏背面/蒂部、Ring遮住的Polyp、无可信纹理的头部深度、真实畸变、跨拍摄是否完全静止、真实绝对毫米误差、未注册照片的相机、未使用frame15的检查结果。无新网络/TSDF/3DGS掩盖这些失败；无旧预测回填；不新增清理候选、不删除任何资产。

| 审计项目 | 必须汇报 |
| --- | --- |
| 目标组数 | 1个冻结真实DEV组；1个既有合成场景；8个主实验、6个辅助深度实验 |
| 本算法独立成功 | 主前向8/8、辅助前向6/6产生独立数值；不等同于可信几何成功 |
| 本算法失败 | 最终前向0/14；部署失败保留日志；真实准确性未认证；跨视频/照片注册0/4资产 |
| 历史测量值回退 | 0；M0/M2/DA3仅评价，绝不填充新深度 |
| 失败组及具体原因 | 同一DEV组的相机不确定、留出误差及跨资产对应不足，见FAILURES.md和metrics/extra_asset_audit.json |
| 最终统计样本 | 8个主实验全部32个变体＋14个历史对照=46行；竞争表22行；不删失败/空曲面 |
| 是否使用 GT 选择算法 | 否。参数/源码/源视角/14次预测及曲面先冻结，后统一读取GT评价；未拟合GT尺度、偏移或ICP |


## 交付核验中的实际失败

首次全仓库一致性断言失败，原因是DXY仓库运行期间已有外部文档/验证证据提交，不是本任务改动；详见`metrics/concurrent_DXY_changes.json`和`logs/delivery_verification_attempt00.log`。4474个历史三维文件与根仓库原修改均不变，未回退并行提交。初版图8/9为节省显示面数抽样，造成假孔；已改为展示全部导出三角面，原图保留attempt00。图2原展示了M2未通过valid的深度候选，已改显示冻结valid，评价无变化。

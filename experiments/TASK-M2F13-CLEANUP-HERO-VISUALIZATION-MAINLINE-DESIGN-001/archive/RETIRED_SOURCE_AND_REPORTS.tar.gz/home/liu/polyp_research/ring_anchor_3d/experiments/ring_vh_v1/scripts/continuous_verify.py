"""Observation-only continuous point validation after center-sampled voxel carving.
Required correctness repair: nearest voxel intersection need not satisfy its center's
image/Ring free-space tests. All methods get identical ray step/budget, no GT depth.
Raw voxel-center predictions remain immutable. Strict S0 adds complete-cone FOV check.
"""
from common import *
from solve import frames_data
import argparse,time,trimesh

def accepted(X,poses,K,obs,method,strict):
 c=cfg();good=np.ones(len(X),bool)
 for ob in obs:
  ids=np.flatnonzero(good)
  if not len(ids):break
  uv,z=project(X[ids],poses[ob['frame']],K);ij=np.rint(uv).astype(int);inside=(ij[:,0]>=0)&(ij[:,0]<640)&(ij[:,1]>=0)&(ij[:,1]<360)&(z>0);xx=ij[:,0].clip(0,639);yy=ij[:,1].clip(0,359);positive=inside&ob['positive'][yy,xx]
  if method=='VH0':bad=(inside&~positive)|(~inside if strict else False)
  else:
   bz=ob['bg_depth'][yy,xx];bad=inside&ob['bg'][yy,xx]&np.isfinite(bz)&(z<bz-c['background_free_margin_mm'])
   if method=='VH2':
    rz=ob['ring_depth'][yy,xx];bad|=inside&ob['ring'][yy,xx]&np.isfinite(rz)&(z<rz-c['ring_free_margin_mm'])
  good[ids[bad]]=False
 return good

def ray_verify(occ,pose,K,mask,poses,obs,method,strict):
 c=cfg();bounds=np.array(c['roi_mm']);s=c['voxel_mm'];size=np.array(occ.shape);lo=np.full(mask.shape,np.nan,np.float32);hi=lo.copy();width=lo.copy();seg=np.zeros(mask.shape,np.uint16);touch=np.zeros(mask.shape,bool);y,x=np.nonzero(mask);raw_candidates=0;removed=0
 for st in range(0,len(x),300):
  yy=y[st:st+300];xx=x[st:st+300];D=(np.c_[xx,yy,np.ones(len(xx))]@np.linalg.inv(K).T)@pose[:3,:3].T;C=pose[:3,3]
  with np.errstate(divide='ignore',invalid='ignore'):t1=(bounds[:,0]-C)/D;t2=(bounds[:,1]-C)/D
  enter=np.maximum(np.minimum(t1,t2).max(1),1e-4);leave=np.maximum(t1,t2).min(1);span=np.maximum(leave-enter,0);ns=int(np.ceil(span.max()/c['ray_step_mm']))+2;t=enter[:,None]+np.arange(ns)*c['ray_step_mm'];X=C+D[:,None]*t[:,:,None];ix=np.floor((X-bounds[:,0])/s).astype(int);v=(ix>=0).all(2)&(ix<size).all(2)&(t<=leave[:,None]);ix=np.clip(ix,0,size-1);hit=v&occ[ix[:,:,0],ix[:,:,1],ix[:,:,2]];ids=np.flatnonzero(hit.ravel());P=X.reshape(-1,3)[ids];ok=accepted(P,poses,K,obs,method,strict);raw_candidates+=len(ok);removed+=int((~ok).sum());hit.ravel()[ids[~ok]]=False;has=hit.any(1);first=hit.argmax(1);last=hit.shape[1]-1-hit[:,::-1].argmax(1);a=t[np.arange(len(t)),first];b=t[np.arange(len(t)),last];lo[yy[has],xx[has]]=a[has];hi[yy[has],xx[has]]=b[has];width[yy[has],xx[has]]=b[has]-a[has];starts=hit&~np.pad(hit[:,:-1],((0,0),(1,0)),constant_values=False);seg[yy,xx]=starts.sum(1);touch[yy[has],xx[has]]=(a[has]<=enter[has]+c['ray_step_mm'])|(b[has]>=leave[has]-2*c['ray_step_mm'])
 return dict(depth_min=lo,depth_max=hi,interval_width=width,interval_count=seg,ROI_clipped=touch),dict(discrete_voxel_candidate_samples=raw_candidates,continuous_inconsistent_samples_removed=removed,continuous_valid_sample_count=raw_candidates-removed)

def main():
 a=argparse.ArgumentParser();a.add_argument('scope',choices=['S0_GT','S1_GT','S2_0','S2_1']);args=a.parse_args();verify('protocol');verify('predictions');verify('strict_S0_predictions');firewall(args.scope.split('_')[0]);cached={};outputs=[]
 for st in sorted((R/'predictions').glob(args.scope+'*_status.json')):
  tag=st.name[:-12]
  if 'verified' in tag:continue
  t0=time.monotonic();status=json.loads(st.read_text());a=np.load(R/f'predictions/{tag}_reference.npz');v=np.load(R/f'predictions/{tag}_volume.npz');frames=status['frames'];method=next(m for m in ['VH0','VH1','VH2'] if m in tag);key=(tuple(frames),tag.startswith('S0'))
  if key not in cached:cached[key]=frames_data(a['c2w'],a['K'],frames,key[1],v['background_plane'])[0]
  obs=cached[key];d,record=ray_verify(v['feasible'],a['c2w'][8],a['K'],a['target_mask'],a['c2w'],obs,method,'strict_complete' in tag);valid=a['target_mask']&np.isfinite(d['depth_min']);y,x=np.nonzero(valid);X=unproject(d['depth_min'][y,x],a['c2w'][8],np.c_[x,y],a['K']);passed=accepted(X,a['c2w'],a['K'],obs,method,'strict_complete' in tag);assert passed.all(),'post-verification constraint failure';bits=np.zeros(valid.shape,np.uint16);counts=np.zeros(valid.shape,np.uint8)
  for ob in obs:
   uv,z=project(X,a['c2w'][ob['frame']],a['K']);ij=np.rint(uv).astype(int);inside=(ij[:,0]>=0)&(ij[:,0]<640)&(ij[:,1]>=0)&(ij[:,1]<360)&(z>0);xx=ij[:,0].clip(0,639);yy=ij[:,1].clip(0,359);p=inside&ob['positive'][yy,xx];bits[y[p],x[p]]|=np.uint16(1<<ob['frame']);counts[y[p],x[p]]+=1
  path=R/f'predictions/{tag}_verified_reference.npz';np.savez_compressed(path,**d,valid=valid,target_mask=a['target_mask'],positive_support_view_bits=bits,positive_support_view_count=counts,c2w=a['c2w'],K=a['K'],state='VISUAL_HULL_BOUNDARY_CANDIDATE',not_true_surface=True,continuous_point_rules_verified=True);color=cv2.imread(str(R/'inputs/rgb_008.png'))[:,:,::-1];mesh=depth_mesh(d['depth_min'],valid,a['c2w'][8],a['K'],color);mesh.remove_unreferenced_vertices();mesh.export(R/f'meshes/{tag}_verified_open.obj');record.update(run=tag,valid_pixels=int(valid.sum()),target_pixels=int(a['target_mask'].sum()),mesh_faces=len(mesh.faces),runtime_s=time.monotonic()-t0,GT_depth_or_shape_used=False,post_check_rule_violations=0,no_GT_tuning=True);save(f'predictions/{tag}_verified_status.json',record);outputs+=[path,R/f'predictions/{tag}_verified_status.json',R/f'meshes/{tag}_verified_open.obj'];print(tag,record,flush=True)
 freeze('verified_'+args.scope,outputs+[Path(__file__)])
if __name__=='__main__':main()

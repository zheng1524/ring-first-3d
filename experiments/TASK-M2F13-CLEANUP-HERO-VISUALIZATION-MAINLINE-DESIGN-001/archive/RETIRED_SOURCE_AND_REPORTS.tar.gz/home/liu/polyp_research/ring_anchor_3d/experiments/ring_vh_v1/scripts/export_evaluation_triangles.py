"""Read-only original scene; export Blender's tessellation for independent evaluation.
No camera/scene creation, rendering, training or file save of the source .blend.
"""
import bpy,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];src=R.parent/'ring_first_v4_synthetic_audit/private_gt/models/scene.blend'
bpy.ops.wm.open_mainfile(filepath=str(src));o=bpy.data.objects['Ip_original_mesh'];o.data.calc_loop_triangles();verts=[o.matrix_world@v.co for v in o.data.vertices];tri=[tuple(t.vertices) for t in o.data.loop_triangles]
with (R/'evaluation/GT_polyp_blender_triangles.obj').open('w') as f:
 f.write('# evaluation-only original saved Blender mesh, exact loop triangulation, mm\n')
 for p in verts:f.write('v %.12g %.12g %.12g\n'%tuple(p))
 for t in tri:f.write('f '+' '.join(str(i+1) for i in t)+'\n')
(R/'evaluation/GT_tessellation_source.json').write_text(json.dumps({'source':str(src),'object':o.name,'vertices':len(verts),'triangles':len(tri),'source_read_only':True,'only_evaluation_output':True,'new_scene_or_render':False},indent=2))
print('EXPORTED_EVALUATION_ONLY',len(verts),len(tri))

from pathlib import Path
import numpy as np,cv2,json,datetime,hashlib,ast,sys
R=Path(__file__).resolve().parents[1];E=R.parent;P=E.parent;REPO=P.parent;V4=E/'ring_first_v4_synthetic_audit';V2=E/'surface_pilot_v2'
sys.path.insert(0,str(E/'ring_depth_v3/vendor'))
def cfg():return json.loads((R/'config.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def clean(x):
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,np.ndarray):return clean(x.tolist())
 if isinstance(x,(np.integer,np.bool_)):return x.item()
 if isinstance(x,(float,np.floating)):return float(x) if np.isfinite(x) else None
 return x
def save(p,d):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(clean(d),ensure_ascii=False,indent=2,allow_nan=False))
def stats(x):
 a=np.asarray(x,float).ravel();a=a[np.isfinite(a)];return dict(n=len(a),median=float(np.median(a)) if len(a) else None,MAE=float(np.mean(abs(a))) if len(a) else None,p95=float(np.percentile(abs(a),95)) if len(a) else None,max=float(np.max(abs(a))) if len(a) else None)
def freeze(name,paths):save(f'metrics/freeze_{name}.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files={str(p.resolve()):sha(p) for p in sorted(set(map(Path,paths)))},historical_measurement_fallback=0))
def verify(name):
 d=json.loads((R/f'metrics/freeze_{name}.json').read_text());assert all(sha(p)==s for p,s in d['files'].items()),name
source=E/'ring_first_v1/scripts/common.py'
for name in ['project','unproject','sample','torus_depth','depth_mesh','render']:
 node=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name);exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),globals())
source2=E/'ring_first_v3_static_ba/scripts/common.py'
node=next(n for n in ast.parse(source2.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='triangle');exec(compile(ast.Module(body=[node],type_ignores=[]),str(source2),'exec'),globals())
def axes():
 c=cfg();s=c['voxel_mm'];return [np.arange(lo+s/2,hi,s) for lo,hi in c['roi_mm']]
def grid_points(ax):return np.stack(np.meshgrid(*ax,indexing='ij'),-1).reshape(-1,3)
def firewall(mode):
 # Physical GT input copies allowed only for separately labelled diagnostic conditions.
 def hook(event,args):
  if event!='open' or not isinstance(args[0],(str,bytes)):return
  s=str(Path(args[0]).resolve())
  if '/private_gt/' in s or '/evaluation_exports/' in s or '/new-polyp-dxy/' in s:raise PermissionError('VH prediction firewall: '+s)
  if mode!='S0' and '/debug_inputs/complete_' in s:raise PermissionError('complete silhouette leakage: '+s)
  if mode=='S2' and ('/debug_inputs/' in s or '/evaluation/' in s):raise PermissionError('GT leakage S2: '+s)
 sys.addaudithook(hook)

"""Independent evaluation after predictor/input/outputs SHA freeze. No prediction writes."""
from common import *
from solve import raycast
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation
import trimesh,csv,time

def symmetry(P,GT):
 best=None
 for H in [np.eye(3),np.diag([1.,-1,-1])]:
  S=sum(GT[i,:3,:3]@(H@P[i,:3,:3]).T for i in range(len(P)));a=np.arctan2(S[1,0]-S[0,1],S[0,0]+S[1,1]);U=Rotation.from_rotvec([0,0,a]).as_matrix()@H;error=np.mean([np.linalg.norm(Rotation.from_matrix(GT[i,:3,:3].T@U@P[i,:3,:3]).as_rotvec()) for i in range(len(P))])
  if best is None or error<best[0]:best=error,U
 return best[1]
def span(poses,frames):
 C=poses[frames,:3,3];rad=C/np.linalg.norm(C,axis=1,keepdims=True);a=np.degrees(np.arccos(np.clip(rad@rad.T,-1,1)));dist=np.linalg.norm(C[:,None]-C[None],axis=-1)
 return {'views':frames,'angular_span_about_ring_deg':float(a.max()),'max_baseline_mm':float(dist.max()),'radius_mm':stats(np.linalg.norm(C,axis=1))}
def all_stats(e):return stats(e)
def contains(mesh,P):
 # GT bounds used ONLY to accelerate independent evaluation, never ROI/prediction.
 inside=((P>=mesh.bounds[0])&(P<=mesh.bounds[1])).all(1);ids=np.flatnonzero(inside);out=np.zeros(len(P),bool)
 for st in range(0,len(ids),10000):out[ids[st:st+10000]]=mesh.contains(P[ids[st:st+10000]])
 return out

def holdout(occ,poses,K,plane):
 rows=[];lattice=np.zeros((360,640),bool);lattice[2::4,2::4]=True;y,x=np.nonzero(lattice)
 for i in cfg()['heldout_views']:
  lab=cv2.imread(str(R/f'inputs/labels_{i:03d}.png'),0);d=raycast(occ,poses[i],K,lattice)['depth_min'][y,x];D=(np.c_[x,y,np.ones(len(x))]@np.linalg.inv(K).T)@poses[i,:3,:3].T;den=D@plane[:3];bgz=-(poses[i,:3,3]@plane[:3]+plane[3])/den;front=np.isfinite(d)&(d<bgz-cfg()['background_free_margin_mm']);target=lab[y,x]==1;negative=lab[y,x]==0;known=target|negative;inter=int((front&target).sum());union=int(((front|target)&known).sum());positive_recall=float((np.isfinite(d)&target).sum()/max(1,target.sum()))
  rows.append(dict(view=i,sampling='4px fixed image lattice, 14400 rays/view',target_samples=int(target.sum()),visible_mask_IoU_excluding_ring=inter/max(union,1),positive_ray_feasibility_recall=positive_recall,known_background_front_free_violations=int((front&negative).sum()),known_background_samples=int(negative.sum()),ring_pixels_ignored_unknown=int((~known).sum()),not_surface_accuracy=True))
 return rows

def main():
 verify('protocol');verify('inputs');verify('predictions');save('evaluation/start.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prediction_hashes_verified_before_GT_metrics':True,'no_GT_parameter_or_result_selection':True})
 c=cfg();gt=np.load(V4/'private_gt/scene.npz');GT=gt['c2w'];K=gt['K'];g=np.load(V4/f'private_gt/{c["reference"]:03d}.npz');lab=g['labels'];mask=lab==1;Z=g['depth'];y,x=np.nonzero(mask);uv=np.c_[x,y];GTP=unproject(Z[y,x],GT[c['reference']],uv,K);height=np.full(mask.shape,np.nan);height[y,x]=GTP[:,2];head=mask&(height>=np.median(GTP[:,2]));ringdist=cv2.distanceTransform((lab!=2).astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);near=mask&(ringdist<=12);far=mask&(ringdist>24)
 mesh=trimesh.load(V4/'private_gt/models/polyp.obj',process=False);assert mesh.is_watertight and mesh.is_winding_consistent,'Solid volume evaluation is invalid for non-watertight GT';X=grid_points(axes());native=np.load(R/'evaluation/GT_native_solids.npz');truth=native['solid_GT'];np.savez_compressed(R/'evaluation/GT_reference_and_grid.npz',GT_depth=np.where(mask,Z,np.nan),GT_surface=GTP,GT_solid_voxels=truth,target_mask=mask,head_mask=head,near_ring=near,far_ring=far,not_prediction=True)
 # Independent D0-like evaluation sanity: mesh ray-depth vs Blender ray-depth + pixel roundtrip.
 sel=np.arange(0,len(uv),max(1,len(uv)//128));renderz=render(mesh,GT[c['reference']],uv[sel],K);backq,backz=project(GTP,GT[c['reference']],K)
 gate={'GT_mesh_watertight':mesh.is_watertight,'mesh_ray_vs_Blender_axisZ_mm':stats(renderz-Z[y[sel],x[sel]]),'pixel_roundtrip_max_px':float(np.linalg.norm(backq-uv,axis=1).max()),'depth_roundtrip_max_mm':float(abs(backz-Z[y,x]).max()),'voxel_GT_volume_mm3':float(truth.sum()*c['voxel_mm']**3),'mesh_volume_mm3':float(mesh.volume),'GT_inside_ROI':bool(((mesh.bounds[0]>=np.array(c['roi_mm'])[:,0])&(mesh.bounds[1]<=np.array(c['roi_mm'])[:,1])).all()),'ROI_not_GT_derived':True}
 gate['native_Blender_check']=json.loads((R/'evaluation/Blender_native_geometry_check.json').read_text());gate['OBJ_tessellation_discrepancy_preserved_not_threshold_tuned']=True;gate['solid_classifier']='exact native Blender BVHTree parity, evaluation only';gate['passed']=gate['native_Blender_check']['passed'] and gate['pixel_roundtrip_max_px']<1e-8;save('metrics/evaluation_geometry_gate.json',gate);assert gate['passed'],'Independent geometry check failed: stop'
 rows=[];details={};cameras={};alignments={};ringchecks={}
 for condition in ['GT','0','1']:
  poses=GT if condition=='GT' else np.load(R/f'inputs/pred_camera_{condition}.npz')['c2w'];U=np.eye(3) if condition=='GT' else symmetry(poses,GT);alignments[condition]=U;W=poses.copy();W[:,:3,:3]=U@poses[:,:3,:3];W[:,:3,3]=poses[:,:3,3]@U.T;ce=np.linalg.norm(W[:,:3,3]-GT[:,:3,3],axis=1);rot=np.degrees([np.linalg.norm(Rotation.from_matrix(GT[i,:3,:3].T@W[i,:3,:3]).as_rotvec()) for i in range(16)]);cameras[condition]={'all16':span(poses,list(range(16))),'train':span(poses,c['training_views']),'local':span(poses,c['local_views']),'center_error_mm':stats(ce),'rotation_error_deg':stats(rot),'ATE_RMSE_mm':float(np.sqrt(np.mean(ce**2))),'single_symmetry_rotation_only':U}
  re=[];rr=[]
  for i in range(16):
   q=np.load(V4/f'private_gt/{i:03d}.npz');rv=cv2.erode(q['visible_ring'].astype(np.uint8),np.ones((3,3),np.uint8))>0;yy,xx=np.nonzero(rv);rz=torus_depth(np.c_[xx,yy],poses[i],K,np.zeros(3),np.eye(3),major=c['ring_major_mm'],tube=c['ring_tube_mm']);re.extend(rz-q['ring_depth_alone'][yy,xx]);rr.append(float(np.isfinite(rz).mean()))
  ringchecks[condition]={'analytic_torus_axisZ_vs_Blender_visible_ring_mm':stats(re),'intersection_recall_min':min(rr),'heldout_included_for_evaluation_only':True}
  print('camera+ring evaluated',condition,flush=True)
 for real in [0,1]:
  realc=np.load(R/f'inputs/real_camera_{real}.npz');tr=np.load(R/'inputs/real_tracks.npz');cat=tr['category'];cameras[f'real{real}']={'all16':span(realc['c2w'],list(range(16))),'train':span(realc['c2w'],c['training_views']),'reference8_tracks':int(np.isfinite(tr['xy'][:,8,0]).sum()),'background_tracks':int((cat==0).sum()),'polyp_tracks':int((cat==1).sum()),'predicted_background_points':int((cat[realc['point_ids']]==0).sum()),'predicted_polyp_points':int((cat[realc['point_ids']]==1).sum()),'no_independent_pose_GT':True,'read_only_no_BA_rerun':True}
 for st in sorted((R/'predictions').glob('*_status.json')):
  tag=st.name[:-12];
  if tag.endswith('_verified'):continue
  status=json.loads(st.read_text());status['mesh_faces']=json.loads((R/f'predictions/{tag}_verified_status.json').read_text())['mesh_faces'];condition='GT' if '_GT_' in tag else tag.split('_')[1];a=np.load(R/f'predictions/{tag}_verified_reference.npz');v=np.load(R/f'predictions/{tag}_volume.npz');occ=v['feasible'];valid=a['valid']&mask;z=a['depth_min'];e=z-Z;iv=valid&head;U=alignments[condition];gtocc=native['solid_'+condition];assert np.max(abs(native['U_'+condition]-U))<1e-8;false=gtocc&~occ;extra=occ&~gtocc;sup=v['positive_support']>0;refp=np.isfinite(z)&mask;pp=unproject(z[refp],a['c2w'][c['reference']],np.c_[np.nonzero(refp)[1],np.nonzero(refp)[0]],K)@U.T;ch=(cKDTree(pp).query(GTP)[0].mean()+cKDTree(GTP).query(pp)[0].mean())/2 if len(pp) else np.nan
  # Hidden solid which projects into a visible Ring pixel in >=1 training view.
  solidids=np.flatnonzero(gtocc.ravel());solidX=X[solidids];hidden=np.zeros(len(solidids),bool)
  for i in status['frames']:
   q,zz=project(solidX,a['c2w'][i],K);ij=np.rint(q).astype(int);inside=(ij[:,0]>=0)&(ij[:,0]<640)&(ij[:,1]>=0)&(ij[:,1]<360)&(zz>0);ll=cv2.imread(str(R/f'inputs/labels_{i:03d}.png'),0);ij[:,0]=ij[:,0].clip(0,639);ij[:,1]=ij[:,1].clip(0,359);hidden|=inside&(ll[ij[:,1],ij[:,0]]==2)
  wrongly_hidden=int((hidden&~occ.ravel()[solidids]).sum());held=holdout(occ,a['c2w'],K,v['background_plane']);m=dict(run=tag,numeric_success=status['success'],target_pixels=int(mask.sum()),valid_pixels=int(valid.sum()),coverage=float(valid.sum()/mask.sum()),head_coverage=float(iv.sum()/head.sum()),depth_error_mm=stats(e[valid]),head_depth_error_mm=stats(e[iv]),median_abs_relative_axisZ_error=float(np.median(abs(e[valid])/Z[valid])) if valid.any() else None,Chamfer_visible_mm=float(ch),interval_width_mm=stats(a['interval_width'][valid]),head_interval_width_mm=stats(a['interval_width'][iv]),GT_depth_inside_envelope_fraction=float(((Z[valid]>=z[valid]-c['voxel_mm'])&(Z[valid]<=a['depth_max'][valid]+c['voxel_mm'])).mean()),multiple_disjoint_intervals_fraction=float((a['interval_count'][valid]>1).mean()),ROI_clipped_intervals_fraction=float(a['ROI_clipped'][valid].mean()),wrongly_carved_GT_fraction=float(false.sum()/gtocc.sum()),wrongly_carved_GT_mm3=float(false.sum()*c['voxel_mm']**3),extra_feasible_mm3=float(extra.sum()*c['voxel_mm']**3),extra_feasible_over_GT_volume=float(extra.sum()/gtocc.sum()),positive_supported_extra_mm3=float((extra&sup).sum()*c['voxel_mm']**3),unknown_only_feasible_mm3=float((occ&~sup).sum()*c['voxel_mm']**3),GT_solid_mm3=float(gtocc.sum()*c['voxel_mm']**3),occluded_GT_solid_voxels=int(hidden.sum()),occluded_GT_wrongly_carved_voxels=wrongly_hidden,occluded_GT_wrongly_carved_fraction=wrongly_hidden/max(1,int(hidden.sum())),near_ring_error_mm=stats(e[valid&near]),far_ring_error_mm=stats(e[valid&far]),heldout=held,ROI_touch=status['ROI_touched'],surface_is_only_candidate=True,mesh_faces=status['mesh_faces'])
  details[tag]=m;rows.append(dict(run=tag,coverage=m['coverage'],head_coverage=m['head_coverage'],MAE_mm=m['depth_error_mm']['MAE'],p95_mm=m['depth_error_mm']['p95'],max_mm=m['depth_error_mm']['max'],median_ARE=m['median_abs_relative_axisZ_error'],head_MAE_mm=m['head_depth_error_mm']['MAE'],Chamfer_mm=ch,median_interval_mm=m['interval_width_mm']['median'],wrong_carve_fraction=m['wrongly_carved_GT_fraction'],extra_feasible_mm3=m['extra_feasible_mm3'],extra_supported_mm3=m['positive_supported_extra_mm3'],occluded_GT_wrong_carve_fraction=m['occluded_GT_wrongly_carved_fraction'],heldout_IoU=np.mean([h['visible_mask_IoU_excluding_ring'] for h in held]),heldout_recall=np.mean([h['positive_ray_feasibility_recall'] for h in held]),faces=m['mesh_faces']));print(tag,'MAE',m['depth_error_mm']['MAE'],'head',m['head_depth_error_mm']['MAE'],'width',m['interval_width_mm']['median'],'wrong',m['wrongly_carved_GT_fraction'],flush=True)
 # Shared-support and paired Ring-only effect; never chooses a winner subset.
 common=mask.copy()
 for tag in details:common&=np.load(R/f'predictions/{tag}_verified_reference.npz')['valid']
 paired={};effect={}
 for tag in details:
  z=np.load(R/f'predictions/{tag}_verified_reference.npz')['depth_min'];paired[tag]=stats((z-Z)[common])
 for scope in ['S1_GT','S2_0','S2_1']:
  a=np.load(R/f'predictions/{scope}_VH1_verified_reference.npz');b=np.load(R/f'predictions/{scope}_VH2_verified_reference.npz');pair=mask&a['valid']&b['valid'];delta=b['depth_min']-a['depth_min'];ea=abs(a['depth_min']-Z);eb=abs(b['depth_min']-Z);changed=pair&(abs(delta)>1e-5);av=np.load(R/f'predictions/{scope}_VH1_volume.npz');bv=np.load(R/f'predictions/{scope}_VH2_volume.npz');extra_carve=av['feasible']&~bv['feasible'];condition=scope.split('_')[1];gg=native['solid_'+condition]
  effect[scope]={'common_pixels':int(pair.sum()),'changed_pixels':int(changed.sum()),'changed_head_pixels':int((changed&head).sum()),'depth_change_mm':stats(delta[changed]),'improved_pixels':int((changed&(eb<ea-1e-5)).sum()),'worsened_pixels':int((changed&(eb>ea+1e-5)).sum()),'mean_absolute_error_change_on_changed_mm':float(np.mean((eb-ea)[changed])) if changed.any() else None,'additional_ring_carved_voxels':int(extra_carve.sum()),'additional_GT_wrongly_carved_voxels':int((extra_carve&gg).sum()),'paired_before_MAE_mm':stats((a['depth_min']-Z)[pair])['MAE'],'paired_after_MAE_mm':stats((b['depth_min']-Z)[pair])['MAE']}
  np.savez_compressed(R/f'evaluation/{scope}_ring_effect.npz',changed=changed,depth_delta=delta,abs_depth_error_delta=eb-ea,ring_carved_voxels=extra_carve,head=head)
 a=np.load(R/'predictions/S2_0_VH2_verified_reference.npz');b=np.load(R/'predictions/S2_1_VH2_verified_reference.npz');s=mask&a['valid']&b['valid'];init={'common_pixels':int(s.sum()),'absolute_depth_difference_mm':stats((a['depth_min']-b['depth_min'])[s]),'native_scale_no_alignment':True}
 g=cfg()['real_gate'];primary=details['S1_GT_VH2'];passed=(primary['head_coverage']>=g['head_coverage_min'] and primary['depth_error_mm']['MAE']<=g['depth_MAE_max_mm'] and primary['depth_error_mm']['p95']<=g['depth_p95_max_mm'] and primary['wrongly_carved_GT_fraction']<=g['wrongly_carved_GT_fraction_max'] and primary['interval_width_mm']['median']<=g['median_interval_width_max_mm']);gate_real={'passed':bool(passed),'pre_frozen_thresholds':g,'measured_run':'S1_GT_VH2','real_execution':'eligible; not automatic' if passed else 'SKIPPED: GT geometry gate for useful VH surface failed','no_real_mesh_claim':True}
 with (R/'metrics/summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 save('metrics/evaluation.json',{'runs':details,'common_valid_pixels_all_runs':int(common.sum()),'paired_common_error_mm':paired,'Ring_independent_effect':effect,'initialization_sensitivity':init,'camera_audit':cameras,'Ring_depth_independent_GT_check':ringchecks,'real_gate':gate_real,'no_ICP_no_scale_fit_no_prediction_change':True,'reference_surfaces_continuously_verified':True});save('metrics/real_gate.json',gate_real);freeze('evaluation',list((R/'metrics').glob('*.csv'))+[R/'metrics/evaluation.json',R/'metrics/evaluation_geometry_gate.json',Path(__file__)]);print('EVALUATION_COMPLETE',gate_real,flush=True)
if __name__=='__main__':main()

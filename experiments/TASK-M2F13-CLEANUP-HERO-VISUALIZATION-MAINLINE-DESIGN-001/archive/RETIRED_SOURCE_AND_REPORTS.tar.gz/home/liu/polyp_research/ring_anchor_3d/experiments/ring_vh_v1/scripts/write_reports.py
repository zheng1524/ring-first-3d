from common import *
import csv,shutil

def main():
 M=json.loads((R/'metrics/evaluation.json').read_text());runs=M['runs'];A=json.loads((R/'metrics/constraint_activation.json').read_text());D=json.loads((R/'metrics/delivery_checks.json').read_text());I=json.loads((R/'metrics/initialization_sensitivity.json').read_text());G=json.loads((R/'metrics/evaluation_geometry_gate.json').read_text());c=cfg();eff=M['Ring_independent_effect']['S1_GT'];base=runs['S1_GT_VH1'];main=runs['S1_GT_VH2'];s0=runs['S0_GT_VH0_strict_complete'];loc=runs['S1_GT_VH2_local'];shutil.copyfile(R/'metrics/freeze_protocol.json',R/'freeze.json')
 human='GT头部误差7.97mm；环有局部收益，VH仅作深度融合约束。未改Dxy、未删旧文件。\n\n|审计项目|必须汇报|\n|---|---|\n|目标组数|1组12配置|\n|本算法独立成功|12数值|\n|本算法失败|12几何|\n|历史测量值回退|0|\n|失败组及具体原因|[深度歧义](FAILURES.md)|\n|最终统计样本|12/12|\n|是否使用 GT 选择算法|[否](freeze.json)|\n'
 assert len(human)<=200,len(human);(R/'HUMAN_SUMMARY.md').write_text(human)
 audit='''| 审计项目 | 必须汇报 |
| --- | --- |
| 目标组数 | 1个既有Blender静态场景，12个配置；固定reference8的13,148个可见息肉像素。另有1个真实DEV组仅只读相机审计。 |
| 本算法独立成功 | 12/12产生本轮独立VH可行空间及数值候选曲面；0/12达到冻结的可信表面关口。数值输出不等于重建正确。 |
| 本算法失败 | 数值运行失败0/12；几何未认证12/12。像素缺失保持NaN，未执行真实VH不计为成功。 |
| 历史测量值回退 | 0；未以旧深度、旧曲面或任何Dxy测量值填补预测。 |
| 失败组及具体原因 | 全部12配置及两项实现检查见[FAILURES.md](FAILURES.md)，可视证据见[误差图](visualizations/fig3_depth_error_and_intervals.png)。 |
| 最终统计样本 | 全部12配置，逐配置报告13,148像素分母、覆盖率与缺失；共同有效像素12,968，另给严格配对结果。 |
| 是否使用 GT 选择算法 | 否。参数、原预测、连续点复核协议及其输出分别在GT评分前冻结；检查修复与新增诊断均保留旧结果，见[初始冻结](metrics/freeze_protocol.json)、[连续点协议](metrics/freeze_continuous_point_protocol.json)、[评价协议](metrics/freeze_verified_evaluation_protocol.json)。 |
'''
 def fmt(x,n=3):return f'{x:.{n}f}' if x is not None else 'NaN'
 table='|配置|有效覆盖 %|头部覆盖 %|深度MAE mm|p95 mm|最大 mm|头部MAE mm|Chamfer mm|区间中位宽 mm|GT误雕刻 %|\n|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n'
 for tag,v in runs.items():table+=f"|{tag}|{100*v['coverage']:.3f}|{100*v['head_coverage']:.3f}|{v['depth_error_mm']['MAE']:.3f}|{v['depth_error_mm']['p95']:.3f}|{v['depth_error_mm']['max']:.3f}|{v['head_depth_error_mm']['MAE']:.3f}|{v['Chamfer_visible_mm']:.3f}|{v['interval_width_mm']['median']:.3f}|{100*v['wrongly_carved_GT_fraction']:.5f}|\n"
 pair='|配置|共同12,968像素MAE mm|\n|---|---:|\n'+''.join(f"|{t}|{s['MAE']:.3f}|\n" for t,s in M['paired_common_error_mm'].items())
 vol='|配置|额外可行空间 mm³|其中至少1视角Polyp支持 mm³|GT实体误雕刻 %|被Ring遮挡的GT实体误雕刻 %|\n|---|---:|---:|---:|---:|\n'
 for t in ['S0_GT_VH0_strict_complete','S1_GT_VH0','S1_GT_VH1','S1_GT_VH2','S2_0_VH2','S2_1_VH2']:
  a=runs[t];vol+=f"|{t}|{a['extra_feasible_mm3']:.2f}|{a['positive_supported_extra_mm3']:.2f}|{100*a['wrongly_carved_GT_fraction']:.5f}|{100*a['occluded_GT_wrongly_carved_fraction']:.3f}|\n"
 camera='|相机|训练观察跨度 °|最大基线 mm|中心ATE RMSE mm|旋转MAE °|Ring深度MAE mm|\n|---|---:|---:|---:|---:|---:|\n'
 for t in ['GT','0','1']:
  v=M['camera_audit'][t];ri=M['Ring_depth_independent_GT_check'][t];camera+=f"|{t}|{v['train']['angular_span_about_ring_deg']:.3f}|{v['train']['max_baseline_mm']:.3f}|{v['ATE_RMSE_mm']:.3f}|{v['rotation_error_deg']['MAE']:.3f}|{ri['analytic_torus_axisZ_vs_Blender_visible_ring_mm']['MAE']:.6f}|\n"
 protected='历史3D文件起止保护核验通过；根仓库既有未提交修改保持不变；DXY仓库HEAD、受检已跟踪文件哈希及状态均未变化。' if all(v['unchanged'] for v in D['git'].values()) else '历史3D保护核验通过；工作空间存在范围外Git变化，详见delivery_checks，未恢复或重算Dxy。'
 tech=f'''# Ring-VH V1 技术报告

日期：2026-10-18（Asia/Shanghai）。本轮只回答现有视角下，保守轮廓可行域能否提供可信的reference8可见表面。

## 实际结论与唯一决策

**不能把本轮VH最近包络作为准确息肉头部。** 使用GT相机和严格完整剪影，深度MAE仍为{s0['depth_error_mm']['MAE']:.3f} mm，头部MAE {s0['head_depth_error_mm']['MAE']:.3f} mm。三值遮挡处理大幅减少错误雕刻；Ring已知深度还有独立的自由空间收益，但没有消除表面歧义。

GT相机下，VH1→VH2的参考可见深度MAE从{base['depth_error_mm']['MAE']:.3f}降到{main['depth_error_mm']['MAE']:.3f} mm；头部仍为{main['head_depth_error_mm']['MAE']:.3f} mm，区间中位宽度{main['interval_width_mm']['median']:.3f} mm。**暂停独立Visual Hull表面路线，只保留遮挡感知可行域作为后续深度融合的几何约束候选。** 真实VH关口未通过，未运行真实曲面，不使用其他路线回填。

## 固定审计

{audit}
## 继承资产和数据边界

复用`ring_first_v4_synthetic_audit`的原始Ip Blender模型、单个R10套头场景、16个RGB/实例标签、原相机轨迹和冻结C2_0/C2_1相机候选。未新建、移动或重渲染场景。背景与息肉材质纹理固定在三维表面。原场景参数：息肉宽9.8 mm；torus中心(0,0,0)，法向+Z，中心线半径5.6 mm、截面半径0.6 mm。9.8 mm与真实支撑面位置只描述GT场景，不进入正式ROI、初始化或参数选择。

正式S2输入只有冻结RGB导出的相机、RGB背景轨迹、理想可见实例标签和已知Ring尺寸。没有调用新的Ring拟合，不修改DXY-MID；二维Mid椭圆没有被当作三维物理对应点。`inputs/DXY_reuse.json`只记录历史底层缓存/几何来源。本轮合成Mask来自Blender理想实例分割，不能据此推断真实分割鲁棒性。

独立目录为`{R}`。输入完整SHA见[来源清单](inputs/source_manifest.json)、[输入冻结](metrics/freeze_inputs.json)。旧相机属于被用户授权复用的定位资产；新Polyp体积和深度均由本轮剪影程序产生，没有读取DA2/DA3深度、旧TSDF或Dxy测量。

S0中的“完整剪影”直接由原存档`polyp_depth_alone`的有限值提取，只有受控S0可读；S1用隔离GT相机、实际可见Polyp/Ring标签；S2只读预测相机。S2的Python文件访问防火墙拒绝`private_gt`、`debug_inputs`、`evaluation`和DXY仓库。本文S0为用户指定的本轮合成诊断，不是历史S0直径路线。

## 冻结几何协议

640×360像素，K=(fx,fy,cx,cy)=(490,490,319.5,179.5)，无畸变。像素索引中心；OpenCV相机+x右、+y下、+z前；`c2w`把相机点变到Ring世界，轴向深度Z以mm表示。投影`q=R_cw^T(X-C)`；`u=fx*qx/qz+cx`。相机尺度沿用已知R10锚定尺度，不借GT进行尺度拟合。

ROI各轴[-15.5,15.5] mm，来自`2.5×(5.6+0.6)`，**不用GT息肉边界**。体素0.25 mm，共124³=1,906,624个中心；射线轴向步长0.125 mm；Mask固定1 px容差；Ring自由空间保留0.25 mm余量，背景平面保留0.5 mm余量。不平滑、不ICP、不逐帧或各向异性缩放、不把ROI裁切边界当物体表面。

主训练帧：{c['training_views']}；参考8，留出剪影10、15。另固定6/7/8/9作为局部小跨度诊断，不因GT结果选择帧。训练相机关于Ring的视角跨度{M['camera_audit']['GT']['train']['angular_span_about_ring_deg']:.3f}°，局部仅{M['camera_audit']['GT']['local']['angular_span_about_ring_deg']:.3f}°；没有360°环绕。

留出的只是本轮VH的Polyp剪影。冻结相机和原RGB轨迹曾使用这些帧的RGB/部分Ring信息，因此不是端到端完全未见图像测试，不能夸大独立性。背景平面估计不使用本轮留出帧观测。

## 背景自由空间：附加假设及限制

背景Mask本身不提供深度，因此不能把整条背景射线删除。为满足保守雕刻要求，本合成场景引入**RGB估计的单背景平面**：只用类别0训练轨迹，按各条件相机DLT三角化，至少3帧、正深度、≥1°视差、重投影中位<1 px；固定种子500次RANSAC，阈值0.15 mm，至少30内点，3次SVD重拟合。仅雕刻估计平面前方0.5 mm之外的自由空间，平面后方始终UNKNOWN。

GT相机条件接受2,765条背景轨迹，平面内点1,892；拟合平面约`-0.000728x+0.000379y+0.9999997z+5.635966=0`，内点绝对残差MAE0.0614 mm。没有读GT背景深度、支撑面真值来拟合或选择平面。相机0/1分别重新按相同规则估计，结果均保存，未按GT挑选。

这不是一般人体内镜中已知的平面；人工确认“静态”不等于“平面”。真实迁移若没有可信背景深度，仍须保留未知。本轮没有将这一合成平面假设强行用于真实DEV。

## VH定义与点级正确性

投影、反投影、解析torus求交、开放网格和DLT三角化直接加载已有三维函数，不执行旧实验入口。旧V3体素函数硬编码336×252、16视图和支撑底面，不能直接套用本轮640×360/可变视图；保留其体素交集与射线步进结构，新增参数化三值适配。没有另写Ring椭圆拟合，也没有修改DXY核心。

- POSITIVE：可见Polyp或固定像素容差内。它仅允许候选体素保留，不证明整条射线被物体占满。
- Ring像素：Ring身份可信，后方未知。VH1保留这条射线；VH2只排除Ring表面前方确定自由空间。
- 背景：只有经RGB平面及余量确认在其前方的部分为NEGATIVE；平面后方/图像外/无交点为UNKNOWN。

VH0为故意朴素的二值对照：在图像内，只保留Polyp剪影锥，错误地把可见Ring像素也当负观测。其图像外保留UNKNOWN。
VH1使用三值规则和上述背景深度终止。
VH2在相同VH1基础上，加入完整3D torus最近正射线交点，只有腐蚀1 px后的真实可见Ring像素、有效交点且不处于Polyp容差区才使用`Z_voxel < Z_ring - 0.25`自由空间删除。Ring后方未知；不使用Ring平面作为息肉基底，不复制深度或制造接触。

S0另有严格“完整且未截断剪影锥”控制：图像外也排除。原保守S0完整保留。两者最终参考曲面完全相同，但严格版本去掉无视角支持的ROI空间，所以不能把全部未知体积当恢复实体。严格控制没有挑选更好结果替代原结果。

首次射线包络仅检查体素中心，发现点级Ring规则仍有5,672/13,148个违反。原因是一个中心通过测试的立方体不代表内部任意点通过像素级测试；这是几何实现问题，不能解释成Ring失效。已冻结并对**全部12配置**加入相同连续点复核：每个体素命中采样点再次通过原始多视角Mask、背景及Ring规则，输出最近/最远通过点和区间数量。步长、相机、权重和容差均未改变，原预测、违规图与日志保留。最终各配置断言点级规则违反数为0；这只证明观测相容，不证明真实深度准确。

输出最近候选、最远候选、外包区间宽度、分离区间数量、各视角Polyp支持bitmask和ROI截断。区间宽度包含可能的空隙，不是物体厚度；不提供统计置信区间。开放网格只连接reference8可见Mask内相邻像素、深度跳变≤0.75 mm的三角形，不跨Ring遮挡区连接，不封闭背面。所有曲面标记`VISUAL_HULL_BOUNDARY_CANDIDATE`。

## 评价正确性关口与修复证据

反投影/投影往返最大像素误差{G['pixel_roundtrip_max_px']:.2e} px，深度误差{G['depth_roundtrip_max_mm']:.2e} mm。原OBJ的非平面四边形经Trimesh三角化后，相对Blender BVH抽查129条射线最大差0.03696 mm，首次评价按预先0.01 mm门槛停止，未调低门槛。单独导出loop triangles也未完全重现原BVH。

随后只读加载原`.blend`，复用**原GT生成器相同的BVHTree.FromPolygons**重放射线：最大差{G['native_Blender_check']['max_mm']:.2e} mm，验证坐标与原GT深度自洽。实体占据评价也改用同一原生BVH奇偶射线法，固定通用射线及0.0001 mm前进量；不再把不同多边形三角化当相同几何。GT体素实体{G['voxel_GT_volume_mm3']:.3f} mm³，原三角化OBJ体积{G['mesh_volume_mm3']:.3f} mm³。GT网格水密且全体位于独立ROI内。这些GT资产只供评价进程读取。

失败证据：[初始门槛](evaluation/attempt00_failed_geometry_gate.json)、[原生BVH重放](evaluation/Blender_native_geometry_check.json)、[原生实体方法](evaluation/native_solid_method.json)、[点级修复原因](metrics/continuous_repair_reason.json)。原始评价与未点级复核结果保留在`evaluation/attempt01/`、`evaluation/attempt02_raw_voxel_surfaces/`，不是本报告最终成绩。

最终评价只允许每条预测相机序列一个Ring对称规范：统一绕法向yaw及法向符号等价变换；无GT平移/尺度校正，无逐帧配准。深度轴向Z直接按同一像素比较；Chamfer是参考帧GT直接可见点与候选可见点的双向最近距离均值，包含覆盖损失，不使用隐藏表面。头部仅在评价中定义为GT可见点世界Z上半分位，不参与预测。近Ring区域为可见Ring距离≤12 px、远区>24 px。

## 全部12配置最终结果

以下均为连续点复核后的候选，非原始体素交点结果。覆盖是**数值覆盖**。整个目标分母13,148，缺失不补齐；深度MAE只对有效像素统计，完整缺失比例同时保留，未将NaN计为零。中位绝对相对轴向Z误差见CSV的`median_ARE`，不是高度相对误差。

{table}
完整机器数据：[summary.csv](metrics/summary.csv)、[evaluation.json](metrics/evaluation.json)。所有配置都达到不了可信表面关口，不能凭100%数值覆盖或大量面数宣称成功。

{pair}
## 体积守恒与遮挡错误

{vol}
“额外可行空间”是仍可能存在物体的空间上界，不是估计的息肉实体体积。总量包含图像外、背景后及全遮挡未知；另列至少一个Polyp视角支持的部分，仍不能解释为真实占据。严格S0在完全剪影下仍多出{100*s0['extra_feasible_over_GT_volume']:.1f}%的GT实体体积；VH2额外空间约{main['extra_feasible_over_GT_volume']:.2f}倍GT实体。原始真实GT实体均在ROI内，表明多余体积来自观测不足/保守未知，不是GT被ROI截断。

VH0将约{100*runs['S1_GT_VH0']['wrongly_carved_GT_fraction']:.2f}%真实实体雕刻掉，在至少一帧被可见Ring遮挡的实体子集内误删约{100*runs['S1_GT_VH0']['occluded_GT_wrongly_carved_fraction']:.2f}%；VH1/VH2分别只误删1个GT体素（0.00311%）。不能通过把这些未知区域硬判为空来换取更小体积。

## Ring独立贡献与仍未解决的误差

VH0→VH1还改变背景射线终止方式，不能将其全部差异单独归给Ring；下面VH1→VH2才是其他规则不变的Ring深度配对。

GT相机下VH2相对VH1额外删除{eff['additional_ring_carved_voxels']:,}个自由空间体素（{eff['additional_ring_carved_voxels']*c['voxel_mm']**3:.3f} mm³），未额外删除真实GT体素。{eff['changed_pixels']:,}/13,148个参考点改变，其中头部{eff['changed_head_pixels']:,}；改变点平均轴向深度移动{eff['depth_change_mm']['MAE']:.3f} mm，全部改变点GT绝对误差下降，本场景没有变差点。不能将这一单场景结论推广为普遍保证。预测相机0下，Ring约束额外误删2个GT体素，见完整配对数据；并非所有相机条件都保持实体守恒。

最终连续点VH1仍有{A['S1_GT']['before_VH1']['violating_ref_surface_points']:,}个点违反Ring前方自由空间规则；VH2为0。VH2剩余“投影到可用Ring像素”的点{A['S1_GT']['after_VH2']['ring_applicable_ref_surface_points']}个，均位于允许的后方。应用分母改变也报告，不能只比较违反百分比。

GT下近Ring区域MAE：VH1 {base['near_ring_error_mm']['MAE']:.3f}→VH2 {main['near_ring_error_mm']['MAE']:.3f} mm；远Ring区域{base['far_ring_error_mm']['MAE']:.3f}→{main['far_ring_error_mm']['MAE']:.3f} mm。收益并非只有坐标或尺度，本轮所有方法本来共享毫米尺度；它来自排除不可能在Ring前方的候选点。但前包络仍系统性靠近相机，不能把不等式约束当正确形态。

## 视角跨度、相机误差和初始化

{camera}
GT完整16帧可用视角跨度17.221°，主训练14帧16.031°；4帧局部仅3.456°。局部VH2 MAE {loc['depth_error_mm']['MAE']:.3f} mm、宽度{loc['interval_width_mm']['median']:.3f} mm，主14帧分别{main['depth_error_mm']['MAE']:.3f}和{main['interval_width_mm']['median']:.3f} mm。增加现有视角有效，但仍远不足以定深度。

预测相机0/1下VH2 MAE分别{runs['S2_0_VH2']['depth_error_mm']['MAE']:.3f}/{runs['S2_1_VH2']['depth_error_mm']['MAE']:.3f} mm，相比GT的{main['depth_error_mm']['MAE']:.3f} mm约+0.322/-0.242 mm。后者“更低”不能解释成相机更准确，是错误前包络与相机偏差抵消；没有按此选择初始化。两个初始化共同13,140像素的深度差绝对MAE {I['absolute_depth_difference_mm']['MAE']:.3f} mm，p95 {I['absolute_depth_difference_mm']['p95']:.3f}、最大{I['absolute_depth_difference_mm']['max']:.3f} mm，存在局部敏感性，见[正确区分有符号/绝对中位数](metrics/initialization_sensitivity.json)。

原生GT torus深度与Blender在66,558个腐蚀后可见Ring像素的MAE0.000473 mm，最大0.002064 mm；投影/深度模型在GT相机下正确。预测相机0的Ring深度MAE0.272 mm，候选1为0.027 mm，显示相机误差会传播；两者均保留。预测器仅按观察Mask能否与解析Ring相交做≥95%身份自洽门槛，不使用GT Ring深度筛掉较差初始化。配置里的`ring_depth_gate_median_mm`未进入预测筛选，不能把它误当GT深度认证。

主要残差在GT下已达数毫米，明显大于这两条合成相机候选造成的平均变化；现有视角分布/轮廓信息不足是首要限制。这不是所有相机误差或所有拍摄条件的定量分解，仅是本场景严格配对证据。

## 留出剪影与不确定性

留出10、15帧每帧固定4 px网格14,400条射线，用原体素可行体检验未参与雕刻的剪影。单独记录Polyp射线可行性召回、排除Ring未知后的前背景深度IoU、背景自由空间违反数。严格完整S0平均IoU约0.928，Polyp召回1.0，但深度仍错误；VH2约0.396、召回1.0，说明保守未知包含大量不真实候选。低IoU不授权删除遮挡后未知，高IoU也不证明真实曲面。

VH2约{100*main['ROI_clipped_intervals_fraction']:.2f}%区间碰ROI；GT深度落入外包区间比例约{100*main['GT_depth_inside_envelope_fraction']:.3f}%，但宽度中位{main['interval_width_mm']['median']:.3f} mm。截断区间通常只有有限搜索窗口界限，不能宣称真实深度上下界已闭合。输出UNKNOWN/wide标记保留，开放曲面只是最近可行包络。

## 真实相机只读审计及关口

仅检查同一DEV测量组原16帧/reference8/raw674冻结相机候选0/1与轨迹类别；没有新BA或新Ring拟合。原资产中参考8轨迹1,855条，背景3,380、Polyp186；候选0点云背景2,096/Polyp81，候选1背景2,010/Polyp75，说明定位主要依赖背景。源定位还使用Polyp特征，**不是纯背景消融**。

两条真实候选数值16/16、环中心观察方向跨度约43.59°/41.82°，是未认证的预测跨度，不能当真实视差GT。源V5独立留出重投影MAE约2.539/3.287 px，reference8误差3.727/4.133 px，均未通过原可靠性条件。这些为只读历史定位诊断，不是本轮算法新成绩。静态确认不等于相机已经准确。

冻结真实启动条件：GT-VH2头部覆盖≥80%、MAE≤0.5 mm、p95≤1 mm、误雕刻≤2%、区间中位≤1 mm。实际仅覆盖和守恒通过，准确性/区间失败，因此**真实VH执行0/1，真实开放曲面精度未知**；没有补跑更容易视频、换目标帧或用其他模型补齐。

## 交付与复现

- [图1：已有场景/Mask及相机跨度](visualizations/fig1_observations_and_camera_span.png)。
- [图2：GT、完整剪影与VH0/VH1/VH2同尺度表面](visualizations/fig2_visible_surfaces_same_metric_frame.png)。
- [图3：统一色阶深度、误差与可行区间](visualizations/fig3_depth_error_and_intervals.png)。
- [图4：误雕刻、Ring独立删除区域和真实误差变化](visualizations/fig4_occlusion_and_ring_independent_effect.png)。
- [图5：GT与两个预测相机敏感性](visualizations/fig5_camera_sensitivity_nonblank.png)，已实际打开检查，PNG非空、完全不透明。
- [图6：参考射线区间剖面](visualizations/fig6_reference_ray_ambiguity.png)。
- [图7：全部12配置，包含最差局部视角及两个初始化](visualizations/fig7_all_runs_failures.png)；绝对误差图统一0—20 mm，缺失像素用青色表示。

机器结果索引[scene_manifest.json](meshes/scene_manifest.json)。正式候选用`*_verified_reference.npz`和`*_verified_open.obj`；无`verified`的曲面仅为保留的原始离散实现，不得替代最终曲面。`*_volume.npz`是中心采样的三维可行空间，`*_uncertainty.npz`为宽区间/未知/Ring遮挡标记；不是封闭实体或完整体积估计。

Python复用`ring_anchor_3d/.venv/bin/python`，NumPy/OpenCV/SciPy/Trimesh及既有`ring_depth_v3/vendor`，CPU运行并限制BLAS线程1。Blender5.0.1仅只读重放GT进行评价，不渲染、不建新场景。本轮没有训练、下载或部署新模型。

只在新目录重放，脚本拒绝覆盖当前结果：

```bash
cd /home/liu/polyp_research
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python \\
  ring_anchor_3d/experiments/ring_vh_v1/scripts/run_reproduction.py \\
  --new-dir ring_vh_v1_reproduction
```

入口依次复制本轮源码/配置到新的同级目录→复制并哈希输入→运行S0/S1/S2与4视角控制→冻结→严格完整剪影控制→所有方法相同连续点复核→冻结→原生Blender独立GT评价→图像/报告/保护核验。不会修改原实验。重放修复后的流程，不重复故意触发首次OBJ门槛失败；原始失败证据仍在本交付中。入口本轮仅做语法及拒绝覆盖检查，没有为验证脚本而重复完整实验；实际运行证据为logs中的本轮逐步骤记录。

## 经典依据与适用范围

Laurentini的Visual Hull讨论剪影能定义的几何，以及其无法恢复的非凸表面细节；本轮把“轮廓相容”与“表面真实”分开评价。[作者所属机构条目](https://iris.polito.it/handle/11583/1401917?mode=full)、[原论文DOI](https://doi.org/10.1109/34.273735)。

Guan等2006使用遮挡Mask扩展剪影以避免真实形体被错误删去；其“正确”指真实物体包含在可行外壳中，不表示外壳就是实际表面。本轮借用这一保守思想，并增加已知torus自由空间，未复现论文的动态遮挡检测系统。[作者公开原论文](https://snsinha.github.io/pdfs/Guan3DPVT2006.pdf)、[作者单位摘要](https://www.microsoft.com/en-us/research/publication/visual-hull-construction-presence-partial-occlusion/)。

结论只针对一个有理想分割、平面背景、约16°非环绕视角的既有合成Ip场景及两条冻结相机候选，不能推广至全部Ip/Is/IIa或真实设备毫米精度。

## 工程保护与下一步

{protected} 本轮未写Dxy代码/测量参数/结果，未删除、移动、压缩任何历史资产；未读取未来TEST。受检历史文件{D['protected_history_files']:,}个；其中小于4 MB文件另核SHA，其余检查大小/mtime，复用输入另完整SHA。**不夸大为对所有大文件逐字节重哈希。** 详细见[delivery_checks.json](metrics/delivery_checks.json)。无清理候选：失败VH仍有几何约束价值，且保留其证据。原始数据、模型、Dxy从未列为可清理对象。

唯一建议主线：冻结已有多视角深度初始化，严格配对“无VH约束/加入三值可行域和Ring自由空间”，把约束当可行性筛查和不确定性信息，继续用完整可见表面误差评价。当前不推荐继续纯VH、加大Ring权重或训练新网络。
'''
 (R/'TECHNICAL_REPORT.md').write_text(tech)
 fail='''# Ring-VH V1 失败与未知记录

最终结果不是可信的真实息肉表面。数值输出和几何认证分开，全部分母保留。

'''+audit+'''
## 逐配置失败分母

'''+table+'''
全部12配置深度MAE或区间宽度未达冻结关口；具体像素NaN/覆盖率、头部、远/近Ring和独立留出统计均在[完整数据](metrics/evaluation.json)。不要将只比较有效区域的MAE脱离覆盖率使用。

## 检查失败与修复

1. 初次评价把OBJ自动三角化当作原Blender多边形BVH。129条射线最大差0.03696 mm，按原门槛停止。loop triangle导出也未完全重合；改用同一个原生BVH重放，最大差1.72e-6 mm。未调整精度门槛或预测，初始门槛及日志保留在`evaluation/attempt00_failed_geometry_gate.json`、`logs/evaluation_attempt00.log`。
2. 原始中心采样体素的包络点不一定满足连续像素约束。原VH2参考点违反5,672/13,148；不可把“体素保留”当点的几何证明。相同协议对全部12配置逐采样点验证，最终违反0，保留旧NPZ/网格/日志于原文件及`evaluation/attempt02_raw_voxel_surfaces/`。旧的无verified网格禁止作为最终成果。
3. 完整剪影的原S0图像外空间曾保留未知。增列严格完整剪影锥控制，不覆盖原S0；两者可见表面和误差一致，仅全ROI的无支持空间不同，不影响主要失败判断。
4. `evaluation.json`中的初始化差异stats原有median为有符号差；MAE/p95/max始终是绝对量。显式绝对中位数在[initialization_sensitivity.json](metrics/initialization_sensitivity.json)，不将负中位数称作绝对误差。

## 尚未解决

- 14帧视角跨度只有约16°，完整剪影仍产生约7.10 mm深度MAE。三值规则避免误删，但同时暴露大量未知，不能通过压缩ROI、假设底面或平滑制造形状。
- 约94%的主VH2深度区间碰ROI；29.63 mm中位宽度不是已被精确限定的物体厚度。未观测背面、Ring后方、背景后方和图像外始终未知。
- 预测相机0增加少量真实体素误删，Ring深度误差更大；两个初始化最大参考深度差约7.60 mm。不通过GT挑选更好初始化。
- 真实背景静态但不保证平面，本轮平面自由空间先验不能直接迁移人体内镜。
- 真实候选16/16为数值输出，源独立几何验证未通过；真实VH按GT关口未执行，没有真实毫米精度、完整网格或接触判断。
- 本场景Ring约束使改变点GT误差全下降，但一个场景无变差例不等于普遍无风险；不宣称真实息肉或全部类型有效。

[全部12配置证据图](visualizations/fig7_all_runs_failures.png)、[主要证据图](visualizations/fig3_depth_error_and_intervals.png)、[Ring作用图](visualizations/fig4_occlusion_and_ring_independent_effect.png)、[射线区间图](visualizations/fig6_reference_ray_ambiguity.png)。没有清理候选，没有删除或移动资产。
'''
 (R/'FAILURES.md').write_text(fail)
 decision=f'''# Ring-VH V1 决策

唯一后续方向：**保留遮挡感知Visual Hull作为已有多视角深度融合的几何可行性约束，暂停独立VH表面重建。** 本轮不启动真实VH、网络训练或3DGS。

A. 当前视角可约束外形/排除部分空间，但不能可靠恢复头部真实深度。严格完整剪影+GT相机头部MAE{s0['head_depth_error_mm']['MAE']:.2f} mm；Ring遮挡条件VH2头部MAE{main['head_depth_error_mm']['MAE']:.2f} mm，区间中位{main['interval_width_mm']['median']:.2f} mm。

B. 合成冻结Ring+RGB相机足以复现GT下的主要VH失败，却不能使VH定深度；真实候选仅为数值定位，不能判定其已足够可靠。定位源包含背景与Polyp，不是纯背景独立消融。

C. 有可验证收益：三值规则把GT实体误删从12.11%降到0.00311%；独立Ring自由空间使VH1→VH2深度MAE{base['depth_error_mm']['MAE']:.2f}→{main['depth_error_mm']['MAE']:.2f} mm，新增8,251个自由空间体素删除且没有新增GT体素误删。收益不足以称为真实表面。

D. 在本场景，GT下已有的大幅深度歧义占主导；两个预测相机相对GT的平均表面变化约+0.32/-0.24 mm，但局部初始化变化最大7.60 mm，不能忽略。增加现有观察跨度比只换相机候选更有效，仍未达到准确表面。

E. 作为约束保留，独立路线暂停。下一轮只做一项小对照：同一冻结相机、相同已有深度预测，比较无可行域/加入可行域及Ring自由空间；报告完整覆盖、头部深度误差、违反率和拒绝区域。不依据环二维邻接、接触假设、GT或视觉平滑补表面。

停止真实实验依据：[冻结关口与实际结果](metrics/real_gate.json)。最终数值：[summary.csv](metrics/summary.csv)。

'''+audit
 (R/'DECISION.md').write_text(decision)
 save('metrics/report_checks.json',{'human_summary_chars_including_markdown':len(human),'limit':200,'fixed_audit_tables_present':all('历史测量值回退' in (R/f).read_text() for f in ['HUMAN_SUMMARY.md','TECHNICAL_REPORT.md','FAILURES.md','DECISION.md']),'final_reference_is_continuously_verified':True,'current_final_metrics_not_historical_backfill':True,'cleanup_candidates':[]})
 print('REPORTS_COMPLETE',len(human),'characters human summary',flush=True)
if __name__=='__main__':main()

from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize,TwoSlopeNorm
import trimesh
plt.rcParams.update({'font.size':9,'figure.dpi':130})
def finish(fig,name):fig.savefig(R/'visualizations'/name,dpi=150,bbox_inches='tight',facecolor='white');plt.close(fig)
def pcloud(ax,pts,color,label=None,alpha=.9):
 if len(pts):p=pts[::max(1,len(pts)//4500)];ax.scatter(*p.T,s=1,color=color,alpha=alpha,label=label)
def ring(ax):
 a=np.linspace(0,2*np.pi,256);ax.plot(5.6*np.cos(a),5.6*np.sin(a),np.zeros(len(a)),c='k',lw=1.2)
 for dr in [-.6,.6]:ax.plot((5.6+dr)*np.cos(a),(5.6+dr)*np.sin(a),np.zeros(len(a)),c='gray',lw=.5)
def layout3d(ax,small=True):
 b=np.array(cfg()['roi_mm']);
 for setfun,bounds in zip([ax.set_xlim,ax.set_ylim,ax.set_zlim],b):setfun(bounds)
 ax.set(xlabel='ring X (mm)',ylabel='ring Y (mm)',zlabel='ring Z (mm)');ax.set_box_aspect([1,1,1]);ax.view_init(elev=25,azim=-65)
def points(tag):
 a=np.load(R/f'predictions/{tag}_verified_reference.npz');y,x=np.nonzero(a['valid']);p=unproject(a['depth_min'][y,x],a['c2w'][8],np.c_[x,y],a['K']);condition='GT' if '_GT_' in tag else tag.split('_')[1];U=np.array(M['camera_audit'][condition]['single_symmetry_rotation_only']);return p@U.T

def main():
 global M
 verify('predictions');verify('evaluation');M=json.loads((R/'metrics/evaluation.json').read_text());c=cfg();g=np.load(R/'evaluation/GT_reference_and_grid.npz');Z=g['GT_depth'];mask=g['target_mask'];GTP=g['GT_surface'];gt=np.load(R/'debug_inputs/GT_camera.npz');GT=gt['c2w'];lab=cv2.imread(str(R/'inputs/labels_008.png'),0);rgb=cv2.imread(str(R/'inputs/rgb_008.png'))[:,:,::-1];ys,xs=np.nonzero((lab==1)|(lab==2));box=(slice(max(ys.min()-20,0),min(ys.max()+21,360)),slice(max(xs.min()-20,0),min(xs.max()+21,640)));cmap=plt.get_cmap('tab10');GTmesh=depth_mesh(Z,mask,GT[8],gt['K'],rgb);GTmesh.export(R/'meshes/GT_reference_visible_evaluation_only.obj')
 fig=plt.figure(figsize=(15,8));gs=fig.add_gridspec(2,3)
 for j,i in enumerate([0,8,14]):
  ax=fig.add_subplot(gs[0,j]);im=cv2.imread(str(R/f'inputs/rgb_{i:03d}.png'))[:,:,::-1];ax.imshow(im);ax.set_title(f'Existing Blender RGB {i:02d}'+(' | reference' if i==8 else ''));ax.axis('off')
 ax=fig.add_subplot(gs[1,0]);col=np.zeros((*lab.shape,3));col[lab==1]=[.9,.5,.35];col[lab==2]=[.2,.6,.95];col[lab==0]=[.75,.75,.75];ax.imshow(col);ax.set_title('Visible polyp / Ring UNKNOWN behind / background');ax.axis('off')
 ax=fig.add_subplot(gs[1,1],projection='3d');pcloud(ax,GTP,'salmon');ring(ax);ax.plot(*GT[:,:3,3].T,'k.-',label='GT')
 for rr,colr in [(0,'royalblue'),(1,'darkorange')]:
  Pcam=np.load(R/f'inputs/pred_camera_{rr}.npz')['c2w'];U=np.array(M['camera_audit'][str(rr)]['single_symmetry_rotation_only']);cc=Pcam[:,:3,3]@U.T;ax.plot(*cc.T,c=colr,label=f'frozen RGB+Ring {rr}')
 ax.scatter(*GT[8,:3,3],c='red',s=35);ax.set(xlabel='X mm',ylabel='Y mm',zlabel='Z mm',title='One global Ring symmetry gauge; no scale fit');ax.legend(fontsize=7)
 ax=fig.add_subplot(gs[1,2]);C=GT[:,:3,3];d=C/np.linalg.norm(C,axis=1,keepdims=True);ang=np.degrees(np.arccos(np.clip(d@d[0],-1,1)));ax.plot(range(16),ang,'o-');ax.scatter(c['heldout_views'],ang[c['heldout_views']],c='red',label='held-out silhouettes');ax.set(xlabel='existing frame',ylabel='angle from first Ring viewing ray (deg)',title='Existing trajectory, no new views');ax.legend()
 finish(fig,'fig1_observations_and_camera_span.png')
 tags=['S0_GT_VH0_strict_complete','S1_GT_VH0','S1_GT_VH1','S1_GT_VH2','S2_0_VH2'];fig=plt.figure(figsize=(15,9));ax=fig.add_subplot(2,3,1,projection='3d');pcloud(ax,GTP,'salmon');ring(ax);layout3d(ax);ax.set_title('GT directly visible surface')
 for j,tag in enumerate(tags):
  ax=fig.add_subplot(2,3,j+2,projection='3d');pcloud(ax,GTP,'silver',alpha=.3);pcloud(ax,points(tag),cmap(j));ring(ax);layout3d(ax);ax.set_title(tag+'\nBOUNDARY CANDIDATE; no per-method alignment',fontsize=9)
 finish(fig,'fig2_visible_surfaces_same_metric_frame.png')
 tags=['S0_GT_VH0_strict_complete','S1_GT_VH0','S1_GT_VH1','S1_GT_VH2'];allz=[Z]+[np.load(R/f'predictions/{t}_verified_reference.npz')['depth_min'] for t in tags];finite=np.concatenate([a[np.isfinite(a)] for a in allz]);dlo,dhi=finite.min(),finite.max();maxe=20.0;maxw=max(float(np.nanmax(np.load(R/f'predictions/{t}_verified_reference.npz')['interval_width'])) for t in tags);fig,aa=plt.subplots(5,3,figsize=(11,15))
 for j in range(5):
  tag='GT' if j==0 else tags[j-1];a=Z if j==0 else allz[j];err=np.where(mask,abs(a-Z),np.nan);width=np.zeros_like(Z) if j==0 else np.load(R/f'predictions/{tag}_verified_reference.npz')['interval_width'];width=np.where(mask,width,np.nan)
  for k,(img,title,cm,norm) in enumerate([(a,'axis Z mm','viridis',Normalize(dlo,dhi)),(err,'absolute error mm','magma',Normalize(0,maxe)),(width,'feasible envelope width mm','plasma',Normalize(0,maxw))]):
   im=aa[j,k].imshow(img[box],cmap=cm,norm=norm);aa[j,k].set_title(tag+' | '+title);aa[j,k].axis('off');fig.colorbar(im,ax=aa[j,k],fraction=.036,pad=.02)
 finish(fig,'fig3_depth_error_and_intervals.png')
 a=np.load(R/'predictions/S1_GT_VH0_volume.npz')['feasible'];b=np.load(R/'predictions/S1_GT_VH1_volume.npz')['feasible'];d=np.load(R/'predictions/S1_GT_VH2_volume.npz')['feasible'];truth=g['GT_solid_voxels'];axgrid=axes();ix=int(np.argmin(abs(axgrid[0])));effect=np.load(R/'evaluation/S1_GT_ring_effect.npz');fig,aa=plt.subplots(2,3,figsize=(14,8));aa[0,0].imshow(rgb[box]);aa[0,0].set_title('Reference8: Ring in front and behind polyp');aa[0,0].axis('off');extent=[axgrid[1][0],axgrid[1][-1],axgrid[2][0],axgrid[2][-1]]
 for axx,occ,title in [(aa[0,1],a,'VH0: red = true polyp wrongly carved'),(aa[0,2],d,'VH2: retained feasible / GT outline')]:
  im=np.ones((*occ[ix].T.shape,3));im[occ[ix].T]=[.7,.8,.9];im[(truth[ix]&~occ[ix]).T]=[.95,.15,.1];axx.imshow(im,origin='lower',extent=extent,aspect='equal');axx.contour(axgrid[1],axgrid[2],truth[ix].T,levels=[.5],colors='k',linewidths=.7);axx.set(xlabel='Ring Y mm',ylabel='Ring Z mm',title=title+'\nx=0 cross section, full ROI')
 change=(b&~d)[ix].T;aa[1,0].imshow(change,origin='lower',extent=extent,cmap='Reds',aspect='equal',vmin=0,vmax=1);aa[1,0].set(title='Ring-only free-space carve: VH1 minus VH2',xlabel='Ring Y mm',ylabel='Ring Z mm')
 for axx,img,title in [(aa[1,1],effect['depth_delta'],'Reference depth change: VH2 - VH1 (mm)'),(aa[1,2],effect['abs_depth_error_delta'],'True absolute error change (mm; blue better)')]:
  vv=float(np.nanmax(abs(img)));vv=max(vv,.001);im=axx.imshow(np.where(mask,img,np.nan)[box],cmap='coolwarm',norm=TwoSlopeNorm(0,-vv,vv));axx.set_title(title);axx.axis('off');fig.colorbar(im,ax=axx,fraction=.04)
 finish(fig,'fig4_occlusion_and_ring_independent_effect.png')
 fig=plt.figure(figsize=(15,8));gs=fig.add_gridspec(2,3)
 for j,(tag,cc) in enumerate([('S1_GT_VH2','teal'),('S2_0_VH2','royalblue'),('S2_1_VH2','darkorange')]):
  ax=fig.add_subplot(gs[0,j],projection='3d');pcloud(ax,GTP,'silver',alpha=.4);pcloud(ax,points(tag),cc);ring(ax);layout3d(ax);ax.set_title(tag+' | same world/Ring metric gauge')
  ax=fig.add_subplot(gs[1,j]);q=np.load(R/f'predictions/{tag}_verified_reference.npz');im=ax.imshow(abs(q['depth_min']-Z)[box],vmin=0,vmax=maxe,cmap='magma');ax.axis('off');ax.set_title(f'{tag}: MAE {M["runs"][tag]["depth_error_mm"]["MAE"]:.3f} mm');fig.colorbar(im,ax=ax,fraction=.035)
 finish(fig,'fig5_camera_sensitivity_nonblank.png')
 row=int(np.median(np.nonzero(mask)[0]));xx=np.arange(640);fig,aa=plt.subplots(1,2,figsize=(13,4));aa[0].imshow(rgb);aa[0].axhline(row,c='yellow');aa[0].set_title('Deterministic row through input visible-mask median');aa[0].axis('off');q=np.load(R/'predictions/S1_GT_VH2_verified_reference.npz');a=q['depth_min'][row];b=q['depth_max'][row];valid=mask[row]&np.isfinite(a);aa[1].fill_between(xx,np.where(valid,a,np.nan),np.where(valid,b,np.nan),color='cornflowerblue',alpha=.4,label='possible depth envelope');aa[1].plot(xx,Z[row],'k',label='GT visible depth');aa[1].plot(xx,a,'b',lw=.8,label='nearest envelope candidate');aa[1].set(xlim=(xs.min()-5,xs.max()+5),xlabel='pixel x',ylabel='axis Z mm',title='Wide interval is uncertainty, not recovered thickness');aa[1].legend();finish(fig,'fig6_reference_ray_ambiguity.png')
 # Native uncertainty/unknown labels need no GT: numeric surface is never automatically trusted.
 manifest=[]
 for tag in M['runs']:
  a=np.load(R/f'predictions/{tag}_verified_reference.npz');uncertain=(~a['valid'])|(a['interval_width']>c['real_gate']['median_interval_width_max_mm'])|a['ROI_clipped'];np.savez_compressed(R/f'meshes/{tag}_uncertainty.npz',valid_numeric=a['valid'],unknown_or_wide=uncertain,ring_occluded_pixels=lab==2,positive_support_view_bits=a['positive_support_view_bits'],label='VISUAL_HULL_BOUNDARY_CANDIDATE',no_hidden_completion=True);manifest.append({'run':tag,'open_mesh':f'meshes/{tag}_verified_open.obj','depth_intervals':f'predictions/{tag}_verified_reference.npz','feasible_space':f'predictions/{tag}_volume.npz','uncertainty':f'meshes/{tag}_uncertainty.npz'})
 save('meshes/scene_manifest.json',{'units':'mm','c2w':'OpenCV +x right +y down +z forward; pixel index centers K=(490,490,319.5,179.5)','ring':'inputs/R10_ring.obj; center origin, XY plane, full torus R5.6 r.6','ring_yaw_unobservable':True,'native_prediction_meshes':'unchanged original candidate Ring gauges; comparison figures use one global Ring yaw/normal flip only','no_closed_mesh_no_volume_measurement':True,'runs':manifest})
 print('VISUALIZATIONS_COMPLETE',flush=True)
if __name__=='__main__':main()

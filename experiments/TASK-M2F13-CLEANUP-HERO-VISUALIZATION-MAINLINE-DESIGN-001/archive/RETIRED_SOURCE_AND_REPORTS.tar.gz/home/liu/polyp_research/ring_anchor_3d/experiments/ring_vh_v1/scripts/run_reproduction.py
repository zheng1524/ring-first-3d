"""Reproduce the corrected frozen protocol only into a NEW sibling experiment.
Never rerun/overwrite the delivered experiment or write to DXY repositories.
"""
from pathlib import Path
import argparse,shutil,subprocess,sys,os,json

def main():
 p=argparse.ArgumentParser();p.add_argument('--new-dir',required=True);a=p.parse_args();original=Path(__file__).resolve().parents[1];target=Path(a.new_dir)
 if not target.is_absolute():target=original.parent/target
 target=target.resolve()
 if target.exists() or target.parent!=original.parent:raise SystemExit('Use a nonexistent sibling directory under ring_anchor_3d/experiments; original outputs cannot be overwritten.')
 target.mkdir();shutil.copytree(original/'scripts',target/'scripts',ignore=shutil.ignore_patterns('__pycache__'));shutil.copyfile(original/'config.json',target/'config.json')
 for d in ['inputs','debug_inputs','predictions','metrics','visualizations','meshes','logs','evaluation']:(target/d).mkdir()
 sys.path.insert(0,str(target/'scripts'));from common import R,freeze,save,stats,np
 assert R==target
 env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
 def run(script,*args,blender=False):
  cmd=([str(Path.home()/'blender/blender-5.0.1-linux-x64/blender'),'-b','--python',str(target/'scripts'/script)] if blender else [sys.executable,str(target/'scripts'/script),*args]);log=target/'logs'/('_'.join([Path(script).stem,*args]).replace('/','_')+'.log')
  print('RUN',cmd,flush=True)
  with log.open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 run('prepare.py')
 for mode,cond in [('S0','GT'),('S1','GT'),('S2','0'),('S2','1')]:run('solve.py',mode,'--condition',cond)
 run('solve.py','S1','--local');freeze('predictions',list((R/'predictions').glob('*'))+list((R/'meshes').glob('*'))+list((R/'metrics').glob('background_*.json'))+list((R/'metrics').glob('ring_gate_*.json'))+[R/'scripts/evaluate.py'])
 run('strict_complete_control.py');freeze('continuous_point_protocol',[R/'scripts/continuous_verify.py',R/'config.json'])
 save('metrics/continuous_repair_reason.json',{'reproduction_uses_corrected_protocol':True,'original_failure_evidence':str(original/'evaluation/attempt02_raw_voxel_surfaces'),'same_continuous_point_rule_for_all_methods':True,'no_GT_tuning':True})
 for scope in ['S0_GT','S1_GT','S2_0','S2_1']:run('continuous_verify.py',scope)
 run('check_blender_geometry.py',blender=True);run('export_native_GT_solid.py',blender=True)
 freeze('evaluation_repair',[R/'scripts/check_blender_geometry.py',R/'scripts/export_native_GT_solid.py',R/'evaluation/Blender_native_geometry_check.json',R/'evaluation/GT_native_solids.npz'])
 freeze('verified_evaluation_protocol',[R/'scripts/evaluate_verified.py',R/'scripts/constraint_activation_verified.py',R/'metrics/freeze_continuous_point_protocol.json']+list((R/'metrics').glob('freeze_verified_S*.json')))
 run('evaluate_verified.py');run('constraint_activation_verified.py')
 aa=np.load(R/'predictions/S2_0_VH2_verified_reference.npz');bb=np.load(R/'predictions/S2_1_VH2_verified_reference.npz');v=aa['valid']&bb['valid'];e=(aa['depth_min']-bb['depth_min'])[v];save('metrics/initialization_sensitivity.json',{'common_valid_pixels':int(v.sum()),'signed_depth_difference_mm':stats(e),'absolute_depth_difference_mm':stats(abs(e)),'reporting_note':'explicit signed and absolute medians'})
 run('visualize.py');run('visualize_all_runs.py');run('verify_delivery.py');run('write_reports.py');run('verify_delivery.py');freeze('final_reports',[R/f for f in ['HUMAN_SUMMARY.md','TECHNICAL_REPORT.md','FAILURES.md','DECISION.md','metrics/report_checks.json','metrics/delivery_checks.json']]);print('REPRODUCTION_COMPLETE',target,flush=True)
if __name__=='__main__':main()

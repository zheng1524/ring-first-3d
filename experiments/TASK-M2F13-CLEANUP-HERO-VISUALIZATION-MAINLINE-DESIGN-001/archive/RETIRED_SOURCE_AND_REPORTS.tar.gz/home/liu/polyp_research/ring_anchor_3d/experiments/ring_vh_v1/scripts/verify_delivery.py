from common import *
import subprocess,csv,trimesh

def main():
 for name in ['protocol','inputs','predictions','strict_S0_protocol','strict_S0_predictions','evaluation_repair','continuous_point_protocol','verified_evaluation_protocol','verified_S0_GT','verified_S1_GT','verified_S2_0','verified_S2_1','evaluation']:verify(name)
 baseline=json.loads((R/'metrics/protection_start.json').read_text());changes=[]
 for p,(size,mt,h) in baseline['threeD_history'].items():
  f=Path(p)
  if not f.exists():changes.append({'path':p,'reason':'missing'});continue
  st=f.stat()
  if st.st_size!=size or st.st_mtime_ns!=mt:changes.append({'path':p,'reason':'metadata_changed','hash_matches_if_checked':sha(f)==h if h else None})
  elif h and sha(f)!=h:changes.append({'path':p,'reason':'content_changed'})
 repos={}
 for name,old in baseline['git'].items():
  p=Path(name);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip();status=subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=p,text=True);changed=[f for f,h in old['hashes_under4MB'].items() if not Path(f).exists() or sha(f)!=h];repos[name]={'HEAD_before':old['HEAD'],'HEAD_after':head,'HEAD_unchanged':old['HEAD']==head,'tracked_status_unchanged':old['status']==status,'tracked_file_hash_changes_under4MB':changed,'unchanged':old['HEAD']==head and old['status']==status and not changed}
 png=[]
 for p in sorted((R/'visualizations').glob('*.png')):
  a=cv2.imread(str(p),cv2.IMREAD_UNCHANGED);assert a is not None,p;rgb=a[:,:,:3];record={'file':str(p.relative_to(R)),'width':a.shape[1],'height':a.shape[0],'std':float(rgb.std()),'nonwhite_fraction':float((rgb.min(2)<245).mean()),'alpha_all_opaque':bool((a[:,:,3]==255).all()) if a.shape[2]==4 else True};record['passed']=a.shape[0]>400 and a.shape[1]>600 and record['std']>10 and record['nonwhite_fraction']>.05 and record['alpha_all_opaque'];assert record['passed'],record;png.append(record)
 meshes=[]
 for p in sorted((R/'meshes').glob('*_verified_open.obj')):
  m=trimesh.load(p,process=False);assert len(m.faces)>0 and np.isfinite(m.vertices).all();meshes.append({'file':str(p.relative_to(R)),'vertices':len(m.vertices),'faces':len(m.faces),'watertight':bool(m.is_watertight),'marked_open_surface':True})
 assert len(meshes)==12
 rows=list(csv.DictReader((R/'metrics/summary.csv').open()));assert len(rows)==12
 vs=[json.loads(p.read_text()) for p in (R/'predictions').glob('*_verified_status.json')];assert len(vs)==12 and all(v['post_check_rule_violations']==0 for v in vs)
 real=json.loads((R/'metrics/real_gate.json').read_text());save('metrics/delivery_checks.json',{'frozen_hashes_verified':True,'protected_history_files':len(baseline['threeD_history']),'historical_check_scope':'size+mtime for all selected 3D files; additional SHA256 for files under4MB; vendor/venv/pycache excluded. Reused input files fully hashed separately.','threeD_history_changes':changes,'threeD_history_passed':not changes,'git':repos,'Dxy_written_by_this_task':False,'Dxy_measurements_recomputed':False,'historical_deleted_or_moved':False,'png':png,'open_meshes':meshes,'all_run_denominator':12,'numeric_runs':len(rows),'independently_accepted_surface_runs':0,'continuous_point_constraint_violations':0,'real_formal_VH_executed':False,'real_gate':real,'cleanup_candidates':[]});assert not changes,'Historical 3D files changed';print('DELIVERY_CHECKS',len(rows),'runs',len(png),'PNGs',len(meshes),'open meshes; protected3D unchanged',flush=True)
if __name__=='__main__':main()

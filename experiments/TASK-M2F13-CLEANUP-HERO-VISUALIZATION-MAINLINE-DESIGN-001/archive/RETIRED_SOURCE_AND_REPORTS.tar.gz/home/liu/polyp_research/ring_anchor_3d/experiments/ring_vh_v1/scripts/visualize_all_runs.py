from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize

def main():
 verify('evaluation');m=json.loads((R/'metrics/evaluation.json').read_text());g=np.load(R/'evaluation/GT_reference_and_grid.npz');mask=g['target_mask'];z=g['GT_depth'];lab=cv2.imread(str(R/'inputs/labels_008.png'),0);yy,xx=np.nonzero((lab==1)|(lab==2));box=(slice(max(0,yy.min()-8),min(360,yy.max()+9)),slice(max(0,xx.min()-8),min(640,xx.max()+9)));fig,axes=plt.subplots(3,4,figsize=(15,12),layout='constrained');norm=Normalize(0,20)
 for ax,(tag,v) in zip(axes.ravel(),m['runs'].items()):
  a=np.load(R/f'predictions/{tag}_verified_reference.npz');err=np.where(mask,abs(a['depth_min']-z),np.nan);im=ax.imshow(err[box],norm=norm,cmap='magma');invalid=mask&~a['valid'];overlay=np.zeros((*mask.shape,4));overlay[invalid]=[0,1,1,1];ax.imshow(overlay[box]);ax.set_title(f'{tag}\nMAE {v["depth_error_mm"]["MAE"]:.3f}mm | numeric {100*v["coverage"]:.2f}%',fontsize=9);ax.axis('off')
 fig.colorbar(im,ax=axes.ravel().tolist(),label='absolute axis-Z error (mm), same scale for all runs',shrink=.8,pad=.02);fig.suptitle('All 12 configurations retained | cyan = missing | NOT verified true surfaces',fontsize=14);fig.savefig(R/'visualizations/fig7_all_runs_failures.png',dpi=150,facecolor='white');plt.close(fig);save('metrics/error_visualization_scale.json',{'absolute_error_mm_range':[0,20],'same_scale_figures':[3,5,7],'missing_in_fig7':'cyan','outside_target':'white','all12_configurations_included':True})
if __name__=='__main__':main()

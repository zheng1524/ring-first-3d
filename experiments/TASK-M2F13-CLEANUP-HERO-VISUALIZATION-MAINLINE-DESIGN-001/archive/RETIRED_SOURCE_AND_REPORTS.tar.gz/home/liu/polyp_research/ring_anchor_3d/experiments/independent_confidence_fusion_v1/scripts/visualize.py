from icf_common import *
from export_scenes import getmesh,COL
import open3d as o3d
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import importlib.util

def done(fig,name):
 fig.tight_layout(rect=[0,.02,1,.94]);fig.savefig(R/f'visualizations/{name}.png',dpi=175,facecolor='white',transparent=False);plt.close(fig)
def renderer():
 src=next(E.glob('ring_first_v9*/scripts/visualize_v9.py'));node=next(n for n in ast.parse(src.read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='render');ns=dict(np=np,o3d=o3d);exec(compile(ast.Module(body=[node],type_ignores=[]),str(src),'exec'),ns);return ns['render']
def original(video,obj):
 sc=trimesh.load(V13/f'scenes/{video}_LOCAL_UNREGISTERED.glb',force='scene',process=False);parts=[]
 for node in sc.graph.nodes_geometry:
  if 'Ring'in node or(('Background'in node)!=(obj=='Background')):continue
  T,key=sc.graph[node];m=sc.geometry[key].copy();m.apply_transform(T);m.vertices*=1000;parts.append(m)
 return trimesh.util.concatenate(parts)
def parts(video,method,H=np.eye(4)):
 ring=trimesh.load(F2/'inputs/R10_ring.obj',process=False);out=[]
 for obj in ['Polyp','Background']:
  if method=='HISTORICAL':m=original(video,obj)
  else:m=getmesh(video,obj,method)
  m.apply_transform(H);out.append((m,COL[video]if obj=='Polyp'else COL['Background']))
 ring.apply_transform(H);out.append((ring,COL['Ring']));return out
def main():
 render=renderer();refs=cases();ds=load(R/'inputs/datasets.json');ring=trimesh.load(F2/'inputs/R10_ring.obj',process=False);angles=[(-90,88),(-90,0),(0,0),(-65,22)];names=['top','front','side','oblique'];center=[0,3,-6];radius=24
 fig=plt.figure(figsize=(20,10))
 for row,video in enumerate(cfg()['videos']):
  cc=[c for c in refs if c['video']==video]
  for j,c in enumerate(cc):
   ax=fig.add_subplot(2,4,row*4+j+1);ax.imshow(image(c));l=labels(c);ax.contour(l==1,[.5],colors=['cyan'],linewidths=.7);ax.contour(l==2,[.5],colors=['yellow'],linewidths=.7);ax.set_title(c['frame']['id']+(' | NEW HERO'if not c['reused']else' | reused HERO'));ax.axis('off')
  ax=fig.add_subplot(2,4,row*4+4,projection='3d');cam=np.load(ds[video]['camera_files'][0])['c2w'];C=cam[:,:3,3];ax.plot(*C.T,color=COL[video],lw=1);ax.scatter(*C[[c['index']for c in cc]].T,s=60,c=['purple','deepskyblue','darkorange']);q=ring.vertices[::40];ax.scatter(*q.T,s=1,c='k');ax.set(xlabel='x mm',ylabel='y mm',zlabel='z mm',title=video+' frozen candidate0\nlocal yaw gauges remain separate');ax.set_box_aspect((1,1,1))
 fig.suptitle('Fig1 Actual real DEV inputs / cyan Polyp, yellow Ring | new surface fusion; no pose optimization');done(fig,'Fig1_inputs_and_camera_views')
 fig,ax=plt.subplots(2,3,figsize=(17,9));polyz=np.concatenate([data(c)['depth_mm'][data(c)['labels']==1]for c in refs]);lo,hi=np.percentile(polyz,[1,99])
 for a,c in zip(ax.ravel(),refs):
  p=data(c);roi=(p['labels']==1)|(p['labels']==2);im=a.imshow(np.where(roi,p['depth_mm'],np.nan),cmap='turbo',vmin=lo,vmax=hi);a.set_title(c['tag']+(' NEW'if not c['reused']else' reused')+' | axialZ mm');a.axis('off')
 fig.colorbar(im,ax=ax.ravel().tolist(),shrink=.6,label='camera axial depth / mm (not GT)');fig.suptitle('Fig2 HERO depth at six reference views | shared color limits; continuous prediction does not imply validation');fig.subplots_adjust(right=.86);fig.savefig(R/'visualizations/Fig2_HERO_multireference_depths.png',dpi=175,facecolor='white');plt.close(fig)
 for figno,video in [(3,'004'),(4,'005')]:
  fig,ax=plt.subplots(4,4,figsize=(17,16))
  for row,method in enumerate(['HISTORICAL','B','C','D']):
   pp=parts(video,method)
   for j,angle in enumerate(angles):ax[row,j].imshow(render(pp,center,radius,angle,n=500));ax[row,j].axis('off');ax[row,j].set_title(f'{video} {method} {names[j]}\n'+('FUSED / NONMANIFOLD'if method=='C'else'RAW TSDF interpolated / open mask'if method=='D'else'Original layers / MODEL_PREDICTED'),fontsize=9)
  fig.suptitle(f'Fig{figno} {video} independent before/after | same48mm display width / same camera angles\nKnownRing black; Polyp blue004/orange005; Background green; no hidden-surface completion');done(fig,f'Fig{figno}_{video}_independent_before_after')
 fig,ax=plt.subplots(2,3,figsize=(18,10));palette=np.array([[.8,.8,.8],[.82,.64,.25],[.15,.70,.52],[.86,.20,.24],[.69,.24,.70]])
 for row,video in enumerate(cfg()['videos']):
  p=np.load(R/f'provenance/{video}_Polyp_fusion.npz');cc=[c for c in refs if c['video']==video]
  for j,c in enumerate(cc):
   a=ax[row,j];out=image(c).astype(float)/255;sel=p['source_view']==j;uv=p['source_uv'][sel];out[uv[:,1],uv[:,0]]=palette[p['status'][sel]];a.imshow(out);a.set_title(c['tag']+' all numeric points retained');a.axis('off')
 fig.suptitle('Fig5 Model consistency at same fixed poses | amber predicted-only, green model-consistent, red front-conflict, purple mixed\nBehind-surface/Ring occlusion remains unknown; these colors are NOT GT confidence');done(fig,'Fig5_consistency_and_conflict')
 topology=load(R/'metrics/topology.json');ray=load(R/'metrics/ray_evaluation.json');coverage=load(R/'metrics/surface_model_coverage.json');methods=['A_single','HISTORICAL','B_combined','C_fused','D_TSDF'];fig,ax=plt.subplots(2,4,figsize=(20,10))
 for row,video in enumerate(cfg()['videos']):
  T={x['method']:x for x in topology if x['video']==video and x['object']=='Polyp'}
  for j,(key,title)in enumerate([('largest_component_fraction','largest connected area fraction'),('nonmanifold_edges','nonmanifold edges')]):ax[row,j].bar(methods,[T[m][key]for m in methods]);ax[row,j].set_title(video+' '+title);ax[row,j].tick_params(axis='x',rotation=45)
  for j,thin in [(2,False),(3,True)]:
   vals=[]
   for method in methods:
    rr=[x for x in ray if x['video']==video and x['method']==method and x['object']=='Polyp'];den=sum(x['thin_proxy_denominator']if thin else x['target_mask_pixels']for x in rr);num=sum((x['thin_proxy_ray_fraction']*x['thin_proxy_denominator'])if thin else x['ray_hits']for x in rr);vals.append(num/max(den,1))
   ax[row,j].bar(methods,vals);ax[row,j].set(ylim=(0,1),title=video+(' thin-boundary proxy ray coverage'if thin else' all original mask rays coverage'));ax[row,j].tick_params(axis='x',rotation=45)
 fig.suptitle('Fig6 Coverage, continuity and topology | same original model-mask denominators\nHigher largest-component fraction cannot excuse missing thin structures or nonmanifold connections');done(fig,'Fig6_fusion_comparison')
 fig,ax=plt.subplots(2,4,figsize=(19,10))
 for row,cand in enumerate(load(R/'inputs/H_frozen.json')):
  pp=parts('004','C')+parts('005','C',np.array(cand['H']))
  for j,angle in enumerate(angles):ax[row,j].imshow(render(pp,center,radius,angle,n=600));ax[row,j].axis('off');ax[row,j].set_title(cand['tag']+' '+names[j]+'\nUNVERIFIED / separate video layers',fontsize=9)
 fig.suptitle('Fig7 New independent fused surfaces under frozen cross-video hypotheses | blue004 orange005\nOne rigid H applied to all005 geometry and cameras; no cross-video welding, ICP or registration');done(fig,'Fig7_cross_video_layers')
 fig,ax=plt.subplots(2,4,figsize=(18,10))
 for row,video in enumerate(cfg()['videos']):
  pp=parts(video,'C');pp=[pp[0],pp[2]]
  for col,(angle,ctr,rad,title)in enumerate([(angles[0],[0,0,-2],12,'top vicinity'),(angles[2],[0,0,-4],12,'side/neck vicinity'),(angles[3],[0,0,-9],12,'lower/stalk-like visible region')]):ax[row,col].imshow(render(pp,ctr,rad,angle,n=600));ax[row,col].axis('off');ax[row,col].set_title(video+' '+title+'\nview crop only; no geometry removed',fontsize=9)
  cc=[c for c in refs if c['video']==video];c=cc[0]if video=='004'else cc[-1];p=np.load(R/f'provenance/{video}_Polyp_fusion.npz');sel=p['source_view']==(0 if video=='004'else 2);uv=p['source_uv'][sel];m=np.zeros((360,640),np.uint8);m[uv[:,1],uv[:,0]]=p['status'][sel];ax[row,3].imshow(image(c));ax[row,3].imshow(np.ma.masked_where(m==0,m),cmap=ListedColormap(palette),vmin=0,vmax=4,alpha=.8);ax[row,3].axis('off');ax[row,3].set_title(c['tag']+' observed complementary candidate\ngreen=model consistency, NOT true new area',fontsize=9)
 fig.suptitle('Fig8 Top, side and lower visible structures | Ring plane is a coordinate reference, not a tissue base\nNo anatomical GT labels; depth disagreement may masquerade as complementary geometry');done(fig,'Fig8_complementary_visible_regions')
 fig,ax=plt.subplots(2,2,figsize=(12,12));ppcases=[('004 C local',parts('004','C')),('005 C local',parts('005','C'))]+[(c['tag']+' UNVERIFIED',parts('004','C')+parts('005','C',np.array(c['H'])))for c in load(R/'inputs/H_frozen.json')]
 for a,(title,pp)in zip(ax.ravel(),ppcases):a.imshow(render(pp,center,radius,angles[3],n=700));a.axis('off');a.set_title(title+'\ninteractive full geometry in scenes/*.glb')
 fig.suptitle('Fig9 Interactive-GLB previews | all full-resolution layers exported, not a closed reconstructed object');done(fig,'Fig9_interactive_GLB_previews')
 checks=[]
 for p in sorted((R/'visualizations').glob('*.png')):
  im=cv2.imread(str(p),cv2.IMREAD_UNCHANGED);assert im.std()>5 and (im.shape[2]!=4 or np.all(im[:,:,3]==255));checks.append(dict(file=p.name,width=im.shape[1],height=im.shape[0],opaque=True,nonblank_std=float(im.std()),SHA256=sha(p)))
 save('metrics/visualization_QC.json',checks);freeze('visualizations',[Path(__file__)]+list((R/'visualizations').glob('*.png'))+[R/'metrics/visualization_QC.json']);verify();print('VISUALIZATIONS',len(checks),'nonblank opaque PNGs',flush=True)
if __name__=='__main__':main()

from icf_common import *
import open3d as o3d
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

def topology(m):
 nf=len(m.faces)
 if not nf:return dict(vertices=len(m.vertices),faces=0,area_mm2=0,components=0,largest_component_fraction=None,boundary_edges=0,boundary_length_mm=0)
 edges=m.edges_unique_inverse;order=np.argsort(edges,kind='stable');same=np.diff(edges[order])==0;fa=m.edges_face[order];a=fa[:-1][same];b=fa[1:][same];graph=coo_matrix((np.ones(len(a)*2),(np.r_[a,b],np.r_[b,a])),shape=(nf,nf)).tocsr();nc,cl=connected_components(graph,directed=False);area=np.bincount(cl,weights=m.area_faces);edgecount=np.bincount(edges);edge=m.edges_unique[edgecount==1];length=np.linalg.norm(m.vertices[edge[:,0]]-m.vertices[edge[:,1]],axis=1)
 return dict(vertices=len(m.vertices),referenced_vertices=len(np.unique(m.faces)),faces=nf,area_mm2=float(m.area),components=int(nc),largest_component_area_mm2=float(area.max()),largest_component_fraction=float(area.max()/max(m.area,1e-12)),components_ge1mm2=int((area>=1).sum()),boundary_edges=len(edge),boundary_length_mm=float(length.sum()),nonmanifold_edges=int((edgecount>2).sum()),component_definition='all edge incidences connected, including nonmanifold edges; no mesh modification',is_watertight=bool(m.is_watertight),area_is_sum_not_unique_coverage=True)
def historical(video,obj):
 sc=trimesh.load(V13/f'scenes/{video}_LOCAL_UNREGISTERED.glb',force='scene',process=False);parts=[]
 for node in sc.graph.nodes_geometry:
  if ('Ring'in node)or(('Background'in node)!=(obj=='Background')):continue
  T,name=sc.graph[node];m=sc.geometry[name].copy();m.apply_transform(T);m.vertices*=1000;parts.append(m)
 return trimesh.util.concatenate(parts)
def meshes(video,obj):
 refs=[c for c in cases()if c['video']==video];central=next(c for c in refs if c['index']==(8 if video=='004'else 10));paths=dict(A_single=R/f"meshes/{central['tag']}_{obj}_A.ply",B_combined=R/f'meshes/{video}_{obj}_B_raw_multiref.ply',C_fused=R/f'meshes/{video}_{obj}_C_confidence_fused.ply',D_TSDF=R/f'meshes/{video}_{obj}_D_TSDF_open.ply');out={k:trimesh.load(p,process=False)for k,p in paths.items()if p.exists()};out['HISTORICAL']=historical(video,obj);return out
def distances(scene,P):return scene.compute_distance(o3d.core.Tensor(np.asarray(P,np.float32))).numpy()
def valid_uv(p,obj):
 mask=object_mask(p,obj);y,x=np.nonzero(mask);uv=np.c_[x,y];return mask,uv
def head_thin_masks(p):
 mask=p['labels']==1;n,cc,st,_=cv2.connectedComponentsWithStats(mask.astype(np.uint8));head=cc==(1+np.argmax(st[1:,cv2.CC_STAT_AREA]));dt=cv2.distanceTransform(mask.astype(np.uint8),cv2.DIST_L2,3);ring_near=cv2.dilate((p['labels']==2).astype(np.uint8),np.ones((9,9),np.uint8))>0;thin=mask&(dt<=3)&~ring_near;return head,thin

def feature_queries(video):
 datasets=load(R/'inputs/datasets.json');ds=datasets[video];cam=np.load(ds['camera_files'][0]);refs=[c for c in cases()if c['video']==video]
 if video=='004':
  t=np.load(F1/'inputs/real_tracks.npz');hold=~t['train_track']&t['holdout_eligible'];targetindices=[10,15]
 else:
  t=np.load(V6/'observations/tracks005.npz');hold=t['held'];targetindices=[11,20,21]
 queries=[]
 for c in refs:
  p=data(c);i=c['index']
  for h in targetindices:
   ids=np.flatnonzero(hold&np.isfinite(t['xy'][:,i,0])&np.isfinite(t['xy'][:,h,0]))
   for tid in ids:
    uv=t['xy'][tid,i];x,y=np.rint(uv).astype(int);cat=int(t['category'][tid]);obj='Polyp'if cat==1 else'Background'
    if not(0<=x<640 and 0<=y<360)or cat not in[0,1]or not object_mask(p,obj)[y,x]:continue
    queries.append(dict(id=f'{video}_{c["tag"]}_t{tid}_h{h}',family='legacy_held_tracks',video=video,reference=c['tag'],ref_index=i,target_index=h,target_id=ds['ledger'][h]['id'],track_id='LEGACY_'+str(tid),object=obj,source_uv=uv,target_uv=t['xy'][tid,h],target_pose=cam['c2w'][h],source_pose=p['pose']))
 # Read-only additional diagnostic family, not used to fit/choose any fused prediction.
 ct=np.load(V13/f'predictions/CoTracker3_{video}_quality_0.npz');ids=list(ct['key_ids']);lookup={v['id']:i for i,v in enumerate(ds['ledger'])}
 for c in refs:
  if c['frame']['id']not in ids:continue
  a=ids.index(c['frame']['id']);p=data(c)
  for target in ids:
   h=lookup[target]
   if h not in targetindices:continue
   b=ids.index(target);valid=ct['valid'][:,a]&ct['valid'][:,b]
   for tid in np.flatnonzero(valid):
    uv=ct['xy'][tid,a];x,y=np.rint(uv).astype(int);obj='Polyp'if ct['category'][tid]==1 else'Background'
    if not(0<=x<640 and 0<=y<360)or not object_mask(p,obj)[y,x]:continue
    queries.append(dict(id=f'{video}_{c["tag"]}_CT{tid}_h{h}',family='CoTracker3_diagnostic',video=video,reference=c['tag'],ref_index=c['index'],target_index=h,target_id=target,track_id='CT_'+str(tid),object=obj,source_uv=uv,target_uv=ct['xy'][tid,b],target_pose=cam['c2w'][h],source_pose=p['pose']))
 return queries

def main():
 freeze('evaluation_protocol',[Path(__file__),R/'config.json',R/'PROTOCOL.md',R/'reproducibility/C_fusion_predictions.json',R/'reproducibility/D_TSDF_predictions.json']);rows=[];top=[];queryrows=[];all_queries=[];pairwise=[];ringrows=[];area=[]
 for video in cfg()['videos']:
  refs=[c for c in cases()if c['video']==video];packs=[data(c)for c in refs];queries=feature_queries(video);all_queries+=queries
  for obj in ['Polyp','Background']:
   mm=meshes(video,obj);scenes={method:old.o3scene(m)for method,m in mm.items()};prov=np.load(R/f'provenance/{video}_{obj}_fusion.npz');rawP=prov['source_points_mm'];source=prov['source_view'];status=prov['status'];bits=prov['support_views']
   for method,m in mm.items():
    top.append(dict(video=video,object=obj,method=method,**topology(m)));dist=distances(scenes[method],rawP);area.append(dict(video=video,object=obj,method=method,raw_point_denominator=len(rawP),model_relative_surface_distance_mm=stats(dist),within025_model_fraction=float((dist<=.25).mean()),GT_accuracy='UNKNOWN',not_real_unique_coverage=True))
    for j,(c,p)in enumerate(zip(refs,packs)):
     mask,uv=valid_uv(p,obj);u=uv+np.array(cfg()['evaluation_ray_pixel_offset']);z=old.cast(scenes[method],p['pose'],K,u);zmap=np.full(mask.shape,np.nan);zmap[uv[:,1],uv[:,0]]=z;own=p['depth_mm'][mask];error=z-own;hit=np.isfinite(z);rec=dict(video=video,object=obj,method=method,reference=c['tag'],target_mask_pixels=len(uv),ray_hits=int(hit.sum()),ray_hit_fraction=float(hit.mean()),depth_disagreement_to_own_frozen_MODEL_mm=stats(error),not_GT_depth_error=True,GT_depth_MAE=None)
     if obj=='Polyp':
      head,thin=head_thin_masks(p);rec.update(head_proxy_denominator=int(head.sum()),head_proxy_ray_fraction=float(np.isfinite(zmap[head]).mean()),thin_proxy_denominator=int(thin.sum()),thin_proxy_ray_fraction=float(np.isfinite(zmap[thin]).mean())if thin.any()else None,proxy_NOT_anatomical_truth=True)
     rows.append(rec);np.savez_compressed(R/f"metrics/{video}_{obj}_{method}_{c['tag']}_rays.npz",depth_mm=zmap,mask=mask,residual_to_model_mm=np.where(mask,zmap-p['depth_mm'],np.nan),GT_available=False)
    qq=[q for q in queries if q['object']==obj]
    for c,p in zip(refs,packs):
     qs=[q for q in qq if q['reference']==c['tag']]
     if not qs:continue
     uv=np.array([q['source_uv']for q in qs]);z=old.cast(scenes[method],p['pose'],K,uv+np.array(cfg()['evaluation_ray_pixel_offset']));P=unproject(z,p['pose'],uv+np.array(cfg()['evaluation_ray_pixel_offset']),K)
     for q,point,zz in zip(qs,P,z):
      er=None;ang=None;positive=False
      if np.isfinite(zz)and zz>0:
       pred,zt=project(point[None],np.array(q['target_pose']),K);er=float(np.linalg.norm(pred[0]-q['target_uv']));positive=bool(zt[0]>0);a=unit(point-p['pose'][:3,3]);b=unit(point-np.array(q['target_pose'])[:3,3]);ang=float(np.degrees(np.arccos(np.clip(a@b,-1,1))))
      queryrows.append(dict(video=video,method=method,object=obj,query_id=q['id'],family=q['family'],reference=q['reference'],target=q['target_id'],track_id=q['track_id'],error_px=er,positive=positive,parallax_deg=ang,supported=bool(er is not None and er<=cfg()['support_feature_px']and positive and ang>=cfg()['support_angle_deg']),point_mm=point if np.isfinite(zz)else None,status='SPARSE_FEATURE_SUPPORTED_POSE_CONDITIONAL'if er is not None and er<=cfg()['support_feature_px']and positive and ang>=cfg()['support_angle_deg']else 'UNVERIFIED'))
   # View-level additions and repeated geometry are diagnostic against historical surface, not GT coverage.
   hist=scenes['HISTORICAL'];histd=distances(hist,rawP)
   for j,c in enumerate(refs):
    ix=source==j;potential=histd[ix]>.3;area.append(dict(video=video,object=obj,method='NEW_REFERENCE_DIAGNOSTIC',reference=c['tag'],point_denominator=int(ix.sum()),farther_than03mm_from_historical=int(potential.sum()),farther_and_model_consistent=int((potential&(status[ix]==2)).sum()),true_new_observed_area_mm2=None,reason='distance may be depth bias, not newly visible surface'))
  # Direct all-source depth disagreement before fusion, including possible occlusion.
  for i,c in enumerate(refs):
   prov=np.load(R/f'provenance/{video}_Polyp_fusion.npz');ix=prov['source_view']==i
   for j,b in enumerate(refs):
    if i==j:continue
    e=prov['residuals_mm'][ix,j];finite=np.isfinite(e);pairwise.append(dict(video=video,source=c['tag'],target=b['tag'],source_points=int(ix.sum()),projected_same_object=int(finite.sum()),signed_depth_difference_mm=stats(e),agreement_le03mm=int((abs(e)<=.3).sum()),in_front_potential_conflict=int((e<-.3).sum()),behind_occlusion_or_depth_conflict=int((e>.3).sum()),true_consistency_without_GT='UNKNOWN'))
   p=packs[i];ring=np.load(R/f"depths/{c['tag']}_KnownRing_ray_depth.npz")['depth_mm'];mask=p['labels']==2;ok=mask&np.isfinite(ring);ringrows.append(dict(video=video,reference=c['tag'],visible_Ring_mask_pixels=int(mask.sum()),CAD_ray_hits_on_visible_Ring=int(ok.sum()),conditional_CAD_vs_MVS_depth_mm=stats(p['depth_mm'][ok]-ring[ok]),absolute_real_Ring_accuracy='UNKNOWN',Ring_pose_changed=False))
 summaries=[];paired=[];byfamily=[]
 for video in cfg()['videos']:
  for obj in ['Polyp','Background']:
   group=[q for q in queryrows if q['video']==video and q['object']==obj];methods=sorted(set(q['method']for q in group))
   for method in methods:
    q=[x for x in group if x['method']==method];summaries.append(dict(video=video,object=obj,method=method,query_denominator=len(q),finite=sum(x['error_px']is not None for x in q),NaN=sum(x['error_px']is None for x in q),errors_px=stats([np.nan if x['error_px']is None else x['error_px']for x in q]),supported_queries=sum(x['supported']for x in q),unique_supported_tracks=len(set(x['track_id']for x in q if x['supported'])),not_fresh_blind=True,shared_candidate_camera=True))
    for family in sorted(set(x['family']for x in q)):
     z=[x for x in q if x['family']==family];byfamily.append(dict(video=video,object=obj,method=method,family=family,query_denominator=len(z),finite=sum(x['error_px']is not None for x in z),errors_px=stats([np.nan if x['error_px']is None else x['error_px']for x in z]),supported_queries=sum(x['supported']for x in z),physical_identity_overlap_between_families='UNKNOWN_NOT_ADDITIVE_INDEPENDENT_TRACKS'))
   maps={method:{q['query_id']:q for q in group if q['method']==method}for method in methods};keys=sorted(set.intersection(*(set(z)for z in maps.values())));common=[k for k in keys if all(m[k]['error_px']is not None for m in maps.values())]
   paired.append(dict(video=video,object=obj,full_query_denominator=len(keys),common_finite_queries=len(common),metrics={method:stats([m[k]['error_px']for k in common])for method,m in maps.items()},B_to_C_new_support=sum(maps['C_fused'][k]['error_px']is not None and maps['B_combined'][k]['error_px']is None for k in keys),B_to_C_lost_support=sum(maps['C_fused'][k]['error_px']is None and maps['B_combined'][k]['error_px']is not None for k in keys),B_to_D_lost_support=sum(maps['D_TSDF'][k]['error_px']is None and maps['B_combined'][k]['error_px']is not None for k in keys)))
 for name,x in [('topology',top),('ray_evaluation',rows),('surface_model_coverage',area),('raw_multiview_consistency',pairwise),('Ring_depth_diagnostic',ringrows),('feature_evaluation',summaries),('feature_by_family',byfamily),('paired_feature_evaluation',paired),('queries_full',queryrows),('query_registry',all_queries)]:save('metrics/'+name+'.json',x)
 csvwrite('metrics/topology.csv',top);csvwrite('metrics/feature_queries.csv',queryrows);freeze('evaluation_outputs',[Path(__file__)]+list((R/'metrics').glob('*.json'))+[R/'metrics/topology.csv',R/'metrics/feature_queries.csv']);verify();print('EVALUATION_COMPLETE',len(rows),len(queryrows),'query records',flush=True)
if __name__=='__main__':main()

from icf_common import *
import time

def diagnose(P,source,views,packs,obj,ring_depth):
 n=len(P);nv=len(views);res=np.full((n,nv),np.nan);observed=np.zeros((n,nv),bool);agree=np.zeros((n,nv),bool);front=np.zeros((n,nv),bool);behind=np.zeros((n,nv),bool);ring_conflict=np.zeros((n,nv),bool);ring_occ=np.zeros((n,nv),bool)
 tau=cfg()['consistency_mm']
 for j,p in enumerate(packs):
  uv,z=project(P,p['pose'],K);xy=np.rint(uv).astype(int);inside=(xy[:,0]>=0)&(xy[:,0]<640)&(xy[:,1]>=0)&(xy[:,1]<360)&(z>0);ids=np.flatnonzero(inside);x,y=xy[ids].T;mask=object_mask(p,obj);good=mask[y,x]&np.isfinite(p['depth_mm'][y,x])&(p['depth_mm'][y,x]>0);ids=ids[good];x,y=xy[ids].T;res[ids,j]=z[ids]-p['depth_mm'][y,x];observed[ids,j]=True;agree[ids,j]=abs(res[ids,j])<=tau;front[ids,j]=res[ids,j]<-tau;behind[ids,j]=res[ids,j]>tau
  if obj=='Polyp':
   ids=np.flatnonzero(inside);x,y=xy[ids].T;isring=(p['labels'][y,x]==2)&np.isfinite(ring_depth[j][y,x]);ids=ids[isring];x,y=xy[ids].T;rd=z[ids]-ring_depth[j][y,x];ring_conflict[ids,j]=rd<-tau;ring_occ[ids,j]=rd>tau
 # Own prediction is not independent support. Own floating error cannot create a conflict.
 for j in range(nv):
  sel=source==j;agree[sel,j]=True;front[sel,j]=False;behind[sel,j]=False;res[sel,j]=0
 support=agree.sum(1);cf=front.sum(1)+ring_conflict.sum(1);oc=behind.sum(1)+ring_occ.sum(1);status=np.ones(n,np.uint8);status[(support>=2)&(cf==0)]=2;status[(support==1)&(cf>0)]=3;status[(support>=2)&(cf>0)]=4
 return dict(residuals_mm=res,projected_same_object=observed,agreement=agree,support_views=support,front_conflicts=front,behind_or_depth_conflict=behind,Ring_front_conflicts=ring_conflict,Ring_occluded_unknown=ring_occ,status=status,occlusion_count=oc)

def merge_supported(P,N,rgb,source,uv,protected,diag,voxel=None):
 """No deletion: merge only geometrically supported interior samples, preserve all others."""
 voxel=cfg()['fusion_voxel_mm']if voxel is None else voxel;eligible=(diag['support_views']>=2)&np.isin(diag['status'],[2])&~protected&(np.linalg.norm(N,axis=1)>.9);eligible_ids=np.flatnonzero(eligible);mapping=np.arange(len(P));members=[]
 if len(eligible_ids):
  cell=np.floor(P[eligible_ids]/voxel).astype(np.int64);_,inv=np.unique(cell,axis=0,return_inverse=True);order=np.argsort(inv,kind='stable');splits=np.split(eligible_ids[order],np.flatnonzero(np.diff(inv[order]))+1)
  for ids in splits:
   ss=np.unique(source[ids])
   if len(ss)<2:continue
   if np.min(N[ids]@N[ids].T)<np.cos(np.deg2rad(cfg()['normal_angle_deg'])):continue
   root=ids[0];mapping[ids]=root;members.append(ids)
 roots,inverse=np.unique(mapping,return_inverse=True);Q=P[roots].copy();color=rgb[roots].astype(float);unc=np.zeros(len(roots));bits=np.left_shift(np.uint32(1),source[roots].astype(np.uint32));positions={int(root):i for i,root in enumerate(roots)}
 for ids in members:
  out=positions[int(ids[0])];per=[];col=[]
  for view in np.unique(source[ids]):
   sub=ids[source[ids]==view];other=np.abs(diag['residuals_mm'][sub]);count=np.isfinite(other).sum(1);err=np.nansum(other,axis=1)/np.maximum(count,1);w=1/(1+err/cfg()['consistency_mm']);per.append(np.average(P[sub],axis=0,weights=w));col.append(np.average(rgb[sub],axis=0,weights=w))
  Q[out]=np.mean(per,axis=0);color[out]=np.mean(col,axis=0);unc[out]=np.max(np.linalg.norm(P[ids]-Q[out],axis=1));bits[out]=np.bitwise_or.reduce(np.left_shift(np.uint32(1),source[ids].astype(np.uint32)))
 return Q,np.clip(color,0,255).astype(np.uint8),inverse,dict(eligible=eligible,merged_clusters=len(members),merged_input_points=sum(len(x)for x in members),source_bits=bits,max_source_displacement_mm=unc)

def remap_faces(faces,mapping,source_bits):
 remapped=mapping[faces];ok=(remapped[:,0]!=remapped[:,1])&(remapped[:,1]!=remapped[:,2])&(remapped[:,0]!=remapped[:,2]);ids=np.flatnonzero(ok);canon=np.sort(remapped[ok],axis=1);_,first,inv=np.unique(canon,axis=0,return_index=True,return_inverse=True);out=remapped[ok][first];bits=np.zeros(len(out),np.uint32);np.bitwise_or.at(bits,inv,source_bits[ok]);original_to_output=np.full(len(faces),-1);original_to_output[ids]=inv;return out,bits,original_to_output

def main():
 freeze('fusion_protocol',[R/'PROTOCOL.md',R/'config.json']+list((R/'scripts').glob('*.py'))+[R/'reproducibility/depth_and_raw_mesh.json']);runs=[]
 ring=trimesh.load(F2/'inputs/R10_ring.obj',process=False);ring_sc=old.o3scene(ring)
 for video in cfg()['videos']:
  refs=[c for c in cases()if c['video']==video and (R/f"depths/{c['tag']}.npz").exists()];packs=[data(c)for c in refs];rd=[]
  for c,p in zip(refs,packs):
   yy,xx=np.mgrid[:360,:640];z=old.cast(ring_sc,p['pose'],K,np.c_[xx.ravel(),yy.ravel()]).reshape(360,640);rd.append(z);np.savez_compressed(R/f"depths/{c['tag']}_KnownRing_ray_depth.npz",depth_mm=z,visible_Ring_mask=p['labels']==2,unit='mm',status='PHYSICAL_PRIOR_POSE_CONDITIONAL')
  for obj in ['Polyp','Background']:
   st=time.monotonic();points=[];norm=[];color=[];view=[];uvs=[];protect=[];faces=[];face_view=[];offset=0
   for j,c in enumerate(refs):
    p=packs[j];src=np.load(R/f"points/{c['tag']}_{obj}_source.npz");m=trimesh.load(R/f"meshes/{c['tag']}_{obj}_A.ply",process=False);P=src['points_mm'];assert len(P)==len(m.vertices);mask=object_mask(p,obj);dt=cv2.distanceTransform(mask.astype(np.uint8),cv2.DIST_L2,3);uv=src['uv'];protected=dt[uv[:,1],uv[:,0]]<=cfg()['boundary_protection_px'];points.append(P);norm.append(unit(np.array(m.vertex_normals)));color.append(src['rgb']);view.append(np.full(len(P),j));uvs.append(uv);protect.append(protected);faces.append(src['original_faces']+offset);face_view.append(np.full(len(m.faces),np.uint32(1<<j)));offset+=len(P)
   P=np.concatenate(points);N=np.concatenate(norm);rgb=np.concatenate(color);source=np.concatenate(view);uv=np.concatenate(uvs);protected=np.concatenate(protect);ff=np.concatenate(faces);fbits=np.concatenate(face_view);diag=diagnose(P,source,refs,packs,obj,rd);Q,colors,mapping,info=merge_supported(P,N,rgb,source,uv,protected,diag);fac,facbits,face_map=remap_faces(ff,mapping,fbits);combined=trimesh.Trimesh(P,ff,vertex_colors=rgb,process=False);fused=trimesh.Trimesh(Q,fac,vertex_colors=colors,process=False);export(combined,f'meshes/{video}_{obj}_B_raw_multiref.ply');export(fused,f'meshes/{video}_{obj}_C_confidence_fused.ply');export(trimesh.points.PointCloud(P,colors=rgb),f'points/{video}_{obj}_B_combined.ply');export(trimesh.points.PointCloud(Q,colors=colors),f'points/{video}_{obj}_C_fused.ply')
   np.savez_compressed(R/f'provenance/{video}_{obj}_fusion.npz',source_points_mm=P,source_normals=N,source_view=source,source_uv=uv,source_rgb=rgb,protected_boundary=protected,source_to_fused=mapping,source_faces=ff,source_face_view_bits=fbits,source_face_to_fused_face=face_map,fused_face_view_bits=facbits,fused_points_mm=Q,**diag,**info)
   pointdelta=np.linalg.norm(Q[mapping]-P,axis=1);rec=dict(video=video,object=obj,success=len(fac)>0,refs=[c['frame']['id']for c in refs],input_vertices=len(P),output_vertices=len(Q),input_faces=len(ff),output_faces=len(fac),merged_clusters=info['merged_clusters'],merged_input_points=info['merged_input_points'],points_deleted=0,original_identities_retained=len(P),faces_collapsed_or_duplicate=int((face_map<0).sum()+np.count_nonzero(np.bincount(face_map[face_map>=0])>1)),boundary_points=int(protected.sum()),boundary_max_displacement_mm=float(pointdelta[protected].max())if protected.any()else None,all_point_displacement_mm=stats(pointdelta),status_counts={str(i):int((diag['status']==i).sum())for i in [1,2,3,4]},multiview_supported_point_count=int((diag['support_views']>=2).sum()),strict_model_consistent_no_front_conflict=int((diag['status']==2).sum()),Ring_front_conflict_samples=int(diag['Ring_front_conflicts'].sum()),Ring_occluded_unknown_samples=int(diag['Ring_occluded_unknown'].sum()),seconds=time.monotonic()-st,knownGT=False,continuous_surface_accuracy='UNKNOWN');runs.append(rec);save('metrics/fusion_runs.json',runs);print('FUSE',rec,flush=True)
 freeze('C_fusion_predictions',[R/'metrics/fusion_runs.json']+list((R/'provenance').glob('*'))+list((R/'meshes').glob('*_C_*'))+list((R/'meshes').glob('*_B_*')));verify()
if __name__=='__main__':main()

from icf_common import *
def table(head,rows):
 def f(x):return 'UNKNOWN'if x is None else f'{x:.4f}'if isinstance(x,float)else str(x).replace('|','/')
 return '| '+' | '.join(head)+' |\n| '+' | '.join(['---']*len(head))+' |\n'+'\n'.join('| '+' | '.join(f(x)for x in row)+' |'for row in rows)+'\n'
def main():
 run=load(R/'metrics/reconstruction_runs.json');fusion=load(R/'metrics/fusion_runs.json');tsdf=load(R/'metrics/tsdf_runs.json');top=load(R/'metrics/topology.json');ray=load(R/'metrics/ray_evaluation.json');cov=load(R/'metrics/surface_model_coverage.json');feat=load(R/'metrics/feature_by_family.json');cross=load(R/'metrics/cross_exploratory.json');frameaudit=load(E/'ring_first_v14a_forensic_audit/inputs/corrected_004_timeline.json');protected=len(load(R/'reproducibility/protected.json')['files']);refs=cases()
 audit='''
## 固定审计表

| 审计项目 | 必须汇报 |
| --- | --- |
| 目标组数 | 1个真实静态测量组，两段视频004/005独立；6个参考视角、2种对象的单视频融合、2套探索跨视频H |
| 本算法独立成功 | 6/6深度输入可用（复用5，新HERO1/1）；4/4对象C融合和4/4对象TSDF产生数值表面；两视频独立新融合2/2。真实绝对几何准确性UNKNOWN |
| 本算法失败 | C有非流形边；TSDF损失薄区域；可信新增表面未证实；跨视频正式认证0/1、正式H全NaN，不执行新配准 |
| 历史测量值回退 | 0。旧HERO是本轮明确授权的冻结输入，非失败补齐；历史单/多参考Mesh单列对照 |
| 失败组及具体原因 | DEV004/005：系统深度错层、薄边界缺失、拓扑问题与相机不确定性；详见[FAILURES.md](FAILURES.md)及[失败表](failure_ledger.csv) |
| 最终统计样本 | 两视频原Polyp像素/点分母51382/47461；各方法同分母。独立观察全查询541条/方法，5方法共2705记录，NaN保留；两个跟踪家族不冒充相互独立物理点 |
| 是否使用GT选择算法 | 否。无真实3D GT；不读取Blender GT、历史直径、Mesh配准GT。参数/输入/融合预测先冻结；评价不反调参数 |

真实GT不可用：绝对深度MAE、Chamfer到真实形状、真实新增面积、真实高度/体积及物理指标相对误差均为UNKNOWN。可计算的模型相互差异、像素残差均保留n、median、MAE、p95、max，不能冒充GT精度。未修改DXY-MID、未训练、未删/移/压缩旧资产；保留用户原有未提交修改。未新增清理候选。
'''
 common='''
## 坐标、尺度和置信边界

工作RGB640×360，K=(490,490,319.5,179.5)，D未知，沿用冻结候选0，不重新标定。深度是相机轴向Z、毫米；c2w把相机点变到各自视频的Ring局部坐标。Ring R10中心线半径5.6mm、截面半径0.6mm，完整torus为固定物理先验，不是MVS成功恢复黑环的证据。环平面不作为息肉基底。004/005的平面内yaw规范保持独立。

GLB按规范导出米：`p_GLTF=p_mm/1000`，H中的平移仍以毫米记录。跨视频同一个H作用于005全部物体、Ring和相机，未独立调整息肉、缩放、ICP或非刚性修形。两套跨视频候选始终UNVERIFIED。

状态区分：`MODEL_PREDICTED`；`MULTIVIEW_MODEL_CONSISTENT_POSE_CONDITIONAL`；`SPARSE_FEATURE_SUPPORTED_POSE_CONDITIONAL`；`UNKNOWN/CONFLICT`。多视图预测共用模型和相机，模型自一致不等于独立几何真值；独立轨迹支持仅限实际采样点，不向整个三角面传播。[逐点来源](provenance/)、[全查询](metrics/feature_queries.csv)、[完整指标](metrics/)、[复现配置](config.json)。
'''
 def report(name,title,text): (R/name).write_text('# '+title+'\n\n'+text+common+audit)
 inputtable=table(['视频','参考','来源','HERO源帧索引','Polyp数值点','开放面数','耗时秒'],[[r['reference'].split('_')[0]if r['reference'].startswith('004')else'005',r['reference'],'本轮新推理'if r['new_HERO_forward']else'冻结深度复用',next(c['sources']for c in refs if c['tag']==r['tag']),r['parts']['Polyp']['numeric_points'],r['parts']['Polyp']['mesh_faces'],r['seconds']]for r in run])
 indep='''本轮有**新的实际重建和融合**，不是只重渲染旧GLB：005 raw745实际运行一次现有官方MVSAnywhere HERO，六参考重新导出公制点云及开放Mesh；两视频分别运行一致性融合C和官方TSDF对照D。004复用已有ref3/8/13，005复用raw57/459，另增raw745。保留历史原始Mesh作为独立对照，不覆盖。

''' + inputtable+'''
005新增参考745是原局部相机已通过条件检查的视角。源帧344/459/172由固定相机角度和冻结训练轨迹重叠选出，不看本轮深度、GT或Mesh外观。005旧raw0预览的相机未通过原局部检查，与57接近重复，保留历史资产但不作为主融合参考；未根据本轮表面好坏删掉它。原独立目标raw516/834/860未作为新增HERO输入。004缓存的ref8旧源帧包含key07，故key07不能作为本轮表面完全隔离验证；实际验证用key10/15。所有相机历史已接触，不声称全流程盲测。

004实际RGB身份使用V14-A确认的绑定：key03/raw303、key08/raw676、key13/raw1043；固定参考RGB未替换。旧相机可能受早期错误时间线影响的风险仍保留，修正标签不等于本轮修正相机。每视角新导出的camera.json记录冻结c2w/K、原RGB/Mask及SHA256来源。

HERO原生352×640深度与K正确缩放：`c' = s(c+0.5)-0.5`；005745原生fy=479.111、cy=175.5，恢复到640×360后用Kfull。使用已有官方适配器，535组全部学习参数加载，checkpoint SHA256=00878bab903b1d384cd6bb9ea092e247a9036d429cb8bcc3d6dcbb81f67e556d。未训练、未部署新模型；新推理约10.32秒，峰值GPU1.51GB。RGB—深度—Mask同分辨率，轴向深度反投影往返最大像素误差<2e−13。

每参考在`inputs/`输出RGB、PolypMask、RingMask、标签及Overlay；`depths/`保存轴向毫米深度、有效性与逐像素可靠性诊断；`points/`保存完整公制点/UV；`meshes/*_A.ply`为原始开放面；每参考相机和Ring深度分别保存。原生HERO置信/代价不是准确率，不直接用于认证。

### 能否恢复更多可信表面

相对单参考，三参考扩大数值可见表面；004的三个参考已是历史多参考基线，本轮不声称新增004观察。005新745贡献14873个数值点，3613个距历史两参考表面>0.3mm，其中只有46个通过模型多视图一致且无前方冲突；这些仍不是独立确认的新增面积。其余差异可能是深度偏差或真正新视野，保留UNKNOWN，不能把点数/面积相加算真实覆盖。

多测量组可复现性：模块、配置和输入接口已按视频通用化，没有按组切算法。本轮只运行1个物理测量组中的2段视频，未运行G02—G06，因此普适性UNKNOWN，不能把两视频当两测量组成功。
'''
 report('INDEPENDENT_RECONSTRUCTION_REPORT.md','单视频多参考独立重建',indep)
 summary=[]
 for video in cfg()['videos']:
  for method in ['A_single','HISTORICAL','B_combined','C_fused','D_TSDF']:
   t=next(x for x in top if x['video']==video and x['object']=='Polyp'and x['method']==method);r=[x for x in ray if x['video']==video and x['object']=='Polyp'and x['method']==method];n=sum(x['target_mask_pixels']for x in r);nt=sum(x['thin_proxy_denominator']for x in r);cover=sum(x['ray_hits']for x in r)/n;thin=sum(x['thin_proxy_ray_fraction']*x['thin_proxy_denominator']for x in r)/nt;model=next(x for x in cov if x['video']==video and x['object']=='Polyp'and x['method']==method);summary.append(dict(video=video,method=method,point_denominator=n,raw_mask_ray_fraction=cover,thin_boundary_proxy_ray_fraction=thin,components=t['components'],largest_component_fraction=t['largest_component_fraction'],largest_component_area_mm2=t['largest_component_area_mm2'],nonmanifold_edges=t['nonmanifold_edges'],boundary_length_mm=t['boundary_length_mm'],original_model_surface_025fraction=model['within025_model_fraction'],vertices=t['vertices'],faces=t['faces'],GT_accuracy=None))
 save('metrics/summary.json',summary);csvwrite('results.csv',summary)
 fusiontable=table(['视频','方法','全Mask射线命中%','薄边界代理命中%','面连通分量','最大连通面积%','非流形边','0.25mm原模型近邻%'],[[s['video'],s['method'],100*s['raw_mask_ray_fraction'],100*s['thin_boundary_proxy_ray_fraction'],s['components'],100*s['largest_component_fraction'],s['nonmanifold_edges'],100*s['original_model_surface_025fraction']]for s in summary])
 famtable=table(['视频','方法','验证家族','分母','有限','支持≤2px且≥1°','MAE px','p95 px'],[[x['video'],x['method'],x['family'],x['query_denominator'],x['finite'],x['supported_queries'],x['errors_px']['MAE'],x['errors_px']['p95']]for x in feat if x['object']=='Polyp'])
 fusiontext='''## 实际方法与来源保留

A是中央单参考004ref8/005raw459原开放Mesh，另保留每个参考A。HISTORICAL单列旧局部GLB表面（004三参考，005两参考）。B是三参考全部原始点/面直接组合。C在0.3mm跨视图深度一致、同物体、无前方冲突、离边界>3px、跨源法向≤30°时，才在0.15mm桶内合并；先源内平均，再源间平均，避免像素密度主导。其他点原位保留。面只由原面重映射，不新增三角形，不平滑或补洞。点/面映射和源视角保存在provenance中。

C保留两视频全部51382/47461源点身份；6653/6196个边界点最大移动0。内部最大移动0.1283/0.1509mm，合并后顶点49868/39412；面96048/76256。部分退化/重复面移除有完整原面映射，不把它当成删除错误点后的精度提高。`fusion_face_accounting.json`是面数量的准确计数；早期fusion_runs日志的同名字段合计了重复组数，不能当删除面数，原日志保留。

D直接复用官方`CustomOpen3dFuser`原类：0.15mm体素、0.45mm截断、原相机/深度/Mask、无置信度修剪，Polyp/Background分开积分。保存原始TSDF及开放版本，后者只保留能由某源同物体Mask和≤0.45mm深度解释的面；不把无观察插值背面当恢复。004/005 Polyp分别有831/730个原始TSDF面缺少该支持，保留原始文件并标UNKNOWN。

''' + fusiontable+'''
**表中全Mask命中是候选曲面覆盖，不是GT准确覆盖**；0.25mm近邻只相对于冻结HERO源点，不是绝对几何误差。薄边界代理是Mask内距离边界≤3px且远离Ring的区域，不是经过GT确认的蒂部。全部原像素分母51382/47461、薄边界分母2179/1529都保留；Ring挡住的区域不参与假补面。

## 连续性与拓扑

C把004/005最大连通面积从17.84%/22.95%增至48.21%/66.78%，分量24→21、23→19；因此有限连接确实发生。但新增586/1993条非流形边，边界总长度也未降低，说明点桶合并不足以生成干净的流形开放面。该C Mesh标为EXPERIMENTAL，不能直接用于曲率、面积或体积认证。没有通过拓扑修补掩盖问题。

首次评价采用Trimesh face_adjacency，只连接恰好两个面的边，忽略≥3面边，曾误报大量碎片。原始评价/源码完整归档到`diagnostics/initial_face_adjacency_metric/`。后续改为所有边关联的面连通统计，并明确非流形边数；受控测试覆盖三面共边。只修评价，不改融合预测、体素、阈值或相机。边界边数、边界总长度与碎片数用于破碎诊断；因为曲面本来开放、包含真实遮挡边界，真实缺失孔洞数UNKNOWN，不把全部开放边界都当算法孔洞。

D较强地合并错层，但全Mask命中约88%，薄区域命中仅约29%；C分别保持97.40%/96.92%全Mask命中和56.26%/66.12%薄边界代理。不能用TSDF较高最大分量比例掩盖失去的结构。因此不把D替代原始开放层。

## 多视图几何与独立观察

原多参考预测存在显著错层、前方潜在冲突及遮挡不确定。C仅在很小范围合并，无法修复系统深度偏差。来源图中绿色只是模型一致；红/紫冲突、低支持点均保留，没有把Ring深度复制给Polyp或强制接触。

下面完整保留原稀疏家族及额外只读CoTracker3诊断家族；后者因005原稀疏仅1条而追加，未用于选择/优化预测。所有方法同查询，NaN不删；跨家族材料身份可能重叠，不相加称独立锚点。两家族及相机历史已暴露，不是新盲测。

''' + famtable+'''
这不支持精度成功结论：004 C的CoTracker残差几乎等于B（约1.903px），旧稀疏家族约7.325px；005 C的CoTracker约5.336px，略高于历史两参考5.326px，且p95长尾未改善。不能仅选较好的家族。C对背景也没有真实GT；只另输出实际≤2px、视差≥1°的稀疏支持点，不向邻面传播。

建议当前保存B完整层和C逐点置信/融合点云；C焊接Mesh作为研究性显示，TSDF作为会损失细节的对照，不作为物理指标输入。[共同有效查询及支持增减](metrics/paired_feature_evaluation.json)、[完整残差](metrics/feature_queries.csv)、[拓扑](metrics/topology.csv)、[模型覆盖](metrics/surface_model_coverage.json)、[面计数](metrics/fusion_face_accounting.json)。
'''
 report('MULTIVIEW_FUSION_REPORT.md','单视频置信感知融合及TSDF对照',fusiontext)
 ctable=table(['冻结H','方向','模型近邻中位mm','近邻p95mm','重叠候选面积比例%','前方冲突候选%','源独有/未知候选%'],[[x['candidate'],x['source']+'→'+x['target'],x['nearest_other_model_distance_mm']['median'],x['nearest_other_model_distance_mm']['p95'],100*x['classes']['1']['area_fraction'],100*x['classes']['2']['area_fraction'],100*x['classes']['4']['area_fraction']]for x in cross])
 crossbody='''实际使用新C融合表面生成两套跨视频场景，不是读取旧探索GLB换视角：004/005的Polyp、Background和Known Ring均独立图层，相机和轨迹一并输出。只用冻结Full-LightGlue/Full-RoMa，无重新匹配、变换拟合、ICP或跨视频焊接。保留所有局部面，不根据Mesh观感选择候选。

''' + ctable+'''
面积比例是源三角面面积加权的模型诊断，不是独立真实新增覆盖。重叠候选定义为到另一模型≤0.3mm且法向相容≤30°；距离较大不等于真正的新可见面，还可能是错层。前方冲突按相同冻结H下其他源模型深度判断，也是候选。未投到其他可见Polyp的面仍可能被Ring/组织遮挡或视野不重叠，保留UNKNOWN，不据此认定真实背面恢复。

两套候选Ring中心差约0.154/0.115mm，法向差约2.60°/2.54°，只是已知候选的内部几何关系，不是对真实准确性的测量。两套H仍有约10%—16%的前方冲突候选，以及大量遮挡/深度未知。不能将可视化近似重叠当认证。

相较旧005两参考，新增745改善了一些模型显示范围和薄边界射线命中；但缺乏独立新增区域支持，不能证明跨视频互补精度提高。最终保留两层、不输出焊接联合Mesh。正式跨源H仍NaN，下游不得自动把两个探索候选作为认证位姿。

交互GLB：[Full-LightGlue](scenes/FULL_LightGlue_NEW_LOCAL_FUSION_LAYERS_UNVERIFIED.glb)、[Full-RoMa](scenes/FULL_RoMa_NEW_LOCAL_FUSION_LAYERS_UNVERIFIED.glb)。完整每源面分类、面积权重、最近距离和误差状态见`provenance/*cross_analysis.npz`及[cross_exploratory.json](metrics/cross_exploratory.json)。
'''
 report('CROSS_SOURCE_EXPLORATORY_FUSION.md','跨视频探索性分层场景',crossbody)
 decision='''本轮完成新的单视频重建/融合与探索跨视频场景；**保留“单视频原始开放层＋置信标注/保守融合点云”作为主线**。不把C非流形Mesh或损失薄结构的TSDF升级为正式几何，不重启跨视频特征配准。

**Q1：多参考是否恢复更多可信表面？** 更多模型可见候选，可信新增尚未证实。004复用历史三个参考，无新增观察；005增加raw745，参考三视图的全Mask候选命中由历史94.15%增至96.92%，但3613个距旧模型>0.3mm的新点中仅46个模型一致、仍未独立认证。不能等同真实新增面积。

**Q2：能否形成更连续的开放表面？** 数值连通性提高：最大连通面积比例004约18%→48%，005约23%→67%，全原分母候选覆盖保持。新增非流形边586/1993、边界破碎/深度错层仍在，尚非可靠流形曲面，几何精度未证实。

**Q3：何种融合适合保留顶部/侧面/蒂部？** 当前保留全部来源开放面、逐点状态与保守跨视图一致性点融合更合适；边界不移动，低支持细节不删除。TSDF薄边界代理命中降至约29%，不作默认。顶部/蒂部的真实准确性无GT，图中解剖区域仅人工检查对象，不能由边界代理认证。

**Q4：各自改善后跨视频互补更好吗？** 新视角提供潜在互补显示范围，已输出两套新局部融合分层场景；未通过新的跨视频认证，部分前方冲突仍在，不宣称几何更准确，不焊接。

**Q5：能提取物理指标吗？** 已有毫米坐标、源视角及有效性表示，具备探索局部几何的工程基础；尚缺唯一可靠表面、非流形处理和误差验证，不能认证真实高度、面积、体积或完整物理指标，本轮未计算这些指标。

仅建议下一轮由人工选择1项：(1)在单视频内研究多参考系统性深度错层，必须保持全部原始可见区域和独立轨迹分母；或(2)研究只在确认相同表面的重叠区生成保留边界的流形开放面，先证明不伤害细结构。本轮不自动执行，不扩组、不优化跨源H。
'''
 report('DECISION.md','本轮决策与五个问题',decision)
 figs=[('Fig1_inputs_and_camera_views','两视频3参考RGB/Mask与冻结局部轨迹'),('Fig2_HERO_multireference_depths','六参考轴向毫米深度，共用色阶，非GT误差图'),('Fig3_004_independent_before_after','004历史/B/C/TSDF同尺度四视图'),('Fig4_005_independent_before_after','005历史/B/C/TSDF同尺度四视图'),('Fig5_consistency_and_conflict','模型一致/冲突/混合/低支持完整保留'),('Fig6_fusion_comparison','全分母覆盖、薄边界、连通和非流形对照'),('Fig7_cross_video_layers','两冻结未认证H，新局部融合分层，不焊接'),('Fig8_complementary_visible_regions','顶部/侧面/低处供人工审查，非GT解剖标签'),('Fig9_interactive_GLB_previews','10个交互GLB的预览；scenes完整资产')]
 index='''所有图来自真实DEV数据，无Blender GT。单位mm；GLB存储m，乘1000对应数值毫米。新HERO与新融合日志见logs/，不是只重渲染历史GLB。相机、Ring、内参和跨源H均未优化。

''' +table(['PNG','内容及限制'],[['['+n+'.png](visualizations/'+n+'.png)',s]for n,s in figs])+'''
固定四视图为Ring局部top/front/side/oblique，48mm显示宽度、中心(0,3,−6)mm。局部yaw规范不同，不把004/005未注册原视角当同一物理方向。Fig8是明确标注的24mm视窗裁片，未删除导出几何。白底不透明，实际非空检查见[QC](metrics/visualization_QC.json)。

交互资产使用Blender/标准GLB查看器打开，可旋转并检查分层节点；[场景清单](scenes/SCENE_MANIFEST.json)。各视频B为完整原始三参考层，C为保守融合候选，D为TSDF诊断，CONFIDENCE_LABELS给模型条件状态，不是准确率热力图。
'''
 report('VISUALIZATION_INDEX.md','可视化及交互GLB索引',index)
 fails=[dict(video='004',stage='C_surface_topology',status='EXPERIMENTAL',reason='586 nonmanifold edges, boundary length not improved',evidence='metrics/topology.json',figure='visualizations/Fig6_fusion_comparison.png'),dict(video='005',stage='C_surface_topology',status='EXPERIMENTAL',reason='1993 nonmanifold edges; no clear held geometry improvement',evidence='metrics/topology.json',figure='visualizations/Fig6_fusion_comparison.png'),dict(video='004/005',stage='TSDF',status='NOT_DEFAULT',reason='thin boundary proxy ray fraction .289/.296, lower than raw multiview .563/.661',evidence='metrics/ray_evaluation.json',figure='visualizations/Fig3_004_independent_before_after.png'),dict(video='005_745',stage='new_coverage_validation',status='UNKNOWN',reason='3613 far-old model points; only46 self-consistent, no independent new-area GT',evidence='metrics/surface_model_coverage.json',figure='visualizations/Fig8_complementary_visible_regions.png'),dict(video='004/005',stage='cross_source',status='UNVERIFIED',reason='frozen H not newly certified; layers only',evidence='metrics/cross_exploratory.json',figure='visualizations/Fig7_cross_video_layers.png'),dict(video='004/005',stage='black_Ring_MVS',status='UNVERIFIED',reason='MVS Ring depth has large tails; use fixedCAD as prior, not copy depth to Polyp',evidence='metrics/Ring_depth_diagnostic.json',figure='visualizations/Fig1_inputs_and_camera_views.png'),dict(video='evaluation',stage='initial_face_adjacency',status='CORRECTED_METRIC_PRESERVED',reason='Trimesh adjacency ignored nonmanifold edge incidences; all-edge metric added; no prediction changed',evidence='diagnostics/initial_face_adjacency_metric/',figure='visualizations/Fig6_fusion_comparison.png'),dict(video='export',stage='first_import',status='FIXED_NO_GEOMETRY_CHANGE',reason='same-named historical evaluate module shadowed unused import; removed unused import',evidence='logs/export_initial_import_failure.log',figure='visualizations/Fig9_interactive_GLB_previews.png')]
 csvwrite('failure_ledger.csv',fails);report('FAILURES.md','完整失败与不确定性',table(['对象','步骤','状态','原因','证据'],[[f['video'],f['stage'],f['status'],f['reason'],'['+f['evidence']+']('+f['evidence']+')']for f in fails]))
 human='本轮新增005一个HERO视角，并实际完成两视频各三参考的保守融合及TSDF对照。融合保持候选覆盖、提高连通性，但新增非流形边；TSDF明显损失薄区域。新增真实可信面积仍未证实。两套跨视频场景保留独立图层并标未认证。建议保留原开放面和置信点云，下一步只研究单视频错层或流形融合；未改Dxy、未删旧资产。';assert len(human)<=200;(R/'HUMAN_SUMMARY.md').write_text(human+'\n')
 protocol='''## 方法和运行记录

- 复用成熟HERO及官方TSDF，无训练、无新增匹配器、无相机优化。
- 新推理005raw7451次；其余5个深度明确复用。实际C对象4/4、D对象4/4数值成功。
- 全部原点身份保留；源点→新点、原面→新面、支持视角与原UV可追溯。
- 分阶段配置/源码/输入/预测SHA256冻结；评价指标修正和追加CT诊断不反调融合参数。真实结果缺少GT。
- 8项受控测试覆盖轴向Z/射线单位、保护边界、冲突保留、源密度归一、无新增三角形、TSDF可见性和非流形连通统计。
'''
 report('TECHNICAL_REPORT.md','Independent Reconstruction & Confidence-Aware Fusion',decision+'\n'+protocol+inputtable+'\n'+fusiontable+f'\n历史保护检查覆盖{protected}个文件。全部报告、原始数据指针、失败日志和参数都在本目录。\n\n'+table(['报告','内容'],[['[独立重建](INDEPENDENT_RECONSTRUCTION_REPORT.md)','六参考/新HERO/帧身份/K单位'],['[单视频融合](MULTIVIEW_FUSION_REPORT.md)','A/B/C/D/完整覆盖与独立观察'],['[跨源探索](CROSS_SOURCE_EXPLORATORY_FUSION.md)','冻结H/保留图层/冲突'],['[图索引](VISUALIZATION_INDEX.md)','PNG及可交互GLB'],['[失败](FAILURES.md)','完整保留与不确定性'],['[复现](README.md)','命令/模块/版本']]))
 cmd='PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python';scriptroot=str(R/'scripts');commands=['setup.py','reconstruct.py','confidence_fusion.py','tsdf_compare.py','evaluate.py','export_scenes.py','visualize.py','delivery_metadata.py','write_reports.py','final_integrity.py'];readme='''# Independent Reconstruction & Confidence-Aware Fusion V1

入口：[人工摘要](HUMAN_SUMMARY.md)、[决策](DECISION.md)、[技术报告](TECHNICAL_REPORT.md)。本轮有新HERO推理及融合输出。不能把任何GLB标为真实几何认证。

## 环境和重现

现有Python3.12 venv，PyTorch CUDA、OpenCV、NumPy、SciPy、Trimesh、Matplotlib，Open3D来自surface_fusion_v3/vendor；HERO及DINO权重只读复用既有官方适配器。不要新安装或训练模型。

以下是实际流程。**重现时复制脚本/配置到新实验目录**，让icf_common.R指向该目录；不要直接覆盖本目录冻结结果。先保留输入引用、模型权重及既有代码哈希。

```bash
'''+cmd+' '+str(R/'tests/test_fusion.py')+'\n'+'\n'.join(cmd+' '+scriptroot+'/'+s for s in commands)+'\n```\n'+'''
首次evaluate输出及源码保存在diagnostics中；最终evaluate包含完整边关联计量与额外只读CT家族，不改变任何融合预测/阈值。失败导出日志亦保留。

inputs：原图/Mask/来源/相机；raw：本轮新HERO原生结果；depths：6张轴向毫米深度和状态图；points：原始/组合/融合/独立支持点；meshes：A/B/C及D原始/开放版PLY；provenance：所有身份/源帧/UV/面映射；metrics：全分母指标与NaN；scenes：10个GLB；visualizations：9类PNG；reproducibility：分阶段SHA256；logs：真实运行日志。

GLB为米，数值几何/PLY为毫米。RingCAD尺寸固定，005跨视频只能用带UNVERIFIED标记的冻结H，不自动联合HERO。最终C非流形，D损薄边界；B原始层始终保留，不把C/D当可认证物理表面。无清理候选、无旧资产删除。
''';(R/'README.md').write_text(readme)
 np.savez_compressed(R/'scenes/FORMAL_CROSS_SOURCE_TRANSFORM.npz',H=np.full((4,4),np.nan),certified=False,status='NO_NEW_CERTIFICATION_FROZEN_HYPOTHESES_ONLY');freeze('reports',list(R.glob('*.md'))+[R/'results.csv',R/'failure_ledger.csv',Path(__file__),R/'metrics/summary.json',R/'scenes/FORMAL_CROSS_SOURCE_TRANSFORM.npz']);verify();print('REPORTS_COMPLETE',flush=True)
if __name__=='__main__':main()

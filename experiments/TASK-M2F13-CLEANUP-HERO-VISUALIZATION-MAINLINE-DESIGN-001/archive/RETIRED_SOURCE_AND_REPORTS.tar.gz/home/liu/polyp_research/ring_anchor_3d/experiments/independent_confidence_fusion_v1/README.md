# Independent Reconstruction & Confidence-Aware Fusion V1

入口：[人工摘要](HUMAN_SUMMARY.md)、[决策](DECISION.md)、[技术报告](TECHNICAL_REPORT.md)。本轮有新HERO推理及融合输出。不能把任何GLB标为真实几何认证。

## 环境和重现

现有Python3.12 venv，PyTorch CUDA、OpenCV、NumPy、SciPy、Trimesh、Matplotlib，Open3D来自surface_fusion_v3/vendor；HERO及DINO权重只读复用既有官方适配器。不要新安装或训练模型。

以下是实际流程。**重现时复制脚本/配置到新实验目录**，让icf_common.R指向该目录；不要直接覆盖本目录冻结结果。先保留输入引用、模型权重及既有代码哈希。

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/tests/test_fusion.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/setup.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/reconstruct.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/confidence_fusion.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/tsdf_compare.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/evaluate.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/export_scenes.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/visualize.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/delivery_metadata.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/write_reports.py
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 ring_anchor_3d/.venv/bin/python /home/liu/polyp_research/ring_anchor_3d/experiments/independent_confidence_fusion_v1/scripts/final_integrity.py
```

首次evaluate输出及源码保存在diagnostics中；最终evaluate包含完整边关联计量与额外只读CT家族，不改变任何融合预测/阈值。失败导出日志亦保留。

inputs：原图/Mask/来源/相机；raw：本轮新HERO原生结果；depths：6张轴向毫米深度和状态图；points：原始/组合/融合/独立支持点；meshes：A/B/C及D原始/开放版PLY；provenance：所有身份/源帧/UV/面映射；metrics：全分母指标与NaN；scenes：10个GLB；visualizations：9类PNG；reproducibility：分阶段SHA256；logs：真实运行日志。

GLB为米，数值几何/PLY为毫米。RingCAD尺寸固定，005跨视频只能用带UNVERIFIED标记的冻结H，不自动联合HERO。最终C非流形，D损薄边界；B原始层始终保留，不把C/D当可认证物理表面。无清理候选、无旧资产删除。

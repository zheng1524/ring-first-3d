from icf_common import *
import subprocess
def main():
 for p in ['inputs','depths','raw','meshes','points','provenance','metrics','logs','scenes','visualizations','reproducibility','tests']: (R/p).mkdir(exist_ok=True)
 paths=set(Path(p)for p in load(LAST/'reproducibility/protected.json')['files']);paths.update(p for p in LAST.rglob('*')if p.is_file()and'__pycache__'not in p.parts)
 for base in [F1/'inputs',F2/'predictions',V6/'predictions',V6/'raw',V6/'inputs',V6/'observations',V13/'scenes']:
  paths.update(p for p in base.rglob('*')if p.is_file()and'__pycache__'not in p.parts)
 dirty=subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=REPO,text=True);(R/'reproducibility/initial_git_status.txt').write_text(dirty)
 for line in dirty.splitlines():
  p=REPO/line[3:]
  if p.is_file():paths.add(p)
 freeze('protected',paths);ds={d['id'][-3:]:d for d in load(RASR/'inputs/datasets.json')if d['id'].startswith('G01_')};save('inputs/datasets.json',ds);refs=[]
 for ref in [3,8,13]:
  path=F2/f"predictions/real_0_{'A2'if ref==8 else'B7'}_r{ref:02d}.npz";p=np.load(path);assert np.max(abs(p['pose']-np.load(ds['004']['camera_files'][0])['c2w'][ref]))<1e-10
  refs.append(dict(tag=f'004_ref{ref:02d}',video='004',index=ref,frame=ds['004']['ledger'][ref],pose=p['pose'],K=p['K'],sources=p['sources'],cache=str(path),depth_key='depth',reused=True))
 for raw in [57,459]:
  ref=next(i for i,x in enumerate(ds['005']['ledger'])if x['raw_frame']==raw);path=V6/f'predictions/005_supported_ref{raw:05d}_surface.npz';p=np.load(path);assert np.max(abs(p['pose']-np.load(ds['005']['camera_files'][0])['c2w'][ref]))<1e-10
  refs.append(dict(tag=f'005_raw{raw:05d}',video='005',index=ref,frame=ds['005']['ledger'][ref],pose=p['pose'],K=p['K'],sources=p['source_frames'],cache=str(path),depth_key='depth_mm',reused=True))
 L=ds['005']['ledger'];cam=np.load(ds['005']['camera_files'][0]);vv=load(V6/'metrics/local_validation.json');records=next(x for x in vv['versions']if x['version']==0)['per_frame'];rr=next(i for i,v in enumerate(L)if v['raw_frame']==cfg()['new005reference_raw']);assert records[rr]['status']=='VALIDATED';tr=np.load(V6/'observations/tracks005.npz');P=np.array(vv['coverage'][0]['P_estimate_mm']);dire=unit(P-cam['c2w'][:,:3,3]);scores=[]
 for i in range(len(L)):
  if i==rr or L[i]['raw_frame']in cfg()['reserved005_raw']or records[i]['status']!='VALIDATED':continue
  overlap=int((np.isfinite(tr['xy'][:,rr,0])&np.isfinite(tr['xy'][:,i,0])&~tr['held']).sum());ang=float(np.degrees(np.arccos(np.clip(dire[i]@dire[rr],-1,1))))
  if overlap>=15:scores.append(dict(index=i,overlap=overlap,angle_deg=ang,score=min(ang,25)*min(overlap,100)))
 scores.sort(key=lambda x:(-x['score'],-x['overlap'],x['index']));src=[x['index']for x in scores[:3]];assert len(src)==3
 refs.append(dict(tag='005_raw00745',video='005',index=rr,frame=L[rr],pose=cam['c2w'][rr],K=K,sources=src,reused=False,source_selection=scores));save('inputs/references.json',refs);save('inputs/H_frozen.json',[x for x in load(LAST/'inputs/baselines.json')if x['tag']in cfg()['cross_candidates']]);save('inputs/historical_baselines.json',dict(original004=str(V13/'scenes/004_LOCAL_UNREGISTERED.glb'),original005=str(V13/'scenes/005_LOCAL_UNREGISTERED.glb'),excluded005preview_raw0='historical MODEL_PREDICTED camera; near duplicate57, retained only as frozen baseline',no_depth_fallback=True))
 for c in refs:
  assert sha(c['frame']['RGB_path'])==c['frame']['RGB_SHA256'];assert sha(c['frame']['Mask_path'])==c['frame']['Mask_SHA256']
 freeze('input_selection',[R/'config.json',R/'PROTOCOL.md',R/'inputs/references.json',R/'inputs/H_frozen.json',R/'inputs/datasets.json']+list((R/'scripts').glob('*.py')));verify();print('SELECTED',[(c['tag'],c['sources'])for c in refs],flush=True)
if __name__=='__main__':main()

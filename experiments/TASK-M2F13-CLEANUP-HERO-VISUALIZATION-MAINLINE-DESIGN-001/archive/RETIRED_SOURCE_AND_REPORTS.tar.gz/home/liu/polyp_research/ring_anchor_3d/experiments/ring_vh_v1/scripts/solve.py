"""Conservative silhouette feasibility, not solid occupancy or true-surface estimation.
Reuses V3 voxel-intersection/ray-casting scheme with three-state/free-space changes.
GT cameras and complete silhouettes are physically isolated diagnostic inputs.
"""
from common import *
from scipy.ndimage import binary_erosion
import time,trimesh

def estimate_background(poses,K,frames):
 pack=np.load(R/'inputs/rgb_tracks.npz');xy=pack['xy'];ids=np.flatnonzero((pack['category']==0)&pack['train_track']);points=[];errors=[]
 for j in ids:
  fr=np.array([i for i in frames if np.isfinite(xy[j,i,0])]);
  if len(fr)<3:continue
  X=triangle(xy[j,fr],poses[fr],K);q=(X-poses[fr,:3,3]);z=np.einsum('ni,ni->n',q,poses[fr,:3,2]);rays=q/np.linalg.norm(q,axis=1,keepdims=True);angle=np.degrees(np.arccos(np.clip(np.min(rays@rays.T),-1,1)));uv=np.array([project(X[None],poses[i],K)[0][0] for i in fr]);err=np.median(np.linalg.norm(uv-xy[j,fr],axis=1))
  if (z>0).all() and angle>=1 and err<1:points.append(X);errors.append(err)
 X=np.array(points).reshape(-1,3);record={'background_tracks':len(ids),'triangulated_accepted':len(X),'train_views':frames,'reprojection_px':stats(errors)}
 if len(X)<cfg()['background_plane_min_inliers']:return None,{**record,'success':False,'reason':'insufficient RGB background plane support'}
 rng=np.random.default_rng(cfg()['background_plane_seed']);best=None
 for _ in range(500):
  t=X[rng.choice(len(X),3,False)];n=np.cross(t[1]-t[0],t[2]-t[0]);l=np.linalg.norm(n)
  if l<1e-8:continue
  n/=l;d=-n@t[0];v=abs(X@n+d)<cfg()['background_plane_ransac_mm']
  if best is None or v.sum()>best.sum():best=v
 if best.sum()<cfg()['background_plane_min_inliers']:return None,{**record,'success':False,'reason':'background not sufficiently planar'}
 for _ in range(3):
  m=X[best].mean(0);_,_,V=np.linalg.svd(X[best]-m,full_matrices=False);n=V[-1];d=-n@m;best=abs(X@n+d)<cfg()['background_plane_ransac_mm']
 if n[2]<0:n=-n;d=-d
 plane=np.r_[n,d];record.update(success=True,plane=plane,inliers=int(best.sum()),residual_mm=stats(abs(X[best]@n+d)),uncertainty_margin_mm=cfg()['background_free_margin_mm'],assumption='synthetic background is planar; fitted ONLY from RGB tracks, no GT background depth')
 return plane,record

def frames_data(poses,K,frames,complete=False,plane=None):
 c=cfg();h,w=360,640;ys,xs=np.mgrid[:h,:w];uv=np.c_[xs.ravel(),ys.ravel()];out=[];gates=[]
 for i in frames:
  lab=cv2.imread(str(R/f'inputs/labels_{i:03d}.png'),0);mask=lab==1
  if complete:mask=np.load(R/f'debug_inputs/complete_{i:03d}.npz')['polyp']
  sdf=cv2.distanceTransform((~mask).astype(np.uint8),cv2.DIST_L2,cv2.DIST_MASK_PRECISE);positive=sdf<=c['mask_tolerance_px'];ring=(lab==2)&~positive
  bg=(lab==0)&~positive;rz=np.full((h,w),np.nan,np.float32);rv=cv2.erode((lab==2).astype(np.uint8),np.ones((3,3),np.uint8))>0;y,x=np.nonzero(rv)
  z=torus_depth(np.c_[x,y],poses[i],K,np.zeros(3),np.eye(3),major=c['ring_major_mm'],tube=c['ring_tube_mm']);rz[y,x]=z
  recall=float(np.isfinite(z).mean()) if len(z) else 0
  gates.append({'frame':i,'eroded_visible_ring_pixels':len(z),'valid_intersections':int(np.isfinite(z).sum()),'intersection_recall':recall,'passed':recall>=c['ring_depth_gate_recall']})
  if plane is not None:
   D=(np.c_[uv,np.ones(len(uv))]@np.linalg.inv(K).T)@poses[i,:3,:3].T;den=D@plane[:3];zbg=-(poses[i,:3,3]@plane[:3]+plane[3])/den;zbg[(abs(den)<1e-6)|(zbg<=0)]=np.nan;zbg=zbg.reshape(h,w).astype(np.float32)
  else:zbg=np.full((h,w),np.nan,np.float32)
  out.append(dict(frame=i,positive=positive,ring=ring,bg=bg,ring_depth=rz,bg_depth=zbg,lab=lab))
 return out,gates

def carve(poses,K,obs,method):
 c=cfg();ax=axes();shape=tuple(map(len,ax));N=int(np.prod(shape));keep=np.zeros(N,bool);pos_count=np.zeros(N,np.uint8);unk_count=np.zeros(N,np.uint8);first_carve=np.zeros(N,np.uint8);byview=[]
 for st in range(0,N,c['max_chunk']):
  flat=np.arange(st,min(st+c['max_chunk'],N));ix=np.array(np.unravel_index(flat,shape)).T;X=np.column_stack([ax[j][ix[:,j]] for j in range(3)]);valid=np.ones(len(X),bool);pc=np.zeros(len(X),np.uint8);uc=pc.copy();fc=pc.copy()
  for ob in obs:
   uv,z=project(X,poses[ob['frame']],K);rounded=np.rint(uv).astype(int);inside=(rounded[:,0]>=0)&(rounded[:,0]<640)&(rounded[:,1]>=0)&(rounded[:,1]<360)&(z>0);x=np.clip(rounded[:,0],0,639);y=np.clip(rounded[:,1],0,359);p=inside&ob['positive'][y,x];pc+=p
   if method=='VH0':bad=inside&~p
   else:
    b=ob['bg'][y,x];zb=ob['bg_depth'][y,x];bad=inside&b&np.isfinite(zb)&(z<zb-c['background_free_margin_mm'])
    if method=='VH2':
     zr=ob['ring_depth'][y,x];bad|=inside&ob['ring'][y,x]&np.isfinite(zr)&(z<zr-c['ring_free_margin_mm'])
   uc+=~p&~bad
   new=valid&bad;fc[new]=ob['frame']+1;valid&=~bad
  keep[flat]=valid;pos_count[flat]=pc;unk_count[flat]=uc;first_carve[flat]=fc
 return keep.reshape(shape),pos_count.reshape(shape),unk_count.reshape(shape),first_carve.reshape(shape)

def raycast(occ,pose,K,mask):
 c=cfg();bounds=np.array(c['roi_mm']);s=c['voxel_mm'];size=np.array(occ.shape);h,w=mask.shape;lo=np.full((h,w),np.nan,np.float32);hi=lo.copy();width=lo.copy();segments=np.zeros((h,w),np.uint16);touch=np.zeros((h,w),bool);y,x=np.nonzero(mask)
 for st in range(0,len(x),400):
  yy=y[st:st+400];xx=x[st:st+400];D=(np.c_[xx,yy,np.ones(len(xx))]@np.linalg.inv(K).T)@pose[:3,:3].T;C=pose[:3,3]
  with np.errstate(divide='ignore',invalid='ignore'):t1=(bounds[:,0]-C)/D;t2=(bounds[:,1]-C)/D
  enter=np.maximum(np.minimum(t1,t2).max(1),1e-4);leave=np.maximum(t1,t2).min(1);span=np.maximum(leave-enter,0);ns=int(np.ceil(span.max()/c['ray_step_mm']))+2;t=enter[:,None]+np.arange(ns)*c['ray_step_mm'];P=C+D[:,None]*t[:,:,None];ix=np.floor((P-bounds[:,0])/s).astype(int);valid=(ix>=0).all(2)&(ix<size).all(2)&(t<=leave[:,None]);ix=np.clip(ix,0,size-1);hit=valid&occ[ix[:,:,0],ix[:,:,1],ix[:,:,2]];has=hit.any(1);first=hit.argmax(1);last=hit.shape[1]-1-hit[:,::-1].argmax(1);a=t[np.arange(len(t)),first];b=t[np.arange(len(t)),last];lo[yy[has],xx[has]]=a[has];hi[yy[has],xx[has]]=b[has];width[yy[has],xx[has]]=b[has]-a[has];starts=hit&~np.pad(hit[:,:-1],((0,0),(1,0)),constant_values=False);segments[yy,xx]=starts.sum(1);touch[yy[has],xx[has]]=(a[has]<=enter[has]+c['ray_step_mm'])|(b[has]>=leave[has]-2*c['ray_step_mm'])
 return dict(depth_min=lo,depth_max=hi,interval_width=width,interval_count=segments,ROI_clipped=touch)

def support_maps(depth,pose,K,poses,frames,obs):
 valid=np.isfinite(depth);y,x=np.nonzero(valid);X=unproject(depth[y,x],pose,np.c_[x,y],K);bits=np.zeros(len(X),np.uint16);counts=np.zeros(len(X),np.uint8)
 for ob in obs:
  uv,z=project(X,poses[ob['frame']],K);q=np.rint(uv).astype(int);inside=(q[:,0]>=0)&(q[:,0]<640)&(q[:,1]>=0)&(q[:,1]<360)&(z>0);q[:,0]=q[:,0].clip(0,639);q[:,1]=q[:,1].clip(0,359);v=inside&ob['positive'][q[:,1],q[:,0]];bits[v]|=np.uint16(1<<ob['frame']);counts+=v
 b=np.zeros(valid.shape,np.uint16);n=np.zeros(valid.shape,np.uint8);b[y,x]=bits;n[y,x]=counts;return b,n

def run(condition,mode,frames,methods,suffix=''):
 c=cfg();cam=np.load(R/('debug_inputs/GT_camera.npz' if condition=='GT' else f'inputs/pred_camera_{condition}.npz'));poses=cam['c2w'];K=cam['K'];plane,record=estimate_background(poses,K,frames);save(f'metrics/background_{mode}_{condition}{suffix}.json',record);obs,gates=frames_data(poses,K,frames,mode=='S0',plane);save(f'metrics/ring_gate_{mode}_{condition}{suffix}.json',gates)
 # S2 only independent self-consistency gate; precise GT-depth agreement tested separately after freeze.
 good=all(g['passed'] for g in gates);lab=cv2.imread(str(R/f'inputs/labels_{c["reference"]:03d}.png'),0);mask=lab==1;color=cv2.imread(str(R/f'inputs/rgb_{c["reference"]:03d}.png'))[:,:,::-1]
 for method in methods:
  tag=f'{mode}_{condition}_{method}{suffix}';t0=time.monotonic()
  if method=='VH2' and not good:save(f'predictions/{tag}_failure.json',{'success':False,'reason':'torus/visible mask intersection gate failed','held_as_failure':True});print(tag,'FAILED ring gate',flush=True);continue
  if method!='VH0' and plane is None:save(f'predictions/{tag}_failure.json',{'success':False,'reason':'no confirmed background free-space plane'});continue
  occ,ps,us,fc=carve(poses,K,obs,method);np.savez_compressed(R/f'predictions/{tag}_volume.npz',feasible=occ,positive_support=ps,unknown_support=us,first_carving_view_plus1=fc,roi_mm=c['roi_mm'],voxel_mm=c['voxel_mm'],view_ids=frames,background_plane=plane if plane is not None else np.full(4,np.nan),semantic='POSSIBLE_OCCUPANCY_NOT_RECOVERED_SOLID')
  dep=raycast(occ,poses[c['reference']],K,mask);bits,counts=support_maps(dep['depth_min'],poses[c['reference']],K,poses,frames,obs);np.savez_compressed(R/f'predictions/{tag}_reference.npz',**dep,valid=np.isfinite(dep['depth_min'])&mask,target_mask=mask,positive_support_view_bits=bits,positive_support_view_count=counts,c2w=poses,K=K,state='VISUAL_HULL_BOUNDARY_CANDIDATE',not_true_surface=True)
  mesh=depth_mesh(dep['depth_min'],mask,poses[c['reference']],K,color);mesh.remove_unreferenced_vertices();mesh.export(R/f'meshes/{tag}_open.obj');edge=(occ[0].any() or occ[-1].any() or occ[:,0].any() or occ[:,-1].any() or occ[:,:,0].any() or occ[:,:,-1].any())
  save(f'predictions/{tag}_status.json',dict(success=bool(np.isfinite(dep['depth_min']).any()),numeric_only=True,run=tag,frames=frames,voxels=int(occ.sum()),feasible_volume_mm3=float(occ.sum()*c['voxel_mm']**3),ROI_touched=bool(edge),valid_pixels=int(np.isfinite(dep['depth_min']).sum()),target_pixels=int(mask.sum()),mesh_vertices=len(mesh.vertices),mesh_faces=len(mesh.faces),runtime_s=time.monotonic()-t0,generated_this_round=True,GT_camera_diagnostic=condition=='GT',GT_complete_silhouette_diagnostic=mode=='S0',background_model=record,ring_gate_passed=good,no_GT_polyp_depth_or_shape=True));print(tag,'voxels',occ.sum(),'pixels',np.isfinite(dep['depth_min']).sum(),'seconds',round(time.monotonic()-t0,2),flush=True)

def main():
 import argparse
 a=argparse.ArgumentParser();a.add_argument('mode',choices=['S0','S1','S2']);a.add_argument('--condition',default='GT');a.add_argument('--local',action='store_true');args=a.parse_args();verify('protocol');verify('inputs');firewall(args.mode);frames=cfg()['local_views'] if args.local else cfg()['training_views'];methods=['VH0'] if args.mode=='S0' else (['VH2'] if args.local else ['VH0','VH1','VH2']);run(args.condition,args.mode,frames,methods,'_local' if args.local else '')
if __name__=='__main__':main()

from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize,TwoSlopeNorm
plt.rcParams.update({'font.size':9,'figure.dpi':140})

def finish(fig,name):fig.savefig(R/'visualizations'/name,dpi=150,bbox_inches='tight',facecolor='white');plt.close(fig)
def crop(scope):
 ll=labels(scope,8);y,x=np.nonzero((ll==1)|(ll==2));return slice(max(y.min()-12,0),min(y.max()+13,360)),slice(max(x.min()-12,0),min(x.max()+13,640))
def pixel(ax,a,box,title,cmap='viridis',norm=None):
 im=ax.imshow(a[box],cmap=cmap,norm=norm);ax.set_title(title,fontsize=9);ax.axis('off');return im

def main():
 verify('evaluation');res=json.loads((R/'metrics/results.json').read_text())['methods'];sets=json.loads((R/'inputs/source_sets.json').read_text());primary=[n for n in res if n.startswith('MVS_') and n.endswith('_F0_S0')];zall=[]
 for n in primary:
  a=np.load(R/f'predictions/{n}.npz');zall.extend(a['depth'][a['valid']])
 if zall:dlo,dhi=float(np.min(zall)),float(np.max(zall))
 else:dlo,dhi=0.,1.
 depthnorm=Normalize(dlo,dhi);errnorm=Normalize(0,20);GT=np.load(V4/'private_gt/008.npz')['depth'];boxs=crop('synth');boxr=crop('real')
 fig,aa=plt.subplots(2,7,figsize=(19,6))
 for row,scope in enumerate(['synth','real']):
  ids=[8]+sets[scope]['E0']+sets[scope]['E1']
  for ax,i in zip(aa[row],ids):ax.imshow(image(scope,i));ax.set_title(f'{scope} '+('ref8' if i==8 else f'source {i}')+(' | E0' if 0<list(aa[row]).index(ax)<4 else ' | E1' if i!=8 else ''));ax.axis('off')
 finish(fig,'fig1_frozen_source_views.png')
 names=['M0_synth_GT_historical','M2_synth_GT_historical','DA3_synth_GT_historical','MVS_synth_GT_E0_r08_F0_S0','MVS_synth_GT_E1_r08_F0_S0'];fig,aa=plt.subplots(3,6,figsize=(17,9));gmask=labels('synth',8)==1;pixel(aa[0,0],np.where(gmask,GT,np.nan),boxs,'GT axial Z mm',norm=depthnorm);pixel(aa[1,0],np.where(gmask,0,np.nan),boxs,'GT error 0',cmap='magma',norm=errnorm);aa[2,0].imshow(image('synth',8)[boxs]);aa[2,0].set_title('Existing Blender RGB');aa[2,0].axis('off')
 for j,name in enumerate(names,1):
  v=res[name];a=np.load(R/f'metrics/{name}_evaluation.npz');p=np.load(R/f'predictions/{name}.npz') if (R/f'predictions/{name}.npz').exists() else __import__('evaluate').competition_inputs()[0][name];pixel(aa[0,j],p['depth'],boxs,name+'\nraw depth; numeric '+f'{100*v["numeric_coverage"]:.1f}%',norm=depthnorm);im=pixel(aa[1,j],a['GT_view_error'],boxs,'GT-view mesh error; faces '+str(v['mesh_faces']),cmap='magma',norm=errnorm);pixel(aa[2,j],a['state'],boxs,'0 unknown / 1 model / 2 screened',cmap='viridis',norm=Normalize(0,2))
 fig.colorbar(im,ax=aa[1].tolist(),fraction=.025,pad=.03,label='mm, >20 saturated; full errors in CSV');finish(fig,'fig2_Blender_competition.png')
 fig,aa=plt.subplots(4,5,figsize=(14,12));realnames=[]
 for row,(cond,exp) in enumerate([('0','E0'),('0','E1'),('1','E0'),('1','E1')]):
  n=f'MVS_real_{cond}_{exp}_r08_F0_S0';realnames.append(n);v=res[n];p=np.load(R/f'predictions/{n}.npz');s=np.load(R/f'predictions/{n[:-2]}S1.npz');a=np.load(R/f'metrics/{n}_evaluation.npz');aa[row,0].imshow(image('real',8)[boxr]);aa[row,0].set_title(f'camera{cond}/{exp}: ref8 raw674');aa[row,0].axis('off');pixel(aa[row,1],labels('real',8),boxr,'visible Mask: 1 Polyp / 2 Ring',norm=Normalize(0,2));im=pixel(aa[row,2],p['depth'],boxr,'raw model axial Z candidate mm',norm=depthnorm);pixel(aa[row,3],s['depth'],boxr,'edge-preserving S1',norm=depthnorm);pixel(aa[row,4],a['state'],boxr,f'numeric {100*v["numeric_coverage"]:.1f}% | screened {v["GEOMETRICALLY_SUPPORTED"]} px',norm=Normalize(0,2))
 fig.colorbar(im,ax=aa[:,2:4].ravel().tolist(),fraction=.018,pad=.02,label='mm candidate; no real depth GT');finish(fig,'fig3_real_depth_validity.png')
 points=[];poses=[]
 for n in realnames:
  p=np.load(R/f'predictions/{n}.npz');y,x=np.nonzero(p['valid']);P=unproject(p['depth'][p['valid']],p['pose'],np.c_[x,y],p['K']);points.append(P);poses.append(p['c2w'][:,:3,3])
 allp=np.concatenate(points+poses+[np.array([[-6.2,-6.2,-.6],[6.2,6.2,.6]])]);lo,hi=allp.min(0),allp.max(0);mid=(lo+hi)/2;span=max(np.ptp(allp,axis=0))*.55;fig=plt.figure(figsize=(14,11));angles=np.linspace(0,2*np.pi,200)
 for j,(n,P,C) in enumerate(zip(realnames,points,poses)):
  ax=fig.add_subplot(2,2,j+1,projection='3d');idx=np.linspace(0,len(P)-1,min(4500,len(P))).astype(int) if len(P) else np.array([],int);ax.scatter(*P[idx].T,s=1,c=P[idx,2] if len(idx) else 'blue',cmap='viridis');ax.plot(5.6*np.cos(angles),5.6*np.sin(angles),np.zeros(len(angles)),'k',lw=2,label='known R10 centerline');ax.plot(*C.T,'r.-',lw=.7,label='frozen candidate cameras');ax.set(xlim=(mid[0]-span,mid[0]+span),ylim=(mid[1]-span,mid[1]+span),zlim=(mid[2]-span,mid[2]+span),xlabel='Ring X mm',ylabel='Ring Y mm',zlabel='Ring Z mm',title=n+'\nMODEL_PREDICTED, no ICP / closure');ax.set_box_aspect([1,1,1]);ax.view_init(25,-60);ax.legend(fontsize=7)
 finish(fig,'fig4_real_Ring_surface_and_cameras.png')
 tag='MVS_synth_GT_E0_r08';eff=np.load(R/f'predictions/{tag}_constraint_effect.npz');fig,aa=plt.subplots(3,3,figsize=(11,10))
 for j,f in enumerate(['F0','F1','F2']):
  n=tag+'_'+f+'_S0';p=np.load(R/f'predictions/{n}.npz');a=np.load(R/f'metrics/{n}_evaluation.npz');v=res[n];pixel(aa[0,j],p['depth'],boxs,f+f' | numeric {100*v["numeric_coverage"]:.1f}%',norm=depthnorm);pixel(aa[1,j],a['raw_axisZ_error'],boxs,'GT raw-depth error; rejected = missing',cmap='magma',norm=errnorm);reject=np.zeros(gmask.shape,bool) if f=='F0' else eff['rejected_'+f];pixel(aa[2,j],reject.astype(float),boxs,'rejected by trusted free-space (red)',cmap='Reds',norm=Normalize(0,1))
 fig.suptitle('VH only rejects; retained depth delta = 0. No hull-boundary clamping.');finish(fig,'fig5_VH_Ring_fusion_effect.png')
 fig,aa=plt.subplots(2,4,figsize=(14,7))
 for row,(scope,cond) in enumerate([('synth','GT'),('real','0')]):
  tag=f'MVS_{scope}_{cond}_E0_r08';p=np.load(R/f'predictions/{tag}_F0_S0.npz');q=np.load(R/f'predictions/{tag}_F0_S1.npz');d=q['depth']-p['depth'];box=boxs if scope=='synth' else boxr;pixel(aa[row,0],p['depth'],box,scope+' S0 original',norm=depthnorm);pixel(aa[row,1],q['depth'],box,'S1 limited edge-preserving smoothing',norm=depthnorm);im=pixel(aa[row,2],d,box,'axial change mm',cmap='coolwarm',norm=TwoSlopeNorm(0,-.25,.25));a=np.load(R/f'metrics/{tag}_F0_S0_evaluation.npz');b=np.load(R/f'metrics/{tag}_F0_S1_evaluation.npz')
  if scope=='synth':pixel(aa[row,3],b['raw_axisZ_error']-a['raw_axisZ_error'],box,'absolute GT error change; blue better',cmap='coolwarm',norm=TwoSlopeNorm(0,-.25,.25))
  else:
   errs0=a['held_reprojection_errors'];errs1=b['held_reprojection_errors'];good=np.isfinite(errs0)&np.isfinite(errs1);aa[row,3].scatter(errs0[good],errs1[good],s=3);m=max(float(np.nanmax(errs0)) if np.isfinite(errs0).any() else 1,float(np.nanmax(errs1)) if np.isfinite(errs1).any() else 1);aa[row,3].plot([0,m],[0,m],'k--');aa[row,3].set(xlabel='S0 held10 reprojection px',ylabel='S1 px',title='real: consistency, not GT accuracy')
 finish(fig,'fig6_smoothing_before_after.png')
 fig,aa=plt.subplots(2,4,figsize=(15,8))
 for ax,n in zip(aa.ravel(),primary):
  p=np.load(R/f'predictions/{n}.npz');v=res[n];scope=v['scope'];box=crop(scope);a=np.load(R/f'metrics/{n}_evaluation.npz');data=a['raw_axisZ_error'] if scope=='synth' else a['state'];pixel(ax,data,box,n+f'\nnum {100*v["numeric_coverage"]:.1f}% | screened {v["GEOMETRICALLY_SUPPORTED"]} px',cmap='magma' if scope=='synth' else 'viridis',norm=errnorm if scope=='synth' else Normalize(0,2))
 finish(fig,'fig7_all_primary_conditions.png');save('metrics/visualization_policy.json',{'all8_primary_conditions_shown':True,'same_real_depth_scale':[dlo,dhi],'absolute_GT_error_scale_mm':[0,20],'out_of_scale_errors_retained_in_tables':True,'no_pretty_result_selection':True});print('VISUALIZATIONS_COMPLETE',flush=True)
if __name__=='__main__':main()

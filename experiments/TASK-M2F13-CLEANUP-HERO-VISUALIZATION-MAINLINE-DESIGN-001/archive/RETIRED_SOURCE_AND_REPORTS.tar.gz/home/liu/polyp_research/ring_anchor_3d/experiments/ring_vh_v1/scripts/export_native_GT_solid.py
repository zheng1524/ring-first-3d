"""Evaluation-only exact Blender BVH parity; no predictions or old files changed."""
import bpy,numpy as np,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parents[1];V=R.parent/'ring_first_v4_synthetic_audit';c=json.loads((R/'config.json').read_text());bpy.ops.wm.open_mainfile(filepath=str(V/'private_gt/models/scene.blend'));o=bpy.data.objects['Ip_original_mesh'];verts=np.array([tuple(o.matrix_world@v.co) for v in o.data.vertices]);faces=[tuple(p.vertices) for p in o.data.polygons];bvh=BVHTree.FromPolygons([Vector(v) for v in verts],faces);axes=[np.arange(a+c['voxel_mm']/2,b,c['voxel_mm']) for a,b in c['roi_mm']];shape=tuple(map(len,axes));X=np.stack(np.meshgrid(*axes,indexing='ij'),-1).reshape(-1,3);G=np.load(V/'private_gt/scene.npz')['c2w'];out={};rotations={};direction=Vector((.263,.437,.86));direction.normalize()
for condition in ['GT','0','1']:
 U=np.eye(3)
 if condition!='GT':
  P=np.load(R/f'inputs/pred_camera_{condition}.npz')['c2w'];best=None
  for H in [np.eye(3),np.diag([1.,-1,-1])]:
   S=sum(G[i,:3,:3]@(H@P[i,:3,:3]).T for i in range(16));a=np.arctan2(S[1,0]-S[0,1],S[0,0]+S[1,1]);cc,ss=np.cos(a),np.sin(a);Q=np.array([[cc,-ss,0],[ss,cc,0],[0,0,1]])@H;err=np.mean([np.arccos(np.clip((np.trace(G[i,:3,:3].T@Q@P[i,:3,:3])-1)/2,-1,1)) for i in range(16)])
   if best is None or err<best[0]:best=(err,Q)
  U=best[1]
 points=X@U.T;ids=np.flatnonzero(((points>=verts.min(0))&(points<=verts.max(0))).all(1));inside=np.zeros(len(X),bool)
 for j in ids:
  origin=Vector(points[j]);n=0
  for _ in range(32):
   hit,normal,idx,dist=bvh.ray_cast(origin,direction,2000.)
   if hit is None:break
   n+=1;origin=hit+direction*1e-4
  inside[j]=n%2==1
 out['solid_'+condition]=inside.reshape(shape);out['U_'+condition]=U;rotations[condition]={'GT_solid_voxels':int(inside.sum()),'volume_mm3':float(inside.sum()*c['voxel_mm']**3),'tested_bbox_voxels':len(ids),'global_ring_symmetry_rotation':U.tolist()};print('EXACT_NATIVE_GT_SOLID',condition,rotations[condition],flush=True)
np.savez_compressed(R/'evaluation/GT_native_solids.npz',**out);(R/'evaluation/native_solid_method.json').write_text(json.dumps({'method':'Blender BVHTree.FromPolygons exactly as original GT generator; odd-intersection parity, fixed generic ray, 0.0001mm advance','evaluation_only':True,'source_mesh_not_modified':True,'conditions':rotations},indent=2))

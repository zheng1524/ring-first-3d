"""S0 correctness control: complete, uncropped silhouette implies outside-FOV exclusion.
The prior S0 conservative off-image UNKNOWN variant is preserved, not replaced.
No GT depth/shape, GT-error tuning, or changes to formal S1/S2 predictions.
"""
from common import *
from solve import raycast,support_maps,frames_data,estimate_background
import time
import trimesh

def main():
 verify('protocol');verify('inputs');verify('predictions');freeze('strict_S0_protocol',[Path(__file__),R/'config.json']);firewall('S0');tag='S0_GT_VH0_strict_complete';assert not (R/f'predictions/{tag}_volume.npz').exists();t0=time.monotonic();c=cfg();cam=np.load(R/'debug_inputs/GT_camera.npz');poses=cam['c2w'];K=cam['K'];frames=c['training_views'];plane,bg=estimate_background(poses,K,frames);obs,gates=frames_data(poses,K,frames,True,plane);v=np.load(R/'predictions/S0_GT_VH0_volume.npz');occ=v['feasible'].copy();X=grid_points(axes());keep=occ.ravel()
 for ob in obs:
  uv,z=project(X,poses[ob['frame']],K);ij=np.rint(uv).astype(int);inside=(ij[:,0]>=0)&(ij[:,0]<640)&(ij[:,1]>=0)&(ij[:,1]<360)&(z>0);keep&=inside
 occ=keep.reshape(occ.shape);lab=cv2.imread(str(R/'inputs/labels_008.png'),0);mask=lab==1;dep=raycast(occ,poses[8],K,mask);bits,counts=support_maps(dep['depth_min'],poses[8],K,poses,frames,obs);np.savez_compressed(R/f'predictions/{tag}_volume.npz',feasible=occ,positive_support=v['positive_support'],unknown_support=v['unknown_support'],roi_mm=c['roi_mm'],voxel_mm=c['voxel_mm'],view_ids=frames,background_plane=plane,semantic='COMPLETE_SILHOUETTE_CONE_CONTROL');np.savez_compressed(R/f'predictions/{tag}_reference.npz',**dep,valid=np.isfinite(dep['depth_min'])&mask,target_mask=mask,positive_support_view_bits=bits,positive_support_view_count=counts,c2w=poses,K=K,state='VISUAL_HULL_BOUNDARY_CANDIDATE',not_true_surface=True)
 color=cv2.imread(str(R/'inputs/rgb_008.png'))[:,:,::-1];m=depth_mesh(dep['depth_min'],mask,poses[8],K,color);m.remove_unreferenced_vertices();m.export(R/f'meshes/{tag}_open.obj');save(f'predictions/{tag}_status.json',dict(success=bool(np.isfinite(dep['depth_min']).any()),numeric_only=True,run=tag,frames=frames,voxels=int(occ.sum()),feasible_volume_mm3=float(occ.sum()*c['voxel_mm']**3),ROI_touched=bool(occ[0].any() or occ[-1].any() or occ[:,0].any() or occ[:,-1].any() or occ[:,:,0].any() or occ[:,:,-1].any()),valid_pixels=int(np.isfinite(dep['depth_min']).sum()),target_pixels=int(mask.sum()),mesh_vertices=len(m.vertices),mesh_faces=len(m.faces),runtime_s=time.monotonic()-t0,generated_this_round=True,GT_camera_diagnostic=True,GT_complete_silhouette_diagnostic=True,no_GT_polyp_depth_or_shape=True,controlled_change='outside-image cone exclusion for complete uncropped S0 only; no formal-method changes',background_model=bg));freeze('strict_S0_predictions',list((R/'predictions').glob(tag+'*'))+[R/f'meshes/{tag}_open.obj']);print('STRICT_COMPLETE_S0_FROZEN',flush=True)
if __name__=='__main__':main()

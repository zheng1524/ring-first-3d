1. `PYTHONPATH=adapters:code python code/reproduce_offline.py`
2. `PYTHONPATH=adapters:code python -m unittest discover -s tests`
3. `python code/replay_historical.py` (needs the historical 020 artifacts on the workstation; not in this package)

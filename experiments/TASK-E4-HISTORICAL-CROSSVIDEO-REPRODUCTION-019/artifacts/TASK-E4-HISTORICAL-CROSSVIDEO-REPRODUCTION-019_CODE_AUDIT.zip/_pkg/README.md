# CODE AUDIT — TASK-E4-HISTORICAL-CROSSVIDEO-REPRODUCTION-019
Level 1: `PYTHONPATH=adapters:code python code/reproduce_offline.py` → theta 47.667, median 7.52, inlier3 0.2095.
Tests: `PYTHONPATH=adapters:code python -m unittest discover -s tests` → 7/7.
